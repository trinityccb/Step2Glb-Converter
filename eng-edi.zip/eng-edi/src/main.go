// stp2glb-lite -- lightweight STEP to GLB converter.
// A fully self-contained STEP parser and tessellation kernel; no heavy geometry
// libraries such as OpenCASCADE.
package main

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"stp2glb-lite/internal/console"
	"stp2glb-lite/internal/glb"
	"stp2glb-lite/internal/logx"
	"stp2glb-lite/internal/step"
)

const version = "1.8.3"

type options struct {
	input    string
	outDir   string
	name     string
	tol      float64
	tolRatio float64
	// tolSet records that a tolerance-related option was given explicitly by the
	// user. The default tolRatio=0.0015 does not count, otherwise the automatic
	// retry of the "size ratio guard" would never trigger.
	tolSet    bool
	maxDepth  int
	logDir    string
	noNormals bool
	noOutline bool
	// When outlineAngle > 0 only edges whose dihedral angle is at least this value
	// are drawn (drops the soft edges where fillets are tangent to flat faces).
	outlineAngle float64
	// angTol is the maximum angular tolerance per curve segment, in degrees. Chord
	// tolerance scales with the model, so on a large assembly it can reach a few
	// millimeters and a small hole (6-10 mm) can no longer be subdivided -- the
	// round hole degenerates into a diamond.
	// The angular criterion is scale independent; <=0 disables it (chord tolerance
	// only, not recommended).
	angTol  float64
	fast    bool
	precise bool
	flat    bool
	// singleSided disables the double-sided material. The default is double-sided:
	// most automotive STEP files are **surface models** (OPEN_SHELL /
	// SHELL_BASED_SURFACE_MODEL, zero thickness), and glTF viewers in the browser
	// render single-sided by spec (three.js FrontSide), so those faces are culled
	// when seen from behind and a whole region turns from solid to hollow, leaving
	// only the outline. CATIA and desktop viewers always show both sides, so the
	// same GLB looks correct on the desktop but hollow in the browser.
	singleSided bool
	quiet       bool
	verbose     bool
	inspect     bool
	usage       bool
	diag        bool
	ver         bool
	historyN    int
	doHistory   bool
	workers     int
}

func main() {
	// The purpose of console initialization is to make console output display
	// correctly in any terminal. A real console switches to the WriteConsole
	// (Unicode) path; pipes and redirected output stay UTF-8.
	console.Init()
	code := run(os.Args[1:])
	console.Restore()
	os.Exit(code)
}

func run(args []string) int {
	opt, err := parseArgs(args)
	if err != nil {
		console.Err("argument error: " + err.Error())
		console.Err(usageText())
		return 1
	}
	if opt.ver {
		console.Outf("stp2glb-lite %s  (%s/%s, self-contained geometry kernel, no OpenCASCADE)",
			version, runtime.GOOS, runtime.GOARCH)
		return 0
	}
	if opt.doHistory {
		return showHistory(opt.historyN)
	}
	if opt.usage {
		console.Out(usageText())
		return 0
	}
	if opt.diag {
		return showEncoding()
	}

	// No arguments: enter interactive mode so a double-clicked window does not
	// flash and disappear
	if opt.input == "" {
		got, ok := interactive()
		if !ok {
			return 1
		}
		opt.input = got.input
		opt.outDir = got.outDir
		defer pauseAtEnd()
	}

	log, err := logx.New(opt.logDir, opt.quiet, opt.verbose)
	if err != nil {
		console.Err("cannot initialize log: " + err.Error())
	}
	defer log.Close()

	return convert(opt, log)
}

type paths struct{ input, outDir string }

// interactive collects the paths from prompts when no arguments are given.
func interactive() (paths, bool) {
	rd := bufio.NewReader(os.Stdin)
	console.Out("")
	console.Out(strings.Repeat("-", 66))
	console.Out("  stp2glb-lite -- interactive mode (drag a .stp/.step file into this window to get its path)")
	console.Out(strings.Repeat("-", 66))

	var input string
	for i := 1; i <= 3; i++ {
		console.OutRaw("  1) Input .stp/.step file path (press Enter to cancel): ")
		line, _ := rd.ReadString('\n')
		line = cleanPath(line)
		if line == "" {
			console.Out("  Cancelled.")
			return paths{}, false
		}
		abs, err := filepath.Abs(line)
		if err == nil {
			if st, e2 := os.Stat(abs); e2 == nil && !st.IsDir() {
				input = abs
				break
			}
		}
		console.Outf("  File not found: %s (attempt %d/3)", line, i)
		if i == 3 {
			return paths{}, false
		}
	}
	def := filepath.Join(filepath.Dir(input), "glb_output")
	console.OutRaw(fmt.Sprintf("  2) Output folder (press Enter for the default %s): ", def))
	line, _ := rd.ReadString('\n')
	line = cleanPath(line)
	outDir := def
	if line != "" {
		if abs, err := filepath.Abs(line); err == nil {
			outDir = abs
		}
	}
	return paths{input: input, outDir: outDir}, true
}

func cleanPath(s string) string {
	s = strings.TrimSpace(s)
	s = strings.Trim(s, "\"")
	s = strings.Trim(s, "'")
	return strings.TrimSpace(s)
}

// pauseAtEnd keeps a double-clicked window from closing instantly.
func pauseAtEnd() {
	console.Out("")
	console.OutRaw("  Press Enter to exit...")
	_, _ = bufio.NewReader(os.Stdin).ReadString('\n')
}

func convert(opt options, log *logx.Logger) int {
	tAll := time.Now()

	inAbs, err := filepath.Abs(opt.input)
	if err != nil {
		log.Error("cannot resolve input path: %v", err)
		return 2
	}
	st, err := os.Stat(inAbs)
	if err != nil || st.IsDir() {
		log.Error("input file does not exist or is not a regular file: %s", inAbs)
		return 2
	}
	if st.Size() == 0 {
		log.Error("input file is empty")
		return 2
	}

	outDir := opt.outDir
	if outDir == "" {
		outDir = filepath.Join(filepath.Dir(inAbs), "glb_output")
	}
	outAbs, _ := filepath.Abs(outDir)
	if err := os.MkdirAll(outAbs, 0o755); err != nil {
		log.Error("cannot create output directory: %v", err)
		return 1
	}
	base := opt.name
	if base == "" {
		base = strings.TrimSuffix(filepath.Base(inAbs), filepath.Ext(inAbs))
	}
	base = strings.TrimSuffix(base, ".glb")
	finalPath := filepath.Join(outAbs, base+".glb")

	log.Plain("")
	log.Info("Input    : %s  (%.1f MB)", inAbs, float64(st.Size())/1048576)
	log.Info("Output   : %s", finalPath)
	if log.Dir != "" {
		log.Info("Log dir  : %s", log.Dir)
	}

	// --- 1) Read ---
	t := time.Now()
	data, err := os.ReadFile(inAbs)
	if err != nil {
		log.Error("read failed: %v", err)
		return 2
	}
	log.Info("Read     : %.1f MB in %.2fs", float64(len(data))/1048576, time.Since(t).Seconds())

	// --- 2) Parse ---
	t = time.Now()
	file, err := step.Parse(data)
	if err != nil {
		log.Error("STEP parse failed: %v", err)
		return 3
	}
	data = nil
	log.Info("Parsed   : %s entities (schema: %s) in %.2fs",
		comma(len(file.Entities)), file.Schema, time.Since(t).Seconds())
	if len(file.Entities) == 0 {
		log.Error("no entities could be parsed from the file; it may not be a STEP file")
		return 3
	}

	// --- 3) Structure planning: assembly expansion + true bounding box ---
	// Tolerance must be based on the "true bounding box in assembly coordinates".
	// Raw part coordinates can sit far from the origin (common in weld fixture
	// assemblies); deriving the tolerance from the raw vertex bounding box would be
	// absurdly coarse.
	t = time.Now()
	geom := step.NewGeom(file)
	plan := geom.PlanAssembly()
	bbMin, bbMax := plan.Min, plan.Max
	diag := bbMax.Sub(bbMin).Len()
	log.Info("Assembly : %s shapes / %s instances%s in %.2fs",
		comma(plan.Asm.Nodes), comma(plan.Asm.Instances), asmNote(plan.Asm.HasRel), time.Since(t).Seconds())
	if tr := plan.Tree; tr != nil && len(tr.Nodes) > 0 {
		root := ""
		if tr.Root >= 0 {
			root = nodeLabel(&tr.Nodes[tr.Root])
		}
		log.Info("Asm tree : %s nodes / depth %d / %s leaves (root: %s)",
			comma(len(tr.Nodes)), tr.Depth(), comma(tr.LeafCount()), root)
		if n := tr.NoNameCount(); n > 0 {
			log.Warn("Asm tree : %s nodes have no product name, no instance name and no "+
				"description in the STEP file, so the kernel fallback name shape_NNNN is "+
				"shown (missing information in the source, not a conversion error)", comma(n))
		}
		if os.Getenv("STP2GLB_DBG_TREE") != "" {
			for _, ln := range tr.Lines(200) {
				log.Plain("    " + ln)
			}
		}
		if os.Getenv("STP2GLB_DBG_NAMES") != "" {
			log.Plain("    [names] the displayed node name always equals prod (the STEP " +
				"product name); inst/part are names from the assembly relations, for comparison only")
			// Limit 0 = everything; naming problems usually show up on individual
			// branches, and truncating them would hide those.
			for _, ln := range tr.NameDebug(0) {
				log.Plain("    " + ln)
			}
		}
	}
	log.Info("BBox     : (%.1f, %.1f, %.1f) ~ (%.1f, %.1f, %.1f), diagonal %.1f",
		bbMin.X, bbMin.Y, bbMin.Z, bbMax.X, bbMax.Y, bbMax.Z, diag)
	if rawDiag := plan.RawMax.Sub(plan.RawMin).Len(); rawDiag > diag*2 {
		log.Info("(raw vertex bbox diagonal %.0f, reduced to %.0f by the assembly transforms; tolerance is computed from the latter)",
			rawDiag, diag)
	}

	tol := opt.tol
	if tol <= 0 {
		ratio := opt.tolRatio
		if ratio <= 0 {
			ratio = 0.0015
		}
		tol = diag * ratio
		if tol <= 0 {
			tol = 0.01
		}
	}
	if opt.fast {
		tol = diag * 0.006
	}
	if opt.precise {
		tol = diag * 0.0004
	}
	log.Info("Chord tol: %.5f (%.4f%% of the model diagonal)", tol, tol/diag*100)
	// Angular tolerance is independent of model scale. With chord tolerance alone a
	// 6 mm hole in a two-meter assembly keeps only 3-6 points because the chord
	// always passes -- that is exactly why round holes turn into diamonds.
	ang := opt.angTol * math.Pi / 180
	if opt.angTol > 0 {
		log.Info("Ang tol  : <= %.0f deg per segment (at least 12 segments per circle, 16 after bisection)", opt.angTol)
	} else {
		log.Info("Ang tol  : disabled (chord tolerance only, round holes may be drawn as polygons)")
	}
	sampleOpts := step.SampleOpts{Tol: tol, Ang: ang}

	// When the user pinned the tolerance explicitly, the size ratio guard below no
	// longer changes it on its own.
	tolPinned := opt.tolSet

	// --- 4) Extract faces ---
	t = time.Now()
	faces, est := plan.Extract(sampleOpts)
	log.Info("Faces    : %s (unique %s, shells %s, assembly nodes %s/%s instances%s) in %.2fs",
		comma(est.FaceInstances), comma(est.FacesTotal), comma(est.Shells),
		comma(est.AssemblyNodes), comma(est.AssemblyInstances),
		asmNote(est.HasAssembly), time.Since(t).Seconds())
	if est.ReusedShapes > 0 {
		log.Info("Reused   : %s parts are referenced more than once, %s extra instances in total (geometry is emitted per instance)",
			comma(est.ReusedShapes), comma(est.ExtraInstances))
	}
	if est.BorrowedShapes > 0 {
		log.Info("Pairing  : %s assembly nodes are bare frames and borrowed geometry from a "+
			"sibling representation (otherwise no geometry at all would be emitted for "+
			"those parts)", comma(est.BorrowedShapes))
	}
	if est.AltReprs > 0 {
		log.Info("Dup repr : dropped %s sibling geometry representations fully enclosed by the "+
			"primary bounding box (another encoding of the same part; emitting both would "+
			"only overlap: %s faces in total)",
			comma(est.AltReprs), comma(est.SupersededFaces))
	}
	if est.AltKeptReprs > 0 {
		log.Warn("Sibling  : %s sibling representations could not be proven duplicate (bounding "+
			"box or surface set does not match); kept on the \"rather overlap than lose\" "+
			"principle, adding %s faces",
			comma(est.AltKeptReprs), comma(est.AltKeptFaces))
	}
	if est.DuplicateShapes > 0 {
		log.Warn("Redundant: removed %s duplicate shape representations identical to the "+
			"assembled geometry (they take no part in the assembly; emitting them would print "+
			"another copy of the model at the raw coordinates)", comma(est.DuplicateShapes))
	}
	if est.DetachedShapes > 0 {
		log.Warn("Loose    : %s shape representations are not in the assembly tree and were emitted at their raw coordinates", comma(est.DetachedShapes))
	}
	if est.OrphanFaces > 0 {
		log.Warn("%s faces are not referenced by any shape representation and were emitted with the identity transform (the assembly structure may be incomplete)",
			comma(est.OrphanFaces))
	}
	if len(faces) == 0 {
		log.Error("no faces available for tessellation (the file may be a pure wireframe/curve model)")
		return 3
	}

	if opt.inspect {
		printInspect(geom, file, faces, est, diag, log)
		return 0
	}

	// --- 5) Tessellate ---
	t = time.Now()
	worker := opt.workers
	if worker <= 0 {
		worker = runtime.NumCPU()
	}
	// tessOpts builds the tessellation options. depth is passed separately because
	// the size ratio guard needs to shrink the mesh without changing the tolerance
	// (see phase B below).
	tessOpts := func(tl float64, depth int) step.TessOpts {
		return step.TessOpts{
			Tol:        tl,
			MaxDepth:   depth,
			MaxLoopPts: 6000,
			MaxPerFace: 500000,
		}
	}

	// outlineOpts builds the outline options. The tolerance matches tessellation --
	// with separate tolerances the lines drift away from the faces (faces subdivided
	// at 0.02 and lines at 0.5 differ visibly where curvature is high).
	outlineOpts := func(tl float64) step.OutlineOpts {
		return step.OutlineOpts{
			Tol:         tl,
			Ang:         ang,
			Angle:       opt.outlineAngle,
			MaxSegments: 8000000,
		}
	}
	outEnabled := !opt.noOutline
	var outAgg step.OutlineStats

	gen := fmt.Sprintf("stp2glb-lite %s (self-contained kernel)", version)

	// Actual size written to the GLB. This may differ from the "Asm tree" line
	// above -- empty shell nodes without geometry are pruned on output (see the
	// comment in buildPartDocument). Reported explicitly here so nobody reading the
	// log thinks the tree statistics are wrong.
	var glbNodes, glbMeshes, glbEmpty int

	// buildTree groups faces by part, tessellates them in parallel and assembles a
	// GLB with a node tree.
	//
	// Faces are no longer flattened into one big mesh: a part instanced N times
	// keeps **one** copy of its geometry (vertices baked with the transform of the
	// part's first instance) and the remaining instances are handled by glTF node
	// matrices. The node hierarchy comes straight from the STEP assembly relations
	// and matches the CATIA assembly tree.
	//
	// Measured benefit (72 MB body-in-white assembly, same tolerance 3.69353):
	//   flat 16.9 MB / 518,064 triangles  ->  node tree 6.0 MB / 221,024 triangles
	//   (static data)
	// Both have **bit-identical triangle counts and surface areas once expanded to
	// world coordinates** -- only the duplicated storage is gone.
	buildTree := func(fs []*step.FaceGeom, tl float64, depth int) ([]byte, step.TessStats, int, int) {
		partBase := plan.PartBase()
		seen := make(map[int]bool, len(fs))
		partFaces := make(map[int][]*step.FaceGeom, 256)
		order := make([]int, 0, 256)
		for _, f := range fs {
			if seen[f.ID] {
				// faces of the 2nd..Nth instance of the same part: the first copy
				// already represents the geometry
				continue
			}
			seen[f.ID] = true
			if b, ok := partBase[f.Group]; ok {
				f.Xform = b
			}
			if _, ok := partFaces[f.Group]; !ok {
				order = append(order, f.Group)
			}
			partFaces[f.Group] = append(partFaces[f.Group], f)
		}

		opts := tessOpts(tl, depth)
		meshes := make([]*step.Mesh, len(order))
		stats := make([]step.TessStats, len(order))
		outs := make([]step.OutlineStats, len(order))
		sem := make(chan struct{}, worker)
		var wg sync.WaitGroup
		for i, g := range order {
			wg.Add(1)
			go func(i int, gf []*step.FaceGeom) {
				defer wg.Done()
				sem <- struct{}{}
				defer func() { <-sem }()
				meshes[i], stats[i] = step.Tessellate(gf, opts)
				// Outlines are computed in the same goroutine to save one dispatch;
				// every part is independent, there is no shared state.
				if outEnabled && len(meshes[i].Indices) >= 3 {
					lp, li, os := geom.BuildOutline(gf, outlineOpts(tl))
					meshes[i].LinePositions = lp
					meshes[i].LineIndices = li
					outs[i] = os
				}
			}(i, partFaces[g])
		}
		wg.Wait()
		outAgg = step.OutlineStats{}
		for i := range outs {
			outAgg.Add(outs[i])
		}

		total := step.TessStats{
			BySurface:        map[string]int{},
			FailedByType:     map[string]int{},
			DegradedByReason: map[string]int{},
			FaceReason:       map[int]string{},
		}
		tri, verts := 0, 0
		for i := range stats {
			mergeTessStats(&total, &stats[i])
			tri += len(meshes[i].Indices) / 3
			verts += len(meshes[i].Positions) / 3
		}

		doc := buildPartDocument(plan, order, meshes, partBase, gen)
		doc.SingleSided = opt.singleSided
		glbNodes, glbEmpty = len(doc.Nodes), 0
		glbMeshes = 0
		for i := range doc.Meshes {
			if len(doc.Meshes[i].Indices) >= 3 && len(doc.Meshes[i].Positions) >= 9 {
				glbMeshes++
			}
		}
		if tr := plan.Tree; tr != nil && len(doc.Nodes) < len(tr.Nodes) {
			glbEmpty = len(tr.Nodes) - len(doc.Nodes)
		}
		buf, err := glb.Encode(doc)
		if err != nil {
			log.Error("GLB encoding failed: %v", err)
			return nil, total, tri, verts
		}
		return buf, total, tri, verts
	}

	// buildFlat is the behavior before the refactor: no instancing, the faces of
	// every instance are baked into the same mesh. Kept only as a fallback (--flat)
	// in case some viewer does not honor node matrices.
	buildFlat := func(fs []*step.FaceGeom, tl float64, depth int) ([]byte, step.TessStats, int, int) {
		mesh, st := tessellateByShell(fs, tessOpts(tl, depth), worker)
		tri, verts := len(mesh.Indices)/3, len(mesh.Positions)/3
		outAgg = step.OutlineStats{}
		if outEnabled && tri > 0 {
			// After flattening, faces of all instances are mixed together;
			// BuildOutline dedups by (pose, edge) internally, so different instances
			// of the same part each get their own lines, consistent with the vertex
			// baking.
			lp, li, os := geom.BuildOutline(fs, outlineOpts(tl))
			mesh.LinePositions = lp
			mesh.LineIndices = li
			outAgg = os
		}
		doc := &glb.Document{Generator: gen}
		doc.SingleSided = opt.singleSided
		doc.Meshes = []glb.Mesh{{
			Positions: mesh.Positions, Normals: mesh.Normals,
			Indices: mesh.Indices, Name: base,
			LinePositions: mesh.LinePositions, LineIndices: mesh.LineIndices,
		}}
		doc.Nodes = []glb.Node{{Mesh: 0, Name: base}}
		doc.Roots = []int{0}
		buf, err := glb.Encode(doc)
		if err != nil {
			log.Error("GLB encoding failed: %v", err)
			return nil, st, tri, verts
		}
		return buf, st, tri, verts
	}

	buildDoc := buildTree
	if opt.flat {
		buildDoc = buildFlat
		log.Info("Format   : --flat enabled, geometry is flattened per instance into a single mesh (no node tree)")
	}

	out, ts, triCount, vertCount := buildDoc(faces, tol, opt.maxDepth)
	if opt.flat {
		log.Info("GLB      : flat output, 1 mesh under 1 node")
	} else if glbNodes > 0 {
		extra := ""
		if glbEmpty > 0 {
			extra = fmt.Sprintf("; %s geometry-less empty nodes pruned", comma(glbEmpty))
		}
		log.Info("GLB      : %s nodes / %s meshes (one geometry per part, the rest restored by node matrices)%s",
			comma(glbNodes), comma(glbMeshes), extra)
	}
	log.Info("Tess     : %s faces ok, %s failed, %s degraded in %.2fs",
		comma(ts.FacesOK), comma(ts.FacesFailed), comma(ts.FacesDegraded), time.Since(t).Seconds())
	if outEnabled {
		note := ""
		if opt.outlineAngle > 0 {
			note = fmt.Sprintf("; dihedral >= %g deg filtered out %s edges", opt.outlineAngle, comma(outAgg.Filtered))
		}
		if outAgg.Degenerate > 0 {
			note += fmt.Sprintf("; %s degenerate samples skipped", comma(outAgg.Degenerate))
		}
		if outAgg.Truncated {
			note += "; * segment limit reached, output truncated (use --no-outline or a looser tolerance)"
		}
		log.Info("Outline  : %s B-Rep edges -> %s segments / %s points%s",
			comma(outAgg.Kept), comma(outAgg.Segments), comma(outAgg.Points), note)
	} else {
		log.Info("Outline  : disabled by --no-outline")
	}
	if ts.FacesFailed > 0 {
		log.Warn("failed faces by type: %s", topFailures(ts.FailedByType))
	}
	if (ts.FacesFailed > 0 || ts.FacesDegraded > 0) && len(ts.DegradedByReason) > 0 {
		log.Info("degraded/failed reasons: %s", topFailures(ts.DegradedByReason))
	}
	if os.Getenv("STP2GLB_DBG_PHASE") != "" {
		pr, gr, ea, sb, pl := step.PhaseTimes()
		g, e, pf := step.PathCounts()
		log.Info("Phases   : project %v / grid %v / ear clipping %v / subdivision emit %v / flat fallback %v",
			pr.Round(time.Millisecond), gr.Round(time.Millisecond), ea.Round(time.Millisecond),
			sb.Round(time.Millisecond), pl.Round(time.Millisecond))
		log.Info("Paths    : grid %s faces / ear clipping %s faces / flat fallback %s faces", comma(g), comma(e), comma(pf))
	}
	if n := step.EarAnomalyCount(); n > 0 {
		log.Warn("Accuracy : %s faces with holes have an ear clipping area inconsistent with "+
			"\"outer loop minus holes\" (deviation >2%%); these regions may contain a few "+
			"overlapping or missing triangles (set STP2GLB_DBG_EAR=1 to list face ids)", comma(n))
	}
	if triCount == 0 {
		log.Error("tessellation produced no triangles")
		return 3
	}

	// --- 6) Write ---
	t = time.Now()

	// --- 6b) Size ratio guard ---
	// Goal: the GLB must be **clearly** smaller than the source STEP. When a small
	// part (a few dozen KB of STP) is tessellated into a high-precision mesh at the
	// default tolerance, the index and normal bytes can exceed the ASCII text of the
	// source file, so the mesh is shrunk and rebuilt automatically here.
	//
	// The trigger is 90% of the source file rather than 100%: this program is a
	// "lightweight converter", and a GLB at 98% of the source is not lightweight.
	// More importantly, 100% is a **knife edge** -- after the periodic curve arc
	// length was fixed, the first pass of `ZZ-QBE-RF010-JG01-17.stp` went from
	// "slightly above the source" to 98.5%, the guard stopped stepping in and the
	// GLB grew from 5.9 MB to 20.0 MB. 90% leaves margin for this policy and rarely
	// misfires in practice: in a library of 90 real parts **only that one** had a
	// first-pass ratio above 90%, all others were <= 83.8%. Large models are far
	// below the source on the first pass and never enter this branch, so it costs
	// nothing.
	budget := st.Size() * 9 / 10
	if !tolPinned && int64(len(out)) >= budget && triCount >= 32 {
		bestLen := len(out)
		// Phase A: increase the tolerance step by step. Most effective on large
		// parts and leaves the subdivision depth alone.
		for _, k := range []float64{2, 4, 8, 16} {
			nt := tol * k
			f2, _ := plan.Extract(step.SampleOpts{Tol: nt, Ang: ang}) // reuse the same structure plan, do not re-run assembly expansion
			if len(f2) == 0 {
				continue
			}
			o2, ts2, tri2, v2 := buildDoc(f2, nt, opt.maxDepth)
			if o2 == nil || tri2 == 0 {
				continue
			}
			if len(o2) < bestLen {
				bestLen = len(o2)
				ts, triCount, vertCount, out = ts2, tri2, v2, o2
				log.Info("Ratio    : tolerance raised to %.5f (x%g), GLB down to %.1f KB (source %.1f KB)",
					nt, k, float64(len(o2))/1024, float64(st.Size())/1024)
			}
			if int64(len(o2)) < budget {
				break
			}
		}
		// Phase B: when loosening the tolerance is still not enough, lower the
		// subdivision depth step by step.
		//
		// Why this stage is required: the effective tolerance of each face is
		//     faceTol = min(global tolerance, face size * 0.05)
		// (see tessFace in tess.go; the cap keeps the coarse tolerance of a large
		// assembly from blurring small faces into one blob). So for faces where
		// "face size < global tolerance / 0.05" the global tolerance has **no effect
		// at all**. Worse, the choice of mesh path itself depends on the tolerance:
		// a looser tolerance lets thinLines merge grid lines and pushes some faces
		// from the "structured grid" path back to "ear clipping + subdivision", which
		// costs more triangles. Measured on a 7.2 MB assembly: after tolerance x16
		// the triangle count went up instead of down (417,929 -> 824,495), so phase A
		// failed completely, while subdivision depth 6 -> 3 reliably dropped it to
		// 142,415 triangles. Only lowering the depth truly shrinks the mesh there.
		//
		// Try maxDepth-1 downwards and take the first depth that fits the budget
		// (90% of the source file), which is the smallest change.
		if int64(bestLen) >= budget {
			for d := opt.maxDepth - 1; d >= 1; d-- {
				o2, ts2, tri2, v2 := buildDoc(faces, tol, d)
				if o2 == nil || tri2 == 0 {
					continue
				}
				if len(o2) < bestLen {
					bestLen = len(o2)
					ts, triCount, vertCount, out = ts2, tri2, v2, o2
					log.Info("Ratio    : subdivision depth lowered to %d, GLB down to %.1f KB (source %.1f KB)",
						d, float64(len(o2))/1024, float64(st.Size())/1024)
				}
				if int64(len(o2)) < budget {
					break
				}
			}
		}
		// If neither stage fits the budget, fall back to the result with the fewest
		// triangles and report it honestly, but never silently write a GLB larger
		// than the budget.
		if int64(bestLen) >= budget {
			log.Warn("Ratio    : after loosening the tolerance and lowering the subdivision depth, "+
				"the GLB is still above 90%% of the source (%.1f MB vs %.1f MB). The source may be "+
				"an extremely small curve/wireframe model, or the part may have far more faces "+
				"than its text size suggests. Pass --max-depth explicitly for a smaller mesh",
				float64(bestLen)/1048576, float64(st.Size())/1048576)
		}
	}

	tmp := finalPath + ".tmp"
	if err := os.WriteFile(tmp, out, 0o644); err != nil {
		log.Error("write failed: %v", err)
		return 4
	}
	if err := os.Rename(tmp, finalPath); err != nil {
		os.Remove(tmp)
		log.Error("rename failed: %v", err)
		return 4
	}
	log.Info("Written  : %.1f MB in %.2fs", float64(len(out))/1048576, time.Since(t).Seconds())

	// --- 7) Summary ---
	ratio := float64(len(out)) / float64(st.Size())
	log.Plain("")
	log.Plain(strings.Repeat("=", 66))
	log.Plain("  Conversion result")
	log.Plain(strings.Repeat("-", 66))
	log.Plain(fmt.Sprintf("  Input    : %s  (%.1f MB)", filepath.Base(inAbs), float64(st.Size())/1048576))
	log.Plain(fmt.Sprintf("  Output   : %s  (%.1f MB)", filepath.Base(finalPath), float64(len(out))/1048576))
	log.Plain(fmt.Sprintf("  Ratio    : %.1f%%  %s", ratio*100, ratioNote(ratio)))
	log.Plain(fmt.Sprintf("  Faces    : ok %s / failed %s / degraded %s (total %s)",
		comma(ts.FacesOK), comma(ts.FacesFailed), comma(ts.FacesDegraded), comma(ts.FacesTotal)))
	log.Plain(fmt.Sprintf("  Triangles: %s", comma(triCount)))
	log.Plain(fmt.Sprintf("  Vertices : %s", comma(vertCount)))
	log.Plain(fmt.Sprintf("  Elapsed  : %.2fs", time.Since(tAll).Seconds()))
	log.Plain(strings.Repeat("=", 66))
	log.Plain("")

	status := "ok"
	if ts.FacesFailed > 0 {
		status = "partial"
	}
	log.AppendHistory(logx.HistoryEntry{
		TS:         time.Now().Format("2006-01-02 15:04:05"),
		Input:      inAbs,
		Output:     finalPath,
		InputBytes: st.Size(),
		OutBytes:   int64(len(out)),
		Ratio:      ratio,
		Triangles:  triCount,
		Vertices:   vertCount,
		FacesOK:    ts.FacesOK,
		FacesFail:  ts.FacesFailed,
		DurationMs: time.Since(tAll).Milliseconds(),
		Status:     status,
	})
	return 0
}

// tessellateByShell groups faces by shell, tessellates the groups in parallel and
// merges the result into one mesh (used by --flat). Faces of the same shell must
// land in the same shard, otherwise deduplication of shared vertices breaks.
func tessellateByShell(faces []*step.FaceGeom, opts step.TessOpts, workers int) (*step.Mesh, step.TessStats) {
	if workers < 1 {
		workers = 1
	}
	if workers == 1 || len(faces) < 64 {
		return step.Tessellate(faces, opts)
	}

	groups := map[int][]*step.FaceGeom{}
	order := []int{}
	for _, f := range faces {
		if _, ok := groups[f.Shell]; !ok {
			order = append(order, f.Shell)
		}
		groups[f.Shell] = append(groups[f.Shell], f)
	}
	// Largest shells first so the shards are evenly loaded
	sort.SliceStable(order, func(i, j int) bool {
		return len(groups[order[i]]) > len(groups[order[j]])
	})

	shards := make([][]*step.FaceGeom, workers)
	for i, shell := range order {
		shards[i%workers] = append(shards[i%workers], groups[shell]...)
	}

	type result struct {
		mesh *step.Mesh
		st   step.TessStats
	}
	ch := make(chan result, workers)
	launched := 0
	for _, sh := range shards {
		if len(sh) == 0 {
			continue
		}
		launched++
		go func(fs []*step.FaceGeom) {
			m, st := step.Tessellate(fs, opts)
			ch <- result{mesh: m, st: st}
		}(sh)
	}

	merged := &step.Mesh{}
	total := step.TessStats{
		BySurface:        map[string]int{},
		FailedByType:     map[string]int{},
		DegradedByReason: map[string]int{},
		FaceReason:       map[int]string{},
	}
	for i := 0; i < launched; i++ {
		r := <-ch
		base := uint32(len(merged.Positions) / 3)
		merged.Positions = append(merged.Positions, r.mesh.Positions...)
		merged.Normals = append(merged.Normals, r.mesh.Normals...)
		for _, idx := range r.mesh.Indices {
			merged.Indices = append(merged.Indices, idx+base)
		}
		mergeTessStats(&total, &r.st)
	}
	return merged, total
}

// mergeTessStats adds shard statistics into the total.
func mergeTessStats(dst, src *step.TessStats) {
	dst.FacesTotal += src.FacesTotal
	dst.FacesOK += src.FacesOK
	dst.FacesFailed += src.FacesFailed
	dst.FacesDegraded += src.FacesDegraded
	for k, v := range src.BySurface {
		dst.BySurface[k] += v
	}
	for k, v := range src.FailedByType {
		dst.FailedByType[k] += v
	}
	for k, v := range src.DegradedByReason {
		dst.DegradedByReason[k] += v
	}
	for k, v := range src.FaceReason {
		dst.FaceReason[k] = v
	}
}

// nodeLabel is the text displayed for a node in the assembly tree; see
// AsmNode.Label(). Logs and the GLB must use the same naming, otherwise comparing
// them during troubleshooting makes you doubt your own eyes.
func nodeLabel(n *step.AsmNode) string { return n.Label() }

// matToGLTF converts the internal 3x4 rigid transform into the 4x4 column-major
// matrix glTF expects.
//
// Mat34.R is a row-major 3x3 (see Apply in geom.go), while the glTF matrix holds
// 16 numbers in column-major order, hence the transpose here.
func matToGLTF(m step.Mat34) *[16]float64 {
	var o [16]float64
	o[0], o[1], o[2] = m.R[0], m.R[3], m.R[6]
	o[4], o[5], o[6] = m.R[1], m.R[4], m.R[7]
	o[8], o[9], o[10] = m.R[2], m.R[5], m.R[8]
	o[12], o[13], o[14] = m.T.X, m.T.Y, m.T.Z
	o[15] = 1
	return &o
}

// matrixOrNil is the byte-saving variant of matToGLTF: an identity matrix is
// omitted entirely. Most container nodes in an assembly tree (sub-assemblies,
// frames) have an identity world transform, and a 16-number matrix costs about
// 400 bytes of JSON, which is worth saving across thousands of nodes.
func matrixOrNil(m step.Mat34) *[16]float64 {
	if m.IsIdentity() {
		return nil
	}
	return matToGLTF(m)
}

// buildPartDocument assembles the "part meshes + assembly tree" into a glTF scene.
//
// Transform derivation (the easiest part of this feature to get wrong):
//   - mesh vertices hold base*v_local, where base is the accumulated transform of
//     the part's **first instance**;
//   - the accumulated transform of tree node i is World_i;
//   - so the node's own world transform must be World_i*base^-1, because then
//     (World_i*base^-1)*(base*v_local) = World_i*v_local lands back in the right
//     place.
//
// But glTF matrices are **relative to the parent** and children inherit all parent
// transforms. So when a node has **both geometry and children**, base^-1 must not
// stay on it -- otherwise the whole subtree would be multiplied by base^-1 once
// more and shift. In that case a separate geometry-only leaf node is created,
// base^-1 goes on the leaf, and the container keeps a "clean" world transform.
func buildPartDocument(plan *step.Plan, order []int, meshes []*step.Mesh, base map[int]step.Mat34, gen string) *glb.Document {
	tree := plan.Tree

	doc := &glb.Document{Generator: gen}
	meshOf := make(map[int]int, len(order))

	// Mesh names come from the first tree node that uses the shape representation.
	label := make(map[int]string)
	treeSR := make(map[int]bool)
	if tree != nil {
		for i := range tree.Nodes {
			nd := &tree.Nodes[i]
			treeSR[nd.SR] = true
			if _, ok := label[nd.SR]; !ok {
				label[nd.SR] = nodeLabel(nd)
			}
		}
	}
	// loose holds mesh groups that are not in the assembly tree (detached shape
	// representations plus loose faces not referenced by any shape representation).
	// They have no pose, their vertices are baked at raw coordinates, and they are
	// attached under the scene root at the end; they must never be dropped.
	var loose []int
	for i, g := range order {
		// Register only meshes that really have triangles: Tessellate may produce
		// not a single triangle for a part, and such empty meshes are skipped by
		// Encode. A node carrying an empty mesh is better treated as having no
		// geometry at all -- the empty-node pruning below relies on this test.
		if len(meshes[i].Indices) >= 3 && len(meshes[i].Positions) >= 9 {
			meshOf[g] = i
		}
		nm := label[g]
		if nm == "" {
			if g == 0 {
				nm = "loose faces (no shape representation)"
			} else {
				nm = fmt.Sprintf("detached geometry %d", g)
			}
		}
		if tree != nil && !treeSR[g] {
			loose = append(loose, i)
		}
		doc.Meshes = append(doc.Meshes, glb.Mesh{
			Positions:     meshes[i].Positions,
			Normals:       meshes[i].Normals,
			Indices:       meshes[i].Indices,
			Name:          nm,
			LinePositions: meshes[i].LinePositions,
			LineIndices:   meshes[i].LineIndices,
		})
	}

	if tree == nil || len(tree.Nodes) == 0 {
		// Fallback: without an assembly structure, hang every mesh flat under one
		// root.
		root := len(doc.Nodes)
		doc.Nodes = append(doc.Nodes, glb.Node{Name: "model", Mesh: -1})
		for i := range doc.Meshes {
			child := len(doc.Nodes)
			doc.Nodes = append(doc.Nodes, glb.Node{Mesh: i, Name: doc.Meshes[i].Name})
			doc.Nodes[root].Children = append(doc.Nodes[root].Children, child)
		}
		doc.Roots = []int{root}
		return doc
	}

	// --- Prune "empty nodes" ----------------------------------------------
	// A tree node with neither geometry nor children is a pure stub in glTF and the
	// Khronos validator reports NODE_EMPTY for each one. The 72 MB assembly we
	// measured had 16 such nodes (`shape_45`, `shape_368459`, ...): their shape
	// representation does not reference any faces in the source file -- the geometry
	// was borrowed by a frame representation in the same group, leaving only a
	// coordinate frame. They never corresponded to a line in the CATIA tree either,
	// so pruning them both keeps validation warning-free and leaves only the real
	// assembly root at the top level.
	//
	// Scan bottom-up: child indices are always greater than the parent (walk records
	// the parent before recursing), so one reverse pass also prunes containers whose
	// children were all pruned.
	empty := make([]bool, len(tree.Nodes))
	for i := len(tree.Nodes) - 1; i >= 0; i-- {
		nd := &tree.Nodes[i]
		if _, has := meshOf[nd.SR]; has {
			continue
		}
		if len(nd.Children) == 0 {
			empty[i] = true
			continue
		}
		all := true
		for _, c := range nd.Children {
			if !empty[c] {
				all = false
				break
			}
		}
		empty[i] = all
	}

	// Assign glTF node indices to the remaining tree nodes (same order as the tree,
	// to make troubleshooting easier).
	idx := make([]int, len(tree.Nodes))
	nodes := make([]glb.Node, 0, len(tree.Nodes)+16)
	for i := range tree.Nodes {
		if empty[i] {
			idx[i] = -1
			continue
		}
		idx[i] = len(nodes)
		nodes = append(nodes, glb.Node{Mesh: -1})
	}

	for i := range tree.Nodes {
		if empty[i] {
			continue
		}
		tn := &tree.Nodes[i]
		self := idx[i]

		parentWorld := step.Identity()
		if tn.Parent >= 0 {
			parentWorld = tree.Nodes[tn.Parent].World
		}
		// parent frame -> this node's frame
		container := parentWorld.InverseRigid().Mul(tn.World)

		nodes[self].Name = nodeLabel(tn)
		meshID, hasMesh := meshOf[tn.SR]
		hasKids := false
		for _, c := range tn.Children {
			if !empty[c] {
				hasKids = true
				break
			}
		}

		// base[tn.SR] is the accumulated transform of the part's first instance. In
		// theory every SR in the tree is in insts and therefore in base; if a gap does
		// appear, fall back to the identity matrix -- a slightly wrong position is
		// better than dropping the node entirely.
		inv, ok := base[tn.SR]
		if ok {
			inv = inv.InverseRigid()
		} else {
			inv = step.Identity()
		}

		switch {
		case hasMesh && !hasKids:
			nodes[self].Matrix = matrixOrNil(container.Mul(inv))
			nodes[self].Mesh = meshID
		case hasMesh && hasKids:
			nodes[self].Matrix = matrixOrNil(container)
			leaf := len(nodes)
			nodes = append(nodes, glb.Node{
				Name:   nodeLabel(tn),
				Mesh:   meshID,
				Matrix: matrixOrNil(inv),
			})
			nodes[self].Children = append(nodes[self].Children, leaf)
		default:
			nodes[self].Matrix = matrixOrNil(container)
		}

		for _, c := range tn.Children {
			if idx[c] >= 0 {
				nodes[self].Children = append(nodes[self].Children, idx[c])
			}
		}
	}

	// Detached geometry hangs under the scene root (inheriting no assembly
	// transform) and is collected into a single container node so that foreign parts
	// are not mixed into the CATIA assembly tree.
	//
	// Two kinds of things are collected here:
	//   1) loose -- meshes that never entered the assembly tree (detached shape
	//      representations, unreferenced loose faces);
	//   2) stray -- roots that are in the tree but have no assembly relation and no
	//      children. The 72 MB assembly we measured had 16 such roots (`shape_45`,
	//      `shape_368459`, ...); they are "another encoding of the same part" that
	//      the converter exported additionally. The geometry must not be lost, but
	//      they are not nodes of the CATIA tree, and placing them side by side at the
	//      top level would make the assembly tree look like it has 17 roots, so they
	//      all go into one bucket.
	//
	// The "true root" is the largest subtree rather than the first one -- if the
	// enumeration order ever changes, the whole assembly still will not end up inside
	// "unassembled geometry".
	trueRoot := tree.Root
	if trueRoot < 0 || trueRoot >= len(tree.Nodes) || empty[trueRoot] {
		trueRoot = -1
	}
	if trueRoot >= 0 {
		best := subtreeSize(tree, trueRoot)
		for i := range tree.Nodes {
			if empty[i] || tree.Nodes[i].Parent >= 0 {
				continue
			}
			if s := subtreeSize(tree, i); s > best {
				best, trueRoot = s, i
			}
		}
	}
	var stray []int
	for i := range tree.Nodes {
		if empty[i] || i == trueRoot || tree.Nodes[i].Parent >= 0 {
			continue
		}
		stray = append(stray, idx[i])
	}

	if len(stray) > 0 || len(loose) > 0 {
		box := len(nodes)
		nodes = append(nodes, glb.Node{Mesh: -1, Name: "unassembled geometry"})
		nodes[box].Children = append(nodes[box].Children, stray...)
		for _, i := range loose {
			child := len(nodes)
			nodes = append(nodes, glb.Node{Mesh: i, Name: doc.Meshes[i].Name})
			nodes[box].Children = append(nodes[box].Children, child)
		}
	}

	doc.Nodes = nodes
	return doc
}

// subtreeSize counts how many descendants a node has; used to pick the real
// assembly root among several roots.
func subtreeSize(t *step.AsmTree, root int) int {
	n := 0
	stack := []int{root}
	for len(stack) > 0 {
		i := stack[len(stack)-1]
		stack = stack[:len(stack)-1]
		n++
		if n > len(t.Nodes) {
			return n // safety: do not loop forever on a malformed structure
		}
		stack = append(stack, t.Nodes[i].Children...)
	}
	return n
}

func ratioNote(r float64) string {
	switch {
	case r < 0.3:
		return "(well below the source file)"
	case r < 1.0:
		return "(below the source file)"
	default:
		return "(not smaller than the source file: the source may be a tiny curve/wireframe " +
			"model, or the part may have far more faces than its text size. Note that a looser " +
			"tolerance does not help here; use --max-depth to control mesh density)"
	}
}

func asmNote(has bool) string {
	if has {
		return ", assembly transforms applied"
	}
	return ""
}

// printInspect prints the structure diagnostic report without converting.
func printInspect(g *step.Geom, f *step.File, faces []*step.FaceGeom, est step.ExtractStats, diag float64, log *logx.Logger) {
	types := map[string]int{}
	for _, id := range f.Order {
		types[f.Entities[id].Type]++
	}
	log.Plain("")
	log.Plain(strings.Repeat("=", 66))
	log.Plain("  Structure diagnostics (no conversion performed)")
	log.Plain(strings.Repeat("-", 66))
	log.Plain(fmt.Sprintf("  schema          : %s", f.Schema))
	log.Plain(fmt.Sprintf("  entities        : %s", comma(len(f.Entities))))
	log.Plain(fmt.Sprintf("  faces           : %s (%s after expanding assembly instances)", comma(est.FacesTotal), comma(est.FaceInstances)))
	log.Plain(fmt.Sprintf("  shells          : %s", comma(est.Shells)))
	log.Plain(fmt.Sprintf("  assembly        : %s shapes / %s instances (%s)",
		comma(est.AssemblyNodes), comma(est.AssemblyInstances), asmLabel(est.HasAssembly)))
	if est.ReusedShapes > 0 {
		log.Plain(fmt.Sprintf("  reused parts    : %s parts referenced more than once, %s extra instances",
			comma(est.ReusedShapes), comma(est.ExtraInstances)))
	}
	if est.BorrowedShapes > 0 {
		log.Plain(fmt.Sprintf("  geometry pair   : %s bare-frame nodes borrowed geometry", comma(est.BorrowedShapes)))
	}
	if est.AltReprs > 0 {
		log.Plain(fmt.Sprintf("  duplicate repr  : %s (dropped %s overlapping faces)",
			comma(est.AltReprs), comma(est.SupersededFaces)))
	}
	if est.AltKeptReprs > 0 {
		log.Plain(fmt.Sprintf("  sibling kept    : %s (added %s faces; STP2GLB_DEDUP_ALT=1 merges aggressively)",
			comma(est.AltKeptReprs), comma(est.AltKeptFaces)))
	}
	if est.DuplicateShapes > 0 {
		log.Plain(fmt.Sprintf("  redundant repr  : %s (removed)", comma(est.DuplicateShapes)))
	}
	if est.DetachedShapes > 0 {
		log.Plain(fmt.Sprintf("  detached repr   : %s (emitted at raw coordinates)", comma(est.DetachedShapes)))
	}
	log.Plain(fmt.Sprintf("  bbox diagonal   : %.2f (assembly coordinates)", diag))
	if rd := est.RawBBoxMax.Sub(est.RawBBoxMin).Len(); rd > diag*2 {
		log.Plain(fmt.Sprintf("  raw diagonal    : %.2f (no assembly transform, for reference only)", rd))
	}
	log.Plain("")
	log.Plain("  key geometry entity types:")
	keys := []string{
		"ADVANCED_FACE", "FACE_OUTER_BOUND", "FACE_BOUND", "EDGE_LOOP", "ORIENTED_EDGE",
		"EDGE_CURVE", "VERTEX_POINT", "CARTESIAN_POINT",
		"PLANE", "CYLINDRICAL_SURFACE", "CONICAL_SURFACE", "SPHERICAL_SURFACE",
		"TOROIDAL_SURFACE", "B_SPLINE_SURFACE_WITH_KNOTS", "RATIONAL_B_SPLINE_SURFACE",
		"SURFACE_OF_LINEAR_EXTRUSION", "SURFACE_OF_REVOLUTION",
		"CIRCLE", "ELLIPSE", "LINE", "B_SPLINE_CURVE_WITH_KNOTS", "TRIMMED_CURVE",
		"CLOSED_SHELL", "OPEN_SHELL", "ORIENTED_CLOSED_SHELL", "ORIENTED_OPEN_SHELL",
		"MANIFOLD_SOLID_BREP", "BREP_WITH_VOIDS", "SHELL_BASED_SURFACE_MODEL",
	}
	for _, k := range keys {
		if n := types[k]; n > 0 {
			log.Plain(fmt.Sprintf("    %-34s %s", k, comma(n)))
		}
	}
	if len(faces) > 0 {
		byType := map[string]int{}
		for _, fc := range faces {
			byType[fc.SurfaceType]++
		}
		log.Plain("")
		log.Plain("  surface types of tessellable faces:")
		type kv struct {
			k string
			v int
		}
		var arr []kv
		for k, v := range byType {
			arr = append(arr, kv{k, v})
		}
		sort.Slice(arr, func(i, j int) bool { return arr[i].v > arr[j].v })
		for _, e := range arr {
			log.Plain(fmt.Sprintf("    %-34s %s", e.k, comma(e.v)))
		}
	}
	log.Plain(strings.Repeat("=", 66))
	log.Plain("")
}

func asmLabel(has bool) string {
	if has {
		return "assembly structure present"
	}
	return "no assembly structure (single part)"
}

func topFailures(m map[string]int) string {
	type kv struct {
		k string
		v int
	}
	var arr []kv
	for k, v := range m {
		arr = append(arr, kv{k, v})
	}
	sort.Slice(arr, func(i, j int) bool { return arr[i].v > arr[j].v })
	var sb strings.Builder
	for i, e := range arr {
		if i >= 5 {
			break
		}
		if i > 0 {
			sb.WriteString(", ")
		}
		fmt.Fprintf(&sb, "%s x %d", e.k, e.v)
	}
	return sb.String()
}

func showHistory(n int) int {
	if n <= 0 {
		n = 20
	}
	dir := defaultLogDir()
	items, total, err := logx.ReadHistory(dir, n)
	if err != nil {
		console.Outf("no history yet (%s does not exist)", filepath.Join(dir, "history.jsonl"))
		return 0
	}
	console.Outf("\nlast %d conversion history records (%d total)", len(items), total)
	console.Out(strings.Repeat("-", 108))
	console.Outf("  %-19s %-8s %-24s %-10s %-10s %-8s %s", "time", "status", "input file", "source", "output", "ratio", "elapsed")
	for _, e := range items {
		status := "ok"
		if e.Status == "partial" {
			status = "partial"
		}
		console.Outf("  %-19s %-8s %-24s %-10s %-10s %-8s %.1fs",
			e.TS, status, shorten(filepath.Base(e.Input), 24),
			mb(e.InputBytes), mb(e.OutBytes),
			fmt.Sprintf("%.1f%%", e.Ratio*100), float64(e.DurationMs)/1000)
	}
	console.Out(strings.Repeat("-", 108))
	console.Out("")
	return 0
}

func shorten(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	if n <= 2 {
		return string(r[:n])
	}
	return "..." + string(r[len(r)-n+1:])
}

func mb(b int64) string { return fmt.Sprintf("%.1f MB", float64(b)/1048576) }

func defaultLogDir() string {
	exe, err := os.Executable()
	if err != nil {
		return "logs"
	}
	return filepath.Join(filepath.Dir(exe), "logs")
}

func comma(n int) string {
	s := strconv.Itoa(n)
	if len(s) <= 3 {
		return s
	}
	var out []byte
	c := 0
	for i := len(s) - 1; i >= 0; i-- {
		out = append(out, s[i])
		c++
		if c%3 == 0 && i > 0 {
			out = append(out, ',')
		}
	}
	for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
		out[i], out[j] = out[j], out[i]
	}
	return string(out)
}

func usageText() string {
	return strings.TrimSpace(fmt.Sprintf(`
stp2glb-lite %s -- lightweight STEP to GLB converter (self-contained geometry kernel, no OpenCASCADE)

Usage:
  stp2glb-lite <input.stp> [output folder] [options]

Run without arguments to enter interactive mode. With only an input file, the output
goes to the glb_output folder next to that file.

Options:
  --tol <value>       Chord tolerance (absolute, in model units). By default it adapts
                      to the model diagonal
  --tol-ratio <r>     Chord tolerance as a fraction of the bounding box diagonal
                      (default 0.0015)
  --ang-tol <deg>     Maximum angular tolerance per arc segment (default 30, i.e. at
                      least 12 segments per full circle, 16 after bisection). Chord
                      tolerance follows the model scale, so on a two-meter assembly it
                      can reach 3-4 mm, larger than the radius of a 6 mm hole; with
                      chord tolerance alone a round hole is drawn as a diamond or a
                      hexagon. This criterion is independent of scale.
                      It triggers when chord sampling first turns the edge into a
                      polygon (adjacent segments more than 40 deg apart), so edges that
                      are already round enough gain no extra points.
                      The test only looks at the polyline shape, not the curve type, so
                      a circle written as NURBS (B_SPLINE_CURVE) by CATIA is fixed too.
                      Pass 0 to disable it (old behavior, round holes may become
                      polygons).
  --fast              Fast mode: coarser tolerance (0.6%% of the diagonal), fastest
                      result. Note: on assemblies with very many faces a looser
                      tolerance can push more faces from the structured grid back to
                      ear clipping + subdivision, making the mesh denser. Use
                      --max-depth to reduce the file size
  --precise           Precise mode: finer tolerance (0.04%% of the diagonal)
  --max-depth <n>     Maximum adaptive subdivision depth (default 6)
  --flat              Flatten into a single mesh without the assembly node tree
                      (the tree is the default; only needed when a viewer does not
                      honor node matrices)
  --single-sided      Disable the double-sided material so the viewer culls backfaces.
                      Double-sided is the default: automotive STEP is mostly surface
                      models (zero-thickness OPEN_SHELL) and single-sided rendering
                      makes whole regions disappear when seen from behind, the "solid
                      turns hollow" effect; CATIA and desktop viewers always show both
                      sides, so only the browser reveals it. Use it only when the model
                      is entirely closed solids and you want maximum performance.
  --name <file>       Output file name (.glb is appended)
  --workers <n>       Number of parallel workers (default: CPU cores)
  --no-normals        Do not write vertex normals
  --no-outline        Do not write outlines (B-Rep edges are written by default)
  --outline-angle <deg>
                      Only draw edges whose dihedral angle is at least this value.
                      Default 0 = all B-Rep edges; 20-30 filters out the soft edges
                      where fillets are tangent to flat faces, for a cleaner picture
  --log-dir <dir>     Log directory (default: logs next to the exe)
  --history [n]       Show the last n conversions (default 20)
  --inspect           Structure diagnostics only, no conversion
  --diag              Encoding/console self-test (use it when text does not display
                      correctly)
  --quiet             Minimal output
  --verbose           Debug output
  -h, --help          Show help
  -v, --version       Show version

Examples:
  stp2glb-lite part.stp
  stp2glb-lite part.stp D:\out --fast
  stp2glb-lite big.stp D:\out --tol 0.02 --workers 8
  stp2glb-lite --inspect big.stp

Exit codes: 0=success  1=argument or environment error  2=input file problem  3=parse or tessellation failure  4=write failure
`, version))
}

// showEncoding prints the encoding/console self-test information.
// When text does not display correctly, running `stp2glb-lite --diag` once and
// sending a screenshot is enough to diagnose it.
func showEncoding() int {
	console.Out("stp2glb-lite encoding self-test")
	console.Out(strings.Repeat("=", 66))
	console.Out("")
	for _, l := range strings.Split(console.Description(), "\n") {
		console.Out("  " + l)
	}
	console.Out("")
	console.Out("  environment variable STP2GLB_ENC = " + showEnv(os.Getenv("STP2GLB_ENC")) +
		" (leave it empty; set it to gbk only when the consumer is a GBK-only pipe)")
	console.Out("")
	console.Out("  The two lines below should display correctly:")
	console.Out("    text: input file | output file | model bounding box | tessellation | ratio 12.7%")
	console.Out("    symbols: x -> - >= deg ... 2 pi (these are typographic symbols, not mojibake)")
	console.Err("  [stderr] this line goes through the error stream and should display correctly too")
	console.Out("")
	console.Out("  If you see question marks, empty boxes or a row of dotted diamonds above,")
	console.Out("  the terminal decoding does not match the bytes.")
	console.Out("=" + strings.Repeat("=", 65))
	return 0
}

func showEnv(v string) string {
	if v == "" {
		return "(empty)"
	}
	return v
}

func parseArgs(args []string) (options, error) {
	o := options{
		tolRatio: 0.0015,
		angTol:   30,
		maxDepth: 6,
		historyN: 20,
		workers:  0,
	}
	var pos []string
	takes := map[string]bool{
		"--tol": true, "--tol-ratio": true, "--max-depth": true, "--name": true,
		"--log-dir": true, "--workers": true, "--outline-angle": true, "--ang-tol": true,
	}
	numArg := func(v string, name string) (float64, error) {
		f, err := strconv.ParseFloat(v, 64)
		if err != nil {
			return 0, fmt.Errorf("%s needs a number, got %q", name, v)
		}
		return f, nil
	}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			o.usage = true
		case "-v", "--version":
			o.ver = true
		case "--fast":
			o.fast = true
			o.tolSet = true
		case "--precise":
			o.precise = true
			o.tolSet = true
		case "--no-normals":
			o.noNormals = true
		case "--no-outline":
			o.noOutline = true
		case "--flat":
			o.flat = true
		case "--single-sided":
			o.singleSided = true
		case "--quiet":
			o.quiet = true
		case "--verbose":
			o.verbose = true
		case "--inspect":
			o.inspect = true
		case "--diag", "--encoding":
			o.diag = true
		case "--history":
			o.doHistory = true
			if i+1 < len(args) {
				if n, err := strconv.Atoi(args[i+1]); err == nil {
					o.historyN = n
					i++
				}
			}
		default:
			if takes[a] {
				if i+1 >= len(args) {
					return o, fmt.Errorf("%s requires a value", a)
				}
				v := args[i+1]
				i++
				switch a {
				case "--tol":
					f, err := numArg(v, a)
					if err != nil {
						return o, err
					}
					o.tol = f
					o.tolSet = true
				case "--tol-ratio":
					f, err := numArg(v, a)
					if err != nil {
						return o, err
					}
					o.tolRatio = f
					o.tolSet = true
				case "--max-depth":
					n, err := strconv.Atoi(v)
					if err != nil {
						return o, fmt.Errorf("--max-depth needs an integer")
					}
					o.maxDepth = n
				case "--workers":
					n, err := strconv.Atoi(v)
					if err != nil {
						return o, fmt.Errorf("--workers needs an integer")
					}
					o.workers = n
				case "--outline-angle":
					f, err := numArg(v, a)
					if err != nil {
						return o, err
					}
					if f < 0 || f >= 180 {
						return o, fmt.Errorf("--outline-angle needs an angle in degrees between 0 and 180, got %q", v)
					}
					o.outlineAngle = f
				case "--ang-tol":
					f, err := numArg(v, a)
					if err != nil {
						return o, err
					}
					if f < 0 || f > 180 {
						return o, fmt.Errorf("--ang-tol needs an angle in degrees between 0 and 180, got %q", v)
					}
					o.angTol = f
				case "--name":
					o.name = v
				case "--log-dir":
					o.logDir = v
				}
			} else if strings.HasPrefix(a, "-") && len(a) > 1 {
				return o, fmt.Errorf("unknown option %s", a)
			} else {
				pos = append(pos, a)
			}
		}
	}
	if len(pos) > 0 {
		o.input = pos[0]
	}
	if len(pos) > 1 {
		o.outDir = pos[1]
	}
	if len(pos) > 2 {
		return o, fmt.Errorf("too many arguments; only <input file> and an optional <output folder> are accepted")
	}
	if o.logDir == "" && o.input != "" {
		o.logDir = defaultLogDir()
	}
	// Drag-and-drop quotes are handled in positional-argument mode as well
	o.input = cleanPath(o.input)
	o.outDir = cleanPath(o.outDir)
	return o, nil
}
