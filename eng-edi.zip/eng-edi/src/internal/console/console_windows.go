//go:build windows

package console

import (
	"os"
	"sync"
	"syscall"
	"unsafe"
)

var (
	kernel32 = syscall.NewLazyDLL("kernel32.dll")

	procGetStdHandle        = kernel32.NewProc("GetStdHandle")
	procGetConsoleMode      = kernel32.NewProc("GetConsoleMode")
	procSetConsoleMode      = kernel32.NewProc("SetConsoleMode")
	procGetConsoleOutputCP  = kernel32.NewProc("GetConsoleOutputCP")
	procSetConsoleOutputCP  = kernel32.NewProc("SetConsoleOutputCP")
	procGetACP              = kernel32.NewProc("GetACP")
	procWriteConsoleW       = kernel32.NewProc("WriteConsoleW")
	procMultiByteToWideChar = kernel32.NewProc("MultiByteToWideChar")
	procWideCharToMultiByte = kernel32.NewProc("WideCharToMultiByte")
)

const (
	cpUTF8     = 65001
	enableVT   = 0x0004 // ENABLE_VIRTUAL_TERMINAL_PROCESSING
	stdOutput  = ^uintptr(11) + 1
	stdError   = ^uintptr(12) + 1
	invalidHnd = ^uintptr(0)
)

var (
	initOnce    sync.Once
	inited      bool
	haveConsole bool
	vtEnabled   bool

	acp, outCP  uint32
	restoreCP   uint32
	restoreCPOK bool
)

// writeTo sends one string to the target file.
//
// A real console goes through WriteConsoleW first (Unicode, independent of the
// code page); in every other case UTF-8 bytes are written.
func writeTo(f *os.File, s string) {
	initPlatform()
	if h, ok := stdHandle(f); ok {
		if writeConsoleW(h, s) {
			return
		}
	}
	_, _ = f.Write(encodeBytes(s))
}

// encodeBytes decides the byte encoding for "not a console" output.
// UTF-8 by default; STP2GLB_ENC=gbk forces GBK (the odd legacy consumer that
// only understands GBK).
func encodeBytes(s string) []byte {
	switch os.Getenv("STP2GLB_ENC") {
	case "gbk", "936", "gb2312":
		if b, ok := toCodePage(s, 936); ok {
			return b
		}
	}
	return []byte(s)
}

// stdHandle returns the console handle for the file; false if it is not a
// console.
func stdHandle(f *os.File) (uintptr, bool) {
	var which uintptr
	switch f {
	case os.Stdout:
		which = stdOutput
	case os.Stderr:
		which = stdError
	default:
		return 0, false
	}
	h, _, _ := procGetStdHandle.Call(which)
	if h == 0 || h == invalidHnd {
		return 0, false
	}
	var mode uint32
	if r, _, _ := procGetConsoleMode.Call(h, uintptr(unsafe.Pointer(&mode))); r == 0 {
		return 0, false
	}
	return h, true
}

// initPlatform does two things, both lightweight:
//
//  1. turn on ANSI escape support, otherwise the color codes in the log are
//     printed as ordinary characters;
//  2. if the console code page is not one that can display Chinese while the
//     system one is, switch over temporarily (the code page decides which font
//     conhost picks) and restore it in restorePlatform on exit.
//
// Note: the output itself does not depend on the code page - it goes through
// WriteConsoleW.
func initPlatform() {
	initOnce.Do(func() {
		inited = true
		h, ok := stdHandle(os.Stdout)
		if !ok {
			h, ok = stdHandle(os.Stderr)
		}
		if !ok {
			return // pipe / redirect: stay on UTF-8, nothing to do
		}
		haveConsole = true

		var mode uint32
		if r, _, _ := procGetConsoleMode.Call(h, uintptr(unsafe.Pointer(&mode))); r != 0 {
			if mode&enableVT != 0 {
				vtEnabled = true
			} else if r2, _, _ := procSetConsoleMode.Call(h, uintptr(mode|enableVT)); r2 != 0 {
				vtEnabled = true
			}
		}

		a, _, _ := procGetACP.Call()
		c, _, _ := procGetConsoleOutputCP.Call()
		acp, outCP = uint32(a), uint32(c)
		if isCJKCodePage(acp) && !isCJKCodePage(outCP) {
			if r, _, _ := procSetConsoleOutputCP.Call(uintptr(acp)); r != 0 {
				restoreCP, restoreCPOK = outCP, true
				outCP = acp
			}
		}
	})
}

func restorePlatform() {
	if inited && haveConsole && restoreCPOK {
		_, _, _ = procSetConsoleOutputCP.Call(uintptr(restoreCP))
		restoreCPOK = false
		outCP = restoreCP
	}
}

// Description returns a description of the console state (for diagnostics).
func Description() string {
	initPlatform()
	if !haveConsole {
		return "standard output is not attached to a console (pipe/redirect), writing UTF-8"
	}
	vt := "off"
	if vtEnabled {
		vt = "on"
	}
	cpNote := ""
	if restoreCPOK {
		cpNote = ", temporarily switched to the system code page so a Chinese font can be selected (restored on exit)"
	}
	return "console detected: system code page " + itoa(int(acp)) +
		", console code page " + itoa(int(outCP)) +
		", ANSI escape " + vt + cpNote +
		"\noutput method: WriteConsole (Unicode directly, independent of the code page)"
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	var b [8]byte
	i := len(b)
	for n > 0 && i > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	return string(b[i:])
}

func isCJKCodePage(cp uint32) bool {
	switch cp {
	case 936, 950, 932, 949, 54936, cpUTF8:
		return true
	}
	return false
}

// writeConsoleW writes to the console through the Unicode API and reports
// whether it succeeded.
// At most 4096 UTF-16 code units at a time, so a large block of output does not
// trigger ERROR_NOT_ENOUGH_MEMORY.
func writeConsoleW(h uintptr, s string) bool {
	w, ok := utf8ToUTF16(s)
	if !ok {
		return false
	}
	const chunk = 4096
	for len(w) > 0 {
		n := len(w)
		if n > chunk {
			n = chunk
			// do not cut in the middle of a UTF-16 surrogate pair
			if w[n-1] >= 0xD800 && w[n-1] < 0xDC00 {
				n--
			}
		}
		var written uint32
		r, _, _ := procWriteConsoleW.Call(h,
			uintptr(unsafe.Pointer(&w[0])), uintptr(n),
			uintptr(unsafe.Pointer(&written)), 0)
		if r == 0 || written == 0 {
			return false
		}
		w = w[written:]
	}
	return true
}

// utf8ToUTF16 goes through kernel32's MultiByteToWideChar(CP_UTF8) and depends
// only on system libraries, pulling in no third-party dependency.
func utf8ToUTF16(s string) ([]uint16, bool) {
	src := []byte(s)
	if len(src) == 0 {
		return nil, true
	}
	n, _, _ := procMultiByteToWideChar.Call(
		uintptr(cpUTF8), 0,
		uintptr(unsafe.Pointer(&src[0])), uintptr(len(src)),
		0, 0)
	if int32(n) <= 0 {
		return nil, false
	}
	w := make([]uint16, int(n))
	n, _, _ = procMultiByteToWideChar.Call(
		uintptr(cpUTF8), 0,
		uintptr(unsafe.Pointer(&src[0])), uintptr(len(src)),
		uintptr(unsafe.Pointer(&w[0])), uintptr(len(w)))
	if int32(n) <= 0 {
		return nil, false
	}
	return w[:int(n)], true
}

// toCodePage performs the two-step UTF-8 -> UTF-16 -> target code page
// conversion, used only when STP2GLB_ENC=gbk.
func toCodePage(s string, cp uint32) ([]byte, bool) {
	wide, ok := utf8ToUTF16(s)
	if !ok || len(wide) == 0 {
		return nil, false
	}
	m, _, _ := procWideCharToMultiByte.Call(
		uintptr(cp), 0,
		uintptr(unsafe.Pointer(&wide[0])), uintptr(len(wide)),
		0, 0, 0, 0)
	if int32(m) <= 0 {
		return nil, false
	}
	out := make([]byte, int(m))
	m, _, _ = procWideCharToMultiByte.Call(
		uintptr(cp), 0,
		uintptr(unsafe.Pointer(&wide[0])), uintptr(len(wide)),
		uintptr(unsafe.Pointer(&out[0])), uintptr(len(out)), 0, 0)
	if int32(m) <= 0 {
		return nil, false
	}
	return out[:int(m)], true
}
