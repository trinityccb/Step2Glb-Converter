//go:build !windows

package console

import "os"

// writeTo needs no transcoding on non-Windows platforms, UTF-8 goes out
// directly.
func writeTo(f *os.File, s string) { _, _ = f.WriteString(s) }

func initPlatform()    {}
func restorePlatform() {}

// Description returns a description of the console state (for diagnostics).
func Description() string { return "non-Windows platform, writing UTF-8 directly" }
