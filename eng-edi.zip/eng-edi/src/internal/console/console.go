// Package console delivers program output correctly into the target
// environment.
//
// Pitfalls already hit (do not walk back down this road):
//
//	The old version read the console code page, converted UTF-8 to 936 (GBK)
//	and then wrote the bytes. That is fine in classic cmd.exe, but as soon as a
//	terminal forwards console output verbatim to a layer above (ConPTY
//	passthrough, Windows Terminal, and any other terminal that decodes as
//	UTF-8), the GBK bytes are treated as invalid UTF-8: the ASCII part is
//	intact, every Chinese character becomes U+FFFD, and the screen shows rows
//	of "diamonds with dots" - which looks like missing font glyphs but is in
//	fact an encoding mismatch.
//
// The current approach:
//   - The target is a real console -> go through WriteConsoleW and hand over
//     Unicode directly; the question "what encoding are these bytes" no longer
//     exists, and a code page of 437 / 936 / 65001 is equally correct;
//   - The target is a pipe / redirect / file -> write UTF-8 (log files and
//     downstream tools both read UTF-8).
//
// The only place that still needs to look at the code page is "let the console
// pick a font that can display Chinese", see initPlatform in
// console_windows.go.
package console

import (
	"fmt"
	"os"
	"sync"
)

// mu guards one complete output, so debug output from parallel triangulation
// does not cut in on itself.
var mu sync.Mutex

// Out writes one line to standard output (newline added).
func Out(s string) { write(os.Stdout, s+"\n") }

// Err writes one line to standard error (newline added).
func Err(s string) { write(os.Stderr, s+"\n") }

// Outf formats and writes to standard output.
func Outf(format string, a ...any) { Out(fmt.Sprintf(format, a...)) }

// Errf formats and writes to standard error.
func Errf(format string, a ...any) { Err(fmt.Sprintf(format, a...)) }

// OutRaw writes to standard output without a trailing newline (for prompts).
func OutRaw(s string) { write(os.Stdout, s) }

// Init is called once at program startup (idempotent, safe to call repeatedly).
func Init() { initPlatform() }

// Restore is called before exit and undoes the console changes made by Init.
func Restore() { restorePlatform() }

func write(f *os.File, s string) {
	if s == "" {
		return
	}
	mu.Lock()
	defer mu.Unlock()
	writeTo(f, s)
}
