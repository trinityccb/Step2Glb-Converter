// Package logx provides synchronized console + file logging and maintains the
// conversion history records.
package logx

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"stp2glb-lite/internal/console"
)

// Logger writes the log to standard error (stderr) and to a file at the same
// time.
type Logger struct {
	file    *os.File
	Hist    string
	Dir     string
	Quiet   bool
	Verbose bool
	start   time.Time
}

// HistoryEntry is one conversion history record.
type HistoryEntry struct {
	TS         string  `json:"ts"`
	Input      string  `json:"input"`
	Output     string  `json:"output"`
	InputBytes int64   `json:"inputBytes"`
	OutBytes   int64   `json:"outputBytes"`
	Ratio      float64 `json:"ratio"`
	Triangles  int     `json:"triangles"`
	Vertices   int     `json:"vertices"`
	FacesOK    int     `json:"facesOk"`
	FacesFail  int     `json:"facesFail"`
	DurationMs int64   `json:"durationMs"`
	Status     string  `json:"status"`
	Note       string  `json:"note,omitempty"`
}

// New creates the log file under dir. When dir is empty only the console is
// written.
func New(dir string, quiet, verbose bool) (*Logger, error) {
	l := &Logger{Quiet: quiet, Verbose: verbose, start: time.Now()}
	if dir == "" {
		return l, nil
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return l, err
	}
	name := time.Now().Format("2006-01-02") + ".log"
	f, err := os.OpenFile(filepath.Join(dir, name), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
	if err != nil {
		return l, err
	}
	l.file = f
	l.Dir = dir
	l.Hist = filepath.Join(dir, "history.jsonl")
	return l, nil
}

// Close closes the log file.
func (l *Logger) Close() {
	if l.file != nil {
		_ = l.file.Close()
		l.file = nil
	}
}

func (l *Logger) write(level, msg string) {
	if l.file == nil {
		return
	}
	ts := time.Now().Format("2006-01-02 15:04:05.000")
	fmt.Fprintf(l.file, "%s [%-5s] %s\n", ts, level, msg)
}

func (l *Logger) emit(tag, color, msg string) {
	if !l.Quiet {
		// route through console for encoding, otherwise Chinese text is garbled
		// in a cmd window (GBK code page)
		console.Err(fmt.Sprintf("%s%s\033[0m %s", color, tag, msg))
	}
}

// Info prints a normal message.
func (l *Logger) Info(format string, a ...any) {
	msg := fmt.Sprintf(format, a...)
	l.emit("[info]", "\033[36m", msg)
	l.write("INFO", msg)
}

// Ok prints a success message.
func (l *Logger) Ok(format string, a ...any) {
	msg := fmt.Sprintf(format, a...)
	l.emit("[ok]", "\033[32m", msg)
	l.write("OK", msg)
}

// Warn prints a warning.
func (l *Logger) Warn(format string, a ...any) {
	msg := fmt.Sprintf(format, a...)
	l.emit("[warn]", "\033[33m", msg)
	l.write("WARN", msg)
}

// Error prints an error.
func (l *Logger) Error(format string, a ...any) {
	msg := fmt.Sprintf(format, a...)
	l.emit("[error]", "\033[31m", msg)
	l.write("ERROR", msg)
}

// Debug only prints when --verbose is set.
func (l *Logger) Debug(format string, a ...any) {
	msg := fmt.Sprintf(format, a...)
	if l.Verbose {
		l.emit("[debug]", "\033[90m", msg)
	}
	l.write("DEBUG", msg)
}

// Plain writes one line directly.
func (l *Logger) Plain(s string) {
	if !l.Quiet {
		console.Err(s)
	}
}

// Elapsed returns the time elapsed since the logger was created.
func (l *Logger) Elapsed() time.Duration { return time.Since(l.start) }

// AppendHistory appends one history record.
func (l *Logger) AppendHistory(e HistoryEntry) {
	if l.Hist == "" {
		return
	}
	b, err := json.Marshal(e)
	if err != nil {
		return
	}
	f, err := os.OpenFile(l.Hist, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = f.Write(append(b, '\n'))
}

// ReadHistory reads the most recent n history records.
func ReadHistory(dir string, n int) ([]HistoryEntry, int, error) {
	p := filepath.Join(dir, "history.jsonl")
	data, err := os.ReadFile(p)
	if err != nil {
		return nil, 0, err
	}
	var all []HistoryEntry
	start := 0
	for i := 0; i <= len(data); i++ {
		if i == len(data) || data[i] == '\n' {
			if i > start {
				var e HistoryEntry
				if json.Unmarshal(data[start:i], &e) == nil {
					all = append(all, e)
				}
			}
			start = i + 1
		}
	}
	total := len(all)
	if n > 0 && len(all) > n {
		all = all[len(all)-n:]
	}
	return all, total, nil
}
