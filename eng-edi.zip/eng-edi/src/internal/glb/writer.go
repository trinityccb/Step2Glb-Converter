// Package glb hand-writes the glTF 2.0 binary container without depending on
// any third-party runtime library.
// The output follows the spec strictly: chunks are 4-byte aligned and POSITION
// accessors carry min/max.
package glb

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"math"
)

// Mesh is the mesh data of one part (or one piece of loose geometry).
//
// In an assembly, the same part installed N times still stores only **one** copy
// of the geometry: vertices are baked with the transform of the part's first
// instance, and the remaining instances are restored from Node.Matrix. This is
// exactly the advantage glTF has over "flattening".
type Mesh struct {
	Positions []float32
	Normals   []float32
	Indices   []uint32
	Name      string
	// LinePositions / LineIndices are the outline overlaid on this mesh:
	// one point per 3 floats, one segment per 2 indices (glTF mode=1 LINES).
	// Keeping them in the same Mesh is deliberate: the node matrix and
	// instancing then carry the lines along automatically, with no need to open
	// another set of nodes for every part.
	LinePositions []float32
	LineIndices   []uint32
}

// Node is one node of the assembly tree, matching a row in the CATIA assembly
// tree.
type Node struct {
	Name string
	// Mesh is the index of the referenced Mesh; -1 means a pure assembly
	// container (only groups things, no geometry).
	Mesh int
	// Matrix is the 4x4 transform relative to the parent node (column-major, as
	// the glTF spec requires); nil means the identity matrix.
	Matrix *[16]float64
	// Children holds the child node indices.
	Children []int
}

// Document is the complete scene to write out: a set of part meshes plus a
// node tree.
type Document struct {
	Meshes []Mesh
	Nodes  []Node
	// Roots holds the top-level node indices; when left empty, every node
	// without a parent is used.
	Roots     []int
	Generator string
	// When SingleSided is true, no double-sided material is written (the viewer
	// keeps backface culling on).
	// doubleSided is written by default - otherwise a curved surface model is a
	// hollow sheet when seen from the back.
	SingleSided bool
}

type asset struct {
	Version   string `json:"version"`
	Generator string `json:"generator,omitempty"`
}

type buffer struct {
	ByteLength int `json:"byteLength"`
}

type bufferView struct {
	Buffer     int `json:"buffer"`
	ByteOffset int `json:"byteOffset,omitempty"`
	ByteLength int `json:"byteLength"`
	Target     int `json:"target,omitempty"`
}

type accessor struct {
	BufferView    int       `json:"bufferView"`
	ByteOffset    int       `json:"byteOffset,omitempty"`
	ComponentType int       `json:"componentType"`
	Count         int       `json:"count"`
	Type          string    `json:"type"`
	Min           []float64 `json:"min,omitempty"`
	Max           []float64 `json:"max,omitempty"`
}

type primitive struct {
	Attributes map[string]int `json:"attributes"`
	Indices    int            `json:"indices"`
	Material   *int           `json:"material,omitempty"`
	Mode       int            `json:"mode"`
}

// pbr / material are prepared for the outline only: triangles keep the glTF
// default material and are left untouched - adding a material would change how
// they originally looked.
type pbr struct {
	BaseColorFactor [4]float64 `json:"baseColorFactor"`
	MetallicFactor  float64    `json:"metallicFactor"`
	RoughnessFactor float64    `json:"roughnessFactor"`
}

type material struct {
	Name string `json:"name,omitempty"`
	PBR  *pbr   `json:"pbrMetallicRoughness,omitempty"`
	// With DoubleSided=true the viewer does no backface culling. A curved surface
	// model (an OPEN_SHELL with no thickness) needs this when viewed from the
	// back side, otherwise the whole surface turns from solid into a hollow.
	DoubleSided bool `json:"doubleSided,omitempty"`
}

type meshJSON struct {
	Name       string      `json:"name,omitempty"`
	Primitives []primitive `json:"primitives"`
}

type nodeJSON struct {
	Mesh     *int      `json:"mesh,omitempty"`
	Name     string    `json:"name,omitempty"`
	Matrix   []float64 `json:"matrix,omitempty"`
	Children []int     `json:"children,omitempty"`
}

type sceneJSON struct {
	Nodes []int `json:"nodes"`
}

type gltf struct {
	Asset       asset        `json:"asset"`
	Scene       int          `json:"scene"`
	Scenes      []sceneJSON  `json:"scenes"`
	Nodes       []nodeJSON   `json:"nodes"`
	Meshes      []meshJSON   `json:"meshes"`
	Materials   []material   `json:"materials,omitempty"`
	Accessors   []accessor   `json:"accessors"`
	BufferViews []bufferView `json:"bufferViews"`
	Buffers     []buffer     `json:"buffers"`
}

const (
	compFloat         = 5126
	compUnsignedShort = 5123
	compUnsignedInt   = 5125
	modeTriangles     = 4
	modeLines         = 1
	targetArrayBuf    = 34962
	targetElemBuf     = 34963
)

// Encode writes the complete scene out as GLB.
//
// All meshes share a single binary buffer, and each mesh's POSITION / NORMAL /
// INDICES takes its own bufferView - so multiple meshes bring no extra buffer
// overhead, and the node tree itself costs only a few dozen bytes of JSON per
// node.
func Encode(doc *Document) ([]byte, error) {
	if doc == nil || len(doc.Nodes) == 0 {
		return nil, fmt.Errorf("scene is empty, cannot write out GLB")
	}

	bin := &bytes.Buffer{}
	views := make([]bufferView, 0, len(doc.Meshes)*3)
	accs := make([]accessor, 0, len(doc.Meshes)*3)
	meshes := make([]meshJSON, 0, len(doc.Meshes))
	// mats / lineMat are only materialized when an outline really exists, so as
	// not to emit an empty materials array
	var mats []material
	lineMat := -1
	// surfMat is the double-sided material for triangles, created lazily: it is
	// only needed once triangles are actually written out.
	surfMat := -1

	// mesh index -> glTF mesh index. Empty meshes are skipped, so a mapping must
	// be kept.
	meshIdx := make([]int, len(doc.Meshes))
	for i := range meshIdx {
		meshIdx[i] = -1
	}

	for i := range doc.Meshes {
		m := &doc.Meshes[i]
		if len(m.Positions) < 9 || len(m.Indices) < 3 {
			continue
		}
		vcount := len(m.Positions) / 3

		// --- POSITION ---
		posOffset := bin.Len()
		writeFloats(bin, m.Positions)
		views = append(views, bufferView{Buffer: 0, ByteOffset: posOffset, ByteLength: len(m.Positions) * 4, Target: targetArrayBuf})
		mn, mx := minMax(m.Positions, 3)
		accs = append(accs, accessor{
			BufferView: len(views) - 1, ComponentType: compFloat,
			Count: vcount, Type: "VEC3", Min: mn, Max: mx,
		})
		attrs := map[string]int{"POSITION": len(accs) - 1}

		// --- NORMAL ---
		if len(m.Normals) == len(m.Positions) {
			nrmOffset := bin.Len()
			writeFloats(bin, m.Normals)
			views = append(views, bufferView{Buffer: 0, ByteOffset: nrmOffset, ByteLength: len(m.Normals) * 4, Target: targetArrayBuf})
			accs = append(accs, accessor{
				BufferView: len(views) - 1, ComponentType: compFloat,
				Count: vcount, Type: "VEC3",
			})
			attrs["NORMAL"] = len(accs) - 1
		}

		// --- indices: use 16-bit when the vertex count allows it, which shrinks
		// the file noticeably ---
		pad4(bin)
		idxOffset := bin.Len()
		comp := compUnsignedInt
		if vcount < 65536 {
			comp = compUnsignedShort
			buf := make([]byte, len(m.Indices)*2)
			for k, v := range m.Indices {
				binary.LittleEndian.PutUint16(buf[k*2:], uint16(v))
			}
			bin.Write(buf)
		} else {
			buf := make([]byte, len(m.Indices)*4)
			for k, v := range m.Indices {
				binary.LittleEndian.PutUint32(buf[k*4:], v)
			}
			bin.Write(buf)
		}
		idxLen := len(m.Indices) * 4
		if comp == compUnsignedShort {
			idxLen = len(m.Indices) * 2
		}
		views = append(views, bufferView{Buffer: 0, ByteOffset: idxOffset, ByteLength: idxLen, Target: targetElemBuf})
		accs = append(accs, accessor{
			BufferView: len(views) - 1, ComponentType: comp,
			Count: len(m.Indices), Type: "SCALAR",
		})
		pad4(bin)

		name := m.Name
		if name == "" {
			name = fmt.Sprintf("part_%d", i)
		}
		// Surface material (double-sided). pbrMetallicRoughness is not written, so
		// the glTF default lighting parameters stay, and only doubleSided is added
		// - that way the default look is not altered by us.
		if !doc.SingleSided && surfMat < 0 {
			mats = append(mats, material{Name: "surface", DoubleSided: true})
			surfMat = len(mats) - 1
		}
		prims := []primitive{{Attributes: attrs, Indices: len(accs) - 1, Mode: modeTriangles}}
		if surfMat >= 0 {
			smi := surfMat
			prims[0].Material = &smi
		}

		// --- outline: attach one more LINES primitive in the same mesh --------
		//
		// LINE_STRIP is not used: one primitive can only be a single strip, and a
		// model carries thousands of disjoint edges, which would require
		// thousands of primitives. With LINES every 2 indices form one segment,
		// so all of them can be merged into one primitive.
		//
		// No NORMAL is written for lines either: the direction of a line comes
		// from the vertex order, normals mean nothing for LINES, and writing
		// them would only waste space.
		if len(m.LineIndices) >= 2 && len(m.LinePositions) >= 6 {
			lcount := len(m.LinePositions) / 3
			lposOffset := bin.Len()
			writeFloats(bin, m.LinePositions)
			views = append(views, bufferView{Buffer: 0, ByteOffset: lposOffset, ByteLength: len(m.LinePositions) * 4, Target: targetArrayBuf})
			// The POSITION accessor must carry min/max, otherwise the Khronos
			// validator reports ACCESSOR_POSITION_MIN_MAX_MISSING.
			lmn, lmx := minMax(m.LinePositions, 3)
			accs = append(accs, accessor{
				BufferView: len(views) - 1, ComponentType: compFloat,
				Count: lcount, Type: "VEC3", Min: lmn, Max: lmx,
			})
			lposAcc := len(accs) - 1

			pad4(bin)
			lidxOffset := bin.Len()
			lcomp := compUnsignedInt
			lidxLen := len(m.LineIndices) * 4
			if lcount < 65536 {
				lcomp = compUnsignedShort
				lidxLen = len(m.LineIndices) * 2
				buf := make([]byte, lidxLen)
				for k, v := range m.LineIndices {
					binary.LittleEndian.PutUint16(buf[k*2:], uint16(v))
				}
				bin.Write(buf)
			} else {
				buf := make([]byte, lidxLen)
				for k, v := range m.LineIndices {
					binary.LittleEndian.PutUint32(buf[k*4:], v)
				}
				bin.Write(buf)
			}
			views = append(views, bufferView{Buffer: 0, ByteOffset: lidxOffset, ByteLength: lidxLen, Target: targetElemBuf})
			accs = append(accs, accessor{
				BufferView: len(views) - 1, ComponentType: lcomp,
				Count: len(m.LineIndices), Type: "SCALAR",
			})
			pad4(bin)

			// The line material is created once on demand: with no outline the
			// materials array is not written, otherwise the Khronos validator
			// reports UNUSED_OBJECT.
			if lineMat < 0 {
				mats = append(mats, material{
					Name: "outline",
					PBR: &pbr{
						BaseColorFactor: [4]float64{0.06, 0.06, 0.07, 1.0},
						MetallicFactor:  0,
						RoughnessFactor: 1,
					},
				})
				lineMat = len(mats) - 1
			}
			mi := lineMat
			prims = append(prims, primitive{
				Attributes: map[string]int{"POSITION": lposAcc},
				Indices:    len(accs) - 1,
				Material:   &mi,
				Mode:       modeLines,
			})
		}

		meshIdx[i] = len(meshes)
		meshes = append(meshes, meshJSON{
			Name:       name,
			Primitives: prims,
		})
	}
	if len(meshes) == 0 {
		return nil, fmt.Errorf("there is no non-empty mesh, cannot write out GLB")
	}

	// --- node tree ---
	hasParent := make([]bool, len(doc.Nodes))
	for i := range doc.Nodes {
		for _, c := range doc.Nodes[i].Children {
			if c >= 0 && c < len(hasParent) {
				hasParent[c] = true
			}
		}
	}
	nodes := make([]nodeJSON, 0, len(doc.Nodes))
	for i := range doc.Nodes {
		n := &doc.Nodes[i]
		nj := nodeJSON{Name: n.Name}
		if n.Mesh >= 0 && n.Mesh < len(meshIdx) && meshIdx[n.Mesh] >= 0 {
			v := meshIdx[n.Mesh]
			nj.Mesh = &v
		}
		if n.Matrix != nil {
			nj.Matrix = n.Matrix[:]
		}
		if len(n.Children) > 0 {
			nj.Children = n.Children
		}
		nodes = append(nodes, nj)
	}

	roots := doc.Roots
	if len(roots) == 0 {
		for i := range hasParent {
			if !hasParent[i] {
				roots = append(roots, i)
			}
		}
	}
	if len(roots) == 0 {
		roots = []int{0}
	}

	gen := doc.Generator
	if gen == "" {
		gen = "stp2glb-lite"
	}
	out := gltf{
		Asset:       asset{Version: "2.0", Generator: gen},
		Scene:       0,
		Scenes:      []sceneJSON{{Nodes: roots}},
		Nodes:       nodes,
		Meshes:      meshes,
		Materials:   mats,
		Accessors:   accs,
		BufferViews: views,
		Buffers:     []buffer{{ByteLength: bin.Len()}},
	}

	jsonBytes, err := json.Marshal(out)
	if err != nil {
		return nil, err
	}
	return assemble(jsonBytes, bin.Bytes()), nil
}

// assemble concatenates the header + JSON chunk + BIN chunk.
func assemble(jsonBytes, binBytes []byte) []byte {
	jsonPadded := padTo4(jsonBytes, ' ')
	binPadded := padTo4(binBytes, 0)

	total := 12 + 8 + len(jsonPadded) + 8 + len(binPadded)
	out := make([]byte, 0, total)

	out = append(out, 'g', 'l', 'T', 'F')
	out = appendU32(out, 2)
	out = appendU32(out, uint32(total))

	out = appendU32(out, uint32(len(jsonPadded)))
	out = append(out, 'J', 'S', 'O', 'N')
	out = append(out, jsonPadded...)

	out = appendU32(out, uint32(len(binPadded)))
	out = append(out, 'B', 'I', 'N', 0)
	out = append(out, binPadded...)

	return out
}

func appendU32(b []byte, v uint32) []byte {
	return append(b, byte(v), byte(v>>8), byte(v>>16), byte(v>>24))
}

func padTo4(b []byte, filler byte) []byte {
	if r := len(b) % 4; r != 0 {
		for i := 0; i < 4-r; i++ {
			b = append(b, filler)
		}
	}
	return b
}

func pad4(buf *bytes.Buffer) {
	if r := buf.Len() % 4; r != 0 {
		buf.Write(make([]byte, 4-r))
	}
}

func writeFloats(buf *bytes.Buffer, f []float32) {
	b := make([]byte, len(f)*4)
	for i, v := range f {
		binary.LittleEndian.PutUint32(b[i*4:], math.Float32bits(v))
	}
	buf.Write(b)
}

// minMax computes the accessor bounding box; the glTF spec requires it for
// POSITION.
func minMax(f []float32, stride int) ([]float64, []float64) {
	n := len(f) / stride
	mn := make([]float64, stride)
	mx := make([]float64, stride)
	for i := 0; i < stride; i++ {
		mn[i] = math.Inf(1)
		mx[i] = math.Inf(-1)
	}
	for i := 0; i < n; i++ {
		for j := 0; j < stride; j++ {
			v := float64(f[i*stride+j])
			if v < mn[j] {
				mn[j] = v
			}
			if v > mx[j] {
				mx[j] = v
			}
		}
	}
	for i := range mn {
		if math.IsInf(mn[i], 0) {
			mn[i] = 0
		}
		if math.IsInf(mx[i], 0) {
			mx[i] = 0
		}
	}
	return mn, mx
}
