package step

import (
	"fmt"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"

	"stp2glb-lite/internal/console"
)

// FaceGeom is a face awaiting triangulation: a surface plus boundary loops
// already discretized into 3D.
type FaceGeom struct {
	ID          int
	Surface     Surface
	SurfaceType string
	SameSense   bool
	Outer       []Vec3
	Inners      [][]Vec3
	Xform       Mat34
	// Shell is the shell number of this face in the source file, for statistics
	Shell int
	// Group is the id of the shape representation that emitted this face, used to
	// attribute faces to parts: all instances of the same part share the same
	// Group, so the geometry only needs to be stored once and the remaining
	// instances are handled by GLB node matrices. Orphan geometry emitted
	// additionally has Group 0.
	Group int
	// Edges holds the EDGE_CURVE ids referenced by all boundary loops of this face
	// (deduplicated within the face, order preserved).
	// The outline is taken directly from here -- using the real B-Rep edges rather
	// than triangle mesh edges: mesh edges split every surface into dozens or
	// hundreds of segments and render as a dense triangle wireframe, whereas B-Rep
	// edges are exactly the ring of creases seen in a CAD viewer.
	Edges []int
}

// ExtractStats summarizes the extraction stage.
type ExtractStats struct {
	FacesTotal     int
	FacesNoSurface int
	FacesNoLoop    int
	Shells         int
	// AssemblyNodes is the number of distinct shape representations, and
	// AssemblyInstances is the total number of expanded instances. If the two
	// differ, the assembly contains reused parts (very common in fixtures).
	AssemblyNodes     int
	AssemblyInstances int
	// ReusedShapes / ExtraInstances only count shape representations **with
	// geometry** that are reused -- reusing an assembly container does not copy
	// geometry, only reusing a part does.
	ReusedShapes   int
	ExtraInstances int
	HasAssembly    bool
	// FaceInstances is the number of faces actually emitted after expanding by
	// instance (>= FacesTotal).
	FaceInstances int
	// OrphanFaces are faces not referenced by any SHAPE_REPRESENTATION. They can
	// only be emitted with the identity transform; a substantial count means the
	// assembly structure was not fully parsed and is worth watching.
	OrphanFaces int
	// DetachedShapes counts shape representations that are not in the assembly
	// tree, whose faces really are not covered by the assembly, and that were
	// emitted with the identity transform. The "standalone part representation"
	// commonly found in files re-references the same faces as the assembly; such
	// duplicates are dropped and not counted here.
	DetachedShapes int
	// DuplicateShapes is the number of redundant shape representations that were
	// removed: these SRs reference exactly the same face set as some SR that takes
	// part in the assembly, yet take part in no assembly relationship (converters
	// such as Datakit export this kind of extra copy). Emitting them as a root
	// would print a whole extra copy of the model at the local coordinates.
	DuplicateShapes int
	// BorrowedShapes is the number of frame SRs that borrow geometry through
	// REPRESENTATION_CONTEXT. CATIA/Datakit write the shape representation
	// referenced by an assembly as a pure coordinate frame, with the geometry in a
	// sibling representation of the same context; without this pairing the whole
	// assembly tree emits no geometry at all.
	BorrowedShapes int
	// AltReprs is the number of geometry representations discarded as "duplicate
	// representations of the same part" (among sibling representations of the same
	// group, those whose bounding box is fully contained by the authoritative one).
	AltReprs int
	// SupersededFaces is the number of faces discarded along with the duplicate
	// representations. They are not "orphan faces": they are deliberately not
	// emitted, which distinguishes "structure not understood" from "intentional
	// deduplication".
	SupersededFaces int
	// AltKeptReprs is the number of geometry representations kept because they
	// **exceed the bounding box of the authoritative one**, among sibling
	// representations of the same group; AltKeptFaces is the number of faces they
	// bring. These two are the sentinel for "did deduplication delete real
	// geometry", and should normally be far below the total face count.
	AltKeptReprs int
	AltKeptFaces int
	// BBoxMin/BBoxMax is the true bounding box in assembly coordinates;
	// RawBBox* is the untransformed bounding box of the raw vertices. When a part
	// sits far from the origin in local coordinates the two can differ by
	// hundreds of times.
	BBoxMin    Vec3
	BBoxMax    Vec3
	RawBBoxMin Vec3
	RawBBoxMax Vec3
}

// ComputeBBox estimates the model bounding box from vertex entities, used to
// derive the default tolerance.
func (g *Geom) ComputeBBox() (Vec3, Vec3) {
	min := Vec3{math.Inf(1), math.Inf(1), math.Inf(1)}
	max := Vec3{math.Inf(-1), math.Inf(-1), math.Inf(-1)}
	n := 0
	for _, id := range g.F.Order {
		e := g.F.Entities[id]
		if e.Type != "CARTESIAN_POINT" {
			continue
		}
		p, ok := g.Point(id)
		if !ok {
			continue
		}
		if !isFinite(p.X) || !isFinite(p.Y) || !isFinite(p.Z) {
			continue
		}
		min = min.Min(p)
		max = max.Max(p)
		n++
		if n > 200000 {
			break
		}
	}
	if n == 0 {
		return Vec3{}, Vec3{1, 1, 1}
	}
	return min, max
}

// asmOrderRev controls how assembly transforms are composed.
//
//	false (default): parent * child -- standard nesting semantics. The parent
//	                 pose is applied to the child's local coordinates.
//	true           : child * parent -- replicates the measured behavior of
//	                 OpenCASCADE / occt-import-js.
//
// Enable with STP2GLB_ASM_ORDER=rev. The two are equivalent for assemblies with
// no rotation or with a single level, and only diverge with multiple nested
// levels where an intermediate level carries a rotation.
var asmOrderRev = os.Getenv("STP2GLB_ASM_ORDER") == "rev"

// ---------------------------------------------------------------------------
// Assembly transforms
// ---------------------------------------------------------------------------

// SRInstance is one occurrence of a shape representation (SHAPE_REPRESENTATION)
// in the assembly tree. When the same SR is referenced by several assembly
// relationships it produces several instances, each with its own accumulated
// transform.
type SRInstance struct {
	SR    int
	Xform Mat34
}

// isShapeRepr reports whether the entity type is a "shape representation".
// CONTEXT_DEPENDENT_SHAPE_REPRESENTATION must be excluded -- it ends with
// REPRESENTATION and its name also contains SHAPE_REPRESENTATION, but it means an
// assembly relationship rather than a geometry container.
func isShapeRepr(t string) bool {
	if strings.Contains(t, "RELATIONSHIP") || strings.HasPrefix(t, "CONTEXT_DEPENDENT") {
		return false
	}
	return strings.Contains(t, "SHAPE_REPRESENTATION")
}

// srContext returns the REPRESENTATION_CONTEXT id of a shape representation.
//
// The canonical layout is SHAPE_REPRESENTATION(name, (items), context), so we
// take Ref(2) directly. But complex instances, and some converters writing the
// context at another position, leave Ref(2) empty, so we fall back further: scan
// all references for the one pointing at REPRESENTATION_CONTEXT (or a complex
// instance).
func (f *File) srContext(sr int) int {
	e := f.Entities[sr]
	if e == nil {
		return 0
	}
	isCtx := func(id int) bool {
		if id == 0 {
			return false
		}
		if f.IsComplex(id) {
			for _, sub := range f.ComplexAll(id) {
				if strings.Contains(sub.Type, "REPRESENTATION_CONTEXT") {
					return true
				}
			}
			return false
		}
		ce := f.Entities[id]
		return ce != nil && strings.Contains(ce.Type, "REPRESENTATION_CONTEXT")
	}
	if c := e.Ref(2); isCtx(c) {
		return c
	}
	for i := range e.Params {
		for _, v := range e.List(i) {
			if v.Kind == KindRef && isCtx(v.Ref) {
				return v.Ref
			}
		}
		if v := e.Params1(i); v.Kind == KindRef && isCtx(v.Ref) {
			return v.Ref
		}
	}
	return 0
}

// subsetSurf reports whether the sub set is covered by the super set.
func subsetSurf(sup, sub map[int]bool) bool {
	for k := range sub {
		if !sup[k] {
			return false
		}
	}
	return true
}

// boxContains reports whether inner is enclosed by outer (allowing tol of slack).
//
// Used to identify "another representation of the same part": a true duplicate
// representation (solid version vs surface-patch version) has an identical
// bounding box; as soon as a sibling representation sticks out of the
// authoritative box it carries geometry the authoritative one does not have and
// must be kept -- here it is better to keep by mistake than to delete by mistake.
func boxContains(outer, inner [2]Vec3, tol float64) bool {
	return inner[0].X >= outer[0].X-tol && inner[0].Y >= outer[0].Y-tol && inner[0].Z >= outer[0].Z-tol &&
		inner[1].X <= outer[1].X+tol && inner[1].Y <= outer[1].Y+tol && inner[1].Z <= outer[1].Z+tol
}

// reprRank ranks the "trustworthiness" of geometry representations, used to pick
// the authoritative one among sibling representations of the same group.
//
// ADVANCED_BREP_SHAPE_REPRESENTATION is a solid (MANIFOLD_SOLID_BREP) with the
// most complete information; MANIFOLD_SURFACE / GEOMETRICALLY_BOUNDED are the
// surface-patch version of the same part, with fewer faces and no inside/outside
// information, i.e. degraded representations. Higher is preferred.
func reprRank(f *File, sr int) int {
	e := f.Entities[sr]
	if e == nil {
		return 0
	}
	switch e.Type {
	case "ADVANCED_BREP_SHAPE_REPRESENTATION":
		return 4
	case "MANIFOLD_SURFACE_SHAPE_REPRESENTATION":
		return 3
	case "GEOMETRICALLY_BOUNDED_SURFACE_SHAPE_REPRESENTATION",
		"GEOMETRICALLY_BOUNDED_WIREFRAME_SHAPE_REPRESENTATION":
		return 2
	case "SHAPE_REPRESENTATION":
		return 1
	}
	return 0
}

// AsmStats summarizes the assembly expansion, to diagnose whether reuse really
// happens.
type AsmStats struct {
	Nodes       int // number of shape representations (SR)
	Instances   int // total number of expanded instances
	Reused      int // number of SRs with more than one instance
	Extra       int // extra instance count, sum(count-1)
	ReusedFaces int // among those, SRs with faces -- only these duplicate geometry
	Dropped     int // number of redundant copies removed
	Detached    int // shape representations not in the assembly tree, emitted at raw coordinates
	HasRel      bool
	// Borrowed is the number of frame SRs that borrow geometry through
	// REPRESENTATION_CONTEXT. CATIA/Datakit write the shape representation
	// referenced by the assembly tree as a "pure coordinate frame holding only
	// AXIS2_PLACEMENT_3D", with the geometry in a sibling representation of the
	// same context; without this pairing the whole assembly emits no geometry.
	Borrowed int
	// AltReprs is the number of geometry SRs discarded as "duplicate
	// representation of the same part" (for example the BREP solid version and the
	// surface-patch version of the same part coexist, and the latter is fully
	// contained by the bounding box of the former).
	AltReprs int
	// AltFaces is the number of faces discarded along with the duplicate
	// representations.
	AltFaces int
	// AltKept is the number of geometry SRs **kept** because, although they are
	// sibling representations of the same group, they are not enclosed by the
	// authoritative bounding box. They hold geometry the authoritative one lacks,
	// so discarding them all would lose real detail.
	AltKept int
	// AltKeptFaces is the number of faces these kept representations bring.
	AltKeptFaces int
}

// buildShapeXforms expands the assembly tree and returns **every occurrence** of
// each shape representation.
//
// Key point: a STEP assembly is "shape definition + repeated reference"; the same
// SR can be reused by N CONTEXT_DEPENDENT_SHAPE_REPRESENTATION entities (bolts,
// clamps and shims in a fixture are reused a dozen times each). So instance
// expansion is mandatory here; keeping a single pose is not enough.
//
// Return values: insts is each occurrence (with accumulated transform), itemsOf is
// the items of each SR, srFaces is the faces expanded from each SR, st is the
// assembly statistics, altFaces is the faces belonging to alternative
// representations.
func buildShapeXforms(g *Geom, shellOf map[int]int) ([]SRInstance, map[int][]int, map[int][]int, AsmStats, map[int]bool, *AsmTree) {
	f := g.F
	itemsOf := make(map[int][]int, 256)
	srIDs := make([]int, 0, 256)

	for _, id := range f.Order {
		e := f.Entities[id]
		if isShapeRepr(e.Type) {
			itemsOf[id] = e.Refs(1)
			srIDs = append(srIDs, id)
		}
	}

	// Assembly name index: pulls instance names, part names and the "shape
	// representation -> product definition" mapping out of NAUO /
	// PRODUCT_DEFINITION / SHAPE_DEFINITION_REPRESENTATION for the assembly tree.
	ix := buildAsmIndex(f)

	// Edges: parent SR -> child SR (carrying the "child -> parent" transform).
	// nauo records the assembly relationship id of this edge (0 means none), used
	// to look up node names.
	type edge struct {
		child int
		xform Mat34
		nauo  int
	}
	children := make(map[int][]edge, 256)
	isChild := make(map[int]bool, 256)
	nRel := 0

	addEdge := func(childSR, parentSR int, m Mat34, nauo int) {
		if childSR == 0 || parentSR == 0 {
			return
		}
		children[parentSR] = append(children[parentSR], edge{child: childSR, xform: m, nauo: nauo})
		isChild[childSR] = true
		nRel++
	}

	for _, id := range f.Order {
		e := f.Entities[id]
		if e.Type != "CONTEXT_DEPENDENT_SHAPE_REPRESENTATION" {
			continue
		}
		rrID := e.Ref(0)
		if rrID == 0 {
			continue
		}
		// The second parameter of each CDSR points at PRODUCT_DEFINITION_SHAPE,
		// which in turn points at an assembly relationship (NAUO). The relationship
		// carries the instance name and part name -- exactly the text shown line by
		// line in the CATIA assembly tree; measured, 137 NAUO and 137 CDSR
		// correspond one to one.
		nauo := f.nauoOfCDSR(e)
		// The relationship entity is usually a complex instance; split it to get
		// each component
		base := f.Complex(rrID, "REPRESENTATION_RELATIONSHIP")
		if base == nil {
			if b := f.Entities[rrID]; b != nil {
				base = b
			}
		}
		if base == nil {
			continue
		}
		childSR := base.Ref(2)
		parentSR := base.Ref(3)
		if childSR == 0 || parentSR == 0 {
			continue
		}
		withT := f.Complex(rrID, "REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION")
		if withT == nil {
			// No transformation operator: treat as identity but still create the
			// parent-child relation
			addEdge(childSR, parentSR, Identity(), nauo)
			continue
		}
		trID := withT.Ref(0)
		tr := f.Entities[trID]
		if tr == nil || tr.Type != "ITEM_DEFINED_TRANSFORMATION" {
			addEdge(childSR, parentSR, Identity(), nauo)
			continue
		}
		p1, ok1 := g.Placement(tr.Ref(2))
		p2, ok2 := g.Placement(tr.Ref(3))
		if !ok1 || !ok2 {
			addEdge(childSR, parentSR, Identity(), nauo)
			continue
		}
		// The transform maps the item_1 frame in child coordinates to the item_2
		// frame in parent coordinates
		m := p2.Mat().Mul(p1.Mat().InverseRigid())
		addEdge(childSR, parentSR, m, nauo)
	}

	// Faces referenced by each SR (the same SR may be instantiated many times;
	// resolve only once here)
	srFaces := make(map[int][]int, len(itemsOf))
	for sr, items := range itemsOf {
		srFaces[sr] = collectFacesFromItems(g, items, shellOf)
	}

	// Assembly graph members: a parent of some relationship and/or a child of some
	// relationship.
	inGraph := make(map[int]bool, len(srIDs))
	for sr := range itemsOf {
		if isChild[sr] || len(children[sr]) > 0 {
			inGraph[sr] = true
		}
	}

	// --- "frame SR + geometry SR" pairing --------------------------------------
	// When CATIA / Datakit export an assembly, the SHAPE_REPRESENTATION that the
	// assembly relationship (CDSR) points at is often a **pure coordinate frame**:
	// all items are AXIS2_PLACEMENT_3D and there is not a single face. The real
	// geometry sits in a **sibling representation** (ADVANCED_BREP_SHAPE_REPRESENTATION
	// wrapping MANIFOLD_SOLID_BREP, MANIFOLD_SURFACE_SHAPE_REPRESENTATION wrapping
	// SHELL_BASED_SURFACE_MODEL, GEOMETRICALLY_BOUNDED_* wrapping surfaces/wireframe).
	//
	// The two share the same local coordinate system -- verified by checking
	// whether the transforms of the same part at two assembly positions are
	// symmetric. So the frame SR should "borrow" the faces of the sibling geometry
	// and emit them with its own instance transforms. Skipping this step does not
	// just lose a little detail: **the whole assembly tree emits no geometry at
	// all** -- every frame resolves to 0 faces, only the detached geometry
	// representations are emitted with the identity transform, so a support post
	// reused 10 times appears once and a pressure face reused 12 times also appears
	// once, all at their local coordinates.
	//
	// Pairing criteria, in order of reliability:
	//   1) The explicit relationship SHAPE_REPRESENTATION_RELATIONSHIP(rep_1, rep_2).
	//      In the spec this is the association between "two representations of the
	//      same shape"; measured on a 72MB body-in-white, all 43 frames hang off
	//      the geometry through it. Which side is the frame and which is the
	//      geometry is not fixed, so decide by "has faces", which is more robust
	//      than guessing parameter positions.
	//   2) Fallback: group by the same REPRESENTATION_CONTEXT -- only used when the
	//      group has **exactly one** geometry candidate. Some exporters put the
	//      whole assembly in one context; pairing by context then hangs every part
	//      off the root frame, which must be prevented.
	//
	// One frame may have several geometry siblings. In that case we cannot simply
	// "keep only the highest priority one": measured on a 72MB body-in-white, the
	// MANIFOLD_SURFACE sibling of the same group had a bounding box 70mm larger than
	// the ADVANCED_BREP authoritative one, showing it holds surfaces the
	// authoritative one lacks -- discarding it would lose real detail (the case the
	// user reported, "only 3 of 8 posts appear", is exactly this kind of loss). The
	// rule is therefore:
	//   - the highest priority one is the authoritative representation;
	//   - the other siblings whose bounding box is **contained** by it are treated
	//     as duplicate representations of the same part and dropped;
	//   - as soon as one exceeds the authoritative bounding box it holds geometry
	//     the authoritative one lacks and is kept as well.
	// The cost is that a few parts may get an extra coincident surface layer, but no
	// geometry is ever lost.
	geoOf := make(map[int]map[int]bool, 256) // frame SR -> set of candidate geometry SRs
	addGeo := func(frame, geo int) {
		if frame == 0 || geo == 0 || frame == geo || len(srFaces[geo]) == 0 {
			return
		}
		m := geoOf[frame]
		if m == nil {
			m = make(map[int]bool, 4)
			geoOf[frame] = m
		}
		m[geo] = true
	}
	explicit := make(map[int]bool, 256) // frames that already got geometry via an explicit relation

	linkReprs := func(a, b int) {
		if a == 0 || b == 0 || a == b {
			return
		}
		fa, fb := len(srFaces[a]) > 0, len(srFaces[b]) > 0
		if fa == fb {
			return // both have faces or neither does: not a "frame<->geometry" relation
		}
		if fa {
			addGeo(b, a)
			explicit[b] = true
		} else {
			addGeo(a, b)
			explicit[a] = true
		}
	}

	// (1) Explicit relationship. SHAPE_REPRESENTATION_RELATIONSHIP(name, desc, rep_1, rep_2)
	for _, id := range f.Order {
		e := f.Entities[id]
		if e == nil {
			continue
		}
		for _, ce := range append([]*Entity{e}, f.ComplexAll(id)...) {
			if !strings.HasPrefix(ce.Type, "SHAPE_REPRESENTATION_RELATIONSHIP") {
				continue
			}
			linkReprs(ce.Ref(2), ce.Ref(3))
		}
	}

	// (2) context fallback: exactly one geometry candidate in the group, and the
	// frame has no explicit relation yet
	ctxOf := make(map[int]int, len(itemsOf))
	for sr := range itemsOf {
		ctxOf[sr] = f.srContext(sr)
	}
	byCtx := make(map[int][]int, len(itemsOf))
	for _, sr := range srIDs {
		if c := ctxOf[sr]; c != 0 {
			byCtx[c] = append(byCtx[c], sr)
		}
	}
	for _, members := range byCtx {
		if len(members) < 2 {
			continue
		}
		var geoms, frames []int
		for _, sr := range members {
			if len(srFaces[sr]) > 0 {
				geoms = append(geoms, sr)
			} else if inGraph[sr] {
				frames = append(frames, sr)
			}
		}
		if len(geoms) != 1 {
			continue // 0: nothing to borrow; 2 or more: ownership undecidable, do not pair
		}
		for _, fr := range frames {
			if explicit[fr] {
				continue
			}
			addGeo(fr, geoms[0])
			explicit[fr] = true
		}
	}

	// (3) pick geometry per frame (see the containment rule above)
	borrowed := make(map[int]int)  // frame SR -> authoritative geometry SR
	claimed := make(map[int]bool)  // geometry SRs already borrowed by a frame (no longer emitted as separate roots)
	altFaces := make(map[int]bool) // faces dropped as duplicate representations
	altDropped, altKept, altKeptFaces := 0, 0, 0

	boxCache := make(map[int][2]Vec3, 1<<13)
	boxHave := make(map[int]bool, 1<<13)
	boxOf := func(faces []int) ([2]Vec3, bool) {
		var box [2]Vec3
		got := false
		for _, fid := range faces {
			b, ok := g.faceLocalBox(fid, boxCache, boxHave)
			if !ok {
				continue
			}
			if !got {
				box, got = b, true
			} else {
				box[0], box[1] = box[0].Min(b[0]), box[1].Max(b[1])
			}
		}
		return box, got
	}
	// surfOf returns the **surface entities** referenced by a face set (the third
	// parameter of ADVANCED_FACE).
	// The hardest evidence for "another representation of the same part" is that
	// the surface set is contained: the two representations are then just the same
	// surfaces cut into different faces. Conversely, if the alternative
	// representation introduces surfaces the authoritative one lacks, it is extra
	// geometry and must never be thrown away.
	surfOf := func(faces []int) map[int]bool {
		m := make(map[int]bool, len(faces))
		for _, fid := range faces {
			if fe := f.Entities[fid]; fe != nil {
				if sid := fe.Ref(2); sid != 0 {
					m[sid] = true
				}
			}
		}
		return m
	}

	frameIDs := make([]int, 0, len(geoOf))
	for fr := range geoOf {
		frameIDs = append(frameIDs, fr)
	}
	sort.Ints(frameIDs)
	for _, fr := range frameIDs {
		cands := make([]int, 0, 4)
		for gsr := range geoOf[fr] {
			cands = append(cands, gsr)
		}
		sort.Ints(cands)
		best := cands[0]
		for _, gsr := range cands[1:] {
			if reprRank(f, gsr) > reprRank(f, best) ||
				(reprRank(f, gsr) == reprRank(f, best) && len(srFaces[gsr]) > len(srFaces[best])) {
				best = gsr
			}
		}
		keep := []int{best}
		bestBox, bestOK := boxOf(srFaces[best])
		bestSurf := surfOf(srFaces[best])
		if dbgPair {
			fmt.Fprintf(os.Stderr, "[pair] frame #%-9d has %d candidates (best #%d %s %d faces %d surfaces)\n",
				fr, len(cands), best, kindOf(f, best), len(srFaces[best]), len(bestSurf))
			for _, gsr := range cands {
				b, ok := boxOf(srFaces[gsr])
				fmt.Fprintf(os.Stderr, "[pair]    %s #%-9d %-52s faces=%-6d surfs=%-6d box=%v~%v ok=%v\n",
					map[bool]string{true: "*", false: " "}[gsr == best], gsr, kindOf(f, gsr),
					len(srFaces[gsr]), len(surfOf(srFaces[gsr])), fmtVec(b[0]), fmtVec(b[1]), ok)
			}
		}
		for _, gsr := range cands {
			if gsr == best {
				continue
			}
			b, ok := boxOf(srFaces[gsr])
			redundant := false
			if bestOK && ok {
				diag := b[1].Sub(b[0]).Len() + bestBox[1].Sub(bestBox[0]).Len()
				if boxContains(bestBox, b, diag*1e-6) {
					// Being inside the bounding box is only "suspicion" -- two shapes can
					// share a box and differ in form. By default the surface set must also
					// be covered by the authoritative one before we dare to drop it; with
					// STP2GLB_DEDUP_ALT set we fall back to the loose criterion (smaller
					// output, at your own risk).
					redundant = dedupAlt || subsetSurf(bestSurf, surfOf(srFaces[gsr]))
				}
			}
			if redundant {
				// Fully enclosed by the authoritative one and the surface set also
				// covered = another writing of the same part (typically the BREP solid
				// version and the surface-patch version coexisting). Register it
				// explicitly as "deliberately not emitted" so PlanAssembly does not
				// treat it as a detached shape and add another copy with the identity
				// transform -- otherwise every part is emitted twice (solid faces +
				// surface-patch faces), and the two coincident surface layers also
				// fight each other in the viewer.
				for _, fid := range srFaces[gsr] {
					altFaces[fid] = true
				}
				altDropped++
				continue
			}
			// Exceeds the authoritative bounding box, or introduces surfaces the
			// authoritative one lacks: it holds extra geometry and must be kept (an
			// extra coincident layer is better than lost detail).
			keep = append(keep, gsr)
			altKept++
			altKeptFaces += len(srFaces[gsr])
		}
		merged := make([]int, 0, 512)
		seenFace := make(map[int]bool, 512)
		for _, gsr := range keep {
			for _, fid := range srFaces[gsr] {
				if seenFace[fid] {
					continue
				}
				seenFace[fid] = true
				merged = append(merged, fid)
			}
		}
		if len(merged) > 0 {
			srFaces[fr] = merged
			borrowed[fr] = best
		}
		for _, gsr := range cands {
			claimed[gsr] = true
		}
	}

	// --- Redundant shape representation removal -------------------------------
	// Some converters (such as Datakit) export an extra "same geometry, same
	// context" SHAPE_REPRESENTATION copy for each part: it references the same
	// ADVANCED_FACE entities as ADVANCED_BREP_SHAPE_REPRESENTATION but appears in no
	// assembly relationship. Emitting it as a root with the identity transform
	// prints a whole extra copy of the model out of thin air at the local
	// coordinates; the typical symptom is a larger bounding box and a face count
	// higher by exactly one "unique face set".
	//
	// Criterion: when the face-set signatures are equal and the signature group has
	// a member that takes part in an assembly relationship, remove the isolated
	// members. When the file has no assembly relationship at all, nothing is
	// removed.
	dupDropped := 0
	roots := make([]int, 0, len(srIDs))
	if nRel == 0 {
		// No assembly relationship = the common single-part form
		// (SHAPE_DEFINITION_REPRESENTATION points at a pure frame and the real BREP
		// hangs off a sibling representation). Every SR is then a root, but **a
		// sibling representation whose geometry was already borrowed by a frame must
		// not be emitted again** -- otherwise the same cube gets 6 faces from the
		// frame and 6 from the sibling, doubling the triangle count.
		for _, sr := range srIDs {
			if claimed[sr] {
				continue
			}
			roots = append(roots, sr)
		}
	} else {
		sigOf := func(sr int) string {
			fl := srFaces[sr]
			if len(fl) == 0 {
				return ""
			}
			s := append([]int(nil), fl...)
			sort.Ints(s)
			var b strings.Builder
			for _, x := range s {
				b.WriteString(strconv.Itoa(x))
				b.WriteByte(',')
			}
			return b.String()
		}
		live := make(map[string]bool, len(srIDs))
		for _, sr := range srIDs {
			if inGraph[sr] {
				if sig := sigOf(sr); sig != "" {
					live[sig] = true
				}
			}
		}
		for _, sr := range srIDs {
			if isChild[sr] {
				continue
			}
			// Sibling representations whose geometry was borrowed by a frame are no
			// longer emitted as independent roots. Those "enclosed by the authoritative
			// bounding box" count as deduplicated; the rest is normal geometry merged
			// into the frame.
			if claimed[sr] {
				continue
			}
			if !inGraph[sr] {
				if sig := sigOf(sr); sig != "" && live[sig] {
					dupDropped++
					continue
				}
			}
			roots = append(roots, sr)
		}
	}

	// Walk down from the roots (SRs that never appear as a child) to expand all
	// instances.
	const depthLimit = 256
	const instanceLimit = 4000000
	insts := make([]SRInstance, 0, len(srIDs)*2)

	// The assembly tree is expanded alongside the instances: every node in the tree
	// is one instance visit here. The same traversal path is deliberately reused
	// (rather than building a second graph) so the hierarchy and transforms in the
	// tree always match the geometry, and we never get "the tree is right but the
	// parts are misplaced".
	tree := &AsmTree{Root: -1}

	var walk func(sr int, acc Mat34, depth, parent int, local Mat34, nauo int)
	walk = func(sr int, acc Mat34, depth, parent int, local Mat34, nauo int) {
		if depth > depthLimit || len(insts) >= instanceLimit {
			return
		}
		insts = append(insts, SRInstance{SR: sr, Xform: acc})

		idx := len(tree.Nodes)
		nd := AsmNode{SR: sr, Local: local, World: acc, Parent: parent}
		if r, ok := ix.relOfNAUO(nauo); ok {
			nd.InstName = r.inst
			nd.PartName = r.part
			// Take the display name from the PRODUCT name (CATIA upper-cases the NAUO
			// description as a whole, Z9_DESIGNPART_002, while the product name keeps
			// the original case), and make it match word for word the tree seen in a
			// STEP viewer -- see the comment on AsmNode.Label.
			if c := ix.nauoChild[nauo]; c != 0 {
				nd.Name = ix.productOf[c]
			}
			if nd.Name == "" {
				nd.Name = r.part
			}
		}
		if nd.Name == "" {
			nd.Name = ix.nameOfSR(sr)
		}
		if nd.Name == "" {
			nd.Name = fmt.Sprintf("shape_%d", sr)
		}
		tree.Nodes = append(tree.Nodes, nd)
		if parent >= 0 {
			tree.Nodes[parent].Children = append(tree.Nodes[parent].Children, idx)
		} else if tree.Root < 0 {
			tree.Root = idx
		}

		for _, ed := range children[sr] {
			var m Mat34
			if asmOrderRev {
				// child * parent: apply the parent pose in the child's local frame
				// first, then overlay the child's own pose
				m = ed.xform.Mul(acc)
			} else {
				// parent * child: standard nesting, the parent pose acts on the already
				// placed child coordinates
				m = acc.Mul(ed.xform)
			}
			walk(ed.child, m, depth+1, idx, ed.xform, ed.nauo)
		}
	}

	for _, sr := range roots {
		walk(sr, Identity(), 0, -1, Identity(), 0)
	}
	// Fallback: if no instance was expanded at all (cycles and the like), expand
	// everything with identity so there is output.
	if len(insts) == 0 {
		for _, sr := range srIDs {
			walk(sr, Identity(), 0, -1, Identity(), 0)
		}
	}

	// Reuse statistics: only "a SR with faces being reused" really duplicates
	// geometry; reusing an assembly container just adds a few parent-child edges.
	// Separating the two is how you can tell whether the expansion took effect.
	st := AsmStats{
		Nodes:        len(itemsOf),
		Instances:    len(insts),
		Dropped:      dupDropped,
		HasRel:       nRel > 0,
		Borrowed:     len(borrowed),
		AltReprs:     altDropped,
		AltFaces:     len(altFaces),
		AltKept:      altKept,
		AltKeptFaces: altKeptFaces,
	}
	count := make(map[int]int, len(srIDs))
	for _, in := range insts {
		count[in.SR]++
	}
	for sr, c := range count {
		if c <= 1 {
			continue
		}
		st.Reused++
		st.Extra += c - 1
		if len(srFaces[sr]) > 0 {
			st.ReusedFaces++
		}
	}

	return insts, itemsOf, srFaces, st, altFaces, tree
}

// collectFacesFromItems expands the items of an SR into a list of ADVANCED_FACE
// ids.
func collectFacesFromItems(g *Geom, items []int, shellOf map[int]int) []int {
	var faces []int
	seen := make(map[int]bool, 128)

	var addShell func(shellID int)
	addShell = func(shellID int) {
		if shellID == 0 || seen[shellID] {
			return
		}
		seen[shellID] = true
		shell := g.E(shellID)
		if shell == nil {
			return
		}
		switch shell.Type {
		case "CLOSED_SHELL", "OPEN_SHELL":
			for _, fid := range shell.Refs(1) {
				fe := g.E(fid)
				if fe == nil {
					continue
				}
				if isFaceEntity(fe.Type) {
					faces = append(faces, fid)
					shellOf[fid] = shellID
				}
			}
		case "MANIFOLD_SOLID_BREP", "BREP_WITH_VOIDS":
			addShell(shell.Ref(1))
			// With voids, the following parameters are the void shells
			for i := 2; i < len(shell.Params); i++ {
				for _, v := range shell.Params1(i).List {
					if v.Kind == KindRef {
						addShell(v.Ref)
					}
				}
			}
		case "ORIENTED_CLOSED_SHELL", "ORIENTED_OPEN_SHELL":
			// * ORIENTED_*_SHELL just adds an orientation layer to a shell; it is not
			// a face container itself.
			//
			// The parameters look like ORIENTED_CLOSED_SHELL('',*,#4222830,.F.):
			// position 0 is the name, position 1 is the derived flag *, the wrapped
			// shell is at position 2, and the last one is the orientation. We scan for
			// the first reference instead of hard-coding index 2 because some
			// exporters omit the derived parameter, and a hard-coded index would
			// yield 0.
			//
			// Why this must be handled: the voids list of BREP_WITH_VOIDS holds only
			// ORIENTED_CLOSED_SHELL entities. Without this branch those faces never
			// make it into srFaces and therefore get no instance transform, so Extract
			// finally treats them as "orphan faces not referenced by any shape
			// representation" and emits them with the **identity transform** at the
			// part's original coordinates -- visually a pile of floating fragments
			// appearing next to the model.
			//
			// Measured on a 469MB fixture (GUARD_RESULT.stp from
			// session-1784883508577): 271 void shells with **2,848 faces** were
			// dropped, which is exactly the log line "2848 faces are not referenced by
			// any shape representation"; 2,216 of them fell outside the assembly
			// bounding box, rendering as the fragments in the top-left corner the user
			// reported. After the fix these faces follow the parent part through the
			// assembly transform and land back inside the part (voids are buried in the
			// material anyway, so the outer surface looks the same).
			for i := 1; i < len(shell.Params); i++ {
				if r := shell.Ref(i); r != 0 {
					addShell(r)
					break
				}
			}
		case "SHELL_BASED_SURFACE_MODEL":
			for _, sid := range shell.Refs(1) {
				addShell(sid)
			}
		default:
			// It may also be a face directly
			if isFaceEntity(shell.Type) {
				faces = append(faces, shellID)
			}
		}
	}

	for _, it := range items {
		e := g.E(it)
		if e == nil {
			continue
		}
		if isFaceEntity(e.Type) {
			faces = append(faces, it)
			continue
		}
		addShell(it)
	}
	return faces
}

func isFaceEntity(t string) bool {
	switch t {
	case "ADVANCED_FACE", "FACE_SURFACE", "CURVE_BOUNDED_SURFACE",
		"RECTANGULAR_TRIMMED_SURFACE", "TRIMMED_FACE":
		return true
	}
	return false
}

// ---------------------------------------------------------------------------
// Face extraction
// ---------------------------------------------------------------------------

// Plan is the "structure plan" of one extraction: the assembly expansion result
// plus the true bounding box in assembly coordinates.
//
// Why it is a separate step: ComputeBBox sees the part's raw coordinates and,
// when the part sits far from the origin in its local frame, returns something far
// larger than the real assembly size (measured: one file was 500x too large).
// Deriving the chord tolerance from it makes the mesh absurdly coarse, and the
// bounding box reported in the log is wrong too. The tolerance must be based on
// the real bounding box after assembly expansion.
type Plan struct {
	g         *Geom
	insts     []SRInstance
	itemsOf   map[int][]int
	srFaces   map[int][]int
	faceViews map[int][]faceView
	shellOf   map[int]int
	Asm       AsmStats
	// Tree is the reconstructed assembly hierarchy (assembly -> sub-assembly ->
	// part instance). In a single-part model without assembly relationships it has
	// only a root node.
	Tree *AsmTree
	// altFaces are the faces of "alternative representations in the same context
	// group": they are superseded by the authoritative one and deliberately not
	// emitted, so they must not count as "orphan faces not referenced by any shape
	// representation".
	altFaces map[int]bool

	// Min/Max is the bounding box in assembly coordinates; RawMin/RawMax is the
	// untransformed bounding box of the raw vertices.
	Min, Max       Vec3
	RawMin, RawMax Vec3
}

// PlanAssembly does the structural planning: expand the assembly tree, gather
// reuse and redundancy statistics, and compute the true bounding box.
func (g *Geom) PlanAssembly() *Plan {
	p := &Plan{g: g, shellOf: make(map[int]int, 512)}
	p.insts, p.itemsOf, p.srFaces, p.Asm, p.altFaces, p.Tree = buildShapeXforms(g, p.shellOf)

	// face -> all instance views that must emit it (a reused part yields several)
	p.faceViews = make(map[int][]faceView, 1<<14)
	for _, in := range p.insts {
		fl := p.srFaces[in.SR]
		if len(fl) == 0 {
			continue
		}
		for _, fid := range fl {
			p.faceViews[fid] = append(p.faceViews[fid], faceView{Xform: in.Xform, SR: in.SR})
		}
	}

	// Shape representations the assembly tree never reached: files often list an
	// extra "standalone part representation" that directly references the same
	// MANIFOLD_SOLID_BREP as the assembly (the same ADVANCED_FACE set) but carries
	// no pose. Emitting those faces too prints a misplaced extra copy at the local
	// coordinates (typically inflating the bounding box). So only faces not covered
	// by the assembly tree are emitted here.
	coveredSR := make(map[int]bool, len(p.itemsOf))
	for _, in := range p.insts {
		coveredSR[in.SR] = true
	}
	for sr := range p.itemsOf {
		if coveredSR[sr] {
			continue
		}
		// SRs already judged redundant fall in here, but their faces must have been
		// emitted by the authoritative one, so the "only add a face that was never
		// emitted" criterion below filters them out naturally. SRs judged
		// alternative representations are skipped wholesale, to avoid emitting the
		// same part again at local coordinates.
		if p.superseded(sr) {
			continue
		}
		added := false
		for _, fid := range p.srFaces[sr] {
			if len(p.faceViews[fid]) == 0 {
				p.faceViews[fid] = append(p.faceViews[fid], faceView{Xform: Identity(), SR: sr})
				added = true
			}
		}
		if added {
			p.Asm.Detached++
		}
	}

	p.RawMin, p.RawMax = g.ComputeBBox()
	p.Min, p.Max = g.assemblyBBox(p.insts, p.srFaces)
	return p
}

// PartBase returns the base transform of each part group: the accumulated
// transform of the **first** instance of that part.
//
// The same part in an assembly is often mounted N times. The geometry only needs
// to be stored once -- vertices are baked with this base transform and the other
// instances are restored in the GLB node matrices with "instance transform *
// inverse of the base".
//
// Why not use the part's own local coordinates as the base: the origin of a
// fixture part's raw coordinate system can be extremely far from the part body
// (measured: the raw vertex bounding box diagonal of one 72MB assembly is 588
// times the assembled one), so storing float32 vertices in local coordinates
// loses precision for nothing; using assembly coordinates as the base keeps
// everything identical to before the change.
func (p *Plan) PartBase() map[int]Mat34 {
	out := make(map[int]Mat34, len(p.srFaces))
	for _, in := range p.insts {
		if len(p.srFaces[in.SR]) == 0 {
			continue
		}
		if _, ok := out[in.SR]; !ok {
			out[in.SR] = in.Xform
		}
	}
	return out
}

// superseded reports whether a shape representation was discarded wholesale by
// the "alternative representation" rule: all of its faces are registered in
// altFaces, meaning it is just another writing of the same part's authoritative
// representation.
func (p *Plan) superseded(sr int) bool {
	fl := p.srFaces[sr]
	if len(fl) == 0 {
		return false
	}
	for _, fid := range fl {
		if !p.altFaces[fid] {
			return false
		}
	}
	return true
}

// assemblyBBox maps each part's local bounding box into assembly coordinates with
// the assembly transform and unions them. Only 8 corners per part need
// transforming, so the cost scales with the number of parts and not with the face
// count.
func (g *Geom) assemblyBBox(insts []SRInstance, srFaces map[int][]int) (Vec3, Vec3) {
	cache := make(map[int][2]Vec3, 1<<11)
	have := make(map[int]bool, 1<<11)

	// Compute local boxes only for shapes the assembly tree really uses; removed
	// redundant copies need not take part.
	used := make(map[int]bool, len(srFaces))
	for _, in := range insts {
		used[in.SR] = true
	}

	local := make(map[int][2]Vec3, len(used))
	for sr := range used {
		var box [2]Vec3
		got := false
		for _, fid := range srFaces[sr] {
			b, ok := g.faceLocalBox(fid, cache, have)
			if !ok {
				continue
			}
			if !got {
				box, got = b, true
			} else {
				box[0] = box[0].Min(b[0])
				box[1] = box[1].Max(b[1])
			}
		}
		if got {
			local[sr] = box
		}
	}

	min := Vec3{math.Inf(1), math.Inf(1), math.Inf(1)}
	max := Vec3{math.Inf(-1), math.Inf(-1), math.Inf(-1)}
	got := false
	for _, in := range insts {
		b, ok := local[in.SR]
		if !ok {
			continue
		}
		for i := 0; i < 8; i++ {
			c := Vec3{X: b[i&1].X, Y: b[(i>>1)&1].Y, Z: b[(i>>2)&1].Z}
			q := in.Xform.Apply(c)
			if !isFinite(q.X) || !isFinite(q.Y) || !isFinite(q.Z) {
				continue
			}
			min, max, got = min.Min(q), max.Max(q), true
		}
	}
	if dbgBBox {
		console.Errf("[dbg] srFaces=%d insts=%d local=%d got=%v\n",
			len(srFaces), len(insts), len(local), got)
		for sr, b := range local {
			console.Errf("[dbg]   sr=#%d local=(%g,%g,%g)..(%g,%g,%g)\n",
				sr, b[0].X, b[0].Y, b[0].Z, b[1].X, b[1].Y, b[1].Z)
		}
	}
	if !got {
		return g.ComputeBBox()
	}
	return min, max
}

var dbgBBox = os.Getenv("STP2GLB_DBG_BBOX") != ""

// dbgPair, when enabled, prints the face count and local bounding box of the
// "candidate geometry" for every frame. Used when investigating "the same part has
// several sibling representations -- which one should be kept".
var dbgPair = os.Getenv("STP2GLB_DBG_PAIR") != ""

// dedupAlt loosens the "sibling representation deduplication" criterion: it only
// checks whether the bounding box is contained and no longer requires the surface
// set to be covered. Smaller output, but it risks dropping real detail as a
// duplicate; therefore off by default. Can be enabled for size comparison
// experiments.
var dedupAlt = os.Getenv("STP2GLB_DEDUP_ALT") != ""

func kindOf(f *File, id int) string {
	if e := f.Entities[id]; e != nil {
		return e.Type
	}
	return "?"
}

func fmtVec(v Vec3) string {
	return fmt.Sprintf("(%.2f,%.2f,%.2f)", v.X, v.Y, v.Z)
}

// faceLocalBox estimates the bounding box of a face in part coordinates from the
// vertices of its boundary loops. It only follows entity references and does no
// curve discretization, so it is very cheap.
func (g *Geom) faceLocalBox(fid int, cache map[int][2]Vec3, have map[int]bool) ([2]Vec3, bool) {
	if have[fid] {
		b, ok := cache[fid]
		return b, ok
	}
	have[fid] = true

	face := g.E(fid)
	if face == nil {
		return [2]Vec3{}, false
	}
	min := Vec3{math.Inf(1), math.Inf(1), math.Inf(1)}
	max := Vec3{math.Inf(-1), math.Inf(-1), math.Inf(-1)}
	got := false
	add := func(p Vec3) {
		if !isFinite(p.X) || !isFinite(p.Y) || !isFinite(p.Z) {
			return
		}
		min, max, got = min.Min(p), max.Max(p), true
	}

	// ADVANCED_FACE(name, bounds, face_geometry, same_sense)
	for _, bid := range face.Refs(1) {
		b := g.E(bid)
		if b == nil {
			continue
		}
		// FACE_BOUND / FACE_OUTER_BOUND(name, bound, orientation)
		// Note: bound is a **direct reference**, not a list, so it must be read with
		// Ref(1); a few converters write it as a list, so fall back to Refs when Ref
		// is empty.
		loops := []int{b.Ref(1)}
		if loops[0] == 0 {
			loops = b.Refs(1)
		}
		for _, lid := range loops {
			l := g.E(lid)
			if l == nil {
				continue
			}
			if l.Type == "POLY_LOOP" {
				for _, pi := range l.Refs(1) {
					if p, ok := g.Point(pi); ok {
						add(p)
					}
				}
				continue
			}
			// EDGE_LOOP(name, edge_list)
			for _, oeid := range l.Refs(1) {
				oe := g.E(oeid)
				if oe == nil {
					continue
				}
				// ORIENTED_EDGE(name, *, *, edge_element, orientation)
				ec := g.E(oe.Ref(3))
				if ec == nil {
					continue
				}
				// EDGE_CURVE(name, edge_start, edge_end, edge_geometry, same_sense)
				for _, vi := range [2]int{ec.Ref(1), ec.Ref(2)} {
					v := g.E(vi)
					if v == nil {
						continue
					}
					if p, ok := g.Point(v.Ref(1)); ok {
						add(p)
					}
				}
			}
		}
	}
	if !got {
		return [2]Vec3{}, false
	}
	cache[fid] = [2]Vec3{min, max}
	return cache[fid], true
}

// SampleOpts controls the discretization precision of B-Rep edge curves.
//
// The chord tolerance (Tol) alone is **not** enough: the tolerance of a large
// assembly is derived from the bounding box diagonal, so a 2 m class tooling part
// can get 3~4 mm, while the holes on it are only D6~D10 -- the tolerance exceeds
// the hole radius, the arc is barely subdivided, and round holes are drawn as
// diamonds/hexagons (measured on a 2000x300 plate with a hole outline written as 2
// arcs: D4 -> 3 points, D6~D30 -> 6 points).
//
// So we add a criterion independent of model scale: **the maximum swept angle Ang
// per curve segment**. This is the same idea as OpenCASCADE's angular deflection.
type SampleOpts struct {
	Tol float64 // chord tolerance (model units)
	Ang float64 // max swept angle per segment (radians); <=0 means chord only
}

// spanAngle infers the swept angle of a curve segment from "sagitta dev / chord
// length cl".
//
// For an arc of radius r and swept angle t: dev = r(1-cos(t/2)),
// cl = 2r*sin(t/2), hence dev/cl = tan(t/4)/2, i.e. t = 4*atan(2*dev/cl).
// The formula is independent of the curve type (it holds for splines and elliptic
// arcs too), so no tangent method has to be added to the Curve interface in order
// to judge the angle.
func spanAngle(dev, cl float64) float64 {
	if cl < 1e-12 {
		return math.Pi
	}
	return 4 * math.Atan(2*dev/cl)
}

// smallFeatureRatio defines a "small feature": when the straight-line distance
// between the two endpoints of an edge does not exceed this many times the chord
// tolerance, the tolerance is too coarse for that edge and chord alone reduces it
// to a few straight segments (a D6 hole -> diamond). **The angular criterion is
// only enabled for small features** -- applying 30 degrees to every edge
// multiplies the triangle count of the whole model by 4 (measured on a 72 MB
// fixture: 221k -> 870k), whereas those large-radius smooth edges are already fine
// with chord alone.
const smallFeatureRatio = 20.0

// polygonDeg is the angle that decides "this arc was squeezed into a polygon by
// the chord criterion": when the angle between adjacent polyline segments exceeds
// it, the full circle kept fewer than 9 edges. An 8-gon is 45 degrees, a 6-gon 60
// and a 4-gon 90 -- that is the range where a user can see at a glance that "it is
// not a circle".
const polygonDeg = 40.0

// smallFeature reports whether this edge is a small feature for which "the
// tolerance is too coarse".
//
// For a 2000 mm class assembly the chord tolerance taken as 0.15% of the diagonal
// can reach 3~4 mm; on a D6~D12 hole the chord criterion barely does anything and
// the whole circumference keeps only 4~6 points. Conversely, edges tens or
// hundreds of millimeters long do not have this problem, and adding the angular
// criterion for them is pure waste.
func smallFeature(chord, tol float64) bool {
	return tol <= 0 || chord <= smallFeatureRatio*tol
}

// maxTurnDeg returns the maximum angle between adjacent polyline segments
// (degrees). For a regular n-gon it is 360/n.
func maxTurnDeg(p []Vec3) float64 {
	max := 0.0
	for i := 1; i+1 < len(p); i++ {
		v1 := p[i].Sub(p[i-1])
		v2 := p[i+1].Sub(p[i])
		l1, l2 := v1.Len(), v2.Len()
		if l1 < 1e-12 || l2 < 1e-12 {
			continue
		}
		cs := v1.Dot(v2) / (l1 * l2)
		if cs > 1 {
			cs = 1
		} else if cs < -1 {
			cs = -1
		}
		if d := math.Acos(cs) * 180 / math.Pi; d > max {
			max = d
		}
	}
	return max
}

// stopRefine reports whether a curve segment is already sampled finely enough.
// It always returns false when depth < minDepth (guaranteeing a minimum number of
// levels, see the full-circle branch of sampleEdge).
func stopRefine(dev, cl float64, o SampleOpts, depth, minDepth int) bool {
	if depth < minDepth {
		return false
	}
	if dev > o.Tol {
		return false
	}
	if o.Ang <= 0 {
		return true
	}
	return spanAngle(dev, cl) <= o.Ang
}

// ExtractFaces is a convenience combination of PlanAssembly + Extract.
func (g *Geom) ExtractFaces(o SampleOpts) ([]*FaceGeom, ExtractStats) {
	return g.PlanAssembly().Extract(o)
}

// Extract turns the structure plan into a triangulatable face set for the given
// tolerance. Any single face failure only adds to the statistics and never aborts
// the whole run.
func (p *Plan) Extract(o SampleOpts) ([]*FaceGeom, ExtractStats) {
	f := p.g.F
	st := ExtractStats{}
	st.BBoxMin, st.BBoxMax = p.Min, p.Max
	st.RawBBoxMin, st.RawBBoxMax = p.RawMin, p.RawMax

	asm := p.Asm
	st.HasAssembly = asm.HasRel
	st.AssemblyNodes = asm.Nodes
	st.AssemblyInstances = asm.Instances
	st.ReusedShapes = asm.ReusedFaces
	st.ExtraInstances = asm.Extra
	st.DuplicateShapes = asm.Dropped
	st.DetachedShapes = asm.Detached
	st.BorrowedShapes = asm.Borrowed
	st.AltReprs = asm.AltReprs
	st.AltKeptReprs = asm.AltKept
	st.AltKeptFaces = asm.AltKeptFaces
	// SupersededFaces is accumulated one by one in the face loop below; it is not
	// preset here, to avoid double counting.
	// The shell count must use **deduplicated shell ids**; shellOf is keyed by face,
	// so len() would give the number of faces that have a shell and misleadingly
	// equal the face count.
	shellSet := make(map[int]struct{}, len(p.shellOf))
	for _, sid := range p.shellOf {
		shellSet[sid] = struct{}{}
	}
	st.Shells = len(shellSet)

	// Resolve each face's geometry once, then clone it per instance for emission
	out := make([]*FaceGeom, 0, 1<<15)
	for _, id := range f.Order {
		e := f.Entities[id]
		if !isFaceEntity(e.Type) {
			continue
		}
		st.FacesTotal++
		views := p.faceViews[id]
		if len(views) == 0 {
			// Faces of "alternative representations in the same context group" are
			// **deliberately** not emitted and must not be mixed into the "orphan
			// face" warning, which would falsely report an incomplete assembly
			// structure.
			if p.altFaces[id] {
				st.SupersededFaces++
				continue
			}
			views = []faceView{{Xform: Identity()}}
			st.OrphanFaces++
		}

		fg := p.g.buildFace(id, e, o)
		if fg == nil {
			st.FaceInstances += len(views)
			continue
		}
		fg.Shell = p.shellOf[id]
		fg.ID = id
		// All views in a batch necessarily share the same SR (a face belongs to only
		// one shape representation), so taking the first one will do.
		fg.Group = views[0].SR
		st.FaceInstances += len(views)
		if len(views) == 1 {
			fg.Xform = views[0].Xform
			out = append(out, fg)
			continue
		}
		// Multiple instances: share the surface and boundary loops and only swap the
		// transform. Surface/loops are transformed on demand during triangulation, so
		// a shallow copy is enough here (everything except Xform is read-only).
		for _, v := range views {
			c := *fg
			c.Xform = v.Xform
			out = append(out, &c)
		}
	}
	// The probe is placed here rather than in buildFace: Xform is only assigned in
	// the lines above, so reading it a moment earlier would give the zero matrix and
	// every centroid would be 0,0,0.
	if debugRing() {
		for _, f := range out {
			p.g.debugRingReport(f, f.Outer, f.Inners)
		}
	}
	return out, st
}

// buildFace resolves the surface and boundary loops of a single face.
func (g *Geom) buildFace(id int, e *Entity, so SampleOpts) *FaceGeom {
	// ADVANCED_FACE(name, bounds, face_geometry, same_sense)
	surfID := e.Ref(2)
	if surfID == 0 {
		return nil
	}
	surf := g.Surface(surfID)
	if surf == nil {
		return nil
	}
	fg := &FaceGeom{
		ID:          id,
		Surface:     surf,
		SameSense:   e.Bool(3),
		SurfaceType: g.typeNameOf(surfID),
	}
	if v := os.Getenv("STP2GLB_DEBUG_LOOP"); v != "" {
		debugLoopOn = v == strconv.Itoa(id)
	}

	boundRefs := e.Refs(1)
	// Record which B-Rep edges this face uses, for outline extraction. It is done
	// here (rather than after sampling) because there are several return branches
	// below and this is the only path all of them take.
	fg.Edges = g.faceEdgeIDs(boundRefs)

	// sampleBounds samples all boundary loops of this face at the given precision.
	sampleBounds := func(o SampleOpts) (marked []Vec3, candidates [][]Vec3) {
		for _, bid := range boundRefs {
			be := g.E(bid)
			if be == nil {
				continue
			}
			loopID := be.Ref(1)
			if loopID == 0 {
				continue
			}
			orientation := true
			if len(be.Params) > 2 {
				orientation = be.Bool(2)
			}
			poly := g.buildLoopPoly(loopID, orientation, o)
			if len(poly) < 2 {
				continue
			}
			if be.Type == "FACE_OUTER_BOUND" {
				marked = poly
			} else {
				candidates = append(candidates, poly)
			}
		}
		return marked, candidates
	}

	// pickOuter chooses between "there is an explicit outer-loop mark" and "take
	// the largest loop".
	pickOuter := func(marked []Vec3, candidates [][]Vec3) ([]Vec3, [][]Vec3, bool) {
		if len(marked) >= 2 {
			return marked, candidates, true
		}
		all := make([][]Vec3, 0, len(candidates)+1)
		if len(marked) >= 2 {
			all = append(all, marked)
		}
		all = append(all, candidates...)
		if len(all) == 0 {
			return nil, nil, false
		}
		best, bestScore := 0, -1.0
		for i, p := range all {
			if s := polyExtent(p); s > bestScore {
				bestScore, best = s, i
			}
		}
		inners := make([][]Vec3, 0, len(all)-1)
		for i, p := range all {
			if i != best {
				inners = append(inners, p)
			}
		}
		return all[best], inners, true
	}

	outerMarked, outerCandidates := sampleBounds(so)
	outer, inners, ok := pickOuter(outerMarked, outerCandidates)
	if !ok {
		return nil
	}
	// In a large assembly (a 70MB class tooling part, say) the global tolerance may
	// be thousands of units while a single small part is only tens of units; full
	// circle edges then degrade to 3~4 points and the loop cannot be triangulated.
	// As soon as the tolerance turns out too coarse for the face's own size, resample
	// once with a per-face tolerance.
	if ext := polyExtent(outer); ext > 0 && so.Tol > ext*0.3 {
		ft := SampleOpts{Tol: ext * 0.02, Ang: so.Ang}
		if m2, c2 := sampleBounds(ft); len(m2) > 0 || len(c2) > 0 {
			if o2, i2, ok2 := pickOuter(m2, c2); ok2 && polyExtent(o2) > 0 {
				outer, inners = o2, i2
			}
		}
	}
	fg.Outer = outer
	fg.Inners = inners

	if len(fg.Outer) < 3 {
		return nil
	}
	return fg
}

func (g *Geom) typeNameOf(id int) string {
	if e := g.E(id); e != nil {
		return e.Type
	}
	return "?"
}

func polyExtent(p []Vec3) float64 {
	if len(p) == 0 {
		return 0
	}
	mn, mx := p[0], p[0]
	for _, q := range p[1:] {
		mn = mn.Min(q)
		mx = mx.Max(q)
	}
	d := mx.Sub(mn)
	return d.X + d.Y + d.Z
}

// faceEdgeIDs collects the EDGE_CURVE ids referenced by all boundary loops of a
// face (deduplicated, order preserved).
//
// It only walks the topology and does not sample curves, so the cost is
// negligible; the real sampling is left to BuildOutline, because the same edge is
// usually referenced once by each of two adjacent faces and must be sampled only
// once after deduplication.
func (g *Geom) faceEdgeIDs(boundRefs []int) []int {
	if len(boundRefs) == 0 {
		return nil
	}
	seen := make(map[int]bool, 8)
	out := make([]int, 0, 8)
	add := func(id int) {
		if id <= 0 || seen[id] {
			return
		}
		seen[id] = true
		out = append(out, id)
	}
	for _, bid := range boundRefs {
		be := g.E(bid)
		if be == nil {
			continue
		}
		l := g.E(be.Ref(1))
		if l == nil {
			continue
		}
		// POLY_LOOP / VERTEX_LOOP have no edge curves, only polyline points or a
		// single vertex
		if l.Type != "EDGE_LOOP" {
			continue
		}
		for _, oeid := range l.Refs(1) {
			oe := g.E(oeid)
			if oe == nil {
				continue
			}
			if oe.Type == "ORIENTED_EDGE" {
				add(oe.Ref(3))
			} else {
				// Rare: the loop gives the edge entity directly
				add(oe.ID)
			}
		}
	}
	return out
}

// buildLoopPoly discretizes an EDGE_LOOP into a 3D polyline.
//
// It does not stitch the segments in the file's edge order: different CAD systems
// (CATIA / NX / SolidWorks) combine ORIENTED_EDGE orientation and EDGE_CURVE
// same_sense differently, and once one segment's direction in a loop is judged
// wrong the loop becomes self-intersecting, a "butterfly" -- after projection to
// the parameter domain it cannot be ear clipped, and adaptive subdivision forces
// it into thousands of degenerate triangles (measured: a 22 point outer loop
// produced 1984 triangles). So we chain the segments into a closed loop by
// endpoint matching instead, which is immune to those writing differences.
func (g *Geom) buildLoopPoly(loopID int, loopOrientation bool, so SampleOpts) []Vec3 {
	le := g.E(loopID)
	if le == nil {
		return nil
	}
	switch le.Type {
	case "POLY_LOOP":
		return g.pointList(le.Refs(1))
	case "VERTEX_LOOP":
		if p, ok := g.Point(le.Ref(1)); ok {
			return []Vec3{p}
		}
		return nil
	}
	oeRefs := le.Refs(1)

	segs := make([][]Vec3, 0, len(oeRefs))
	for _, oeID := range oeRefs {
		oe := g.E(oeID)
		if oe == nil {
			continue
		}
		if oe.Type != "ORIENTED_EDGE" {
			// Rare: the edge is given directly
			if seg := g.sampleEdge(oe, true, so); len(seg) >= 2 {
				segs = append(segs, seg)
			}
			continue
		}
		ec := g.E(oe.Ref(3))
		if ec == nil {
			continue
		}
		oeForward := true
		if len(oe.Params) > 4 {
			oeForward = oe.Bool(4)
		}
		ecSense := true
		if len(ec.Params) > 4 {
			ecSense = ec.Bool(4)
		}
		// Forward along the curve means the oriented edge direction matches the edge
		// curve direction
		forward := oeForward == ecSense
		seg := g.sampleEdge(ec, forward, so)
		if debugLoopOn {
			ct := "?"
			if c := g.Curve(ec.Ref(3)); c != nil {
				ct = fmt.Sprintf("%T", c)
			}
			dumpEdge(loopID, oeID, ec.ID, ct, forward, seg)
		}
		if len(seg) >= 2 {
			segs = append(segs, seg)
		}
	}

	poly := chainSegments(segs)
	poly = dropRepeatedVertices(poly)
	if !loopOrientation {
		poly = reversePoly(poly)
	}
	return poly
}

// dropRepeatedVertices removes vertices that occur more than once in a loop
// (keeping the position of the first occurrence).
//
// Some CAD systems put degenerate oriented edges into a loop: the vertices at both
// ends of an edge coincide, or a vertex shared by two adjacent faces is written
// twice. In the parameter domain these duplicated points land on different
// branches of u (the same azimuth can be reported as 0 or as 2*pi), making the
// parameter-domain polygon overlap itself; ear clipping then fails and degrades
// into thousands of tiny triangles (measured: a 22 point loop produced 1220
// triangles).
func dropRepeatedVertices(p []Vec3) []Vec3 {
	if len(p) < 4 {
		return p
	}
	// The tolerance is relative to the loop's own size (not the global model
	// scale): using the global scale on a large assembly would merge genuinely
	// adjacent vertices of small parts by mistake.
	eps := polyExtent(p) * 1e-7
	if eps < 1e-12 {
		eps = 1e-12
	}
	eps2 := eps * eps
	out := make([]Vec3, 0, len(p))
	for _, pt := range p {
		dup := false
		for i := 0; i < len(out); i++ {
			if pt.Sub(out[i]).LenSq() <= eps2 {
				dup = true
				break
			}
		}
		if !dup {
			out = append(out, pt)
		}
	}
	if len(out) < 3 {
		return p
	}
	return out
}

// chainSegments chains several polyline segments into one continuous polyline by
// endpoint matching. Each segment may be used forwards or backwards; when no match
// is found it falls back to the file order and continues, so no geometry is lost.
func chainSegments(segs [][]Vec3) []Vec3 {
	if len(segs) == 0 {
		return nil
	}
	if len(segs) == 1 {
		return append([]Vec3{}, segs[0]...)
	}
	// The endpoint matching tolerance adapts to the overall scale: in CAD the same
	// vertex usually has exactly identical coordinates, but after inverse curve
	// evaluation the end point may carry a tiny residual.
	mn, mx := segs[0][0], segs[0][0]
	for _, s := range segs {
		for _, q := range s {
			mn = mn.Min(q)
			mx = mx.Max(q)
		}
	}
	eps := mx.Sub(mn).Len() * 1e-7
	if eps < 1e-9 {
		eps = 1e-9
	}

	used := make([]bool, len(segs))
	out := append([]Vec3{}, segs[0]...)
	used[0] = true

	for n := 1; n < len(segs); n++ {
		end := out[len(out)-1]
		hit, rev := -1, false
		for i, s := range segs {
			if used[i] {
				continue
			}
			if s[0].Dist(end) <= eps {
				hit, rev = i, false
				break
			}
			if s[len(s)-1].Dist(end) <= eps {
				hit, rev = i, true
				break
			}
		}
		if hit < 0 {
			// Break: append any unused segment and continue, to avoid losing a whole
			// chunk of geometry
			for i := range segs {
				if !used[i] {
					hit = i
					break
				}
			}
			if hit < 0 {
				break
			}
		}
		s := segs[hit]
		if rev {
			s = reversePoly(s)
		}
		used[hit] = true
		out = appendPoly(out, s)
	}
	return out
}

func appendPoly(dst, seg []Vec3) []Vec3 {
	if len(seg) == 0 {
		return dst
	}
	if len(dst) == 0 {
		return append(dst, seg...)
	}
	// Drop a first point that duplicates the existing last point
	start := 0
	if dst[len(dst)-1].Dist(seg[0]) < 1e-9 {
		start = 1
	}
	return append(dst, seg[start:]...)
}

func reversePoly(p []Vec3) []Vec3 {
	out := make([]Vec3, len(p))
	for i := range p {
		out[i] = p[len(p)-1-i]
	}
	return out
}

// sampleEdge discretizes an EDGE_CURVE into a 3D polyline according to its curve
// geometry.
// With STP2GLB_DBG_ANG set it also logs one line with the actual discretization of
// that edge (curve type / chord length / point count / max adjacent-segment angle).
func (g *Geom) sampleEdge(ec *Entity, forward bool, o SampleOpts) []Vec3 {
	seg := g.sampleEdgeAng(ec, forward, o)
	if debugAngle() {
		c := g.Curve(ec.Ref(3))
		typ := "nil"
		if c != nil {
			typ = fmt.Sprintf("%T", c)
			if i := strings.LastIndexByte(typ, '.'); i >= 0 {
				typ = typ[i+1:]
			}
		}
		chord := math.Inf(1)
		if p1, ok1 := g.Point(ec.Ref(1)); ok1 {
			if p2, ok2 := g.Point(ec.Ref(2)); ok2 {
				chord = p1.Dist(p2)
			}
		}
		debugEdgeAngle(ec.ID, typ, chord, o.Tol, o.Ang, seg)
	}
	return seg
}

// sampleEdgeAng is the decision point for "should the angular criterion be added";
// it works by **two-pass sampling**:
//
//	the first pass samples by chord only, the second (only when needed) resamples
//	with the angular criterion.
//
// Why not start with the angular criterion: measured on body panels (72 MB,
// 56,444 edges), the maximum turn angle of the baseline polyline has a **bimodal
// distribution** -- 54,557 edges are <=20 degrees (chord is already fine enough),
// 1,258 are >=46 degrees (squeezed into polygons), and there is **not a single**
// edge between 20 and 30 degrees. In other words, "an edge is either round to
// begin with or visibly not round", with no grey zone in between. Applying 30
// degrees unconditionally to all small-feature edges grows the triangle count from
// 215,730 to 830,533 (3.85x) -- the extra work is wasted on edges that are already
// round enough. Resampling only the 1,258 squeezed ones fixes every problem edge.
//
// The criterion is also more portable: it looks only at the **sampled polyline**
// and does not care whether the curve in STEP is a CIRCLE, an ELLIPSE or the
// B_SPLINE_CURVE CATIA usually uses (exact NURBS circles). v1.8.1 judged by curve
// type and missed those NURBS circles entirely -- on the MMA_HB51 fixture all 964
// hole edges were BSplineCurve and every hole was drawn as a diamond.
func (g *Geom) sampleEdgeAng(ec *Entity, forward bool, o SampleOpts) []Vec3 {
	if o.Ang <= 0 {
		return g.sampleEdgeCore(ec, forward, o)
	}
	plain := o
	plain.Ang = 0
	seg := g.sampleEdgeCore(ec, forward, plain)

	// A closed edge (full circle) has minDepth=4 in the core full branch,
	// guaranteeing 16 segments, so it is never a polygon and can be skipped (when
	// chord is about 0 smallFeature is always true, which is why this guard must be
	// here).
	chord := math.Inf(1)
	if p1, ok1 := g.Point(ec.Ref(1)); ok1 {
		if p2, ok2 := g.Point(ec.Ref(2)); ok2 {
			chord = p1.Dist(p2)
		}
	}
	if !smallFeature(chord, o.Tol) || len(seg) < 3 || maxTurnDeg(seg) <= polygonDeg {
		return seg
	}
	return g.sampleEdgeCore(ec, forward, o)
}

func (g *Geom) sampleEdgeCore(ec *Entity, forward bool, o SampleOpts) []Vec3 {
	curve := g.Curve(ec.Ref(3))
	if curve == nil {
		// Curve unavailable: degrade to a straight line between the two end points
		p1, ok1 := g.Point(ec.Ref(1))
		p2, ok2 := g.Point(ec.Ref(2))
		if ok1 && ok2 && p1.Dist(p2) > 1e-12 {
			if forward {
				return []Vec3{p1, p2}
			}
			return []Vec3{p2, p1}
		}
		return nil
	}
	p1, ok1 := g.Point(ec.Ref(1))
	p2, ok2 := g.Point(ec.Ref(2))
	if !ok1 {
		p1 = Vec3{}
	}
	if !ok2 {
		p2 = Vec3{}
	}

	t0, t1 := curve.Range()
	ta, _ := curve.ClosestParam(p1, (t0+t1)/2)
	tb, _ := curve.ClosestParam(p2, (t0+t1)/2)
	if debugLoopOn {
		console.Outf("      [sample] ec=%d %T p1=%v p2=%v ta=%.6g tb=%.6g looswap=%v\n",
			ec.ID, curve, p1, p2, ta, tb, tb < ta)
	}

	// Closed edge (full circle / closed spline): start and end are the same vertex,
	// so the whole period is taken
	full := false
	chord := math.Inf(1)
	if ok1 && ok2 {
		chord = p1.Dist(p2)
	}
	if ok1 && ok2 && chord < 1e-7 {
		if curve.Periodic() {
			full = true
		}
	}
	if full {
		if !isFinite(t0) || !isFinite(t1) {
			t0, t1 = 0, 2*math.Pi
		}
		// Align the parameter start to the closest point
		base := ta
		span := t1 - t0
		pa := curve.Point(base)
		pb := curve.Point(base + span)
		// minDepth=4: a full circle is sampled into at least 16 segments. In a large
		// assembly the global tolerance may be large enough that a full circle keeps
		// only 3~4 points, and the degenerate loop cannot be triangulated.
		seg := subdivideMin(curve, base, base+span, pa, pb, o, 0, 4)
		if !forward {
			seg = reversePoly(seg)
		}
		return snapSegEnds(seg, p1, p2, ok1 && ok2)
	}

	// * Periodic curves (full circle / closed spline): **the parameter interval
	// must not be taken as min/max**.
	//
	// ClosestParam uses atan2 for circles, with range (-pi, pi]. For a short arc
	// crossing +/-pi the start and end parameters come out as +179.999 degrees and
	// -179.499 degrees (the true angle is 180.501), and min/max yields exactly the
	// **complementary arc** -- measured: a 9.18 mm short arc (CIRCLE(...,
	// 1046.97350317) in STEP) was blown up into a 359.5 degree arc, which visually
	// is an extra 2094 mm diameter disc appearing in the model out of nowhere (see
	// the "unexplained disc" section of the README).
	//
	// The right way: the arc length is determined **only by EDGE_CURVE.same_sense** --
	//   same_sense = .T.: go from edge_start to edge_end in the direction of
	//   increasing parameter;
	//   same_sense = .F.: in the direction of decreasing parameter.
	// Taking the directed increment **modulo the period** crosses the +/-pi branch
	// cut unambiguously and yields the true arc length.
	//
	// WARNING: **do not use forward**. forward = oe_orientation == same_sense mixes
	// in the ORIENTED_EDGE loop direction; the loop direction only decides the
	// **travel direction** of the polyline (which vertex is the start), not the arc
	// length. Using forward by mistake turns a short edge whose end parameters almost
	// coincide into a full circle (measured: 0.0002 rad -> 6.2830 rad) and blows the
	// model bounding box from 3605x1591x2086 up to 86743x115871x143063, worse than
	// the original bug.
	if curve.Periodic() {
		r0, r1 := curve.Range()
		period := r1 - r0
		if period > 0 {
			ecSense := true
			if len(ec.Params) > 4 {
				ecSense = ec.Bool(4)
			}
			// The polyline starts at edge_start (parameter ta) and travels d along
			// same_sense.
			d := math.Mod(tb-ta, period)
			if !ecSense {
				d = math.Mod(ta-tb, period)
			}
			if d < 0 {
				d += period
			}
			if debugArc() && !full {
				old := math.Abs(tb - ta)
				if d > old*2 || old > d*2 {
					console.Outf("[arc] ec=%d %T sense=%v forward=%v ta=%.6f tb=%.6f period=%.6f old=%.6f new=%.6f chord=%.4f\n",
						ec.ID, curve, ecSense, forward, ta, tb, period, old, d, p1.Dist(p2))
				}
			}
			// d about 0 means the start and end parameters coincide; a real full
			// circle was already handled by the full branch above, so here it can only
			// be numerical noise and we fall through to the degenerate check below.
			if d > 1e-12 {
				seg := sampleArcSpan(curve, ta, d, ecSense, o)
				// The loop direction is decided by ORIENTED_EDGE: oe_orientation ==
				// (forward == ecSense). When true the polyline is
				// edge_start -> edge_end, otherwise reversed.
				if forward != ecSense {
					seg = reversePoly(seg)
				}
				return snapSegEnds(seg, p1, p2, ok1 && ok2)
			}
		}
	}

	if !isFinite(ta) || !isFinite(tb) {
		if ok1 && ok2 {
			if forward {
				return []Vec3{p1, p2}
			}
			return []Vec3{p2, p1}
		}
		return nil
	}
	if math.Abs(tb-ta) < 1e-12 {
		if ok1 && ok2 && p1.Dist(p2) > 1e-12 {
			if forward {
				return []Vec3{p1, p2}
			}
			return []Vec3{p2, p1}
		}
		return nil
	}
	lo, hi := ta, tb
	if lo > hi {
		lo, hi = hi, lo
	}
	seg := subdivide(curve, lo, hi, curve.Point(lo), curve.Point(hi), o, 0)
	if tb < ta {
		seg = reversePoly(seg)
	}
	if !forward {
		seg = reversePoly(seg)
	}
	return snapSegEnds(seg, p1, p2, ok1 && ok2)
}

// sampleArcSpan returns the polyline of the arc that starts at parameter t0 and
// travels span in the given direction.
//
// inc true means the direction of increasing parameter (corresponding to
// EDGE_CURVE.same_sense=.T.), and the polyline then starts at t0; inc false means
// the direction of decreasing parameter, so we sample [t0-span, t0] forwards
// internally and reverse the whole thing afterwards, guaranteeing the first point
// is t0. A periodic curve may cross the +/-pi branch cut at any moment, so the
// interval is always built as "start + directed increment", never as min/max.
func sampleArcSpan(c Curve, t0, span float64, inc bool, o SampleOpts) []Vec3 {
	s, e := t0, t0+span
	if !inc {
		s, e = t0-span, t0
	}
	seg := subdivide(c, s, e, c.Point(s), c.Point(e), o, 0)
	if !inc {
		seg = reversePoly(seg)
	}
	return seg
}

// snapSegEnds snaps the two ends of the polyline back to the edge's vertex
// coordinates.
//
// The end points come from curve.Point(ClosestParam(vertex)) by inverse
// evaluation and differ from the vertex coordinates by a residual of order
// 1e-9~1e-6. Loop chaining relies on endpoint matching, and that residual makes
// matching fail, degrading to stitching in file order, after which the loop
// self-intersects and ear clipping in the parameter domain fails. Snapping is
// applied only when the residual is negligible relative to the segment size, so
// segments inverted out of place are not forced apart.
func snapSegEnds(seg []Vec3, p1, p2 Vec3, haveVerts bool) []Vec3 {
	if !haveVerts || len(seg) < 2 {
		return seg
	}
	ext := polyExtent(seg)
	lim := ext * 0.05
	if lim < 1e-12 {
		lim = 1e-12
	}
	near := func(q, a, b Vec3) Vec3 {
		da, db := q.Dist(a), q.Dist(b)
		switch {
		case da <= db && da <= lim:
			return a
		case db < da && db <= lim:
			return b
		}
		return q
	}
	seg[0] = near(seg[0], p1, p2)
	seg[len(seg)-1] = near(seg[len(seg)-1], p1, p2)
	return seg
}

// subdivide recursively subdivides a curve interval, controlled by the chord
// error.
func subdivide(c Curve, ta, tb float64, pa, pb Vec3, o SampleOpts, depth int) []Vec3 {
	return subdivideMin(c, ta, tb, pa, pb, o, depth, 0)
}

// subdivideMin also guarantees subdivision down to minDepth levels in addition to
// the chord error criterion, and falls back on "max swept angle per segment" (see
// SampleOpts). It keeps subdividing while either criterion is unmet.
func subdivideMin(c Curve, ta, tb float64, pa, pb Vec3, o SampleOpts, depth, minDepth int) []Vec3 {
	const maxDepth = 16
	tm := (ta + tb) / 2
	pm := c.Point(tm)
	// Chord error: distance from the midpoint to the chord
	chord := pb.Sub(pa)
	cl := chord.Len()
	var dev float64
	if cl < 1e-12 {
		dev = pm.Dist(pa)
	} else {
		dev = pm.Sub(pa).Cross(chord).Len() / cl
	}
	if depth >= maxDepth || stopRefine(dev, cl, o, depth, minDepth) {
		return []Vec3{pa, pb}
	}
	left := subdivideMin(c, ta, tm, pa, pm, o, depth+1, minDepth)
	right := subdivideMin(c, tm, tb, pm, pb, o, depth+1, minDepth)
	out := make([]Vec3, 0, len(left)+len(right))
	out = append(out, left...)
	out = append(out, right[1:]...)
	return out
}

// XformedSurface returns the surface with the assembly transform applied.
func (fg *FaceGeom) XformedSurface() Surface {
	if fg.Xform.IsIdentity() {
		return fg.Surface
	}
	return &XFormSurf{Base: fg.Surface, M: fg.Xform}
}

// XformedLoop returns the polyline with the assembly transform applied.
func (fg *FaceGeom) XformedLoop(p []Vec3) []Vec3 {
	if fg.Xform.IsIdentity() {
		return p
	}
	out := make([]Vec3, len(p))
	for i, q := range p {
		out[i] = fg.Xform.Apply(q)
	}
	return out
}
