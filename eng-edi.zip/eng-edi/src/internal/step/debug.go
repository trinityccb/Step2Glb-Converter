package step

import (
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"stp2glb-lite/internal/console"
)

// Debug switch: setting STP2GLB_DEBUG_FACE=<face ID> prints that face's
// parameter-domain and 3D loop information, to locate triangle density
// anomalies (for example over-tessellation caused by the seam of a periodic
// surface). Accepts comma-separated face numbers, and `*` for all faces (when
// checking whether an entire class of faces looks suspicious). With the
// environment variable unset the cost is one parse (done once per process).
var (
	debugFaceOnce sync.Once
	debugFaceID   = -1
	debugFaceAll  bool
	debugFaceSet  map[int]bool
)

func debugFace() int {
	debugFaceParse()
	return debugFaceID
}

// debugFaceMatch reports whether the given face ID is in the STP2GLB_DEBUG_FACE set.
func debugFaceMatch(id int) bool {
	debugFaceParse()
	if debugFaceAll {
		return true
	}
	return debugFaceSet[id]
}

func debugFaceParse() {
	debugFaceOnce.Do(func() {
		debugFaceSet = map[int]bool{}
		s := strings.TrimSpace(os.Getenv("STP2GLB_DEBUG_FACE"))
		if s == "" {
			return
		}
		if s == "*" {
			debugFaceAll = true
			return
		}
		for _, part := range strings.Split(s, ",") {
			if v, err := strconv.Atoi(strings.TrimSpace(part)); err == nil {
				debugFaceSet[v] = true
				if debugFaceID < 0 {
					debugFaceID = v
				}
			}
		}
	})
}

// Debug switch: when STP2GLB_DBG_HOLECOVER=1, reports per hole-carrying face
// whether the points on the hole are covered by emitted triangles -- the direct
// test for "a membrane over an area that should be cut out". With correct
// triangulation hole points land only on triangle **boundaries**; a point
// strictly inside some triangle means that triangle spans the hole.
var (
	debugHoleCoverOnce sync.Once
	debugHoleCoverOn   bool
)

func debugHoleCover() bool {
	debugHoleCoverOnce.Do(func() { debugHoleCoverOn = os.Getenv("STP2GLB_DBG_HOLECOVER") != "" })
	return debugHoleCoverOn
}

// Debug switch: when STP2GLB_DBG_HOLEAREA=1, reports the actual "ear-clipping
// area vs outer loop minus holes" values per hole-carrying face (no 2%
// threshold), to observe the distribution of the deviation.
var (
	debugHoleAreaOnce sync.Once
	debugHoleAreaOn   bool
)

func debugHoleArea() bool {
	debugHoleAreaOnce.Do(func() { debugHoleAreaOn = os.Getenv("STP2GLB_DBG_HOLEAREA") != "" })
	return debugHoleAreaOn
}

// Debug switch: when STP2GLB_DBG_AREABS=1, warns only for hole-carrying faces
// where sum|triangle area| / expected > 1.002.
//
// This is the **primary sentinel** for the "membrane" (more reliable than
// [hoarea], cleaner than [hcover]):
//   - [hoarea] uses signed area, while a membrane is positive and negative
//     triangles cancelling out, so the deviation is always 0.000%;
//   - [hcover] has an inherent false-positive floor (when a hole point lies on
//     an edge shared by two triangles, floating-point rounding yields a tiny
//     positive barycentric coordinate that looks like "inside").
//
// Correct triangulation: sum|dA|/expected = 1.000 and negative winding = 0.
var (
	debugAreaAbsOnce sync.Once
	debugAreaAbsOn   bool
)

func debugAreaAbs() bool {
	debugAreaAbsOnce.Do(func() { debugAreaAbsOn = os.Getenv("STP2GLB_DBG_AREABS") != "" })
	return debugAreaAbsOn
}

// debugLoopOn is set by buildFace while sampling the target face, used to print
// the per-edge loop stitching process.
var debugLoopOn bool

// Debug switch: when STP2GLB_DBG_HOLE=1, prints details of inner loops
// (cut-outs) whose projection fails. Discarding such a loop fills the face in,
// the typical cause of "a slab where there should be a cut-out".
var (
	debugHoleOnce sync.Once
	debugHoleOn   bool
)

func debugHole() bool {
	debugHoleOnce.Do(func() { debugHoleOn = os.Getenv("STP2GLB_DBG_HOLE") != "" })
	return debugHoleOn
}

// Debug switch: when STP2GLB_DBG_EAR=1, prints per-face ear-clipping area
// anomaly details.
var (
	debugEarOnce sync.Once
	debugEarOn   bool
)

func debugEar() bool {
	debugEarOnce.Do(func() { debugEarOn = os.Getenv("STP2GLB_DBG_EAR") != "" })
	return debugEarOn
}

// Debug switch: when STP2GLB_DBG_ARC=1, prints details of periodic curve edges
// where the arc length was picked backwards.
var (
	debugArcOnce sync.Once
	debugArcOn   bool
)

func debugArc() bool {
	debugArcOnce.Do(func() { debugArcOn = os.Getenv("STP2GLB_DBG_ARC") != "" })
	return debugArcOn
}

// Debug switch: when STP2GLB_DBG_BIG=<area>, reports "giant triangles" per face.
//
// A normal face (even a single 2-metre-long panel) never tessellates into
// absurdly large triangles; once a face emits a triangle whose area far exceeds
// its own scale, it looks like an "unidentified disc / a huge sliver spanning
// the whole machine". Such distortion almost always comes from divergent
// parameter evaluation or a misaligned index, and comparing against an area
// threshold pins the face ID directly without bisecting.
var (
	bigTriOnce sync.Once
	bigTriArea float64
)

func bigTriThresh() float64 {
	bigTriOnce.Do(func() {
		if s := os.Getenv("STP2GLB_DBG_BIG"); s != "" {
			if v, err := strconv.ParseFloat(s, 64); err == nil {
				bigTriArea = v
			}
		}
	})
	return bigTriArea
}

// bigTriFaces counts faces that produced a giant triangle (atomic: Tessellate
// runs concurrently per part).
var bigTriFaces int64

// BigTriFaceCount returns the number of faces that produced a giant triangle in
// this process.
func BigTriFaceCount() int { return int(atomic.LoadInt64(&bigTriFaces)) }

func noteBigTriFace() { atomic.AddInt64(&bigTriFaces, 1) }

// Debug switch: STP2GLB_NOFLIP_HOLES=1 disables inner loop winding
// normalisation, for A/B comparison.
var (
	noFlipOnce sync.Once
	noFlipOn   bool
)

func noFlipHoles() bool {
	noFlipOnce.Do(func() { noFlipOn = os.Getenv("STP2GLB_NOFLIP_HOLES") != "" })
	return noFlipOn
}

// earAnomalyCount counts faces where the ear-clipping area does not match the
// expectation. It must be atomic: Tessellate runs concurrently per part on
// multiple goroutines (see main.go).
var earAnomalyCount int64

// EarAnomalyCount returns the cumulative number of faces with ear-clipping area
// anomalies in this process.
func EarAnomalyCount() int { return int(atomic.LoadInt64(&earAnomalyCount)) }

func noteEarAnomaly() { atomic.AddInt64(&earAnomalyCount, 1) }

// Cumulative time per phase (nanoseconds), used to locate tessellation hot spots.
var (
	tProject, tGrid, tEar, tSubdiv, tPlanar int64
)

func addT(p *int64, d time.Duration) { atomic.AddInt64(p, int64(d)) }

// Face counts hit by the three tessellation paths. Check this ratio first when
// locating "a part got slower overall": the grid path (structured gridding) and
// the ear-clipping path differ in speed by one to two orders of magnitude.
var pathGrid, pathEar, pathPlanar int64

func notePath(kind int) {
	switch kind {
	case 0:
		atomic.AddInt64(&pathGrid, 1)
	case 1:
		atomic.AddInt64(&pathEar, 1)
	default:
		atomic.AddInt64(&pathPlanar, 1)
	}
}

// PathCounts returns (grid faces, ear-clipping faces, planar fallback faces).
func PathCounts() (grid, ear, planar int) {
	return int(atomic.LoadInt64(&pathGrid)), int(atomic.LoadInt64(&pathEar)), int(atomic.LoadInt64(&pathPlanar))
}

// PhaseTimes returns the cumulative time per phase for the caller to summarise
// and print.
func PhaseTimes() (proj, grid, ear, subdiv, planar time.Duration) {
	return time.Duration(atomic.LoadInt64(&tProject)),
		time.Duration(atomic.LoadInt64(&tGrid)),
		time.Duration(atomic.LoadInt64(&tEar)),
		time.Duration(atomic.LoadInt64(&tSubdiv)),
		time.Duration(atomic.LoadInt64(&tPlanar))
}

// dumpHole prints one inner loop processing record.
func dumpHole(fid int, stage, why string, poly []Vec3, uvErr bool) {
	mark := "kept"
	if uvErr {
		mark = "discarded"
	}
	console.Outf("[hole] face #%d inner loop %s: %s -> %s (3D extent %.3f, loop points %d)\n",
		fid, stage, why, mark, polyExtent(poly), len(poly))
}

// dumpEdge prints the sample result of a single oriented edge, used to locate
// loop stitching anomalies.
func dumpEdge(loopID, oeID, ecID int, typ string, forward bool, seg []Vec3) {
	p := func(v Vec3) string {
		return fmt.Sprintf("(%.3f,%.3f,%.3f)", v.X, v.Y, v.Z)
	}
	head, tail := "", ""
	if len(seg) > 0 {
		head = p(seg[0])
	}
	if len(seg) > 1 {
		tail = p(seg[len(seg)-1])
	}
	console.Outf("[edge] loop=%d oe=%d ec=%d %s forward=%v n=%d %s -> %s\n",
		loopID, oeID, ecID, typ, forward, len(seg), head, tail)
}

// Debug switch: STP2GLB_SKIP_FACES=1,2,3 skips the given faces, to determine
// whether a face is the source of a problem.
var (
	skipOnce sync.Once
	skipSet  map[int]bool
)

func skipFace(id int) bool {
	skipOnce.Do(func() {
		skipSet = map[int]bool{}
		for _, s := range strings.Split(os.Getenv("STP2GLB_SKIP_FACES"), ",") {
			if v, err := strconv.Atoi(strings.TrimSpace(s)); err == nil {
				skipSet[v] = true
			}
		}
	})
	return skipSet[id]
}

// dumpFaces writes each face's id / surface type / loop counts / bounding box /
// triangle count as TSV, so a suspicious piece of geometry can be traced back to
// its STEP face by "largest bounding box".
// Triggered by STP2GLB_DUMP_FACES=<output path>.
func dumpFaces(path string, faces []*FaceGeom, st *TessStats) {
	// Tessellate is called in batches per part, so append rather than overwrite.
	needHead := true
	if fi, err := os.Stat(path); err == nil && fi.Size() > 0 {
		needHead = false
	}
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		console.Outf("[dump] cannot write %s: %v\n", path, err)
		return
	}
	defer f.Close()
	if needHead {
		fmt.Fprintf(f, "id\tsurface\tnOuter\tnInner\tnTris\textX\textY\textZ\tx0\ty0\tz0\tx1\ty1\tz1\n")
	}
	for _, fg := range faces {
		o := fg.XformedLoop(fg.Outer)
		var mn, mx Vec3
		if len(o) > 0 {
			mn, mx = o[0], o[0]
			for _, q := range o[1:] {
				mn = mn.Min(q)
				mx = mx.Max(q)
			}
		}
		d := mx.Sub(mn)
		fmt.Fprintf(f, "%d\t%s\t%d\t%d\t%d\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\n",
			fg.ID, fg.SurfaceType, len(fg.Outer), len(fg.Inners), st.FaceTris[fg.ID],
			d.X, d.Y, d.Z, mn.X, mn.Y, mn.Z, mx.X, mx.Y, mx.Z)
	}
	console.Outf("[dump] wrote %d faces -> %s\n", len(faces), path)
}

// dumpParamLoops prints each loop's UV bounding box and 3D bounding box, plus
// suspicious edges with "large UV span but small 3D span" (a periodic seam
// signature).
func dumpParamLoops(id int, loops []paramLoop) {
	b := func(f float64) string { return fmt.Sprintf("%.4g", f) }
	e := func(p []Vec3) (Vec3, Vec3) {
		mn := Vec3{math.Inf(1), math.Inf(1), math.Inf(1)}
		mx := Vec3{math.Inf(-1), math.Inf(-1), math.Inf(-1)}
		for _, q := range p {
			mn.X, mn.Y, mn.Z = math.Min(mn.X, q.X), math.Min(mn.Y, q.Y), math.Min(mn.Z, q.Z)
			mx.X, mx.Y, mx.Z = math.Max(mx.X, q.X), math.Max(mx.Y, q.Y), math.Max(mx.Z, q.Z)
		}
		return mn, mx
	}
	console.Outf("[dbg face %d] %d loops\n", id, len(loops))
	for li, l := range loops {
		umn, umx := math.Inf(1), math.Inf(-1)
		vmn, vmx := math.Inf(1), math.Inf(-1)
		for _, q := range l.UV {
			umn, umx = math.Min(umn, q.X), math.Max(umx, q.X)
			vmn, vmx = math.Min(vmn, q.Y), math.Max(vmx, q.Y)
		}
		mn, mx := e(l.P)
		console.Outf("  loop%d points %d  u=[%s,%s](span %s) v=[%s,%s](span %s)\n",
			li, len(l.UV), b(umn), b(umx), b(umx-umn), b(vmn), b(vmx), b(vmx-vmn))
		console.Outf("        3D range (%s,%s,%s)~(%s,%s,%s) size %sx%sx%s\n",
			b(mn.X), b(mn.Y), b(mn.Z), b(mx.X), b(mx.Y), b(mx.Z),
			b(mx.X-mn.X), b(mx.Y-mn.Y), b(mx.Z-mn.Z))
		// Check per edge: UV span vs 3D length, to find edges torn apart by the seam
		nCross, nEdge, maxUV, maxLen := 0, 0, 0.0, 0.0
		for i := 0; i < len(l.UV); i++ {
			j := (i + 1) % len(l.UV)
			du := math.Abs(l.UV[j].X - l.UV[i].X)
			dv := math.Abs(l.UV[j].Y - l.UV[i].Y)
			dl := l.P[j].Dist(l.P[i])
			uv := math.Max(du, dv)
			nEdge++
			if uv > maxUV {
				maxUV = uv
			}
			if dl > maxLen {
				maxLen = dl
			}
			if uv > 1.5 && dl < 1e-6 {
				nCross++
			}
		}
		console.Outf("        edges %d  max param span %s  max 3D edge length %s  edges torn by seam %d\n",
			nEdge, b(maxUV), b(maxLen), nCross)
		for i := 0; i < len(l.UV); i++ {
			j := (i + 1) % len(l.UV)
			du := math.Abs(l.UV[j].X - l.UV[i].X)
			dv := math.Abs(l.UV[j].Y - l.UV[i].Y)
			dl := l.P[j].Dist(l.P[i])
			if math.Max(du, dv) > 1.5 {
				console.Outf("        - edge %d->%d  dUV=(%s,%s) 3D length %s\n",
					i, j, b(l.UV[j].X-l.UV[i].X), b(l.UV[j].Y-l.UV[i].Y), b(dl))
			}
		}
		if os.Getenv("STP2GLB_DEBUG_RAW") != "" {
			for i := range l.UV {
				console.Outf("        #%2d u=%+.6f v=%+.6f  P=(%.4f,%.4f,%.4f)\n",
					i, l.UV[i].X, l.UV[i].Y, l.P[i].X, l.P[i].Y, l.P[i].Z)
			}
		}
	}
}

// Debug switch: when STP2GLB_DBG_ANG=1, reports the actual discretisation of
// each edge after sampling: curve type, whole-edge chord length, chord
// tolerance, final point count, maximum angle between adjacent segments.
// Purpose: for "a round hole drawn as a diamond", find which gate blocked it --
// whether the curve is not CIRCLE/ELLIPSE at all (rejected by isConicCurve),
// or the whole edge is too long and treated as a "large feature" (rejected by
// smallFeatureRatio).
var (
	dbgAngOnce sync.Once
	dbgAngOn   bool
	dbgAngMu   sync.Mutex
	dbgAngSeen map[int]bool
)

func debugAngle() bool {
	dbgAngOnce.Do(func() {
		dbgAngOn = os.Getenv("STP2GLB_DBG_ANG") != ""
		dbgAngSeen = make(map[int]bool, 4096)
	})
	return dbgAngOn
}

// debugEdgeAngle computes the maximum angle between adjacent segments of the
// polyline (360/n for a regular n-gon).
func debugEdgeAngle(id int, typeName string, chord, tol, angIn float64, pts []Vec3) {
	dbgAngMu.Lock()
	if dbgAngSeen[id] {
		dbgAngMu.Unlock()
		return
	}
	dbgAngSeen[id] = true
	dbgAngMu.Unlock()

	maxDeg := 0.0
	for i := 1; i+1 < len(pts); i++ {
		v1 := pts[i].Sub(pts[i-1])
		v2 := pts[i+1].Sub(pts[i])
		l1, l2 := v1.Len(), v2.Len()
		if l1 < 1e-12 || l2 < 1e-12 {
			continue
		}
		cs := v1.Dot(v2) / (l1 * l2)
		if cs > 1 {
			cs = 1
		} else if cs < -1 {
			cs = -1
		}
		if d := math.Acos(cs) * 180 / math.Pi; d > maxDeg {
			maxDeg = d
		}
	}
	fmt.Fprintf(os.Stderr, "[ang] id=%d type=%s chord=%.4f tol=%.4f ang=%.1f pts=%d maxdeg=%.2f\n",
		id, typeName, chord, tol, angIn*180/math.Pi, len(pts), maxDeg)
}

// Debug switch: when STP2GLB_DBG_RING=1, reports faces whose boundary loop is
// still sampled as a polygon, with the loop's world-space centroid. Used to
// locate where in the model "round holes became diamonds" (the coordinates are
// needed for --frame cropping when producing A/B comparison images).
var (
	dbgRingOnce sync.Once
	dbgRingOn   bool
)

func debugRing() bool {
	dbgRingOnce.Do(func() { dbgRingOn = os.Getenv("STP2GLB_DBG_RING") != "" })
	return dbgRingOn
}

func (g *Geom) debugRingReport(fg *FaceGeom, outer []Vec3, inners [][]Vec3) {
	if !debugRing() {
		return
	}
	loops := make([][]Vec3, 0, len(inners)+1)
	loops = append(loops, outer)
	loops = append(loops, inners...)
	for _, lp := range loops {
		if len(lp) < 3 {
			continue
		}
		if d := maxTurnDeg(lp); d > polygonDeg {
			var c Vec3
			for _, p := range lp {
				c = c.Add(fg.Xform.Apply(p))
			}
			c = c.Mul(1.0 / float64(len(lp)))
			console.Outf("[ring] face=%d pts=%d maxdeg=%.1f center=%.1f,%.1f,%.1f\n",
				fg.ID, len(lp), d, c.X, c.Y, c.Z)
		}
	}
}
