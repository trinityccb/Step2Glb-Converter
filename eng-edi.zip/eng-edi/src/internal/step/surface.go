package step

import "math"

// Surface is an evaluable parametric surface. u/v are the natural surface
// parameters.
type Surface interface {
	Point(u, v float64) Vec3
	// D1 returns the point and its first partial derivatives in u and v, used for
	// normals and numerical projection.
	D1(u, v float64) (p, du, dv Vec3)
	// RangeU / RangeV return the valid parameter intervals; a periodic direction
	// spans 2*pi.
	RangeU() (float64, float64)
	RangeV() (float64, float64)
	// Project maps a 3D point back to the parameter domain, guess being the initial hint.
	Project(p Vec3, gu, gv float64) (u, v float64, ok bool)
	PeriodicU() bool
	PeriodicV() bool
}

// ---------------------------------------------------------------------------
// Plane
// ---------------------------------------------------------------------------

// PlaneSurf is PLANE: P(u,v) = O + u*X + v*Y.
type PlaneSurf struct {
	Pl Placement
}

func (s *PlaneSurf) Point(u, v float64) Vec3 {
	return s.Pl.Origin.Add(s.Pl.X.Mul(u)).Add(s.Pl.Y().Mul(v))
}

func (s *PlaneSurf) D1(u, v float64) (Vec3, Vec3, Vec3) {
	return s.Point(u, v), s.Pl.X, s.Pl.Y()
}

func (s *PlaneSurf) RangeU() (float64, float64) { return math.Inf(-1), math.Inf(1) }
func (s *PlaneSurf) RangeV() (float64, float64) { return math.Inf(-1), math.Inf(1) }
func (s *PlaneSurf) PeriodicU() bool            { return false }
func (s *PlaneSurf) PeriodicV() bool            { return false }

func (s *PlaneSurf) Project(p Vec3, gu, gv float64) (float64, float64, bool) {
	rel := p.Sub(s.Pl.Origin)
	return rel.Dot(s.Pl.X), rel.Dot(s.Pl.Y()), true
}

// ---------------------------------------------------------------------------
// Cylinder
// ---------------------------------------------------------------------------

// CylSurf is CYLINDRICAL_SURFACE: P(u,v) = O + R*(cos u * X + sin u * Y) + v*Z.
type CylSurf struct {
	Pl     Placement
	Radius float64
}

func (s *CylSurf) Point(u, v float64) Vec3 {
	c, sn := math.Cos(u), math.Sin(u)
	y := s.Pl.Y()
	radial := s.Pl.X.Mul(c).Add(y.Mul(sn))
	return s.Pl.Origin.Add(radial.Mul(s.Radius)).Add(s.Pl.Z.Mul(v))
}

func (s *CylSurf) D1(u, v float64) (Vec3, Vec3, Vec3) {
	c, sn := math.Cos(u), math.Sin(u)
	y := s.Pl.Y()
	tangent := y.Mul(c).Sub(s.Pl.X.Mul(sn)).Mul(s.Radius)
	return s.Point(u, v), tangent, s.Pl.Z
}

func (s *CylSurf) RangeU() (float64, float64) { return 0, 2 * math.Pi }
func (s *CylSurf) RangeV() (float64, float64) { return math.Inf(-1), math.Inf(1) }
func (s *CylSurf) PeriodicU() bool            { return true }
func (s *CylSurf) PeriodicV() bool            { return false }

func (s *CylSurf) Project(p Vec3, gu, gv float64) (float64, float64, bool) {
	rel := p.Sub(s.Pl.Origin)
	y := s.Pl.Y()
	return math.Atan2(rel.Dot(y), rel.Dot(s.Pl.X)), rel.Dot(s.Pl.Z), true
}

// ---------------------------------------------------------------------------
// Cone
// ---------------------------------------------------------------------------

// ConeSurf is CONICAL_SURFACE. The half angle is measured from the Z axis.
type ConeSurf struct {
	Pl        Placement
	Radius    float64
	SemiAngle float64
}

func (s *ConeSurf) radiusAt(v float64) float64 {
	return s.Radius + v*math.Tan(s.SemiAngle)
}

func (s *ConeSurf) Point(u, v float64) Vec3 {
	c, sn := math.Cos(u), math.Sin(u)
	y := s.Pl.Y()
	radial := s.Pl.X.Mul(c).Add(y.Mul(sn))
	return s.Pl.Origin.Add(radial.Mul(s.radiusAt(v))).Add(s.Pl.Z.Mul(v))
}

func (s *ConeSurf) D1(u, v float64) (Vec3, Vec3, Vec3) {
	c, sn := math.Cos(u), math.Sin(u)
	y := s.Pl.Y()
	radial := s.Pl.X.Mul(c).Add(y.Mul(sn))
	tangential := y.Mul(c).Sub(s.Pl.X.Mul(sn))
	r := s.radiusAt(v)
	ta := math.Tan(s.SemiAngle)
	return s.Point(u, v), tangential.Mul(r), radial.Mul(ta).Add(s.Pl.Z)
}

func (s *ConeSurf) RangeU() (float64, float64) { return 0, 2 * math.Pi }
func (s *ConeSurf) RangeV() (float64, float64) { return math.Inf(-1), math.Inf(1) }
func (s *ConeSurf) PeriodicU() bool            { return true }
func (s *ConeSurf) PeriodicV() bool            { return false }

func (s *ConeSurf) Project(p Vec3, gu, gv float64) (float64, float64, bool) {
	rel := p.Sub(s.Pl.Origin)
	y := s.Pl.Y()
	u := math.Atan2(rel.Dot(y), rel.Dot(s.Pl.X))
	axial := rel.Dot(s.Pl.Z)
	radialDist := rel.Sub(s.Pl.Z.Mul(axial)).Len()
	ta := math.Tan(s.SemiAngle)
	if math.Abs(ta) < 1e-12 {
		return u, axial, true // half angle 0, degenerates to a cylinder
	}
	// In the (radial, axial) plane the generatrix is radial = R + v*ta,
	// axial = v. Orthogonally projecting the point onto this line gives v;
	// dropping the R term adds a systematic ta*R/(1+ta^2) bias, which makes
	// projection fail outright on cones with a large radius.
	v := (ta*(radialDist-s.Radius) + axial) / (1 + ta*ta)
	return u, v, true
}

// ---------------------------------------------------------------------------
// Sphere
// ---------------------------------------------------------------------------

// SphereSurf is SPHERICAL_SURFACE; v runs from -pi/2 to pi/2.
type SphereSurf struct {
	Pl     Placement
	Radius float64
}

func (s *SphereSurf) Point(u, v float64) Vec3 {
	cv, sv := math.Cos(v), math.Sin(v)
	cu, su := math.Cos(u), math.Sin(u)
	y := s.Pl.Y()
	radial := s.Pl.X.Mul(cu).Add(y.Mul(su)).Mul(cv)
	return s.Pl.Origin.Add(radial.Mul(s.Radius)).Add(s.Pl.Z.Mul(sv * s.Radius))
}

func (s *SphereSurf) D1(u, v float64) (Vec3, Vec3, Vec3) {
	cv, sv := math.Cos(v), math.Sin(v)
	cu, su := math.Cos(u), math.Sin(u)
	y := s.Pl.Y()
	tangU := y.Mul(cu).Sub(s.Pl.X.Mul(su)).Mul(cv * s.Radius)
	tangV := s.Pl.X.Mul(cu).Add(y.Mul(su)).Mul(-sv * s.Radius).Add(s.Pl.Z.Mul(cv * s.Radius))
	return s.Point(u, v), tangU, tangV
}

func (s *SphereSurf) RangeU() (float64, float64) { return 0, 2 * math.Pi }
func (s *SphereSurf) RangeV() (float64, float64) { return -math.Pi / 2, math.Pi / 2 }
func (s *SphereSurf) PeriodicU() bool            { return true }
func (s *SphereSurf) PeriodicV() bool            { return false }

func (s *SphereSurf) Project(p Vec3, gu, gv float64) (float64, float64, bool) {
	rel := p.Sub(s.Pl.Origin)
	if rel.Len() < 1e-15 {
		return gu, gv, false
	}
	y := s.Pl.Y()
	u := math.Atan2(rel.Dot(y), rel.Dot(s.Pl.X))
	v := math.Asin(clampF(rel.Dot(s.Pl.Z)/rel.Len(), -1, 1))
	return u, v, true
}

// ---------------------------------------------------------------------------
// Torus
// ---------------------------------------------------------------------------

// TorusSurf is TOROIDAL_SURFACE. Major is the ring radius, Minor the tube radius.
type TorusSurf struct {
	Pl           Placement
	Major, Minor float64
}

func (s *TorusSurf) Point(u, v float64) Vec3 {
	cv, sv := math.Cos(v), math.Sin(v)
	cu, su := math.Cos(u), math.Sin(u)
	y := s.Pl.Y()
	radial := s.Pl.X.Mul(cu).Add(y.Mul(su))
	r := s.Major + s.Minor*cv
	return s.Pl.Origin.Add(radial.Mul(r)).Add(s.Pl.Z.Mul(s.Minor * sv))
}

func (s *TorusSurf) D1(u, v float64) (Vec3, Vec3, Vec3) {
	cv, sv := math.Cos(v), math.Sin(v)
	cu, su := math.Cos(u), math.Sin(u)
	y := s.Pl.Y()
	radial := s.Pl.X.Mul(cu).Add(y.Mul(su))
	circum := y.Mul(cu).Sub(s.Pl.X.Mul(su))
	r := s.Major + s.Minor*cv
	tangU := circum.Mul(r)
	tangV := radial.Mul(-s.Minor * sv).Add(s.Pl.Z.Mul(s.Minor * cv))
	return s.Point(u, v), tangU, tangV
}

func (s *TorusSurf) RangeU() (float64, float64) { return 0, 2 * math.Pi }
func (s *TorusSurf) RangeV() (float64, float64) { return 0, 2 * math.Pi }
func (s *TorusSurf) PeriodicU() bool            { return true }
func (s *TorusSurf) PeriodicV() bool            { return true }

func (s *TorusSurf) Project(p Vec3, gu, gv float64) (float64, float64, bool) {
	rel := p.Sub(s.Pl.Origin)
	y := s.Pl.Y()
	u := math.Atan2(rel.Dot(y), rel.Dot(s.Pl.X))
	axial := rel.Dot(s.Pl.Z)
	radialDist := rel.Sub(s.Pl.Z.Mul(axial)).Len()
	dr := radialDist - s.Major
	v := math.Atan2(axial, dr)
	return u, v, true
}

// ---------------------------------------------------------------------------
// B-spline surface
// ---------------------------------------------------------------------------

// BSplineSurf is a bivariate B-spline (rational variant supported).
// CP is stored as [i][j], i along u and j along v, matching STEP's
// control_points_list.
type BSplineSurf struct {
	DegU, DegV int
	KnotsU     []float64
	KnotsV     []float64
	CP         [][]Vec3
	W          [][]float64 // weights, nil means non-rational
	ClosedU    bool
	ClosedV    bool
	// Tol is the residual limit Project accepts, scaled to the control point
	// bounding box.
	Tol float64
}

func (s *BSplineSurf) RangeU() (float64, float64) {
	if len(s.KnotsU) < 2 {
		return 0, 1
	}
	return s.KnotsU[0], s.KnotsU[len(s.KnotsU)-1]
}

func (s *BSplineSurf) RangeV() (float64, float64) {
	if len(s.KnotsV) < 2 {
		return 0, 1
	}
	return s.KnotsV[0], s.KnotsV[len(s.KnotsV)-1]
}

func (s *BSplineSurf) PeriodicU() bool { return s.ClosedU }
func (s *BSplineSurf) PeriodicV() bool { return s.ClosedV }

// maxSplineDeg is the highest degree the fast path supports. STEP surfaces
// rarely exceed degree 5; 8 leaves headroom for unusual splines, and anything
// higher falls back to pointSlow.
const maxSplineDeg = 8

// Point evaluates with the tensor-product de Boor scheme: contract along u,
// then along v.
//
// This is the hottest function in the whole tessellation: each emitted triangle
// needs 3 normals (5 Point calls each), plus 4-7 calls per adaptive subdivision
// test. So it must be **zero heap allocation** and touch only the small block of
// control points that actually contributes.
//
// The original implementation had two fatal wastes; a single face of a 21MB
// fixture part burned 9.4s:
//  1. `col := make([]Vec4, nv)` + one `make([]Vec4, pu+1)` per column + another
//     inside deBoorVec4 -- that is nv+2 heap allocations per Point call (nv can
//     reach several dozen).
//  2. Along u it contracted the whole row of nv columns, whereas a
//     tensor-product surface at (u,v) has non-zero basis functions only for the
//     (pu+1)x(pv+1) control points i in [ku-pu,ku], j in [kv-pv,kv].
func (s *BSplineSurf) Point(u, v float64) Vec3 {
	nu := len(s.CP)
	if nu == 0 {
		return Vec3{}
	}
	nv := len(s.CP[0])
	if nv == 0 {
		return Vec3{}
	}
	pu, pv := s.DegU, s.DegV
	if pu > nu-1 {
		pu = nu - 1
	}
	if pv > nv-1 {
		pv = nv - 1
	}
	if pu < 0 || pv < 0 {
		return Vec3{}
	}
	// When the knot vector length does not match what de Boor expects, the
	// original implementation degraded (deBoorVec4 returned column 0). Such
	// malformed input goes to pointSlow so behaviour stays bit-for-bit identical.
	if len(s.KnotsU) != nu+pu+1 || len(s.KnotsV) != nv+pv+1 ||
		pu >= maxSplineDeg || pv >= maxSplineDeg {
		return s.pointSlow(u, v, pu, pv)
	}

	u0, u1 := s.RangeU()
	if u < u0 {
		u = u0
	} else if u > u1 {
		u = u1
	}
	// Same as the original deBoorVec4: v is clamped to the ends of the knot
	// vector's "usable span".
	v0, v1 := knotAt(s.KnotsV, pv), knotAt(s.KnotsV, nv)
	if v < v0 {
		v = v0
	} else if v > v1 {
		v = v1
	}

	ku := findSpan(nu-1, pu, u, s.KnotsU)
	kv := findSpan(nv-1, pv, v, s.KnotsV)

	var col, d [maxSplineDeg]Vec4
	for t := 0; t <= pv; t++ {
		j := kv - pv + t
		if j < 0 {
			j = 0
		} else if j > nv-1 {
			j = nv - 1
		}
		for r := 0; r <= pu; r++ {
			i := ku - pu + r
			if i < 0 {
				i = 0
			} else if i > nu-1 {
				i = nu - 1
			}
			w := 1.0
			if s.W != nil {
				w = s.W[i][j]
			}
			q := s.CP[i][j]
			d[r] = Vec4{q.X * w, q.Y * w, q.Z * w, w}
		}
		deBoor1d(d[:pu+1], pu, u, s.KnotsU, ku)
		col[t] = d[pu]
	}
	deBoor1d(col[:pv+1], pv, v, s.KnotsV, kv)
	res := col[pv]
	if math.Abs(res.W) > 1e-15 {
		return Vec3{res.X / res.W, res.Y / res.W, res.Z / res.W}
	}
	return Vec3{res.X, res.Y, res.Z}
}

// pointSlow is the original Point implementation (per-column contraction with
// heap allocation), used only for malformed knot vectors or excessive degree.
func (s *BSplineSurf) pointSlow(u, v float64, pu, pv int) Vec3 {
	nu := len(s.CP)
	nv := len(s.CP[0])
	col := make([]Vec4, nv)
	u0, u1 := s.RangeU()
	if u < u0 {
		u = u0
	}
	if u > u1 {
		u = u1
	}
	ku := findSpan(nu-1, pu, u, s.KnotsU)
	for j := 0; j < nv; j++ {
		col[j] = s.deBoorU(ku, pu, u, j)
	}
	return deBoorVec4(col, pv, v, s.KnotsV)
}

// deBoor1d runs one 1D de Boor evaluation over pts[0..p] (modifying pts in place).
// k is the result of findSpan(len(pts)-1, p, t, knots); knot indices are absolute.
// This is the common kernel of the old deBoorU / deBoorVec4, factored out for
// reuse without heap allocation.
func deBoor1d(pts []Vec4, p int, t float64, knots []float64, k int) {
	for r := 1; r <= p; r++ {
		for m := p; m >= r; m-- {
			i := k - p + m
			lo := knotAt(knots, i)
			hi := knotAt(knots, i+p-r+1)
			alpha := 0.0
			if math.Abs(hi-lo) > 1e-15 {
				alpha = (t - lo) / (hi - lo)
			}
			pts[m] = pts[m-1].Mul(1 - alpha).Add(pts[m].Mul(alpha))
		}
	}
}

// deBoorU evaluates column j of the control points along u and returns a
// homogeneous point.
func (s *BSplineSurf) deBoorU(ku, pu int, u float64, j int) Vec4 {
	nu := len(s.CP)
	d := make([]Vec4, pu+1)
	for r := 0; r <= pu; r++ {
		idx := ku - pu + r
		if idx < 0 {
			idx = 0
		}
		if idx > nu-1 {
			idx = nu - 1
		}
		w := 1.0
		if s.W != nil {
			w = s.W[idx][j]
		}
		p := s.CP[idx][j]
		d[r] = Vec4{p.X * w, p.Y * w, p.Z * w, w}
	}
	U := s.KnotsU
	for r := 1; r <= pu; r++ {
		for m := pu; m >= r; m-- {
			i := ku - pu + m
			lo := knotAt(U, i)
			hi := knotAt(U, i+pu-r+1)
			alpha := 0.0
			if math.Abs(hi-lo) > 1e-15 {
				alpha = (u - lo) / (hi - lo)
			}
			d[m] = d[m-1].Mul(1 - alpha).Add(d[m].Mul(alpha))
		}
	}
	return d[pu]
}

// deBoorVec4 runs de Boor on a 1D homogeneous point sequence and projects back
// to 3D.
func deBoorVec4(pts []Vec4, p int, t float64, knots []float64) Vec3 {
	n := len(pts) - 1
	if n < 0 {
		return Vec3{}
	}
	if p > n {
		p = n
	}
	if len(knots) != n+p+2 {
		// Fall back to the nearest control point on a knot mismatch, to avoid a crash
		return Vec3{pts[0].X, pts[0].Y, pts[0].Z}
	}
	t0, t1 := knots[p], knots[n+1]
	if t < t0 {
		t = t0
	}
	if t > t1 {
		t = t1
	}
	k := findSpan(n, p, t, knots)
	d := make([]Vec4, p+1)
	for r := 0; r <= p; r++ {
		idx := k - p + r
		if idx < 0 {
			idx = 0
		}
		if idx > n {
			idx = n
		}
		d[r] = pts[idx]
	}
	for r := 1; r <= p; r++ {
		for m := p; m >= r; m-- {
			i := k - p + m
			lo := knotAt(knots, i)
			hi := knotAt(knots, i+p-r+1)
			alpha := 0.0
			if math.Abs(hi-lo) > 1e-15 {
				alpha = (t - lo) / (hi - lo)
			}
			d[m] = d[m-1].Mul(1 - alpha).Add(d[m].Mul(alpha))
		}
	}
	res := d[p]
	if math.Abs(res.W) > 1e-15 {
		return Vec3{res.X / res.W, res.Y / res.W, res.Z / res.W}
	}
	return Vec3{res.X, res.Y, res.Z}
}

func knotAt(u []float64, i int) float64 {
	if i < 0 {
		return u[0]
	}
	if i >= len(u) {
		return u[len(u)-1]
	}
	return u[i]
}

// D1 uses central differences for the partial derivatives. Accurate enough for
// normals and projection, and avoids hand-writing analytic derivatives for
// 20-odd surface types.
func (s *BSplineSurf) D1(u, v float64) (Vec3, Vec3, Vec3) {
	u0, u1 := s.RangeU()
	v0, v1 := s.RangeV()
	hu := math.Max((u1-u0)*1e-4, 1e-7)
	hv := math.Max((v1-v0)*1e-4, 1e-7)
	um := u - hu
	up := u + hu
	if um < u0 {
		um = u0
	}
	if up > u1 {
		up = u1
	}
	vm := v - hv
	vp := v + hv
	if vm < v0 {
		vm = v0
	}
	if vp > v1 {
		vp = v1
	}
	p := s.Point(u, v)
	du := s.Point(up, v).Sub(s.Point(um, v)).Mul(1 / math.Max(up-um, 1e-15))
	dv := s.Point(u, vp).Sub(s.Point(u, vm)).Mul(1 / math.Max(vp-vm, 1e-15))
	return p, du, dv
}

// Project maps a 3D point back to the parameter domain with damped,
// backtracking Gauss-Newton iteration. The convergence test uses Tol scaled to
// the surface, so correct converged solutions are not rejected on large models.
func (s *BSplineSurf) Project(p Vec3, gu, gv float64) (float64, float64, bool) {
	tol := s.Tol
	if tol <= 0 {
		tol = 1e-6
	}
	u0, u1 := s.RangeU()
	v0, v1 := s.RangeV()
	su := math.Max(u1-u0, 1e-15)
	sv := math.Max(v1-v0, 1e-15)

	u, v := clampF(gu, u0, u1), clampF(gv, v0, v1)
	bestU, bestV := u, v
	bestD := math.Inf(1)
	for iter := 0; iter < 40; iter++ {
		pt, du, dv := s.D1(u, v)
		r := p.Sub(pt)
		d := r.Len()
		if d < bestD {
			bestD, bestU, bestV = d, u, v
			if d <= tol {
				break
			}
		}
		a := du.Dot(du)
		b := du.Dot(dv)
		c := dv.Dot(dv)
		det := a*c - b*b
		if math.Abs(det) < 1e-24 {
			break // degenerate point, not invertible
		}
		e1 := du.Dot(r)
		e2 := dv.Dot(r)
		stepU := (c*e1 - b*e2) / det
		stepV := (a*e2 - b*e1) / det
		// Limit the step size so it does not fly off in the parameter domain
		amp := math.Hypot(stepU/su, stepV/sv)
		if amp > 0.25 {
			k := 0.25 / amp
			stepU *= k
			stepV *= k
		}
		// Backtracking: accept the step only when the residual really drops
		accepted := false
		for t := 1.0; t >= 1.0/64; t *= 0.5 {
			nu := clampF(u+stepU*t, u0, u1)
			nv := clampF(v+stepV*t, v0, v1)
			if nd := s.Point(nu, nv).Dist(p); nd < d {
				u, v = nu, nv
				accepted = true
				break
			}
		}
		if !accepted {
			break // local optimum reached
		}
	}
	return bestU, bestV, bestD <= tol
}

// ---------------------------------------------------------------------------
// Swept surfaces (linear extrusion / revolution)
// ---------------------------------------------------------------------------

// LinExtrusionSurf is SURFACE_OF_LINEAR_EXTRUSION: P(u,v) = C(u) + v*Dir.
type LinExtrusionSurf struct {
	C   Curve
	Dir Vec3
}

func (s *LinExtrusionSurf) Point(u, v float64) Vec3 {
	return s.C.Point(u).Add(s.Dir.Mul(v))
}

func (s *LinExtrusionSurf) D1(u, v float64) (Vec3, Vec3, Vec3) {
	h := 1e-5
	p := s.Point(u, v)
	du := s.C.Point(u + h).Sub(s.C.Point(u - h)).Mul(1 / (2 * h))
	return p, du, s.Dir
}

func (s *LinExtrusionSurf) RangeU() (float64, float64) { return s.C.Range() }
func (s *LinExtrusionSurf) RangeV() (float64, float64) { return math.Inf(-1), math.Inf(1) }
func (s *LinExtrusionSurf) PeriodicU() bool            { return s.C.Periodic() }
func (s *LinExtrusionSurf) PeriodicV() bool            { return false }

func (s *LinExtrusionSurf) Project(p Vec3, gu, gv float64) (float64, float64, bool) {
	dl := s.Dir.Dot(s.Dir)
	if dl < 1e-24 {
		u, ok := s.C.ClosestParam(p, gu)
		return u, 0, ok
	}
	dh := s.Dir.Mul(1 / math.Sqrt(dl))
	// Key point: the point closest to p on the extrusion surface
	// P(u,v)=C(u)+v*d requires w = p - C(u) to be perpendicular to the extrusion
	// direction d. Taking only "the parameter on C closest to p" does not satisfy
	// this (it minimises |w| rather than |w - (w.d)d|), leaving a deviation of
	// about 1% of the face scale, enough to break the projection test and drop
	// the whole face to a plane.
	u0, _ := s.C.ClosestParam(p, gu)
	u := minPerpParam(s.C, p, dh, u0)
	base := s.C.Point(u)
	v := p.Sub(base).Dot(s.Dir) / dl
	return u, v, true
}

// minPerpParam minimises, over the curve parameter, the distance from p to the
// line through C(u) with direction d, i.e. the length of the component of
// w = p - C(u) perpendicular to d. d must be a unit vector.
func minPerpParam(c Curve, p, d Vec3, guess float64) float64 {
	obj := func(u float64) float64 {
		w := p.Sub(c.Point(u))
		return w.Sub(d.Mul(w.Dot(d))).Len()
	}
	t0, t1 := c.Range()
	return goldenMin(obj, guess, t0, t1)
}

// goldenMin finds the minimum of a 1D function on [lo,hi].
// When the interval is unbounded (common for lines and curves on an infinite
// plane), take a finite window around guess. The objective itself carries a
// length dimension, so comparing function values is enough; no extra tolerance
// is needed.
func goldenMin(f func(float64) float64, guess, lo, hi float64) float64 {
	bounded := isFinite(lo) && isFinite(hi) && hi > lo
	if !bounded {
		span := 1 + math.Abs(guess)
		lo, hi = guess-span, guess+span
	}
	if !(hi > lo) {
		return guess
	}
	const phi = 0.6180339887498949
	x1 := hi - phi*(hi-lo)
	x2 := lo + phi*(hi-lo)
	f1, f2 := f(x1), f(x2)
	for i := 0; i < 60; i++ {
		if f1 < f2 {
			hi, x2, f2 = x2, x1, f1
			x1 = hi - phi*(hi-lo)
			f1 = f(x1)
		} else {
			lo, x1, f1 = x1, x2, f2
			x2 = lo + phi*(hi-lo)
			f2 = f(x2)
		}
	}
	best := (lo + hi) / 2
	// Keep the initial guess when it is already better: minima are
	// ill-conditioned where the objective is flat, and forcing the distant
	// minimum makes the parameters of adjacent points jump and distorts the
	// parameter-domain polygon.
	if f(guess) <= f(best) {
		return guess
	}
	return best
}

// RevolutionSurf is SURFACE_OF_REVOLUTION: rotates a curve about an axis.
type RevolutionSurf struct {
	C      Curve
	Origin Vec3
	Axis   Vec3
}

func (s *RevolutionSurf) Point(u, v float64) Vec3 {
	q := s.C.Point(v)
	rel := q.Sub(s.Origin)
	a := s.Axis
	// Rodrigues rotation formula
	c, sn := math.Cos(u), math.Sin(u)
	term1 := rel.Mul(c)
	term2 := a.Cross(rel).Mul(sn)
	term3 := a.Mul(a.Dot(rel) * (1 - c))
	return s.Origin.Add(term1.Add(term2).Add(term3))
}

func (s *RevolutionSurf) D1(u, v float64) (Vec3, Vec3, Vec3) {
	h := 1e-5
	hu := 1e-4
	p := s.Point(u, v)
	du := s.Point(u+hu, v).Sub(s.Point(u-hu, v)).Mul(1 / (2 * hu))
	dv := s.Point(u, v+h).Sub(s.Point(u, v-h)).Mul(1 / (2 * h))
	return p, du, dv
}

func (s *RevolutionSurf) RangeU() (float64, float64) { return 0, 2 * math.Pi }
func (s *RevolutionSurf) RangeV() (float64, float64) { return s.C.Range() }
func (s *RevolutionSurf) PeriodicU() bool            { return true }
func (s *RevolutionSurf) PeriodicV() bool            { return s.C.Periodic() }

func (s *RevolutionSurf) Project(p Vec3, gu, gv float64) (float64, float64, bool) {
	rel := p.Sub(s.Origin)
	a := s.Axis
	axial := rel.Dot(a)
	perp := rel.Sub(a.Mul(axial))

	v0, _ := s.C.ClosestParam(p, gv)
	t0, t1 := s.C.Range()
	// The correct objective is "the distance from p to the whole circle generated
	// by revolving the curve point C(v) about the axis":
	//   d(v) = sqrt( (axial - axial_c)^2 + (radial - radial_c)^2 )
	// Taking only "the parameter on C closest to p" minimises |p - C(v)|, which is
	// not equivalent -- the former compares only the axial and radial components,
	// the true orthogonality condition for a revolved surface.
	obj := func(v float64) float64 {
		q := s.C.Point(v).Sub(s.Origin)
		qa := q.Dot(a)
		qr := q.Sub(a.Mul(qa)).Len()
		da, dr := axial-qa, perp.Len()-qr
		return math.Sqrt(da*da + dr*dr)
	}
	v := goldenMin(obj, v0, t0, t1)

	// Reference direction: use this point to fix the zero of u
	ref := s.C.Point(v).Sub(s.Origin)
	refPerp := ref.Sub(a.Mul(ref.Dot(a)))
	if refPerp.Len() < 1e-12 || perp.Len() < 1e-12 {
		return 0, v, true
	}
	x := refPerp.Normalize()
	y := a.Cross(x)
	u := math.Atan2(perp.Dot(y), perp.Dot(x))
	return u, v, true
}

// XFormSurf places the surface in the given coordinate system.
type XFormSurf struct {
	Base Surface
	M    Mat34
}

func (s *XFormSurf) Point(u, v float64) Vec3 { return s.M.Apply(s.Base.Point(u, v)) }

func (s *XFormSurf) D1(u, v float64) (Vec3, Vec3, Vec3) {
	p, du, dv := s.Base.D1(u, v)
	return s.M.Apply(p), s.M.ApplyDir(du), s.M.ApplyDir(dv)
}

func (s *XFormSurf) RangeU() (float64, float64) { return s.Base.RangeU() }
func (s *XFormSurf) RangeV() (float64, float64) { return s.Base.RangeV() }
func (s *XFormSurf) PeriodicU() bool            { return s.Base.PeriodicU() }
func (s *XFormSurf) PeriodicV() bool            { return s.Base.PeriodicV() }

func (s *XFormSurf) Project(p Vec3, gu, gv float64) (float64, float64, bool) {
	inv, ok := s.M.InverseGeneral()
	if !ok {
		inv = Identity()
	}
	return s.Base.Project(inv.Apply(p), gu, gv)
}

func clampF(f, lo, hi float64) float64 {
	if f < lo {
		return lo
	}
	if f > hi {
		return hi
	}
	return f
}
