package step

import (
	"bufio"
	"math"
	"os"
	"strconv"
	"strings"
	"sync"

	"stp2glb-lite/internal/console"
)

// P2 is a point in the parameter domain (or any 2D plane).
type P2 struct{ X, Y float64 }

// shoelace returns the signed area, positive counter-clockwise.
func shoelace(p []P2) float64 {
	n := len(p)
	if n < 3 {
		return 0
	}
	s := 0.0
	for i := 0; i < n; i++ {
		j := (i + 1) % n
		s += p[i].X*p[j].Y - p[j].X*p[i].Y
	}
	return s * 0.5
}

func reverseP2(p []P2) {
	for i, j := 0, len(p)-1; i < j; i, j = i+1, j-1 {
		p[i], p[j] = p[j], p[i]
	}
}

func reverseInt(p []int) {
	for i, j := 0, len(p)-1; i < j; i, j = i+1, j-1 {
		p[i], p[j] = p[j], p[i]
	}
}

// triAreaSum accumulates the signed area of a triangulation (positive =
// counter-clockwise).
func triAreaSum(pts []P2, tris []int) float64 {
	s := 0.0
	for i := 0; i+2 < len(tris); i += 3 {
		a, b, c := tris[i], tris[i+1], tris[i+2]
		if a < 0 || b < 0 || c < 0 || a >= len(pts) || b >= len(pts) || c >= len(pts) {
			continue
		}
		s += shoelace([]P2{pts[a], pts[b], pts[c]})
	}
	return s
}

// triAreaAbs returns sum|triangle area| and the number of negative/zero winding
// triangles.
//
// * This is the only reliable sentinel for a "membrane". triAreaSum is a
// **signed** sum, while a membrane shows up as "the same region covered once by
// positive and once by negative triangles" -- the signed areas cancel exactly, so
// triAreaSum matches the expected value to the last digit (0.000% deviation) and
// the sentinel is completely blind; but sum|area| grows to 1.x ~ 4 times the
// expected value and the negative-winding triangle count shoots up with it. The
// criterion for a correct triangulation: sum|area| / expected = 1.000 and negative
// winding = 0.
func triAreaAbs(pts []P2, tris []int) (abs float64, neg int) {
	for i := 0; i+2 < len(tris); i += 3 {
		a, b, c := tris[i], tris[i+1], tris[i+2]
		if a < 0 || b < 0 || c < 0 || a >= len(pts) || b >= len(pts) || c >= len(pts) {
			continue
		}
		s := shoelace([]P2{pts[a], pts[b], pts[c]})
		if s < 0 {
			neg++
		}
		abs += math.Abs(s)
	}
	return abs, neg
}

// concatP2 concatenates [outer, holes...] into one point table; the index order
// matches what Triangulate returns.
func concatP2(loops [][]P2) []P2 {
	n := 0
	for _, l := range loops {
		n += len(l)
	}
	out := make([]P2, 0, n)
	for _, l := range loops {
		out = append(out, l...)
	}
	return out
}

// holeCoverReport checks whether any triangle of the triangulation covers a hole.
//
// Criterion: in a correct triangulation of a polygon with holes, hole points only
// ever lie on the **boundary** of a triangle. As soon as a hole point lies strictly
// inside a triangle (all three barycentric coordinates clearly greater than 0),
// that triangle spans the hole -- visually "a membrane appears exactly where there
// should be a cut-out".
//
// uv is the point table [outer, holes...] concatenated in order (indices match
// tris), and outerLen is the number of outer points. Returns (number of covered
// hole points, total hole points, number of triangles covering a hole).
func holeCoverReport(uv []P2, outerLen int, tris []int) (covered, holePts, fromTris int) {
	if outerLen <= 0 || outerLen >= len(uv) {
		return 0, 0, 0
	}
	holePts = len(uv) - outerLen
	// Relative margin of the barycentric coordinates: the component is exactly 0
	// when a hole point lies on a triangle edge and the floating error is around
	// 1e-15, so 1e-6 neither reports falsely nor misses a real crossing.
	const minBary = 1e-6
	for i := 0; i+2 < len(tris); i += 3 {
		ia, ib, ic := tris[i], tris[i+1], tris[i+2]
		if ia < 0 || ib < 0 || ic < 0 || ia >= len(uv) || ib >= len(uv) || ic >= len(uv) {
			continue
		}
		ax, ay := uv[ia].X, uv[ia].Y
		bx, by := uv[ib].X, uv[ib].Y
		cx, cy := uv[ic].X, uv[ic].Y
		d := (by-cy)*(ax-cx) + (cx-bx)*(ay-cy)
		if math.Abs(d) < 1e-300 {
			continue // degenerate triangle, skip
		}
		hit := 0
		for h := outerLen; h < len(uv); h++ {
			px, py := uv[h].X, uv[h].Y
			l1 := ((by-cy)*(px-cx) + (cx-bx)*(py-cy)) / d
			l2 := ((cy-ay)*(px-cx) + (ax-cx)*(py-cy)) / d
			l3 := 1 - l1 - l2
			if l1 > minBary && l2 > minBary && l3 > minBary {
				covered++
				hit++
			}
		}
		if hit > 0 {
			fromTris++
		}
	}
	return covered, holePts, fromTris
}

// expectedLoopArea returns the expected value of "outer area - sum of hole areas".
func expectedLoopArea(loops [][]P2) float64 {
	if len(loops) == 0 {
		return 0
	}
	a := shoelace(loops[0])
	if a < 0 {
		a = -a
	}
	for _, h := range loops[1:] {
		if v := shoelace(h); v != 0 {
			if v < 0 {
				v = -v
			}
			a -= v
		}
	}
	return a
}

// earAnomalyRatio is the relative tolerance of "ear clipping result area vs outer
// minus holes". Exceeding it means the triangulation of this face with holes is
// wrong (typically a hole counted as area).
const earAnomalyRatio = 0.02

// earAnomalyAbsFloor is the absolute floor of the same criterion (parameter domain
// units). It only filters floating noise on zero-area degenerate faces: for those
// want itself is of order 1e-13, so the relative deviation easily reaches 50%, but
// they produce no triangle at all and reporting them is pure noise.
const earAnomalyAbsFloor = 1e-9

// normalizeHoleWinding flips each inner loop's winding so that it is **opposite**
// to the outer loop.
//
// Why it is required: the bridging path of buildWithHoles is
//     "walk along the outer loop to M -> jump to the hole's rightmost point H ->
//     **walk one full turn in the hole's stored index order** -> back to M"
// and this closed path excludes the hole's interior only when the hole and the
// outer loop have opposite windings. If they agree, walking around the hole is the
// "positive direction" and the hole area is counted as inside the polygon -- the
// result is outer + hole instead of outer - hole. Measured on face #257993 of a
// 21MB fixture part: outer 884.565, hole 416.742, expected 467.822, actual
// 1301.307 = 884.565 + 416.742, exactly.
//
// Note that "normalize everything to counter-clockwise" inside earClip reverses the
// **whole already bridged polygon** at once, so the relative winding of inner and
// outer loops is preserved; do not count on that step to correct hole orientation.
func normalizeHoleWinding(loops []paramLoop) {
	if len(loops) < 2 {
		return
	}
	holes := make([][]P2, 0, len(loops)-1)
	pos := make([][]Vec3, 0, len(loops)-1)
	for _, l := range loops[1:] {
		holes = append(holes, l.UV)
		pos = append(pos, l.P)
	}
	normalizeHoleWindingRaw(loops[0].UV, holes, pos)
}

// normalizeHoleWindingRaw is the low-level implementation of
// normalizeHoleWinding. holesP corresponds one to one with holes (it may be nil)
// and is reversed along with it, keeping the UV-to-3D-point pairing intact.
func normalizeHoleWindingRaw(outer []P2, holes [][]P2, holesP [][]Vec3) {
	if len(holes) == 0 {
		return
	}
	so := shoelace(outer)
	if so == 0 {
		return
	}
	for i, h := range holes {
		if len(h) < 3 {
			continue
		}
		sh := shoelace(h)
		if sh == 0 || (so > 0) != (sh > 0) {
			continue
		}
		// Same winding: reverse. The UV points and their 3D counterparts must be
		// reversed together, otherwise the UV-to-P mapping built by flattenLoops goes
		// out of sync.
		reverseP2(h)
		if i < len(holesP) {
			p := holesP[i]
			for a, b := 0, len(p)-1; a < b; a, b = a+1, b-1 {
				p[a], p[b] = p[b], p[a]
			}
		}
	}
}

func cross2(o, a, b P2) float64 {
	return (a.X-o.X)*(b.Y-o.Y) - (a.Y-o.Y)*(b.X-o.X)
}

// EarDiag records the degeneration signals of the most recent Triangulate, for
// diagnostic output by callers.
// Forced>0 means ear clipping found no legal "ear" and took the forced removal
// branch -- the triangles produced there are not guaranteed to be legal ears and
// may overlap a hole (the direct cause of an excessive area).
// NoVisible>0 means a hole bridge point found no visible vertex and degraded to
// "nearest vertex", so the bridge edge may cross other polygon edges and break
// simplicity.
type EarDiag struct {
	Merged    int // number of holes bridged in
	NoVisible int // times a bridge point had no visible vertex and degraded to the nearest one
	Forced    int // times the forced removal branch was taken
	Iters     int // iterations of the ear clipping main loop
	Pts       int // points taking part in ear clipping (including bridge duplicates)
	// HolesIn / Skipped / IndexShift describe "how many of the supplied holes had
	// zero area and were skipped". IndexShift > 0 means a skipped hole comes before
	// some usable hole, so the indices the latter receives shift forward -- this is
	// the direct cause of "a triangle spanning a hole (a membrane)", see
	// buildWithHoles.
	HolesIn    int
	Skipped    int
	IndexShift int
	// WantTrue is the "corrected expected area" and is > 0 only when a hole loop was
	// not enclosed by the outer loop and boolean clipping (clipRegionTri) was used.
	//
	// Background: expectedLoopArea gives |outer| - sum|holes|, which equals the true
	// region area only when all holes lie inside the outer loop. When a hole sticks
	// out of the outer loop the true area is |outer| - |union(hole intersect outer)|,
	// which is larger (measured differences reach 5x). If the area sentinel kept
	// using the old denominator it would report a correct clipping result as "area
	// too large". All diagnostics upstream prefer WantTrue.
	WantTrue float64
}

// Triangulate triangulates a polygon with an outer loop and some holes.
// The returned indices point into the array built by concatenating outer and holes
// in order.
// This is the last-resort guarantee that "even the most complex face yields
// triangles", so it forces progress on degenerate input.
func Triangulate(outer []P2, holes [][]P2) []int {
	t, _ := TriangulateDiag(outer, holes)
	return t
}

// TriangulateDiag is like Triangulate but also returns degeneration diagnostics.
// Note: diagnostics must be returned with the call rather than kept in package
// variables -- Tessellate runs concurrently in several goroutines in batches per
// part (see main.go), and package variables would overwrite each other.
// TriangulateDiagFid is like TriangulateDiag but also passes the face id through
// to the dump hook (used when STP2GLB_DUMP_EAR is enabled), so the ear clipping
// geometry can be reproduced in the parameter domain afterwards.
func TriangulateDiagFid(outer []P2, holes [][]P2, flatP []Vec3, fid int) ([]int, []paramPoint, EarDiag) {
	return triangulateFull(outer, holes, flatP, fid)
}

func TriangulateDiag(outer []P2, holes [][]P2) ([]int, EarDiag) {
	return triangulateDiag(outer, holes, -1)
}

// bridgeOpt describes one "hole bridging strategy". Switching strategies only
// changes the **bridge topology** (which outer vertex a hole attaches to, which
// hole is merged first) and not the outer/hole data itself, so the output of every
// strategy indexes the same [outer, holes...] point table and they can be compared
// and the best picked.
type bridgeOpt struct {
	asc  bool // true = holes processed by rightmost point x **ascending**; false = descending (status quo)
	side int  // 0 = nearest visible vertex; 1 = only accept candidates with larger x; 2 = only accept candidates with smaller x
}

// earBridgeStrategies is the candidate strategy table; entry 0 is the historical
// behavior.
//
// * Why "multiple strategies + pick the best": the common root cause of every
// "membrane" in this project (a thin sheet covering a place that should be cut out)
// is **degenerate bridge topology** -- the bridge edge runs along a hole edge or
// continues a post edge in a straight line, leaving a zero-width slit in the bridged
// polygon; ear clipping finds no legal ear on the slit and can only force removal,
// emitting a pair of triangles with the same vertices and opposite winding (the
// signed areas cancel exactly while sum|area| doubles).
//
// But **no single heuristic is right for every face**. Two counterexamples measured:
//   - Eberly's ray method (cast a ray from H towards +x and take the edge endpoint):
//     face #1888964 sum|dA| 1.000 -> 4.874;
//   - enabling "only connect to vertices with larger x" globally: the same face
//     1.000 -> 3.730.
// The reason is that they are only right for **specific degenerate configurations**;
// forcing them globally picks a worse bridge point on other faces. Running "several
// strategies and picking the best by sum|area|/expected" means these two strategies
// can **never be worse than the status quo** on any face (at worst they tie entry 0)
// while rescuing the faces each of them is good at.
var earBridgeStrategies = []bridgeOpt{
	{asc: false, side: 0}, // 0: historical behavior (nearest visible vertex + holes by rightmost x descending)
	{asc: false, side: 1}, // 1: prefer connecting to a vertex with larger x (= towards the outer boundary, away from hole walls)
	{asc: true, side: 0},  // 2: holes by rightmost x ascending
	{asc: true, side: 1},  // 3
	{asc: false, side: 2}, // 4: prefer connecting to a vertex with smaller x
}

// earRetryRatio is the quality threshold that triggers "switch strategy and
// retry": sum|triangle area| / expected area. For a correct triangulation the value
// is always 1.000 (a little floating slack is allowed).
const earRetryRatio = 1.002

// earRetryMaxPts limits "bridge reordering retries" to small faces. Ear clipping
// itself is O(n^2) worst case, and multiplying by 5 strategies would slow large
// faces down; measured, every face that had a problem had at most 200 points in its
// parameter-domain table.
const earRetryMaxPts = 1500

// earClipMaxPts is the point limit for **boolean clipping** (clipRegionTri), much
// more generous than for bridge retries. The complexities differ: a bridge retry is
// 5 full ear clippings (O(n^2)), while clipping is
// O(outer triangles x hole triangles) and only runs for faces where "a hole loop
// goes out of bounds", which are rare to begin with. Measured in a 1.4 GB file, a
// few large faces with 13~14 inner loops were blocked by earRetryMaxPts exactly.
const earClipMaxPts = 8000

func triangulateDiag(outer []P2, holes [][]P2, fid int) ([]int, EarDiag) {
	tris, _, d := triangulateFull(outer, holes, nil, fid)
	return tris, d
}

// triangulateFull is the full version of triangulateDiag: besides triangles and
// diagnostics it also returns the **points newly created by clipping** (see
// clipRegionTri); callers append them to the end of the point table, so triangle
// indices are original table indices or [original table length, +len(extra)).
//
// flatP must correspond one to one with the table built by concatenating outer and
// holes in order (3D coordinates). Passing nil disables the boolean clipping
// strategy (the old behavior of Triangulate / TriangulateDiag, indices always <
// len(table)).
func triangulateFull(outer []P2, holes [][]P2, flatP []Vec3, fid int) ([]int, []paramPoint, EarDiag) {
	if len(outer) < 3 {
		return nil, nil, EarDiag{}
	}
	// Note: flipping holes that share the outer loop's winding to the opposite one
	// here (aligning the winding before bridging, the textbook approach) was tried.
	// Measured on the large files of this project it is **neutral to slightly
	// negative**:
	//   72MB body-in-white total surface 12.069M -> 12.133M mm^2
	//   218MB welding fixture          2.045M ->  2.048M mm^2
	// The number of anomalous-area faces is unchanged. Since there is no provable
	// benefit, this extra allocation and behavior change is not introduced. The real
	// root cause is only the wrong winding normalization in earClip (see below).

	loops := make([][]P2, 0, len(holes)+1)
	loops = append(loops, outer)
	loops = append(loops, holes...)
	want := expectedLoopArea(loops)
	total := loopPts(loops)

	// -- Strategy 0 (historical behavior) is always the baseline: this function can
	// **never be worse than the status quo**. --
	var d EarDiag
	pts, org := buildWithHoles(outer, holes, &d, earBridgeStrategies[0])
	if len(pts) < 3 {
		return nil, nil, d
	}
	bestTris := earClip(pts, org, &d)
	var bestExtra []paramPoint
	bestD := d
	bestQ, bestNeg := 1.0, 0
	if want > 0 {
		bestQ, bestNeg = earQuality(loops, want, bestTris)
	}

	// -- Only retry with another strategy on faces that did not come out perfect --
	if want > 0 && bestQ > earRetryRatio && len(holes) > 0 {
		// Bridge reordering retry: ear clipping is O(n^2) worst case and 5 strategies
		// would slow large faces down, so it is limited to small faces.
		if total <= earRetryMaxPts {
			for _, opt := range earBridgeStrategies[1:] {
				var ds EarDiag
				p2, o2 := buildWithHoles(outer, holes, &ds, opt)
				if len(p2) < 3 {
					continue
				}
				t2 := earClip(p2, o2, &ds)
				if !trisInRange(t2, total) {
					continue
				}
				q, neg := earQuality(loops, want, t2)
				if q < bestQ-1e-12 || (q <= bestQ+1e-12 && neg < bestNeg) {
					bestQ, bestNeg, bestTris, bestD, bestExtra = q, neg, t2, ds, nil
				}
				if bestQ <= 1.0+1e-9 {
					break // already perfect, no need to retry
				}
			}
		} else if debugAreaAbs() {
			console.Outf("[clip] face #%d: point table %d exceeds bridge retry limit %d, skipping reorder retry (sum|area|/expected %.4f)\n",
				fid, total, earRetryMaxPts, bestQ)
		}

		// * Bridge reordering did not help at all, and the root cause is "a hole
		// sticking out of the outer loop" (two intersecting loops, invalid input).
		//
		// In that case there is **no need to compare quality against the bridge
		// result**; use boolean clipping directly, because: bridging only attaches
		// the hole to the outer loop through a "there and back" zero-width slit and
		// does not change the signed area of the merged polygon -- it always equals
		// expectedLoopArea = |outer| - sum|holes|. The true region area is |outer| -
		// |union(hole intersect outer)|, and the two are equal only when all holes lie
		// inside the outer loop. That is: **as soon as a hole goes out of bounds the
		// bridge result is mathematically wrong**, no matter how small sum|dA| looks.
		//
		// The complexity of clipping is O(outer triangles x hole triangles), a
		// different thing from bridge retries, so it gets another, more generous point
		// limit; the number of pieces is additionally capped by earRetryMaxPieces.
		if bestQ > earRetryRatio && len(flatP) == total && !holesContained(outer, holes) {
			if total > earClipMaxPts {
				if debugAreaAbs() {
					console.Outf("[clip] face #%d: hole out of bounds, but point table %d exceeds clip limit %d, giving up\n", fid, total, earClipMaxPts)
				}
			} else if t3, ext, ok := clipRegionTri(outer, holes, flatP); ok {
				tbl := concatP2(loops)
				for _, e := range ext {
					tbl = append(tbl, P2{X: e.U, Y: e.V})
				}
				abs3, neg3 := triAreaAbs(tbl, t3)
				// Sanity bounds check: the clipping result must have no negative
				// winding, an area no smaller than the old expected value
				// (|union(hole intersect outer)| <= sum|holes|, so the old value is a
				// lower bound of the true area) and no larger than the outer loop
				// itself (|union(hole intersect outer)| >= 0). Any violation means the
				// clipping itself went wrong, and we prefer to fall back to the bridge
				// result.
				if neg3 == 0 && abs3 >= want*(1-1e-9) && abs3 <= math.Abs(shoelace(outer))*(1+1e-9) {
					bestTris, bestExtra, bestQ, bestNeg = t3, ext, 1.0, 0
					bestD.WantTrue = abs3
				} else if debugAreaAbs() {
					console.Outf("[clip] face #%d: clipping done but failed validation (negative winding %d, area %.4f, allowed range %.4f~%.4f), falling back to bridging\n",
						fid, neg3, abs3, want*(1-1e-9), math.Abs(shoelace(outer))*(1+1e-9))
				}
			} else if debugAreaAbs() {
				console.Outf("[clip] face #%d: hole out of bounds but clipping abandoned (point table %d, too many pieces or degenerate), falling back to bridging (sum|area|/expected %.4f)\n",
					fid, total, bestQ)
			}
		}
	}
	dumpEar(fid, outer, holes, bestTris, bestExtra)
	return bestTris, bestExtra, bestD
}

// earQuality scores one triangulation result: sum|triangle area| / expected area,
// smaller is better (1.0 is perfect). It also returns the number of negative
// winding triangles, as the secondary criterion on ties.
func earQuality(loops [][]P2, want float64, tris []int) (float64, int) {
	abs, neg := triAreaAbs(concatP2(loops), tris)
	return abs / want, neg
}

// trisInRange checks that all indices fall inside the point table. Any
// out-of-range index makes the area statistics silently skip that triangle and
// disguise a bad result as a good one, so it must be screened out first.
func trisInRange(tris []int, n int) bool {
	if len(tris) < 3 {
		return false
	}
	for _, t := range tris {
		if t < 0 || t >= n {
			return false
		}
	}
	return true
}

// buildWithHoles bridges the holes into the outer loop, forming a single simple
// polygon.
func buildWithHoles(outer []P2, holes [][]P2, d *EarDiag, opt bridgeOpt) ([]P2, []int) {
	pts := make([]P2, len(outer))
	org := make([]int, len(outer))
	copy(pts, outer)
	for i := range org {
		org[i] = i
	}
	base := len(outer)

	// Filter degenerate holes.
	//
	// * base must be advanced for **every** hole, including the skipped ones. The
	// returned indices are interpreted against the table built by concatenating
	// outer and all holes in order (flattenLoops / expectedLoopArea / emitFromParam
	// of the same call all use that order), and a skipped hole **still occupies its
	// place** in the table even though it takes no part in bridging. If its length
	// were not added, every later hole's indices would shift forward, and the
	// triangles emitted by earClip would connect to other holes/other points --
	// spanning holes, which visually is "a membrane layer where there should be a
	// cut-out".
	//
	// Measured: exactly 11 faces of the 1.4 GB GUARD_RESULT(1).stp hit this
	// condition, all B_SPLINE_SURFACE_WITH_KNOTS (zero-area holes project easily in
	// the parameter domain), with area deviations up to +50.4%.
	//
	// * The threshold must be **relative**: |shoelace(h)| < 1e-9 * |shoelace(outer)|.
	// The old absolute threshold 1e-18 basically meant "filter out only exact zeros"
	// on real data, while parameter-domain projection produces **needle loops** (two
	// of the three points almost coincide, e.g. 83 == 85) whose area is
	// mathematically 0 but rounds to the 1e-11 range, easily dodging 1e-18. Bridging
	// a needle loop fails very subtly: earClip ends up with exactly {outer point,
	// needle tip, needle base} at the tail of the loop and emits a pair of
	// **same-vertex, opposite winding** triangles whose signed areas cancel exactly
	// (the [hoarea] deviation is 0.000% and the area sentinel cannot see it at all),
	// while sum|triangle area| doubles out of nowhere -- visually "the frame that
	// should be cut out is covered by a membrane".
	//
	// Measured (face #13228953, exactly the "three rectangular frames behind the
	// body" face in the 1.4 GB file): of 4 needle inner loops, 3 had |shoelace|
	// exactly 0 and were filtered by the old threshold, and the remaining one was
	// 2.9e-11 and slipped through, so sum|dA| stayed at 1.015 (a pair of
	// opposite-winding triangles of +/-460.6).
	outerArea := math.Abs(shoelace(outer))
	holeLim := outerArea * 1e-9
	if holeLim < 1e-18 {
		holeLim = 1e-18
	}
	valid := make([][]P2, 0, len(holes))
	validBase := make([]int, 0, len(holes))
	ok := make([]bool, len(holes))
	for i, h := range holes {
		ok[i] = len(h) >= 3 && math.Abs(shoelace(h)) >= holeLim
	}
	d.HolesIn = len(holes)
	// Count the "shift": the number of points skipped before some usable hole (take
	// the maximum). 0 means the indices were not affected; >0 is the trigger
	// condition of this bug.
	run := 0
	for i, h := range holes {
		if ok[i] {
			if run > d.IndexShift {
				d.IndexShift = run
			}
			continue
		}
		d.Skipped++
		run += len(h)
	}
	for i, h := range holes {
		b := base
		base += len(h) // unconditional, keeps in sync with the caller's point table
		if !ok[i] {
			continue
		}
		valid = append(valid, h)
		validBase = append(validBase, b)
	}
	if len(valid) == 0 {
		return pts, org
	}

	// Process holes by rightmost point x, descending
	type holeRef struct {
		idx   int
		right float64
	}
	refs := make([]holeRef, len(valid))
	for i, h := range valid {
		mx := -math.MaxFloat64
		for _, q := range h {
			if q.X > mx {
				mx = q.X
			}
		}
		refs[i] = holeRef{idx: i, right: mx}
	}
	// Insertion sort: descending by rightmost point x by default (merge the
	// rightmost hole first), reversed when opt.asc is set. Changing the order changes
	// where the bridge edges run and the shape of the "already merged polygon", hence
	// the topology -- which is exactly the independent attempt in multi-strategy
	// selection.
	for i := 1; i < len(refs); i++ {
		for j := i; j > 0; j-- {
			swapped := refs[j].right > refs[j-1].right
			if opt.asc {
				swapped = refs[j].right < refs[j-1].right
			}
			if !swapped {
				break
			}
			refs[j], refs[j-1] = refs[j-1], refs[j]
		}
	}

	// Add the holes one by one (by rightmost point x, descending)
	mergedHole := make([]bool, len(valid))
	for _, r := range refs {
		h := valid[r.idx]
		hb := validBase[r.idx]
		// Find the hole's rightmost point
		hi := 0
		for i, q := range h {
			if q.X > h[hi].X {
				hi = i
			}
		}
		hp := h[hi]

		// Other holes not merged yet: the bridge edge must not cross them either,
		// otherwise the bridged polygon self-intersects.
		var others [][]P2
		for k := range valid {
			if k != r.idx && !mergedHole[k] {
				others = append(others, valid[k])
			}
		}

		// Bridge candidate = the nearest "visible vertex". Visibility must satisfy
		// all three conditions (see the comments on nearestVisibleHole /
		// segmentVisible / segmentClearOfHole). When opt.side != 0 the candidates are
		// first filtered by x direction (pointing at the outer boundary instead of
		// running along a neighboring hole); if nothing is left we fall back to
		// nearestVisibleHole, so the candidate set never shrinks because of a
		// strategy switch.
		mi := -1
		if opt.side == 1 {
			mi = nearestVisibleHoleSide(pts, hp, h, hi, others, +1)
		} else if opt.side == 2 {
			mi = nearestVisibleHoleSide(pts, hp, h, hi, others, -1)
		}
		if mi < 0 {
			mi = nearestVisibleHole(pts, hp, h, hi, others)
		}
		if mi < 0 {
			// Still nothing: degrade to the nearest vertex and carry on. This leaves
			// the NoVisible counter in the log; once >0 the bridge edge may have
			// crossed some boundary (-> self-intersecting bridged polygon -> a
			// membrane).
			d.NoVisible++
			best := math.MaxFloat64
			for i := range pts {
				if d := dist2(pts[i], hp); d < best {
					best, mi = d, i
				}
			}
		}
		d.Merged++
		mergedHole[r.idx] = true
		if mi < 0 {
			continue
		}

		// Build the insertion sequence: M, H, h[hi+1..], h[..hi], H, M'
		merged := make([]P2, 0, len(pts)+len(h)+2)
		mergedOrg := make([]int, 0, len(pts)+len(h)+2)
		merged = append(merged, pts[:mi+1]...)
		mergedOrg = append(mergedOrg, org[:mi+1]...)

		merged = append(merged, hp)
		mergedOrg = append(mergedOrg, hb+hi)
		for k := 1; k < len(h); k++ {
			j := (hi + k) % len(h)
			merged = append(merged, h[j])
			mergedOrg = append(mergedOrg, hb+j)
		}
		merged = append(merged, hp)
		mergedOrg = append(mergedOrg, hb+hi)
		merged = append(merged, pts[mi])
		mergedOrg = append(mergedOrg, org[mi])

		merged = append(merged, pts[mi+1:]...)
		mergedOrg = append(mergedOrg, org[mi+1:]...)

		pts, org = merged, mergedOrg
	}
	return pts, org
}

func dist2(a, b P2) float64 {
	dx, dy := a.X-b.X, a.Y-b.Y
	return dx*dx + dy*dy
}

// edgeKey is the quantized key of a **directed edge** (floating bit patterns, no
// tolerance). It is only used to recognize the "written there and back" edges left
// by bridging, whose coordinates are bit-identical (zero-width slits).
type edgeKey struct{ x1, y1, x2, y2 uint64 }

func keyOf(a, b P2) edgeKey {
	return edgeKey{math.Float64bits(a.X), math.Float64bits(a.Y), math.Float64bits(b.X), math.Float64bits(b.Y)}
}

// noDiagCheck is an experiment switch: setting STP2GLB_NO_DIAGCHK=1 disables
// earClip's diagonal edge-crossing check entirely, used to quantify the benefit and
// cost of this criterion (switch off by default = the check is active).
var (
	noDiagCheckOnce sync.Once
	noDiagCheckVal  bool
)

func noDiagCheck() bool {
	noDiagCheckOnce.Do(func() {
		noDiagCheckVal = strings.TrimSpace(os.Getenv("STP2GLB_NO_DIAGCHK")) != ""
	})
	return noDiagCheckVal
}

// coincideEps is the tolerance for "two vertices are the same point" (parameter
// domain units). Bridging writes M and H twice each with identical coordinates; a
// hole may also have coincident vertices of its own.
const coincideEps = 1e-9

// sameP reports whether two vertices coincide.
func sameP(a, b P2) bool {
	dx, dy := a.X-b.X, a.Y-b.Y
	return dx*dx+dy*dy <= coincideEps*coincideEps
}

// nearestVisibleHoleSide is the same as nearestVisibleHole but only accepts
// candidates whose x lies in the **sign direction** from p (sign=+1 requires
// q.X > p.X, sign=-1 requires q.X < p.X); when none is found it returns -1 and the
// caller falls back to nearestVisibleHole.
//
// The tolerance is relative to the parameter-domain bounding box diagonal: the
// aspect ratio of the parameter domain can reach tens of thousands (54x694,
// 1060x18 are common in this project), so an absolute tolerance fails on some
// faces.
//
// * Purpose: H is the hole's rightmost point. When several holes of the same face
// share an (almost) identical right edge x -- the "rectangular frame / louver"
// faces of this project are extremely common (face #1224280 of the 1.4 GB file has
// 5 holes whose rightmost x are all about 48.8757) -- the "nearest visible vertex"
// almost always lands on the **rightmost point of a neighboring hole**, so the
// bridge edge runs along the vertical line x=48.8757, collinear and overlapping
// with the hole's right edge, and the bridged polygon gets a zero-width slit; ear
// clipping finds no legal ear on the slit, drops into the forced removal branch and
// emits negative-winding triangles (signed areas cancel each other -> [hoarea]
// deviation 0.000%, while sum|triangle area| grows 2~3x). Accepting only candidates
// with x > p.x is equivalent to "prefer connecting the hole to the outer boundary",
// avoiding this configuration at the root.
//
// * But it **must not be enabled globally**: measured on face #1888964, forcing it
// globally raises sum|dA| from 1.000 to 3.730 (the configuration it is good at is
// the opposite of #1224280). So it is only one of the candidate strategies, picked
// by triangulateDiag via sum|area|/expected.
func nearestVisibleHoleSide(poly []P2, p P2, hole []P2, hi int, others [][]P2, sign int) int {
	xeps := polySpanEps(poly)
	if xeps <= 0 {
		xeps = 1e-12
	}
	best, bestD := -1, math.MaxFloat64
	for i, q := range poly {
		if sign > 0 && q.X <= p.X+xeps {
			continue
		}
		if sign < 0 && q.X >= p.X-xeps {
			continue
		}
		d := dist2(p, q)
		if d >= bestD {
			continue
		}
		if segmentVisible(poly, p, q) &&
			segmentClearOfHole(p, q, hole, hi) &&
			segmentClearOfLoops(p, q, others) {
			bestD, best = d, i
		}
	}
	return best
}

// polySpanEps returns 1e-9 times the parameter-domain bounding box diagonal, as
// the relative tolerance for "same x/y".
func polySpanEps(poly []P2) float64 {
	if len(poly) == 0 {
		return 0
	}
	minX, minY := poly[0].X, poly[0].Y
	maxX, maxY := minX, minY
	for _, q := range poly {
		if q.X < minX {
			minX = q.X
		}
		if q.X > maxX {
			maxX = q.X
		}
		if q.Y < minY {
			minY = q.Y
		}
		if q.Y > maxY {
			maxY = q.Y
		}
	}
	s := math.Hypot(maxX-minX, maxY-minY)
	if s <= 0 {
		return 0
	}
	return s * 1e-9
}

// nearestVisible finds the nearest vertex of the polygon whose connecting segment
// to p is not blocked by any edge.
//
// Note: callers should generally use nearestVisibleHole -- testing poly alone is
// not enough, see the comment on that function.
func nearestVisible(poly []P2, p P2) int {
	n := len(poly)
	best, bestD := -1, math.MaxFloat64
	for i := 0; i < n; i++ {
		q := poly[i]
		d := dist2(p, q)
		if d >= bestD {
			continue
		}
		if segmentVisible(poly, p, q) {
			bestD, best = d, i
		}
	}
	return best
}

// nearestVisibleHole is the version of nearestVisible that is aware of holes. A
// candidate segment M-H must satisfy:
//  1. it does not cross the already merged polygon poly (segmentVisible);
//  2. it does not cross the edges of the hole H itself belongs to;
//  3. it does not cross any other hole not merged yet.
//
// * Why 2 and 3 are required: H is the hole's rightmost point, which only
// guarantees "the ray from H towards +x does not re-enter the hole", **not** that
// connecting H to an outer vertex to the left/above/below does not cross the hole.
// As soon as a hole is not convex (slot-shaped and snake-shaped holes are very
// common in this project) the segment may cross the hole's notch, or enter the hole
// above it, and the bridged polygon self-intersects -- earClip finds no legal ear,
// drops into the forced removal branch and emits negative-winding triangles. The
// signed areas of those triangles **cancel each other exactly**, so the area
// sentinel (a signed sum) cannot see them at all, but sum|triangle area| grows to
// 2~4 times the expected value and visually "the slot that should be cut out is
// covered by a membrane".
//
// Measured (1.4 GB GUARD_RESULT(1).stp):
//
//	face #2124218 outer 7 pts + hole 38 pts   sum|dA|/expected 2.575 -> 1.000, forced removals 12 -> 0, covered hole points 41 -> 0
//	face #1224280 outer 8 pts + holes 5x12    sum|dA|/expected 2.121 -> 1.000, forced removals 32 -> 0, covered hole points 45 -> 0
//	face #1888964 outer 14 pts + 13 holes     sum|dA|/expected 3.540 -> 1.000, forced removals 44 -> 0, covered hole points 91 -> 0
//
// hi is the index of hp in hole; others are the holes not merged yet.
//
// * Degenerate candidate exclusion: candidates are picked in two rounds. The first
// round excludes candidates where "the bridge edge is collinear with an existing
// edge at p (or q) and continues it in a straight line" -- such bridging creates a
// **zero-width slit** in the polygon, ear clipping finds no legal ear on it and can
// only force removal and emit negative-winding triangles (= a membrane). The second
// round lifts that restriction, guaranteeing the original fallback behavior is
// always available and never worse.
func nearestVisibleHole(poly []P2, p P2, hole []P2, hi int, others [][]P2) int {
	n := len(poly)
	for strict := true; ; strict = false {
		best, bestD := -1, math.MaxFloat64
		for i := 0; i < n; i++ {
			q := poly[i]
			d := dist2(p, q)
			if d >= bestD {
				continue
			}
			if strict && bridgeCollinear(poly, i, p, q, hole, hi) {
				continue
			}
			if segmentVisible(poly, p, q) &&
				segmentClearOfHole(p, q, hole, hi) &&
				segmentClearOfLoops(p, q, others) {
				bestD, best = d, i
			}
		}
		if best >= 0 || !strict {
			return best
		}
	}
}

// collinear3 reports whether the three points a, b, c are (approximately)
// collinear. It compares |cross| / (|b-a|*|c-a|) against a sine threshold, so it is
// independent of coordinate scale; an absolute tolerance fails here -- parameter
// domain coordinates can reach 1e3 and a collinearity test needs 1e-12 precision.
func collinear3(a, b, c P2) bool {
	const sinEps = 1e-9
	ux, uy := b.X-a.X, b.Y-a.Y
	vx, vy := c.X-a.X, c.Y-a.Y
	lu := math.Hypot(ux, uy)
	lv := math.Hypot(vx, vy)
	if lu <= 0 || lv <= 0 {
		return false
	}
	return math.Abs(ux*vy-uy*vx) <= sinEps*lu*lv
}

// bridgeCollinear reports whether bridging p to poly[i] (= q) would "continue" an
// existing edge in a straight line and thereby create a zero-width slit in the
// bridged polygon.
//
// Criteria (any one means degenerate):
//  1. the hole's previous edge at p is collinear with p->q (p is the hole's
//     rightmost point and the previous edge is often the hole's vertical right
//     edge; the bridge edge continuing it downwards is exactly this case);
//  2. p->q is collinear with the hole's next edge at p;
//  3. q's previous edge in poly is collinear with q->p;
//  4. q->p is collinear with q's next edge.
//
// Measured (face #1224280 of the 1.4 GB file): the rightmost x of the 5 "rectangular
// frame" holes are all about 48.8757, so the "nearest visible vertex" always picks
// the rightmost point of a neighboring hole and the bridge edge is exactly the
// straight extension of the hole's right edge, creating a zero-width slit running
// from y=247 all the way down to y=27 -- ear clipping forces removal 42 times and
// sum|dA| grows to 2.94 times the expected value, visually "the frame that should
// be cut out is covered by a membrane". Excluding such candidates drops forced
// removals to 0.
func bridgeCollinear(poly []P2, i int, p, q P2, hole []P2, hi int) bool {
	n := len(poly)
	m := len(hole)
	if m >= 3 {
		if collinear3(hole[(hi+m-1)%m], p, q) {
			return true
		}
		if collinear3(p, q, hole[(hi+1)%m]) {
			return true
		}
	}
	if n >= 3 {
		if collinear3(poly[(i+n-1)%n], q, p) {
			return true
		}
		if collinear3(q, p, poly[(i+1)%n]) {
			return true
		}
	}
	return false
}

// segmentClearOfHole checks that segment p-q does not intersect the edges of hole
// (skipping the two edges adjacent to index hi, and any edge with p as an endpoint).
func segmentClearOfHole(p, q P2, hole []P2, hi int) bool {
	m := len(hole)
	if m < 3 {
		return true
	}
	for k := 0; k < m; k++ {
		a, b := hole[k], hole[(k+1)%m]
		if k == hi || (k+1)%m == hi {
			continue
		}
		if sameP(a, p) || sameP(b, p) {
			continue
		}
		if segIntersect(p, q, a, b) {
			return false
		}
	}
	return true
}

// segmentClearOfLoops checks that segment p-q does not intersect the edges of any
// loop in loops.
func segmentClearOfLoops(p, q P2, loops [][]P2) bool {
	for _, l := range loops {
		m := len(l)
		if m < 3 {
			continue
		}
		for k := 0; k < m; k++ {
			a, b := l[k], l[(k+1)%m]
			if sameP(a, p) || sameP(b, p) {
				continue
			}
			if segIntersect(p, q, a, b) {
				return false
			}
		}
	}
	return true
}

// segmentVisible checks that segment p-q does not intersect any edge of the
// polygon.
//
// * The check must exclude endpoints coinciding with q **by coordinate** (sameP),
// not merely by "adjacent index". Bridging writes the same point twice (different
// indices, same coordinates); excluding only the adjacent copy still counts the
// other copy's edge as "intersecting the segment at its endpoint", so almost
// **every** candidate is judged invisible (measured: of 64 vertices only 6
// remained "visible"), nearestVisibleHole finds nothing usable and degrades to the
// "nearest vertex" fallback -- the bridge edge crosses the hole and we are back to
// a membrane.
func segmentVisible(poly []P2, p, q P2) bool {
	n := len(poly)
	for i := 0; i < n; i++ {
		j := (i + 1) % n
		a, b := poly[i], poly[j]
		if sameP(a, q) || sameP(b, q) {
			continue
		}
		if sameP(a, p) || sameP(b, p) {
			continue
		}
		if segIntersect(p, q, a, b) {
			return false
		}
	}
	return true
}

func segIntersect(p1, p2, p3, p4 P2) bool {
	d1 := cross2(p3, p4, p1)
	d2 := cross2(p3, p4, p2)
	d3 := cross2(p1, p2, p3)
	d4 := cross2(p1, p2, p4)
	if ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) &&
		((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0)) {
		return true
	}
	const eps = 1e-14
	if math.Abs(d1) < eps && onSeg(p3, p4, p1) {
		return true
	}
	if math.Abs(d2) < eps && onSeg(p3, p4, p2) {
		return true
	}
	if math.Abs(d3) < eps && onSeg(p1, p2, p3) {
		return true
	}
	if math.Abs(d4) < eps && onSeg(p1, p2, p4) {
		return true
	}
	return false
}

func onSeg(a, b, c P2) bool {
	return math.Min(a.X, b.X)-1e-12 <= c.X && c.X <= math.Max(a.X, b.X)+1e-12 &&
		math.Min(a.Y, b.Y)-1e-12 <= c.Y && c.Y <= math.Max(a.Y, b.Y)+1e-12
}

// ---------------------------------------------------------------------------
// Hole boolean clipping: handling invalid input where "a hole loop is not enclosed
// by the outer loop"
// ---------------------------------------------------------------------------

// segCrossLoop reports whether segment a-b **properly crosses** some edge of the
// closed loop loop (shared endpoints do not count).
func segCrossLoop(loop []P2, a, b P2) bool {
	n := len(loop)
	for i := 0; i < n; i++ {
		c, d := loop[i], loop[(i+1)%n]
		if sameP(a, c) || sameP(a, d) || sameP(b, c) || sameP(b, d) {
			continue
		}
		if segIntersect(a, b, c, d) {
			return true
		}
	}
	return false
}

// holeContained reports whether hole h lies entirely inside the outer loop outer:
// all vertices inside, and no edge crossing the outer loop.
func holeContained(outer, h []P2) bool {
	if len(h) < 3 {
		return true
	}
	for _, q := range h {
		if !pointInLoop(outer, q.X, q.Y) {
			return false
		}
	}
	for i := range h {
		if segCrossLoop(outer, h[i], h[(i+1)%len(h)]) {
			return false
		}
	}
	return true
}

// holesContained returns false as soon as one hole is not enclosed by the outer
// loop.
//
// * This is the criterion for the third class of "membrane" in this project. The
// first two (ear clipping winding normalization reversed, zero-area hole index base
// not aligned) all happen under the premise "the hole lies entirely inside the outer
// loop"; this class is the opposite -- the outer loop has only 4~7 points
// (diamond/rectangle) while a hole has 5~14 points, and the hole vertices stick
// right outside the outer loop, so the two loops **intersect**. No matter which
// bridge point is chosen, the merged polygon necessarily self-intersects and ear
// clipping can only force its way through, emitting a pile of same-vertex,
// opposite-winding triangles (signed areas cancel exactly, [hoarea] deviation
// 0.000%, visually a membrane covering the hole).
//
// Measured: of the 88 faces with anomalous area in the 1.4 GB GUARD_RESULT(1).stp,
// the remaining 25 **all** hit this condition (and one shape family often has 4~12
// faces, coming from the same part array).
func holesContained(outer []P2, holes [][]P2) bool {
	for _, h := range holes {
		if !holeContained(outer, h) {
			return false
		}
	}
	return true
}

// cPt is a working point of boolean clipping: parameter-domain UV + the
// corresponding 3D point + its index in the caller's point table. ix >= 0 means it
// is point ix of the table; ix < 0 means it was newly created by cutting.
type cPt struct {
	uv P2
	p  Vec3
	ix int
}

// cutByEdge cuts the **convex** polygon poly into two parts with the directed line
// a->b:
//
//	in  = left side of the line (cross(b-a, q-a) >= 0)
//	out = right side of the line
//
// The two parts share the new intersection point (it is computed once and used by
// both, so the geometry is exactly consistent).
func cutByEdge(poly []cPt, a, b cPt) (out, in []cPt) {
	dx, dy := b.uv.X-a.uv.X, b.uv.Y-a.uv.Y
	side := func(q cPt) float64 { return dx*(q.uv.Y-a.uv.Y) - dy*(q.uv.X-a.uv.X) }
	n := len(poly)
	out = make([]cPt, 0, n+2)
	in = make([]cPt, 0, n+2)
	for i := 0; i < n; i++ {
		c, d := poly[i], poly[(i+1)%n]
		sc, sd := side(c), side(d)
		ci, di := sc >= 0, sd >= 0
		if ci {
			in = append(in, c)
		} else {
			out = append(out, c)
		}
		if ci != di {
			t := sc / (sc - sd)
			in = append(in, cPt{
				uv: P2{c.uv.X + (d.uv.X-c.uv.X)*t, c.uv.Y + (d.uv.Y-c.uv.Y)*t},
				p:  c.p.Add(d.p.Sub(c.p).Mul(t)),
				ix: -1,
			})
			out = append(out, in[len(in)-1])
		}
	}
	return
}

// subConvex returns the convex pieces left after subtracting convex polygon clip
// from convex polygon poly. Each edge of clip is used to cut once and the part
// outside that edge is collected; what remains after all cuts is poly intersect
// clip, which is discarded.
func subConvex(poly, clip []cPt) [][]cPt {
	cur := poly
	var out [][]cPt
	for i := range clip {
		if len(cur) < 3 {
			return out
		}
		o, inn := cutByEdge(cur, clip[i], clip[(i+1)%len(clip)])
		if len(o) >= 3 {
			out = append(out, o)
		}
		cur = inn
	}
	return out
}

// earRetryMaxPieces caps the number of convex pieces boolean clipping produces, so
// pathological input cannot blow up the runtime.
const earRetryMaxPieces = 4000

// loopPts returns the total number of points of several loops.
func loopPts(loops [][]P2) int {
	n := 0
	for _, l := range loops {
		n += len(l)
	}
	return n
}

// loopAreaEps returns the area threshold for "counts as zero area", relative to the
// square of the outer loop's bounding box diagonal, so faces with parameter domain
// scales from tens to thousands can share one criterion.
func loopAreaEps(loop []P2) float64 {
	if len(loop) == 0 {
		return 1e-18
	}
	minX, minY := loop[0].X, loop[0].Y
	maxX, maxY := minX, minY
	for _, q := range loop {
		if q.X < minX {
			minX = q.X
		}
		if q.X > maxX {
			maxX = q.X
		}
		if q.Y < minY {
			minY = q.Y
		}
		if q.Y > maxY {
			maxY = q.Y
		}
	}
	e := (maxX - minX) * (maxY - minY) * 1e-12
	if e < 1e-18 {
		e = 1e-18
	}
	return e
}

// clipRegionTri computes the region "outer minus all holes" exactly, using region
// boolean operations instead of bridging + ear clipping.
//
// The returned triangle indices point into "the caller's point table (outer and
// holes concatenated in order) followed by extra"; the points in extra are newly
// created by cutting and the caller just appends them to the end of the table.
//
// Approach: ear clip the outer loop into triangles (convex pieces), ear clip every
// hole into triangles too, then do "convex minus convex" one by one. The result is
// a set of non-overlapping convex pieces, fan triangulated.
// **The sum|area| of the output triangles always equals the expected area
// (|outer| - sum|holes|), so a membrane is impossible.**
//
// It only makes sense when holesContained is false (a hole sticks out of the outer
// loop and bridging would necessarily self-intersect).
func clipRegionTri(outer []P2, holes [][]P2, flatP []Vec3) ([]int, []paramPoint, bool) {
	n0 := len(outer)
	if n0 < 3 || len(flatP) != n0+loopPts(holes) {
		return nil, nil, false
	}
	var dummy EarDiag
	oOrg := make([]int, n0)
	for i := range oOrg {
		oOrg[i] = i
	}
	ot := earClip(outer, oOrg, &dummy) // earClip normalizes to counter-clockwise
	if len(ot) < 3 {
		return nil, nil, false
	}
	mk := func(uv []P2, off int) []cPt {
		out := make([]cPt, len(uv))
		for i := range uv {
			out[i] = cPt{uv: uv[i], p: flatP[off+i], ix: off + i}
		}
		return out
	}
	op := mk(outer, 0)
	pieces := make([][]cPt, 0, 8)
	for i := 0; i+2 < len(ot); i += 3 {
		pieces = append(pieces, []cPt{op[ot[i]], op[ot[i+1]], op[ot[i+2]]})
	}

	off := n0
	for _, h := range holes {
		if len(h) < 3 {
			continue
		}
		hp := mk(h, off)
		off += len(h)
		hOrg := make([]int, len(h))
		for i := range hOrg {
			hOrg[i] = i
		}
		ht := earClip(h, hOrg, &dummy)
		for j := 0; j+2 < len(ht); j += 3 {
			ct := []cPt{hp[ht[j]], hp[ht[j+1]], hp[ht[j+2]]}
			if cross2(ct[0].uv, ct[1].uv, ct[2].uv) < 0 {
				ct[0], ct[1] = ct[1], ct[0] // subConvex needs "the left side is inside"
			}
			if cross2(ct[0].uv, ct[1].uv, ct[2].uv) <= 0 {
				continue
			}
			next := make([][]cPt, 0, len(pieces)+2)
			for _, pc := range pieces {
				next = append(next, subConvex(pc, ct)...)
				if len(next) > earRetryMaxPieces {
					return nil, nil, false
				}
			}
			pieces = next
			if len(pieces) == 0 {
				break
			}
		}
	}
	if len(pieces) == 0 {
		return nil, nil, false
	}

	eps := loopAreaEps(outer)
	total := len(flatP)
	var tris []int
	var extra []paramPoint
	seen := map[P2]int{}
	get := func(q cPt) int {
		if q.ix >= 0 {
			return q.ix
		}
		if k, ok := seen[q.uv]; ok {
			return total + k
		}
		k := len(extra)
		extra = append(extra, paramPoint{U: q.uv.X, V: q.uv.Y, P: q.p})
		seen[q.uv] = k
		return total + k
	}
	for _, pc := range pieces {
		for i := 1; i+1 < len(pc); i++ {
			a, b, c := pc[0], pc[i], pc[i+1]
			if math.Abs(shoelace([]P2{a.uv, b.uv, c.uv})) <= eps {
				continue
			}
			tris = append(tris, get(a), get(b), get(c))
		}
	}
	if len(tris) < 3 {
		return nil, nil, false
	}
	return tris, extra, true
}

// earClip ear clips a simple polygon (counter-clockwise input).
//
// Implementation notes (they determine performance):
//  1. The remaining loop is a doubly linked list, so removing a vertex is O(1), and
//     a vertex's convexity is recomputed once **only when its neighbors change**
//     instead of rescanning every round.
//  2. The containment test only runs for **reflex vertices**: a convex vertex can
//     never lie inside an "ear". The original implementation scanned all m remaining
//     vertices for every candidate and, when a reflex vertex made the test fail,
//     scanned the whole loop again with O(m) before forcing removal, O(n^3) worst
//     case. Measured: a 21MB fixture part went from 35s to 70s because of it; with
//     the linked list it is back to seconds.
//  3. The forced removal branch is only taken when no legal ear is found in a full
//     round (self-intersecting loop / duplicate points), which still guarantees
//     convergence.
//
// Note: org must be reversed together with work (see below); do not reverse the ord
// used for the reverse traversal -- that would make the two reversals cancel, the
// polygon would still be traversed clockwise, the convexity test would never hold,
// ear clipping would drop into the forced removal branch in the first round, and org
// and work would be out of sync, emitting triangles that span holes.
func earClip(pts []P2, org []int, d *EarDiag) []int {
	n := len(pts)
	if n < 3 {
		return nil
	}
	work := make([]P2, n)
	copy(work, pts)
	// Normalize to counter-clockwise: org maps "work position -> original point
	// index", and after reversing work position i holds the former n-1-i, so org
	// must be reversed too.
	if shoelace(work) < 0 {
		reverseP2(work)
		reverseInt(org)
	}

	prev := make([]int, n)
	next := make([]int, n)
	for i := 0; i < n; i++ {
		prev[i] = (i + n - 1) % n
		next[i] = (i + 1) % n
	}
	convex := func(a, b, c int) bool { return cross2(work[a], work[b], work[c]) > 1e-18 }
	reflex := make([]bool, n)
	for i := 0; i < n; i++ {
		reflex[i] = !convex(prev[i], i, next[i])
	}

	// drop removes vertex b and refreshes the convexity of its two neighbors.
	drop := func(b int) (a, c int) {
		a, c = prev[b], next[b]
		next[a], prev[c] = c, a
		reflex[a] = !convex(prev[a], a, next[a])
		reflex[c] = !convex(prev[c], c, next[c])
		return a, c
	}

	d.Pts = n
	out := make([]int, 0, (n-2)*3)
	left := n
	cur := 0
	fails := 0
	guard := 0
	maxGuard := n*n + 64

	// Pre-scan the set of "zero-width slit" edges (the there-and-back edges left by
	// bridging). A slit edge coincides with its twin and has zero width; a diagonal
	// "crossing" it is not a real self-intersection, so the diagonal check below must
	// let it through, otherwise legal ears would be rejected.
	// The key uses floating bit patterns (bridge copies have bit-identical
	// coordinates) with no tolerance, to avoid hurting normal edges.
	slitKeys := map[edgeKey]bool{}
	if !noDiagCheck() {
		cnt := make(map[edgeKey]int, n)
		for i := 0; i < n; i++ {
			cnt[keyOf(work[i], work[next[i]])]++
		}
		for i := 0; i < n; i++ {
			if cnt[keyOf(work[next[i]], work[i])] > 0 {
				slitKeys[keyOf(work[i], work[next[i]])] = true
			}
		}
	}

	for left > 3 && guard < maxGuard {
		guard++
		d.Iters++
		a, b, c := prev[cur], cur, next[cur]
		ok := convex(a, b, c)
		if ok {
			for k := next[c]; k != a; k = next[k] {
				if !reflex[k] {
					continue
				}
				// * Vertices **coinciding** with the ear's three corners must be
				// skipped. Bridging writes M and H twice each (different indices, same
				// coordinates); the copy falls on a corner, pointInTri necessarily
				// returns true, and the ear is rejected by its own copy. Measured on
				// face #1224280: of 78 points 62 are reflex, almost every ear is blocked
				// by a copy, no ear is found in a full round -> forced removals 42 times
				// -> 38 negative-winding triangles emitted.
				if sameP(work[k], work[a]) || sameP(work[k], work[b]) || sameP(work[k], work[c]) {
					continue
				}
				if pointInTri(work[k], work[a], work[b], work[c]) {
					ok = false
					break
				}
			}
		}
		if ok && !noDiagCheck() {
			// * Diagonal edge-crossing check: the classic criterion "no reflex point
			// inside the triangle" fails when there are **coincident vertices** (the
			// zero-width slit left by bridging) -- the copy falls on a corner and its
			// other endpoint falls outside the triangle, so neither counts as an
			// "interior reflex point", yet its edge genuinely crosses the diagonal
			// a-c. Measured on face #1224280: ear (#4,#5,#8) is accepted by the classic
			// criterion, but the edge #19->#20 containing #5's copy #19 crosses a-c;
			// after clipping, the loop self-intersects and no legal ear is left
			// afterwards. So a-c must be explicitly confirmed not to cross any loop
			// edge.
			for k := c; ; k = next[k] {
				nk := next[k]
				if nk == a {
					break
				}
				p1, p2 := work[k], work[nk]
				if sameP(p1, work[a]) || sameP(p1, work[c]) || sameP(p2, work[a]) || sameP(p2, work[c]) {
					continue
				}
				// Zero-width slits (the "written there and back" edges left by
				// bridging) are allowed through separately: such an edge coincides with
				// its twin, so "crossing" the diagonal only touches a zero-width
				// degenerate edge and is not a real self-intersection.
				if slitKeys[keyOf(p1, p2)] {
					continue
				}
				if segIntersect(work[a], work[c], p1, p2) {
					ok = false
					break
				}
			}
		}
		if ok {
			out = append(out, org[a], org[b], org[c])
			cur, _ = drop(b)
			left--
			fails = 0
			continue
		}
		fails++
		cur = c
		if fails < left {
			continue
		}
		// No legal ear in a full round: the loop is degenerate. Remove the "thinnest"
		// vertex to force progress.
		d.Forced++
		best, bv := cur, math.Inf(1)
		for k, cnt := cur, 0; cnt < left; cnt, k = cnt+1, next[k] {
			if v := math.Abs(cross2(work[prev[k]], work[k], work[next[k]])); v < bv {
				bv, best = v, k
			}
		}
		a, b, c = prev[best], best, next[best]
		if bv >= 1e-15 {
			out = append(out, org[a], org[b], org[c])
		}
		cur, _ = drop(b)
		left--
		fails = 0
	}
	if left == 3 {
		a, b, c := cur, next[cur], next[next[cur]]
		out = append(out, org[a], org[b], org[c])
	}
	return out
}

func pointInTri(p, a, b, c P2) bool {
	d1 := cross2(a, b, p)
	d2 := cross2(b, c, p)
	d3 := cross2(c, a, p)
	hasNeg := d1 < -1e-14 || d2 < -1e-14 || d3 < -1e-14
	hasPos := d1 > 1e-14 || d2 > 1e-14 || d3 > 1e-14
	return !(hasNeg && hasPos)
}

// ---------------------------------------------------------------------------
// Ear clipping input/output dump (diagnostics)
// ---------------------------------------------------------------------------

// dumpEar writes the parameter-domain input and output of ear clipping as
// reproducible text, for drawing and analyzing in 2D afterwards.
//
// Trigger: environment variable STP2GLB_DUMP_EAR=<output file> and the face id
// matches STP2GLB_DEBUG_FACE (supports `*` and comma separated). Tessellate is
// concurrent, so writing the file is locked.
//
// Records (one block per face, one line each):
//
//	F <face id> <outer point count> <hole count> <points per hole...>
//	P <outer x y ...>
//	H <all hole points x y ...> (concatenated in hole order, together with P forming the [outer, holes...] table)
//	T <triangle index triples...> (indices into the [outer, holes...] concatenated table)
var (
	earDumpOnce sync.Once
	earDumpPath string
	earDumpMu   sync.Mutex
)

func dumpEar(fid int, outer []P2, holes [][]P2, tris []int, extra []paramPoint) {
	if fid < 0 {
		return
	}
	earDumpOnce.Do(func() {
		earDumpPath = strings.TrimSpace(os.Getenv("STP2GLB_DUMP_EAR"))
	})
	if earDumpPath == "" || !debugFaceMatch(fid) {
		return
	}
	earDumpMu.Lock()
	defer earDumpMu.Unlock()
	f, err := os.OpenFile(earDumpPath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	w := bufio.NewWriter(f)
	var b strings.Builder
	b.WriteString("F ")
	b.WriteString(strconv.Itoa(fid))
	b.WriteString(" ")
	b.WriteString(strconv.Itoa(len(outer)))
	b.WriteString(" ")
	b.WriteString(strconv.Itoa(len(holes)))
	for _, h := range holes {
		b.WriteString(" ")
		b.WriteString(strconv.Itoa(len(h)))
	}
	b.WriteString("\nP")
	for _, q := range outer {
		b.WriteString(" ")
		b.WriteString(strconv.FormatFloat(q.X, 'g', 17, 64))
		b.WriteString(" ")
		b.WriteString(strconv.FormatFloat(q.Y, 'g', 17, 64))
	}
	b.WriteString("\nH")
	for _, h := range holes {
		for _, q := range h {
			b.WriteString(" ")
			b.WriteString(strconv.FormatFloat(q.X, 'g', 17, 64))
			b.WriteString(" ")
			b.WriteString(strconv.FormatFloat(q.Y, 'g', 17, 64))
		}
	}
	if len(extra) > 0 {
		b.WriteString("\nX")
		for _, e := range extra {
			b.WriteString(" ")
			b.WriteString(strconv.FormatFloat(e.U, 'g', 17, 64))
			b.WriteString(" ")
			b.WriteString(strconv.FormatFloat(e.V, 'g', 17, 64))
		}
	}
	b.WriteString("\nT")
	for _, t := range tris {
		b.WriteString(" ")
		b.WriteString(strconv.Itoa(t))
	}
	b.WriteString("\n")
	_, _ = w.WriteString(b.String())
	_ = w.Flush()
	_ = f.Close()
}

