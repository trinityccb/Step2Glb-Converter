package step

import (
	"os"
	"testing"
	"time"
)

// TestParseSample pins down parser behaviour on real files.
// If it loops forever, go test -timeout prints the goroutine stacks for
// immediate diagnosis.
func TestParseSample(t *testing.T) {
	p := os.Getenv("STP_SAMPLE")
	if p == "" {
		p = "../../../stp2glb/node_modules/occt-import-js/test/testfiles/cax-if/as1-tu-203.stp"
	}
	data, err := os.ReadFile(p)
	if err != nil {
		t.Skipf("sample not found: %v", err)
	}
	debugUnconsumed = true
	start := time.Now()
	f, err := Parse(data)
	el := time.Since(start)
	if err != nil {
		t.Fatalf("parse failed: %v", err)
	}
	t.Logf("file %s (%d bytes) -> %d entities, took %v", p, len(data), len(f.Entities), el)
	for _, u := range Unconsumed() {
		t.Logf("unconsumed character pos=%d byte=%q context=%q", u.Pos, u.Byte, u.Ctx)
	}
	if len(f.Entities) == 0 {
		t.Fatalf("no entities parsed")
	}
}
