package step

import (
	"fmt"
	"strings"
)

// Assembly tree: reconstructs the NEXT_ASSEMBLY_USAGE_OCCURRENCE chain of a STEP file into a
// CATIA-like "assembly -> sub-assembly -> part instance" hierarchy, so that GLB can emit it as
// a glTF node tree.
//
// Note: what is reconstructed here is the **assembly structure tree**, not the CATIA
// **feature tree**. STEP (AP214/AP242) records only the final B-Rep and carries no modeling
// history -- none of PAD / POCKET / HOLE / SKETCH / FEATURE_DEFINITION can be found in the
// file, so the "sketch, then extrude, then cut hole" chain does not exist in STEP at all and
// cannot be reconstructed.

// AsmNode is one node of the assembly tree: a part instance or an assembly container.
type AsmNode struct {
	Name     string // display name: the STEP product name copied verbatim (PRODUCT_DEFINITION -> PRODUCT)
	InstName string // id on the assembly relation (NEXT_ASSEMBLY_USAGE_OCCURRENCE parameter 0)
	PartName string // description on the assembly relation (parameter 2); CATIA exports it all upper case
	SR       int    // shape representation of this node (geometry container)
	Local    Mat34  // transform relative to the parent node
	World    Mat34  // transform accumulated up to the root
	Parent   int    // parent node index, -1 for the root
	Children []int
}

// AsmTree is the complete assembly hierarchy; Root is the index of the root node.
type AsmTree struct {
	Nodes []AsmNode
	Root  int
}

// Label is the text shown for a node in the assembly tree, shared by logs and GLB.
//
// There is only one rule: **copy the product name from STEP verbatim** (the name of
// PRODUCT_DEFINITION -> PRODUCT) with no processing whatsoever. The requester requires the GLB
// assembly tree to match the tree seen in a STEP viewer word for word, for easy side-by-side
// comparison.
//
// Why "showing the nicer of the two" is not an option -- a node actually carries two names,
// under different conventions:
//
//	PRODUCT('assembly.810')                                    <- product name
//	NEXT_ASSEMBLY_USAGE_OCCURRENCE('NCBlock','NCBlock',...,#PD) <- name on the assembly relation
//
// Measured (GUARD_RESULT_MMA_HB51_070.stp), the STEP viewer shows the **product name**:
//
//	viewer          : OriginGeoStation > assembly.1396 > GeoStation > .1 / Z1 FZ / Z3 AS
//	                  > assembly.810 > assembly.769 / .774 / .778 ...
//	before renaming : PositionGeoStation (assembly.1396), Z3 AS (.1),
//	                  NCBlock (assembly.810), Console (assembly.769) ...
//
// The old "human name (machine id)" form read better but did not match the viewer, so it was
// dropped entirely as the requester required; the human names are still kept in
// AsmNode.InstName/PartName and can be seen with STP2GLB_DBG_NAMES=1.
//
// When the product name is missing, the instance name, then the description, and only then the
// caller supplied fallback name are used in that order.
func (n *AsmNode) Label() string {
	for _, s := range [...]string{n.Name, n.InstName, n.PartName} {
		if s = strings.TrimSpace(s); s != "" {
			return s
		}
	}
	return fmt.Sprintf("shape_%d", n.SR)
}

// hasName reports whether this node can display a name at all (instead of degrading to shape_NNNN).
func (n *AsmNode) hasName() bool {
	for _, s := range [...]string{n.Name, n.InstName, n.PartName} {
		if strings.TrimSpace(s) != "" {
			return true
		}
	}
	return false
}

// Depth returns the maximum depth of the tree (the root counts as 1).
func (t *AsmTree) Depth() int {
	if t == nil || len(t.Nodes) == 0 {
		return 0
	}
	d := 0
	for i := range t.Nodes {
		n := 0
		for p := t.Nodes[i].Parent; p >= 0; p = t.Nodes[p].Parent {
			n++
			if n > 10000 {
				break // defensive: no endless loop on malformed data
			}
		}
		if n > d {
			d = n
		}
	}
	return d + 1
}

// faceView is "one instance view of a face": which transform emits it and which part group it
// belongs to.
type faceView struct {
	Xform Mat34
	SR    int
}

// asmRel holds the names carried by one assembly relation.
type asmRel struct {
	inst string // parameter 0: id on the assembly relation
	part string // parameter 2: description on the assembly relation (CATIA writes the part name here, all upper case)
}

// Lines renders the assembly tree as indented text with at most max lines (<=0 means unlimited),
// for logs and troubleshooting.
func (t *AsmTree) Lines(max int) []string {
	if t == nil || len(t.Nodes) == 0 {
		return nil
	}
	out := make([]string, 0, 64)
	var rec func(i, depth int)
	rec = func(i, depth int) {
		if max > 0 && len(out) >= max {
			return
		}
		nd := t.Nodes[i]
		out = append(out, strings.Repeat("  ", depth)+"- "+nd.Label())
		for _, c := range nd.Children {
			rec(c, depth+1)
		}
	}
	for i := range t.Nodes {
		if t.Nodes[i].Parent < 0 {
			rec(i, 0)
		}
	}
	return out
}

// LeafCount returns the number of leaves (part instances without children).
func (t *AsmTree) LeafCount() int {
	n := 0
	for i := range t.Nodes {
		if len(t.Nodes[i].Children) == 0 {
			n++
		}
	}
	return n
}

// NoNameCount returns the number of nodes that got no name at all: such nodes can only display
// the kernel fallback name shape_NNNN in the GLB. It should be 0 for a normal file; a value
// above 0 means that assembly node in the source file has an empty product name, instance name
// and description, which is **missing information in the source file**.
func (t *AsmTree) NoNameCount() int {
	n := 0
	for i := range t.Nodes {
		if !t.Nodes[i].hasName() {
			n++
		}
	}
	return n
}

// NameDebug lists every candidate name per node, used by STP2GLB_DBG_NAMES to troubleshoot naming.
//
// The display name always equals the prod (product name) column -- when the two sides differ,
// these three columns tell whether the wrong field is read or the source file simply has none.
func (t *AsmTree) NameDebug(max int) []string {
	if t == nil || len(t.Nodes) == 0 {
		return nil
	}
	out := make([]string, 0, 64)
	var rec func(i, depth int)
	rec = func(i, depth int) {
		if max > 0 && len(out) >= max {
			return
		}
		nd := &t.Nodes[i]
		out = append(out, fmt.Sprintf("%s%-40s prod=%-24q inst=%-32q part=%-20q",
			strings.Repeat("  ", depth), "-> "+nd.Label(), nd.Name, nd.InstName, nd.PartName))
		for _, c := range nd.Children {
			rec(c, depth+1)
		}
	}
	for i := range t.Nodes {
		if t.Nodes[i].Parent < 0 {
			rec(i, 0)
		}
	}
	return out
}

// asmIndex gathers every index needed to resolve assembly names.
type asmIndex struct {
	rel       map[int]asmRel // NAUO id -> name
	nauoChild map[int]int    // NAUO id -> child PRODUCT_DEFINITION
	productOf map[int]string // PRODUCT_DEFINITION -> product name
	srPD      map[int]int    // shape representation -> PRODUCT_DEFINITION
}

// buildAsmIndex scans a STEP file and builds the assembly name index.
//
// Key entities and parameter slots (slots follow the ISO 10303-21 parameter order and must not
// be guessed as "the n-th reference"):
//
//	PRODUCT(name, ...)                                       0 = product name
//	PRODUCT_DEFINITION_FORMATION*(id, desc, of_product, ...)  2 = PRODUCT
//	PRODUCT_DEFINITION(id, desc, formation, frame)            2 = formation
//	NEXT_ASSEMBLY_USAGE_OCCURRENCE(id, name, desc, parent PD, child PD, ref designator)
//	                                                          0 = instance name 2 = part name 4 = child PD
//	SHAPE_DEFINITION_REPRESENTATION(PDS, SR)                  0 = PDS  1 = SR
//	PRODUCT_DEFINITION_SHAPE(id, desc, definition)            2 = PD or NAUO
func buildAsmIndex(f *File) *asmIndex {
	ix := &asmIndex{
		rel:       make(map[int]asmRel, 256),
		nauoChild: make(map[int]int, 256),
		productOf: make(map[int]string, 512),
		srPD:      make(map[int]int, 1024),
	}
	prodName := make(map[int]string, 256)
	formProduct := make(map[int]string, 256)

	// pass 1: PRODUCT names.
	for _, id := range f.Order {
		if e := f.Entities[id]; e != nil && e.Type == "PRODUCT" {
			prodName[id] = strings.TrimSpace(e.Str(0))
		}
	}
	// pass 2: formation -> product name.
	for _, id := range f.Order {
		e := f.Entities[id]
		if e == nil || !strings.HasPrefix(e.Type, "PRODUCT_DEFINITION_FORMATION") {
			continue
		}
		if n := prodName[e.Ref(2)]; n != "" {
			formProduct[id] = n
		}
	}
	// pass 3: product definition -> product name, plus assembly relations and shape representation owners.
	for _, id := range f.Order {
		e := f.Entities[id]
		if e == nil {
			continue
		}
		switch {
		case e.Type == "PRODUCT_DEFINITION":
			if n := formProduct[e.Ref(2)]; n != "" {
				ix.productOf[id] = n
			}
		case strings.Contains(e.Type, "ASSEMBLY_USAGE_OCCURRENCE") ||
			e.Type == "ASSEMBLY_COMPONENT_USAGE":
			ix.rel[id] = asmRel{
				inst: strings.TrimSpace(e.Str(0)),
				part: strings.TrimSpace(e.Str(2)),
			}
			if c := e.Ref(4); c != 0 {
				ix.nauoChild[id] = c
			}
		case e.Type == "SHAPE_DEFINITION_REPRESENTATION":
			if ps := f.Entities[e.Ref(0)]; ps != nil {
				if pd := ps.Ref(2); pd != 0 {
					ix.srPD[e.Ref(1)] = pd
				}
			}
		}
	}
	return ix
}

// nameOfSR gives the product name of a shape representation, for cases without an assembly
// relation such as the root node.
func (ix *asmIndex) nameOfSR(sr int) string {
	if ix == nil || sr == 0 {
		return ""
	}
	return ix.productOf[ix.srPD[sr]]
}

// relOfNAUO gives the names carried by an assembly relation.
func (ix *asmIndex) relOfNAUO(nauo int) (asmRel, bool) {
	if ix == nil || nauo == 0 {
		return asmRel{}, false
	}
	r, ok := ix.rel[nauo]
	return r, ok
}

// nauoOfCDSR resolves the NEXT_ASSEMBLY_USAGE_OCCURRENCE from the second parameter
// (represented_product_relation) of a CONTEXT_DEPENDENT_SHAPE_REPRESENTATION.
//
//	CDSR(#transform relation, #PRODUCT_DEFINITION_SHAPE)
//	PRODUCT_DEFINITION_SHAPE(' ',' ', #NAUO)   <- the assembly relation is here
//
// Returns 0 when it is not found (for example when it points at the product definition itself,
// as is common for assembly roots).
func (f *File) nauoOfCDSR(cdsr *Entity) int {
	if cdsr == nil {
		return 0
	}
	ps := f.Entities[cdsr.Ref(1)]
	if ps == nil {
		return 0
	}
	t := ps.Ref(2)
	te := f.Entities[t]
	if te == nil {
		return 0
	}
	if strings.Contains(te.Type, "ASSEMBLY_USAGE_OCCURRENCE") ||
		te.Type == "ASSEMBLY_COMPONENT_USAGE" {
		return t
	}
	return 0
}
