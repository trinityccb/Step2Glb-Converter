package step

import "math"

// Vec4 is used for homogeneous coordinate arithmetic on rational B-splines.
type Vec4 struct{ X, Y, Z, W float64 }

func (a Vec4) Add(b Vec4) Vec4    { return Vec4{a.X + b.X, a.Y + b.Y, a.Z + b.Z, a.W + b.W} }
func (a Vec4) Mul(s float64) Vec4 { return Vec4{a.X * s, a.Y * s, a.Z * s, a.W * s} }

// Curve is an evaluable parametric curve. t is in the curve's natural parameter
// (angle or length).
type Curve interface {
	// Point returns the 3D point at parameter t.
	Point(t float64) Vec3
	// Range returns the natural parameter range. A closed curve may be (-pi, pi].
	Range() (float64, float64)
	// ClosestParam returns the parameter on the curve closest to p, guess being
	// the initial hint.
	ClosestParam(p Vec3, guess float64) (float64, bool)
	// Periodic reports whether the parameter wraps around (full circle / closed spline).
	Periodic() bool
}

// ---------------------------------------------------------------------------
// Line
// ---------------------------------------------------------------------------

// LineCurve is an infinite line: P(t) = Origin + t*Dir, where Dir carries a
// length (STEP's VECTOR).
type LineCurve struct {
	Origin Vec3
	Dir    Vec3
}

func (c *LineCurve) Point(t float64) Vec3 {
	return c.Origin.Add(c.Dir.Mul(t))
}

func (c *LineCurve) Range() (float64, float64) { return math.Inf(-1), math.Inf(1) }

func (c *LineCurve) Periodic() bool { return false }

func (c *LineCurve) ClosestParam(p Vec3, guess float64) (float64, bool) {
	d := c.Dir
	dd := d.Dot(d)
	if dd < 1e-24 {
		return 0, false
	}
	return p.Sub(c.Origin).Dot(d) / dd, true
}

// ---------------------------------------------------------------------------
// Circle / ellipse
// ---------------------------------------------------------------------------

// ConicCurve represents circles and ellipses with one parametrisation:
// P(t) = Origin + A*cos(t) + B*sin(t), where A and B are orthogonal semi-axis
// vectors carrying a length. A circle is the special case with equal A and B, so
// both share the evaluation and closest-point logic.
type ConicCurve struct {
	Origin Vec3
	A      Vec3 // major semi-axis vector (with length)
	B      Vec3 // minor semi-axis vector (with length)
	Normal Vec3 // plane normal, A x B normalised
}

// NewCircle builds a circle from a local placement and a radius.
func NewCircle(pl Placement, radius float64) *ConicCurve {
	x := pl.X.Mul(radius)
	y := pl.Y().Mul(radius)
	return &ConicCurve{Origin: pl.Origin, A: x, B: y, Normal: x.Cross(y).Normalize()}
}

// NewEllipse builds an ellipse from a local placement and two semi-axis lengths.
func NewEllipse(pl Placement, semi1, semi2 float64) *ConicCurve {
	x := pl.X.Mul(semi1)
	y := pl.Y().Mul(semi2)
	return &ConicCurve{Origin: pl.Origin, A: x, B: y, Normal: x.Cross(y).Normalize()}
}

func (c *ConicCurve) Point(t float64) Vec3 {
	return c.Origin.Add(c.A.Mul(math.Cos(t))).Add(c.B.Mul(math.Sin(t)))
}

func (c *ConicCurve) Range() (float64, float64) { return 0, 2 * math.Pi }

func (c *ConicCurve) Periodic() bool { return true }

// ClosestParam is closed-form for a circle; for an ellipse it uses a little
// sampling plus golden-section refinement.
func (c *ConicCurve) ClosestParam(p Vec3, guess float64) (float64, bool) {
	la, lb := c.A.Len(), c.B.Len()
	rel := p.Sub(c.Origin)
	if math.Abs(la-lb) < 1e-9*math.Max(la, 1) && la > 1e-12 {
		// Circle: closed form
		u := rel.Dot(c.A) / (la * la)
		v := rel.Dot(c.B) / (lb * lb)
		if math.Abs(u) < 1e-18 && math.Abs(v) < 1e-18 {
			return guess, true
		}
		return math.Atan2(v, u), true
	}
	// Ellipse: locate by sampling, then refine
	a1 := math.Atan2(rel.Dot(c.B)/(lb*lb), rel.Dot(c.A)/(la*la))
	best, bestD := a1, math.Inf(1)
	for d := -0.35; d <= 0.35; d += 0.035 {
		t := a1 + d
		dist := c.Point(t).Dist(p)
		if dist < bestD {
			bestD, best = dist, t
		}
	}
	lo, hi := best-0.05, best+0.05
	for i := 0; i < 60; i++ {
		m1 := lo + (hi-lo)/3
		m2 := hi - (hi-lo)/3
		if c.Point(m1).Dist(p) < c.Point(m2).Dist(p) {
			hi = m2
		} else {
			lo = m1
		}
	}
	return (lo + hi) / 2, true
}

// ---------------------------------------------------------------------------
// B-spline curve (rational variant included)
// ---------------------------------------------------------------------------

// BSplineCurve supports standard and rational B-splines; the knot vector is
// already expanded.
type BSplineCurve struct {
	Degree int
	Knots  []float64 // full knot vector, length = len(CP)+Degree+1
	CP     []Vec3    // control points
	W      []float64 // weights, nil means non-rational
	Closed bool
}

// Range returns the valid parameter interval of the spline.
func (c *BSplineCurve) Range() (float64, float64) {
	if len(c.Knots) < 2 {
		return 0, 0
	}
	return c.Knots[0], c.Knots[len(c.Knots)-1]
}

func (c *BSplineCurve) Periodic() bool { return c.Closed }

func (c *BSplineCurve) Point(t float64) Vec3 {
	p := c.Degree
	U := c.Knots
	n := len(c.CP) - 1
	if n < 0 {
		return Vec3{}
	}
	if p > n {
		p = n
	}
	if len(U) != n+p+2 {
		// Knot vector and control points mismatch: fall back instead of crashing
		return c.linearFallback(t)
	}
	t0, t1 := U[p], U[n+1]
	if t < t0 {
		t = t0
	}
	if t > t1 {
		t = t1
	}
	k := findSpan(n, p, t, U)

	// Homogeneous-coordinate de Boor
	d := make([]Vec4, p+1)
	for j := 0; j <= p; j++ {
		idx := k - p + j
		if idx < 0 {
			idx = 0
		}
		if idx > n {
			idx = n
		}
		w := 1.0
		if c.W != nil {
			w = c.W[idx]
		}
		d[j] = Vec4{c.CP[idx].X * w, c.CP[idx].Y * w, c.CP[idx].Z * w, w}
	}
	for r := 1; r <= p; r++ {
		for j := p; j >= r; j-- {
			i := k - p + j
			lo, hi := U[i], U[i+p-r+1]
			alpha := 0.0
			if math.Abs(hi-lo) > 1e-15 {
				alpha = (t - lo) / (hi - lo)
			}
			d[j] = d[j-1].Mul(1 - alpha).Add(d[j].Mul(alpha))
		}
	}
	res := d[p]
	if math.Abs(res.W) > 1e-15 {
		return Vec3{res.X / res.W, res.Y / res.W, res.Z / res.W}
	}
	return Vec3{res.X, res.Y, res.Z}
}

func (c *BSplineCurve) linearFallback(t float64) Vec3 {
	if len(c.CP) == 0 {
		return Vec3{}
	}
	return c.CP[0]
}

// ClosestParam finds the closest parameter with coarse sampling plus local
// refinement; robust enough and derivative-free.
func (c *BSplineCurve) ClosestParam(p Vec3, guess float64) (float64, bool) {
	t0, t1 := c.Range()
	if !(t1 > t0) {
		return t0, false
	}
	const samples = 48
	best, bestD := t0, math.Inf(1)
	for i := 0; i <= samples; i++ {
		t := t0 + (t1-t0)*float64(i)/samples
		d := c.Point(t).Dist(p)
		if d < bestD {
			bestD, best = d, t
		}
	}
	step := (t1 - t0) / samples
	lo, hi := best-step, best+step
	for i := 0; i < 80; i++ {
		m1 := lo + (hi-lo)/3
		m2 := hi - (hi-lo)/3
		if c.Point(m1).Dist(p) < c.Point(m2).Dist(p) {
			hi = m2
		} else {
			lo = m1
		}
	}
	return (lo + hi) / 2, true
}

// findSpan locates the knot span containing parameter t.
func findSpan(n, p int, t float64, U []float64) int {
	if t >= U[n+1] {
		return n
	}
	if t <= U[p] {
		return p
	}
	lo, hi := p, n+1
	mid := (lo + hi) / 2
	for t < U[mid] || t >= U[mid+1] {
		if t < U[mid] {
			hi = mid
		} else {
			lo = mid
		}
		mid = (lo + hi) / 2
		if mid <= p || mid >= n {
			break
		}
	}
	return mid
}

// ---------------------------------------------------------------------------
// Polyline
// ---------------------------------------------------------------------------

// PolylineCurve is a polyline connecting vertices in order; the parameter is the
// vertex index.
type PolylineCurve struct {
	Pts []Vec3
}

func (c *PolylineCurve) Point(t float64) Vec3 {
	n := len(c.Pts)
	if n == 0 {
		return Vec3{}
	}
	if n == 1 {
		return c.Pts[0]
	}
	if t <= 0 {
		return c.Pts[0]
	}
	if t >= float64(n-1) {
		return c.Pts[n-1]
	}
	i := int(math.Floor(t))
	f := t - float64(i)
	if i >= n-1 {
		return c.Pts[n-1]
	}
	return c.Pts[i].Add(c.Pts[i+1].Sub(c.Pts[i]).Mul(f))
}

func (c *PolylineCurve) Range() (float64, float64) {
	return 0, math.Max(0, float64(len(c.Pts)-1))
}

func (c *PolylineCurve) Periodic() bool { return false }

func (c *PolylineCurve) ClosestParam(p Vec3, guess float64) (float64, bool) {
	best, bestD := 0.0, math.Inf(1)
	n := len(c.Pts)
	if n < 2 {
		return 0, false
	}
	for i := 0; i < n-1; i++ {
		a, b := c.Pts[i], c.Pts[i+1]
		ab := b.Sub(a)
		l2 := ab.Dot(ab)
		f := 0.0
		if l2 > 1e-24 {
			f = clamp01(p.Sub(a).Dot(ab) / l2)
		}
		q := a.Add(ab.Mul(f))
		if d := q.Dist(p); d < bestD {
			bestD, best = d, float64(i)+f
		}
	}
	return best, true
}

// ---------------------------------------------------------------------------
// Composite curve (COMPOSITE_CURVE)
// ---------------------------------------------------------------------------

// CompositeCurve is built from directed curve segments joined end to end.
type CompositeCurve struct {
	Segs []Curve
	Rev  []bool // whether each segment is reversed
}

func (c *CompositeCurve) segmentLengths() []float64 {
	out := make([]float64, len(c.Segs))
	for i, s := range c.Segs {
		t0, t1 := s.Range()
		out[i] = math.Abs(t1 - t0)
		if math.IsInf(out[i], 0) {
			out[i] = 1
		}
	}
	return out
}

func (c *CompositeCurve) Point(t float64) Vec3 {
	lens := c.segmentLengths()
	total := 0.0
	for _, l := range lens {
		total += l
	}
	if total <= 0 {
		return Vec3{}
	}
	acc := 0.0
	for i, s := range c.Segs {
		if t <= acc+lens[i] || i == len(c.Segs)-1 {
			f := (t - acc) / math.Max(lens[i], 1e-12)
			f = clamp01(f)
			t0, t1 := s.Range()
			if !isFinite(t0) {
				t0 = 0
			}
			if !isFinite(t1) {
				t1 = 1
			}
			if c.Rev[i] {
				return s.Point(t1 + (t0-t1)*f)
			}
			return s.Point(t0 + (t1-t0)*f)
		}
		acc += lens[i]
	}
	return Vec3{}
}

func (c *CompositeCurve) Range() (float64, float64) {
	lens := c.segmentLengths()
	total := 0.0
	for _, l := range lens {
		total += l
	}
	return 0, total
}

func (c *CompositeCurve) Periodic() bool { return false }

// ClosestParam first locates the segment by coarse sampling, then refines inside
// it with golden-section search. Sampling alone leaves a parameter error of about
// 1/64 of a segment, too large a bias for extrusion surface projection tests.
func (c *CompositeCurve) ClosestParam(p Vec3, guess float64) (float64, bool) {
	t0, t1 := c.Range()
	if !(t1 > t0) {
		return 0, false
	}
	const samples = 64
	best, bestD := t0, math.Inf(1)
	si := 0
	for i := 0; i <= samples; i++ {
		t := t0 + (t1-t0)*float64(i)/samples
		if d := c.Point(t).Dist(p); d < bestD {
			bestD, best = d, t
			si = i
		}
	}
	step := (t1 - t0) / samples
	lo := t0 + float64(si-1)*step
	hi := t0 + float64(si+1)*step
	lo, hi = clampF(lo, t0, t1), clampF(hi, t0, t1)
	if step <= 0 {
		return best, true
	}
	ref := func(t float64) float64 { return c.Point(t).Dist(p) }
	r := goldenMin(ref, best, lo, hi)
	if ref(r) <= ref(best) {
		return r, true
	}
	return best, true
}

// ---------------------------------------------------------------------------
// Transform wrapper
// ---------------------------------------------------------------------------

// XFormCurve places the curve in the given local coordinate system.
type XFormCurve struct {
	Base Curve
	M    Mat34
}

func (c *XFormCurve) Point(t float64) Vec3 { return c.M.Apply(c.Base.Point(t)) }

func (c *XFormCurve) Range() (float64, float64) { return c.Base.Range() }

func (c *XFormCurve) Periodic() bool { return c.Base.Periodic() }

func (c *XFormCurve) ClosestParam(p Vec3, guess float64) (float64, bool) {
	inv, ok := c.M.InverseGeneral()
	if !ok {
		inv = Identity()
	}
	return c.Base.ClosestParam(inv.Apply(p), guess)
}

func clamp01(f float64) float64 {
	if f < 0 {
		return 0
	}
	if f > 1 {
		return 1
	}
	return f
}

func isFinite(f float64) bool {
	return !math.IsInf(f, 0) && !math.IsNaN(f)
}
