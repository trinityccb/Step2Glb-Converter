package step

import "math"

// Outline (feature edge) extraction.
//
// Why take B-Rep edges rather than triangle mesh edges:
//   - Mesh edges are a by-product of tessellation; one surface is cut into
//     dozens or hundreds of quads, drawing a dense triangular wireframe rather
//     than the ring of edges seen in CAD;
//   - B-Rep EDGE_CURVE is the real edge of the design intent -- each edge is
//     drawn once, matching "show edges" in SolidWorks / CATIA.
//
// Outline vertices are baked with the same f.Xform as Tessellate vertices, so
// both live in exactly the same coordinate space: once the node matrix is
// applied, the lines sit right on the faces without drifting.

// OutlineOpts controls outline extraction.
type OutlineOpts struct {
	// Tol is the chord tolerance for curve discretisation; it should match the
	// value used for tessellation, otherwise the lines leave the face.
	Tol float64
	// Ang is the angular tolerance per curve segment (radians); it also has to
	// match tessellation, otherwise a round hole's outline is coarser than the
	// triangles along its rim -- the hole looks round while its ring looks
	// square. Note this is not the Angle below: Angle is the dihedral filter and
	// is in degrees.
	Ang float64
	// Angle is the dihedral angle threshold in degrees. When > 0, only edges
	// whose adjacent face normals differ by at least this much are kept, which
	// filters the "soft edges" (tangent edges) where a fillet meets a plane.
	// <= 0 outputs all B-Rep edges.
	Angle float64
	// MaxSegments caps the total segment count; 0 means unlimited. In very large
	// assemblies the outline itself can take more space than the triangles, so
	// this gate truncates and reports it in the stats.
	MaxSegments int
}

// OutlineStats summarises outline extraction.
type OutlineStats struct {
	Edges      int // deduplicated B-Rep edge count
	Kept       int // edges actually emitted (after angle filtering)
	Segments   int // segment count
	Points     int // vertex count
	Degenerate int // edges with degenerate sampling (too few points / missing entity)
	Filtered   int // edges filtered out by the dihedral threshold
	Truncated  bool
}

// Add accumulates the stats of another part.
func (s *OutlineStats) Add(o OutlineStats) {
	s.Edges += o.Edges
	s.Kept += o.Kept
	s.Segments += o.Segments
	s.Points += o.Points
	s.Degenerate += o.Degenerate
	s.Filtered += o.Filtered
	s.Truncated = s.Truncated || o.Truncated
}

// BuildOutline extracts outlines from the B-Rep boundaries of a set of faces.
//
// Returns LinePositions (one point per 3 floats) and LineIndices (one segment
// per 2 indices, matching glTF mode=1 LINES). The dedup key is
// (transform, edge ID) rather than the edge ID alone: with --flat, several
// instances of the same part share the same EDGE_CURVEs but differ in pose, so
// each must be emitted separately.
func (g *Geom) BuildOutline(faces []*FaceGeom, opt OutlineOpts) ([]float32, []uint32, OutlineStats) {
	st := OutlineStats{}
	if len(faces) == 0 {
		return nil, nil, st
	}
	tol := opt.Tol
	if tol <= 0 {
		tol = 1e-3
	}
	limit := opt.MaxSegments
	if limit <= 0 {
		limit = math.MaxInt32
	}

	// transform -> ID, used in the dedup key
	xfIDs := make(map[[12]float64]int, 8)
	xfOf := make([]int, len(faces))
	for i, f := range faces {
		k := xfKey(f.Xform)
		id, ok := xfIDs[k]
		if !ok {
			id = len(xfIDs)
			xfIDs[k] = id
		}
		xfOf[i] = id
	}

	// Dihedral filtering needs an edge -> adjacent face map. Build it only when
	// the switch is on, to save the usual cost.
	var adj map[[2]int][]int
	if opt.Angle > 0 {
		adj = make(map[[2]int][]int, 1<<12)
		for i, f := range faces {
			for _, ec := range f.Edges {
				k := [2]int{xfOf[i], ec}
				adj[k] = append(adj[k], i)
			}
		}
	}

	var pos []float32
	var idx []uint32
	seen := make(map[[2]int]bool, 1<<12)

outer:
	for i, f := range faces {
		for _, ec := range f.Edges {
			k := [2]int{xfOf[i], ec}
			if seen[k] {
				continue
			}
			seen[k] = true
			st.Edges++

			// Check the gate before sampling: once truncated, stop spending time sampling
			if st.Segments >= limit {
				st.Truncated = true
				break outer
			}

			e := g.E(ec)
			if e == nil {
				st.Degenerate++
				continue
			}
			pts := g.sampleEdge(e, true, SampleOpts{Tol: tol, Ang: opt.Ang})
			if len(pts) < 2 {
				st.Degenerate++
				continue
			}
			if opt.Angle > 0 && !g.edgeIsSharp(adj[k], faces, pts, opt.Angle) {
				st.Filtered++
				continue
			}

			base := uint32(len(pos) / 3)
			for _, p := range pts {
				q := f.Xform.Apply(p)
				pos = append(pos, float32(q.X), float32(q.Y), float32(q.Z))
			}
			for j := 1; j < len(pts); j++ {
				idx = append(idx, base+uint32(j-1), base+uint32(j))
			}
			st.Kept++
			st.Segments += len(pts) - 1
			st.Points += len(pts)
		}
	}
	return pos, idx, st
}

// xfKey flattens the 3x4 transform into a comparable array, to deduplicate poses.
func xfKey(m Mat34) [12]float64 {
	return [12]float64{
		m.R[0], m.R[1], m.R[2],
		m.R[3], m.R[4], m.R[5],
		m.R[6], m.R[7], m.R[8],
		m.T.X, m.T.Y, m.T.Z,
	}
}

// edgeIsSharp reports whether an edge counts as a "sharp edge": the angle
// between adjacent face normals there is >= minDeg.
//
// With only one adjacent face (open boundary), or when the normal cannot be
// computed, always keep the edge -- better one extra line than a missing real
// boundary. When several faces share an edge, judge by the **sharpest** pair.
func (g *Geom) edgeIsSharp(faceIdx []int, faces []*FaceGeom, pts []Vec3, minDeg float64) bool {
	if len(faceIdx) < 2 {
		return true
	}
	mid := pts[len(pts)/2]
	nrm := make([]Vec3, 0, len(faceIdx))
	for _, fi := range faceIdx {
		if n, ok := faces[fi].normalAt(mid); ok {
			nrm = append(nrm, n)
		}
	}
	if len(nrm) < 2 {
		return true
	}
	worst := 1.0 // smallest dot product; closer to 1 means flatter
	for i := 0; i < len(nrm); i++ {
		for j := i + 1; j < len(nrm); j++ {
			if d := nrm[i].Dot(nrm[j]); d < worst {
				worst = d
			}
		}
	}
	return worst <= math.Cos(minDeg*math.Pi/180)
}

// normalAt returns the unit normal of the face at the given point, oriented by
// same_sense. Same convention as surfaceNormal in tess.go, otherwise the
// dihedral angle comes out reversed.
func (fg *FaceGeom) normalAt(p Vec3) (Vec3, bool) {
	s := fg.Surface
	if s == nil {
		return Vec3{}, false
	}
	u, v, ok := s.Project(p, midOf(s.RangeU()), midOf(s.RangeV()))
	if !ok {
		return Vec3{}, false
	}
	_, du, dv := s.D1(u, v)
	n := du.Cross(dv)
	if n.Len() < 1e-18 {
		return Vec3{}, false
	}
	n = n.Normalize()
	if !fg.SameSense {
		n = n.Mul(-1)
	}
	return n, true
}

// midOf returns the midpoint of a parameter interval; unbounded intervals (some
// analytic surfaces report +/-Inf) fall back to 0, otherwise passing Inf as the
// initial projection guess makes ClosestParam diverge.
func midOf(a, b float64) float64 {
	if math.IsInf(a, 0) || math.IsInf(b, 0) || math.IsNaN(a) || math.IsNaN(b) {
		return 0
	}
	return (a + b) / 2
}
