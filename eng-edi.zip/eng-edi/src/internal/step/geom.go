package step

import "math"

// Vec3 is a 3D vector / point.
type Vec3 struct {
	X, Y, Z float64
}

func V3(x, y, z float64) Vec3 { return Vec3{x, y, z} }

func (a Vec3) Add(b Vec3) Vec3    { return Vec3{a.X + b.X, a.Y + b.Y, a.Z + b.Z} }
func (a Vec3) Sub(b Vec3) Vec3    { return Vec3{a.X - b.X, a.Y - b.Y, a.Z - b.Z} }
func (a Vec3) Mul(s float64) Vec3 { return Vec3{a.X * s, a.Y * s, a.Z * s} }

func (a Vec3) Dot(b Vec3) float64 { return a.X*b.X + a.Y*b.Y + a.Z*b.Z }

func (a Vec3) Cross(b Vec3) Vec3 {
	return Vec3{
		a.Y*b.Z - a.Z*b.Y,
		a.Z*b.X - a.X*b.Z,
		a.X*b.Y - a.Y*b.X,
	}
}

func (a Vec3) Len() float64 { return math.Sqrt(a.Dot(a)) }

// LenSq returns the squared length, for distance comparisons without a square root.
func (a Vec3) LenSq() float64 { return a.Dot(a) }

func (a Vec3) Dist(b Vec3) float64 { return a.Sub(b).Len() }

func (a Vec3) Normalize() Vec3 {
	l := a.Len()
	if l < 1e-15 {
		return Vec3{0, 0, 0}
	}
	return a.Mul(1 / l)
}

func (a Vec3) IsZero() bool {
	return math.Abs(a.X) < 1e-15 && math.Abs(a.Y) < 1e-15 && math.Abs(a.Z) < 1e-15
}

// Min/Max component operations.
func (a Vec3) Min(b Vec3) Vec3 {
	return Vec3{math.Min(a.X, b.X), math.Min(a.Y, b.Y), math.Min(a.Z, b.Z)}
}
func (a Vec3) Max(b Vec3) Vec3 {
	return Vec3{math.Max(a.X, b.X), math.Max(a.Y, b.Y), math.Max(a.Z, b.Z)}
}

// Mat34 is an affine transform: rotate by R (row-major 3x3), then translate by T.
type Mat34 struct {
	R [9]float64
	T Vec3
}

// Identity returns the identity transform.
func Identity() Mat34 {
	return Mat34{R: [9]float64{1, 0, 0, 0, 1, 0, 0, 0, 1}}
}

// Apply transforms a point.
func (m Mat34) Apply(p Vec3) Vec3 {
	return Vec3{
		m.R[0]*p.X + m.R[1]*p.Y + m.R[2]*p.Z + m.T.X,
		m.R[3]*p.X + m.R[4]*p.Y + m.R[5]*p.Z + m.T.Y,
		m.R[6]*p.X + m.R[7]*p.Y + m.R[8]*p.Z + m.T.Z,
	}
}

// ApplyDir transforms a direction vector (ignoring translation).
func (m Mat34) ApplyDir(p Vec3) Vec3 {
	return Vec3{
		m.R[0]*p.X + m.R[1]*p.Y + m.R[2]*p.Z,
		m.R[3]*p.X + m.R[4]*p.Y + m.R[5]*p.Z,
		m.R[6]*p.X + m.R[7]*p.Y + m.R[8]*p.Z,
	}
}

// Mul returns the composite transform m*o (o first, then m).
func (m Mat34) Mul(o Mat34) Mat34 {
	var r [9]float64
	for i := 0; i < 3; i++ {
		for j := 0; j < 3; j++ {
			r[i*3+j] = m.R[i*3]*o.R[j] + m.R[i*3+1]*o.R[3+j] + m.R[i*3+2]*o.R[6+j]
		}
	}
	return Mat34{R: r, T: m.Apply(o.T)}
}

// IsIdentity reports whether this is the identity transform (to skip needless
// matrix work).
func (m Mat34) IsIdentity() bool {
	const e = 1e-14
	return math.Abs(m.R[0]-1) < e && math.Abs(m.R[4]-1) < e && math.Abs(m.R[8]-1) < e &&
		math.Abs(m.R[1]) < e && math.Abs(m.R[2]) < e && math.Abs(m.R[3]) < e &&
		math.Abs(m.R[5]) < e && math.Abs(m.R[6]) < e && math.Abs(m.R[7]) < e &&
		m.T.IsZero()
}

// Placement is STEP's AXIS2_PLACEMENT_3D: local origin + Z axis + X reference direction.
type Placement struct {
	Origin Vec3
	Z      Vec3
	X      Vec3
}

// NewPlacement builds an orthogonal frame from an origin, Z axis and reference
// direction.
func NewPlacement(org, z, x Vec3) Placement {
	zz := z.Normalize()
	if zz.IsZero() {
		zz = Vec3{0, 0, 1}
	}
	xx := x.Normalize()
	if xx.IsZero() {
		// When the reference direction is missing, build one not parallel to Z
		if math.Abs(zz.X) < 0.9 {
			xx = Vec3{1, 0, 0}
		} else {
			xx = Vec3{0, 1, 0}
		}
	}
	// Gram-Schmidt orthogonalisation
	xx = xx.Sub(zz.Mul(xx.Dot(zz)))
	if xx.Len() < 1e-12 {
		if math.Abs(zz.X) < 0.9 {
			xx = Vec3{1, 0, 0}
		} else {
			xx = Vec3{0, 1, 0}
		}
		xx = xx.Sub(zz.Mul(xx.Dot(zz)))
	}
	xx = xx.Normalize()
	return Placement{Origin: org, Z: zz, X: xx}
}

// Y returns the third orthogonal axis.
func (p Placement) Y() Vec3 { return p.Z.Cross(p.X) }

// Mat returns the transform for this frame (local -> global).
func (p Placement) Mat() Mat34 {
	y := p.Y()
	return Mat34{
		R: [9]float64{
			p.X.X, y.X, p.Z.X,
			p.X.Y, y.Y, p.Z.Y,
			p.X.Z, y.Z, p.Z.Z,
		},
		T: p.Origin,
	}
}

// LocalTo returns the transform from this frame to the destination frame.
func (p Placement) LocalTo(dst Placement) Mat34 {
	return dst.Mat().InverseRigid().Mul(p.Mat())
}

// InverseRigid inverts a rigid transform (R transposed + negated translation).
func (m Mat34) InverseRigid() Mat34 {
	var r [9]float64
	for i := 0; i < 3; i++ {
		for j := 0; j < 3; j++ {
			r[i*3+j] = m.R[j*3+i]
		}
	}
	inv := Mat34{R: r}
	inv.T = inv.ApplyDir(m.T).Mul(-1)
	return inv
}

// 3x3 matrix inverse (for general non-rigid transforms, e.g. mappings with scale).
func (m Mat34) InverseGeneral() (Mat34, bool) {
	a, b, c := m.R[0], m.R[1], m.R[2]
	d, e, f := m.R[3], m.R[4], m.R[5]
	g, h, i := m.R[6], m.R[7], m.R[8]
	det := a*(e*i-f*h) - b*(d*i-f*g) + c*(d*h-e*g)
	if math.Abs(det) < 1e-18 {
		return Identity(), false
	}
	inv := 1 / det
	var r [9]float64
	r[0] = (e*i - f*h) * inv
	r[1] = (c*h - b*i) * inv
	r[2] = (b*f - c*e) * inv
	r[3] = (f*g - d*i) * inv
	r[4] = (a*i - c*g) * inv
	r[5] = (c*d - a*f) * inv
	r[6] = (d*h - e*g) * inv
	r[7] = (b*g - a*h) * inv
	r[8] = (a*e - b*d) * inv
	out := Mat34{R: r}
	out.T = out.ApplyDir(m.T).Mul(-1)
	return out, true
}
