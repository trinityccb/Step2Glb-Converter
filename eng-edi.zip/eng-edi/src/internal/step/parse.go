package step

import (
	"bytes"
	"fmt"
	"strconv"
	"strings"
	"unicode/utf16"
)

// Kind is the kind of a STEP parameter value.
type Kind uint8

const (
	KindUndefined Kind = iota // $
	KindDerived               // *
	KindString                // 'text'
	KindNumber                // 1.5 / .5 / 1.E-5
	KindEnum                  // .T. / .CARTESIAN.
	KindRef                   // #123
	KindList                  // ( ... )
	KindBinary                // "..."
)

// Value is one STEP entity parameter value, stored compactly to cut memory use
// at millions of entities.
type Value struct {
	Kind Kind
	Str  string  // string literal / enum name
	Num  float64 // numeric value
	Ref  int     // reference ID
	List []Value // list elements
}

// IsRef reports whether the value is an entity reference.
func (v Value) IsRef() bool { return v.Kind == KindRef }

// Entity is one STEP instance record, of the form `#12 = TYPE(a, b, c);`.
type Entity struct {
	ID     int
	Type   string
	Params []Value
}

// File is a fully parsed STEP file.
type File struct {
	Schema   string
	Entities map[int]*Entity
	MaxID    int
	// Order records the order in which entities appear, for stable iteration.
	Order []int
	// complex holds the parts of a complex instance (`#1=(A(..)B(..))`).
	// REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION in assembly relations
	// hides here.
	complex map[int][]*Entity
}

// Complex returns the sub-entity of the given type in the complex instance id,
// or nil if there is none.
func (f *File) Complex(id int, typeName string) *Entity {
	for _, e := range f.complex[id] {
		if e.Type == typeName {
			return e
		}
	}
	return nil
}

// ComplexAll returns all sub-entities of the complex instance id.
func (f *File) ComplexAll(id int) []*Entity { return f.complex[id] }

// IsComplex reports whether id is a complex instance.
func (f *File) IsComplex(id int) bool { return len(f.complex[id]) > 0 }

// HasType reports whether the file contains an entity of the given type.
func (f *File) HasType(t string) bool {
	for _, id := range f.Order {
		if f.Entities[id].Type == t {
			return true
		}
	}
	return false
}

// parser is a single-pass STEP parser. It works directly on the raw bytes; a
// 70MB file with 900k entities needs only one linear scan.
type parser struct {
	data []byte
	pos  int
	n    int
}

// Parse parses ISO-10303-21 text content.
func Parse(data []byte) (*File, error) {
	p := &parser{data: data, n: len(data)}
	f := &File{Entities: make(map[int]*Entity, 1<<16)}

	for {
		p.skipSep()
		if p.pos >= p.n {
			break
		}
		if p.data[p.pos] != '#' {
			// Skip non-entity content (HEADER section and so on)
			p.pos++
			continue
		}
		id, ok := p.readEntity(f)
		if !ok {
			// After a parse failure, skip to the next semicolon to recover as much as possible
			p.skipToSemicolon()
			_ = id
		}
	}

	// Extract the schema
	f.Schema = detectSchema(data)
	return f, nil
}

// skipSep skips whitespace and comments.
func (p *parser) skipSep() {
	for p.pos < p.n {
		switch p.data[p.pos] {
		case ' ', '\t', '\r', '\n':
			p.pos++
		case '/':
			if p.pos+1 < p.n && p.data[p.pos+1] == '*' {
				p.pos += 2
				for p.pos+1 < p.n && !(p.data[p.pos] == '*' && p.data[p.pos+1] == '/') {
					p.pos++
				}
				p.pos += 2
			} else {
				return
			}
		default:
			return
		}
	}
}

func (p *parser) skipToSemicolon() {
	for p.pos < p.n && p.data[p.pos] != ';' {
		p.pos++
	}
	if p.pos < p.n {
		p.pos++
	}
}

// readEntity parses one `#id = TYPE(...) ;` record.
func (p *parser) readEntity(f *File) (int, bool) {
	start := p.pos
	p.pos++ // '#'

	id, ok := p.readUint()
	if !ok {
		p.pos = start
		return 0, false
	}
	p.skipSep()
	if p.pos >= p.n || p.data[p.pos] != '=' {
		return 0, false
	}
	p.pos++
	p.skipSep()

	tname := p.readTypeName()
	if tname == "" && (p.pos >= p.n || p.data[p.pos] != '(') {
		return 0, false
	}

	ent := &Entity{ID: id}
	if tname == "" {
		// Complex instance: `#212=(A(...)B(...)C(...));`
		// REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION in AP214 assembly
		// relations is only reachable in this form, so it must be parsed.
		p.pos++ // enter '('
		for {
			p.skipSep()
			if p.pos >= p.n {
				break
			}
			if p.data[p.pos] == ')' {
				p.pos++
				break
			}
			subType := p.readTypeName()
			if subType == "" {
				p.pos++ // advance one byte when unrecognised, to avoid an infinite loop
				continue
			}
			p.skipSep()
			if p.pos >= p.n || p.data[p.pos] != '(' {
				break
			}
			p.pos++
			subParams, _ := p.parseParams()
			sub := &Entity{ID: id, Type: subType, Params: subParams}
			if f.complex == nil {
				f.complex = make(map[int][]*Entity, 256)
			}
			f.complex[id] = append(f.complex[id], sub)
		}
		ent.Type = "(COMPLEX)"
	} else {
		p.skipSep()
		if p.pos >= p.n || p.data[p.pos] != '(' {
			// A record like `#5=PRODUCT(...)` always has parentheses; treat a missing '(' as an error
			return 0, false
		}
		p.pos++
		ent.Type = tname
		ent.Params, _ = p.parseParams()
	}

	p.skipSep()
	if p.pos < p.n && p.data[p.pos] == ';' {
		p.pos++
	}

	f.Entities[id] = ent
	f.Order = append(f.Order, id)
	if id > f.MaxID {
		f.MaxID = id
	}
	return id, true
}

// parseParams parses up to the matching right parenthesis (the caller has
// already consumed the left one).
func (p *parser) parseParams() ([]Value, error) {
	params := make([]Value, 0, 8)
	for {
		p.skipSep()
		if p.pos >= p.n {
			return params, fmt.Errorf("unexpected end of input in parameter list")
		}
		switch p.data[p.pos] {
		case ')':
			p.pos++
			return params, nil
		case ',':
			p.pos++
			continue
		}
		before := p.pos
		v, err := p.parseValue()
		if err != nil {
			return params, err
		}
		// Guard: if parseValue consumed nothing we must force progress, otherwise
		// malformed input loops forever. Real files do contain constructs the
		// parser does not cover, so fall back to skipping one byte and continue.
		if p.pos == before {
			if debugUnconsumed {
				p.reportUnconsumed()
			}
			p.pos++
			continue
		}
		params = append(params, v)
	}
}

// debugUnconsumed, when enabled, prints context on unrecognised characters to
// help extend the grammar.
var debugUnconsumed = false

type unconsumedReport struct {
	Pos  int
	Byte byte
	Ctx  string
}

var unconsumedLog []unconsumedReport

func (p *parser) reportUnconsumed() {
	if len(unconsumedLog) >= 64 {
		return
	}
	lo := p.pos - 40
	if lo < 0 {
		lo = 0
	}
	hi := p.pos + 40
	if hi > p.n {
		hi = p.n
	}
	unconsumedLog = append(unconsumedLog, unconsumedReport{
		Pos:  p.pos,
		Byte: p.data[p.pos],
		Ctx:  string(p.data[lo:hi]),
	})
}

// Unconsumed returns sampled records of unrecognised characters (for debugging).
func Unconsumed() []unconsumedReport { return unconsumedLog }

func (p *parser) parseValue() (Value, error) {
	p.skipSep()
	if p.pos >= p.n {
		return Value{}, fmt.Errorf("unexpected end of input")
	}
	c := p.data[p.pos]
	switch {
	case c == '\'':
		return Value{Kind: KindString, Str: p.readString()}, nil
	case c == '"':
		return Value{Kind: KindBinary, Str: p.readBinaryString()}, nil
	case c == '#':
		p.pos++
		id, ok := p.readUint()
		if !ok {
			return Value{}, fmt.Errorf("bad reference")
		}
		return Value{Kind: KindRef, Ref: id}, nil
	case c == '(':
		p.pos++
		lst, err := p.parseParams()
		if err != nil {
			return Value{}, err
		}
		return Value{Kind: KindList, List: lst}, nil
	case c == '$':
		p.pos++
		return Value{Kind: KindUndefined}, nil
	case c == '*':
		p.pos++
		return Value{Kind: KindDerived}, nil
	case c == '.':
		// A '.' followed by a digit starts a decimal, followed by a letter an enum
		if p.pos+1 < p.n && isDigit(p.data[p.pos+1]) {
			return p.parseNumber()
		}
		return Value{Kind: KindEnum, Str: p.readEnum()}, nil
	case isAlpha(c):
		// Typed measure, e.g. LENGTH_MEASURE(0.1E-12), VOLUME_MEASURE(664.47),
		// PLANE_ANGLE_MEASURE(1.57). Common in AP203/AP214; just strip the wrapper
		// and take the inner value.
		name := p.readTypeName()
		if name == "" {
			p.pos++
			return Value{Kind: KindUndefined}, nil
		}
		p.skipSep()
		if p.pos < p.n && p.data[p.pos] == '(' {
			p.pos++
			inner, err := p.parseParams()
			if err == nil && len(inner) > 0 {
				return inner[0], nil
			}
		}
		return Value{Kind: KindUndefined}, nil
	default:
		if isDigit(c) || c == '-' || c == '+' {
			return p.parseNumber()
		}
		// Uncovered construct (a private extension of a few exporters): skip the
		// byte so the parser always advances instead of abandoning the whole file
		// over a single character.
		if debugUnconsumed {
			p.reportUnconsumed()
		}
		p.pos++
		return Value{Kind: KindUndefined}, nil
	}
}

func isAlpha(c byte) bool {
	return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')
}

func (p *parser) parseNumber() (Value, error) {
	start := p.pos
	if p.pos < p.n && (p.data[p.pos] == '-' || p.data[p.pos] == '+') {
		p.pos++
	}
	for p.pos < p.n {
		c := p.data[p.pos]
		if isDigit(c) || c == '.' {
			p.pos++
			continue
		}
		if c == 'e' || c == 'E' {
			p.pos++
			if p.pos < p.n && (p.data[p.pos] == '-' || p.data[p.pos] == '+') {
				p.pos++
			}
			continue
		}
		break
	}
	raw := string(p.data[start:p.pos])
	if p.pos == start {
		// Extreme guard: should not happen, but the caller must never loop forever
		p.pos++
		return Value{Kind: KindUndefined}, nil
	}
	f, err := strconv.ParseFloat(raw, 64)
	if err != nil {
		return Value{Kind: KindNumber, Num: 0}, nil
	}
	return Value{Kind: KindNumber, Num: f}, nil
}

func (p *parser) readEnum() string {
	p.pos++ // opening '.'
	start := p.pos
	for p.pos < p.n && p.data[p.pos] != '.' {
		p.pos++
	}
	s := string(p.data[start:p.pos])
	if p.pos < p.n {
		p.pos++ // closing '.'
	}
	return s
}

func (p *parser) readString() string {
	p.pos++ // opening quote
	var sb strings.Builder
	start := p.pos
	for p.pos < p.n {
		c := p.data[p.pos]
		if c == '\'' {
			if p.pos+1 < p.n && p.data[p.pos+1] == '\'' {
				// Escaped single quote
				sb.Write(p.data[start:p.pos])
				sb.WriteByte('\'')
				p.pos += 2
				start = p.pos
				continue
			}
			sb.Write(p.data[start:p.pos])
			p.pos++
			return decodeStepString(sb.String())
		}
		p.pos++
	}
	sb.Write(p.data[start:p.pos])
	return sb.String()
}

func (p *parser) readBinaryString() string {
	p.pos++
	start := p.pos
	for p.pos < p.n && p.data[p.pos] != '"' {
		p.pos++
	}
	s := string(p.data[start:p.pos])
	if p.pos < p.n {
		p.pos++
	}
	return s
}

func (p *parser) readTypeName() string {
	start := p.pos
	for p.pos < p.n {
		c := p.data[p.pos]
		if (c >= 'A' && c <= 'Z') || isDigit(c) || c == '_' || c == '-' {
			p.pos++
			continue
		}
		break
	}
	return string(p.data[start:p.pos])
}

func (p *parser) readUint() (int, bool) {
	start := p.pos
	v := 0
	for p.pos < p.n && isDigit(p.data[p.pos]) {
		v = v*10 + int(p.data[p.pos]-'0')
		p.pos++
	}
	if p.pos == start {
		return 0, false
	}
	return v, true
}

func isDigit(c byte) bool { return c >= '0' && c <= '9' }

// decodeStepString decodes the escape sequences in STEP strings.
// Systems such as CATIA store UTF-16BE text in \X2\....\X0\; reading it as plain
// ASCII yields garbled text.
func decodeStepString(s string) string {
	if !strings.ContainsRune(s, '\\') {
		return s
	}
	var sb strings.Builder
	for i := 0; i < len(s); {
		if s[i] != '\\' {
			sb.WriteByte(s[i])
			i++
			continue
		}
		// \X2\ hex... \X0\
		if i+3 < len(s) && (s[i+1] == 'X' || s[i+1] == 'x') && s[i+2] == '2' && s[i+3] == '\\' {
			end := strings.Index(s[i+4:], "\\X0\\")
			if end < 0 {
				sb.WriteString(s[i:])
				break
			}
			hex := s[i+4 : i+4+end]
			var units []uint16
			for j := 0; j+3 < len(hex); j += 4 {
				v, err := strconv.ParseUint(hex[j:j+4], 16, 32)
				if err != nil {
					break
				}
				units = append(units, uint16(v))
			}
			sb.WriteString(string(utf16.Decode(units)))
			i = i + 4 + end + 4
			continue
		}
		// \X\HH single byte
		if i+2 < len(s) && (s[i+1] == 'X' || s[i+1] == 'x') && s[i+2] == '\\' {
			if i+4 <= len(s) {
				v, err := strconv.ParseUint(s[i+3:i+5], 16, 32)
				if err == nil {
					sb.WriteByte(byte(v))
					i += 5
					continue
				}
			}
		}
		// \S\c means c + 0x80
		if i+2 < len(s) && (s[i+1] == 'S' || s[i+1] == 's') && s[i+2] == '\\' {
			if i+3 < len(s) {
				sb.WriteByte(s[i+3] + 0x80)
				i += 4
				continue
			}
		}
		// \\ means a single backslash
		if i+1 < len(s) && s[i+1] == '\\' {
			sb.WriteByte('\\')
			i += 2
			continue
		}
		sb.WriteByte(s[i])
		i++
	}
	return sb.String()
}

// detectSchema extracts the FILE_SCHEMA content from the file.
func detectSchema(data []byte) string {
	idx := indexBytes(data, []byte("FILE_SCHEMA"))
	if idx < 0 {
		return ""
	}
	end := idx + 400
	if end > len(data) {
		end = len(data)
	}
	seg := string(data[idx:end])
	if a := strings.Index(seg, "("); a >= 0 {
		if b := strings.Index(seg[a:], ")"); b > 0 {
			return strings.Trim(strings.TrimSpace(seg[a+1:a+b]), "'")
		}
	}
	return ""
}

func indexBytes(hay, needle []byte) int {
	return bytes.Index(hay, needle)
}
