package step

import (
	"fmt"
	"math"
	"os"
	"sort"
	"strings"
	"time"

	"stp2glb-lite/internal/console"
)

// Mesh is the triangulation output mesh; positions and normals are float32 to suit GLB.
type Mesh struct {
	Positions []float32
	Normals   []float32
	Indices   []uint32
	// LinePositions / LineIndices hold the outline (B-Rep edges), filled by BuildOutline.
	LinePositions []float32
	LineIndices   []uint32
}

func (m *Mesh) VertexCount() int   { return len(m.Positions) / 3 }
func (m *Mesh) TriangleCount() int { return len(m.Indices) / 3 }

// TessOpts controls triangulation accuracy and size.
type TessOpts struct {
	Tol        float64 // chord tolerance (model units)
	MaxDepth   int     // max depth of adaptive subdivision
	MaxLoopPts int     // max sample points in a single loop
	MaxPerFace int     // triangle budget for a single face
}

// TessStats summarizes the triangulation run.
type TessStats struct {
	FacesTotal    int
	FacesOK       int
	FacesFailed   int
	FacesDegraded int
	// FacesSkipped counts zero-area degenerate faces (CAD modeling residue);
	// skipping them is correct and is not a failure.
	FacesSkipped int
	BySurface    map[string]int
	FailedByType map[string]int
	// DegradedByReason records the real cause of a degrade/failure ("type|reason" -> count),
	// used to diagnose weak spots of the geometry kernel; cost is negligible in normal conversion.
	DegradedByReason map[string]int
	// FaceReason records a per-face reason, only for faces that are not fully successful
	// (face ID -> reason).
	FaceReason map[int]string
	// FaceTris records the triangle count produced per face (face ID -> triangles),
	// used to locate density anomalies.
	FaceTris map[int]int
}

func (st *TessStats) note(typ, reason string) {
	if st.DegradedByReason == nil {
		st.DegradedByReason = map[string]int{}
	}
	st.DegradedByReason[typ+" | "+reason]++
}

// vkey is the vertex dedupe key: a vertex counts as identical only when both
// position and normal match.
type vkey struct {
	x, y, z    uint64
	nx, ny, nz uint64
}

// MeshBuilder handles vertex emission and global dedupe.
type MeshBuilder struct {
	m    *Mesh
	seen map[vkey]uint32
}

// NewMeshBuilder binds the mesh.
func NewMeshBuilder(m *Mesh) *MeshBuilder {
	return &MeshBuilder{m: m, seen: make(map[vkey]uint32, 1<<14)}
}

// Add emits a vertex and returns its index.
func (b *MeshBuilder) Add(p, n Vec3) uint32 {
	k := vkey{
		x: math.Float64bits(p.X), y: math.Float64bits(p.Y), z: math.Float64bits(p.Z),
		nx: math.Float64bits(n.X), ny: math.Float64bits(n.Y), nz: math.Float64bits(n.Z),
	}
	if idx, ok := b.seen[k]; ok {
		return idx
	}
	idx := uint32(len(b.m.Positions) / 3)
	b.m.Positions = append(b.m.Positions, float32(p.X), float32(p.Y), float32(p.Z))
	b.m.Normals = append(b.m.Normals, float32(n.X), float32(n.Y), float32(n.Z))
	b.seen[k] = idx
	return idx
}

// Tri emits a triangle; when flip is true the first two vertices are swapped.
func (b *MeshBuilder) Tri(a, c, d uint32, flip bool) {
	if flip {
		a, c = c, a
	}
	if a == c || c == d || a == d {
		return
	}
	b.m.Indices = append(b.m.Indices, a, c, d)
}

// paramLoop is a loop projected into the parameter domain; UV and 3D points
// correspond one to one.
type paramLoop struct {
	UV []P2
	P  []Vec3
}

// paramPoint is a point carrying both its spatial position and parameter coordinates
// during subdivision.
type paramPoint struct {
	U, V float64
	P    Vec3
}

// faceCtx is the context for triangulating a single face.
type faceCtx struct {
	fid      int
	surf     Surface
	same     bool
	tol      float64
	maxDepth int
	maxTri   int
	mb       *MeshBuilder
	// lastWhy holds the reason of the most recent projection failure, for the caller
	// to write into the diagnostic stats.
	lastWhy string
	// emitCalls / rejArea count degenerate triangles at the emit stage, used to diagnose
	// "0 triangles emitted".
	emitCalls int
	rejArea   int
	// splitCalls counts needsSplit calls during subdivision (up to 4 surface evaluations each).
	// Nearly all of the emitFromParam cost sits here; only per-face counts show which face burns time.
	splitCalls  int
	maxDepthHit int
	// ext is the 3D extent of the outer loop of this face; bigTriLogged makes sure a huge
	// triangle is reported only once.
	// Only "triangle area vs the face own size" is a meaningful criterion: a 2 m long plate
	// should legitimately yield large triangles, and only those far beyond its own size are distortion.
	ext          float64
	bigTriLogged bool
	bigTriArea   float64
	// parameter-domain concatenated point table: outer loop first, then each inner loop
	uvPts []paramPoint
	tri   int
}

// Tessellate triangulates all faces into one mesh. Any single face failure is only
// counted, never fatal.
func Tessellate(faces []*FaceGeom, opts TessOpts) (*Mesh, TessStats) {
	if opts.MaxDepth <= 0 {
		opts.MaxDepth = 6
	}
	if opts.MaxLoopPts <= 0 {
		opts.MaxLoopPts = 6000
	}
	if opts.MaxPerFace <= 0 {
		opts.MaxPerFace = 500000
	}
	m := &Mesh{}
	st := TessStats{
		FacesTotal:   len(faces),
		BySurface:    map[string]int{},
		FailedByType: map[string]int{},
	}
	mb := NewMeshBuilder(m)
	st.FaceTris = map[int]int{}

	// Assembly reuse makes the same face be emitted several times. Local triangulation is
	// computed once and cached; the remaining instances just append rigidly transformed
	// vertices, avoiding repeated Gauss-Newton projection and subdivision.
	type localTess struct {
		pos      []float32
		norm     []float32
		idx      []uint32
		degraded bool
		ok       bool
		reason   string
	}
	local := make(map[int]*localTess, 64)

	for _, fg := range faces {
		if skipFace(fg.ID) {
			continue
		}
		before := len(m.Indices)
		st.BySurface[fg.SurfaceType]++

		// Path A: with an assembly transform -- take the cached local result first,
		// triangulate locally only on a miss
		if !fg.Xform.IsIdentity() {
			lt, hit := local[fg.ID]
			if !hit {
				lc := *fg
				lc.Xform = Identity()
				tmp := &Mesh{}
				deg, ok, reason := tessFace(&lc, opts, NewMeshBuilder(tmp))
				lt = &localTess{degraded: deg, ok: ok, reason: reason}
				if ok && len(tmp.Indices) > 0 {
					lt.pos, lt.norm, lt.idx = tmp.Positions, tmp.Normals, tmp.Indices
				}
				local[fg.ID] = lt
			}
			reason := lt.reason
			if reason != "" {
				if st.FaceReason == nil {
					st.FaceReason = map[int]string{}
				}
				st.FaceReason[fg.ID] = reason
			}
			if strings.HasPrefix(reason, "SKIP:") {
				st.FacesSkipped++
				st.note(fg.SurfaceType, reason)
				continue
			}
			if len(lt.idx) == 0 {
				st.FacesFailed++
				st.FailedByType[fg.SurfaceType]++
				st.note(fg.SurfaceType, "FAIL: "+reason)
				continue
			}
			appendTransformed(m, lt.pos, lt.norm, lt.idx, fg.Xform)
			st.FaceTris[fg.ID] += (len(m.Indices) - before) / 3
			st.FacesOK++
			if lt.degraded {
				st.FacesDegraded++
				st.note(fg.SurfaceType, reason)
			}
			continue
		}

		// Path B: no assembly transform -- triangulate directly
		degraded, ok, reason := tessFace(fg, opts, mb)
		st.FaceTris[fg.ID] += (len(m.Indices) - before) / 3
		if reason != "" {
			if st.FaceReason == nil {
				st.FaceReason = map[int]string{}
			}
			st.FaceReason[fg.ID] = reason
		}
		if strings.HasPrefix(reason, "SKIP:") {
			// Zero-area degenerate face: emitting no triangles is correct, so it is not a failure.
			st.FacesSkipped++
			st.note(fg.SurfaceType, reason)
			continue
		}
		if !ok || len(m.Indices) == before {
			st.FacesFailed++
			st.FailedByType[fg.SurfaceType]++
			st.note(fg.SurfaceType, "FAIL: "+reason)
			continue
		}
		st.FacesOK++
		if degraded {
			st.FacesDegraded++
			st.note(fg.SurfaceType, reason)
		}
	}
	if p := os.Getenv("STP2GLB_DUMP_FACES"); p != "" {
		dumpFaces(p, faces, &st)
	}
	return m, st
}

// appendTransformed appends a local mesh to the destination mesh under a rigid transform.
func appendTransformed(dst *Mesh, pos, norm []float32, idx []uint32, xf Mat34) {
	base := uint32(len(dst.Positions) / 3)
	var v Vec3
	for i := 0; i+2 < len(pos); i += 3 {
		v = Vec3{float64(pos[i]), float64(pos[i+1]), float64(pos[i+2])}
		q := xf.Apply(v)
		dst.Positions = append(dst.Positions, float32(q.X), float32(q.Y), float32(q.Z))
	}
	for i := 0; i+2 < len(norm); i += 3 {
		v = Vec3{float64(norm[i]), float64(norm[i+1]), float64(norm[i+2])}
		q := xf.ApplyDir(v)
		dst.Normals = append(dst.Normals, float32(q.X), float32(q.Y), float32(q.Z))
	}
	for _, t := range idx {
		dst.Indices = append(dst.Indices, base+t)
	}
}

// tessFace returns (degraded, ok, reason).
func tessFace(fg *FaceGeom, opts TessOpts, mb *MeshBuilder) (bool, bool, string) {
	S := fg.XformedSurface()
	if S == nil {
		return false, false, "surface is nil"
	}
	outer := fg.XformedLoop(fg.Outer)
	if len(outer) < 3 {
		return false, false, "outer loop has too few points"
	}
	inners := make([][]Vec3, 0, len(fg.Inners))
	for _, in := range fg.Inners {
		p := fg.XformedLoop(in)
		if len(p) >= 3 {
			inners = append(inners, p)
		}
	}

	// Tolerance scaled per face: the global tolerance of a large assembly is too coarse for
	// small parts, so adaptive subdivision never triggers and coarse triangles come out.
	faceTol := opts.Tol
	ext := polyExtent(outer)
	if ext > 0 && faceTol > ext*0.05 {
		faceTol = ext * 0.05
	}

	ctx := &faceCtx{
		fid:      fg.ID,
		surf:     S,
		same:     fg.SameSense,
		tol:      faceTol,
		maxDepth: opts.MaxDepth,
		maxTri:   opts.MaxPerFace,
		mb:       mb,
		ext:      ext,
	}

	fail := ""
	uvFlat := false
	// The parameter-domain projection is done only once; the grid path and the ear clipping
	// path share the same result.
	_pT0 := time.Now()
	loops, projOK := ctx.projectAll(outer, inners, opts.MaxLoopPts)
	addT(&tProject, time.Since(_pT0))
	if projOK {
		// In the parameter domain an inner loop must run opposite to the outer loop, otherwise
		// the hole is counted into the area (see normalizeHoleWinding).
		if !noFlipHoles() {
			normalizeHoleWinding(loops)
		}
		uvFlat = flatLoop(loops[0].UV)
		if debugHoleCover() && len(inners) > 0 {
			console.Outf("[holes] face #%d: %d 3D inner loops -> %d parameter-domain inner loops (%s)\n",
				fg.ID, len(inners), len(loops)-1, fg.SurfaceType)
		}
		if debugFaceMatch(fg.ID) {
			dumpParamLoops(fg.ID, loops)
		}
	}

	// --- Path 0: structured grid (lay out cells along the loop coordinates) ---
	// Ear clipping cuts an elongated parameter domain into slivers spanning most of the face,
	// and adaptive subdivision can then only split midpoints level after level: an 18-point
	// outer loop (half cylinder) measured 364 triangles where about 20 is ideal. The loop
	// coordinates are natural grid lines (cylinder/cone/sphere/torus/spline patches clipped by
	// a plane normal to the parameter direction are all rectangular domains), so laying out
	// cells directly both follows the boundary and needs no subdivision.
	_gT0 := time.Now()
	if projOK && !uvFlat && ctx.gridTriangulate(loops[0], loops[1:]) && ctx.tri > 0 {
		addT(&tGrid, time.Since(_gT0))
		notePath(0)
		return false, true, ""
	}
	addT(&tGrid, time.Since(_gT0))
	// Reset when the grid path is unusable or produced no triangles, so leftover vertices are not counted
	ctx.tri = 0
	ctx.uvPts = nil
	ctx.emitCalls = 0
	ctx.rejArea = 0

	// --- Path 1: parameter-domain projection + ear clipping + adaptive subdivision ---
	if projOK {
		uvs := make([][]P2, 0, len(loops))
		for _, l := range loops {
			uvs = append(uvs, l.UV)
		}
		ctx.uvPts = flattenLoops(loops)
		// Boolean clipping (see clipRegionTri) only triggers on small faces, so the 3D point
		// table is only built for them, avoiding a pointless copy for faces with hundreds of
		// thousands of points.
		var flatP []Vec3
		if len(ctx.uvPts) <= earRetryMaxPts {
			flatP = make([]Vec3, len(ctx.uvPts))
			for i := range ctx.uvPts {
				flatP[i] = ctx.uvPts[i].P
			}
		}
		triT0 := time.Now()
		tris, earExtra, earD := TriangulateDiagFid(uvs[0], uvs[1:], flatP, fg.ID)
		if len(earExtra) > 0 {
			// Points created by clipping (UV and 3D both from linear interpolation of the
			// endpoints) are appended at the end of the point table; indices in tris that are
			// >= the original table length land on them.
			ctx.uvPts = append(ctx.uvPts, earExtra...)
		}
		addT(&tEar, time.Since(triT0))
		if earD.IndexShift > 0 && (debugHoleArea() || debugHoleCover()) {
			console.Outf("[idx] face #%d %s: %d parameter-domain inner loops, %d zero-area ones skipped, later hole indices shifted by %d points\n",
				fg.ID, fg.SurfaceType, len(uvs)-1, earD.Skipped, earD.IndexShift)
		}
		if el := time.Since(triT0); el > 300*time.Millisecond {
			console.Outf("[slow] face #%d ear clipping %v: %d loops, %d points, %d iterations, %d forced rejects\n",
				fg.ID, el.Round(time.Millisecond), len(uvs), earD.Pts, earD.Iters, earD.Forced)
		}
		if len(tris) >= 3 {
			// Sentinel: the total area of the ear clipping result must equal "outer loop minus
			// holes". Once a holed polygon is triangulated wrongly (a hole is not really cut
			// out, or emitted indices are misaligned with the geometry) the area grows
			// noticeably, which looks like "an extra membrane where the hole should be".
			// Better to report it here than to let it slip silently into the GLB.
			want := expectedLoopArea(uvs)
			if earD.WantTrue > 0 {
				// When a hole pokes outside the outer loop (illegal input with two intersecting
				// loops), |outer| - sum|holes| is not the true area; ear clipping already
				// switched to boolean clipping and returned the exact value (see
				// EarDiag.WantTrue). Keeping the old formula would report a correct result as
				// "area too large".
				want = earD.WantTrue
			}
			if want > 0 {
				// Clipping adds points, so the diagnostic point table must include them;
				// otherwise out-of-range indices are skipped silently and a result with a
				// membrane masquerades as perfect.
				uvAll := concatP2(uvs)
				for _, e := range earExtra {
					uvAll = append(uvAll, P2{X: e.U, Y: e.V})
				}
				got := math.Abs(triAreaSum(uvAll, tris))
				if debugHoleArea() && len(uvs) > 1 {
					console.Outf("[hoarea] face #%d path1 inner loops %d: got %.4f expected %.4f deviation %+.3f%% (forced rejects %d, no visible points %d)\n",
						fg.ID, len(uvs)-1, got, want, (got-want)/want*100, earD.Forced, earD.NoVisible)
				}
				if debugHoleCover() && len(uvs) > 1 {
					cov, hp, ft := holeCoverReport(uvAll, len(uvs[0]), tris)
					if cov > 0 {
						console.Outf("[hcover] face #%d path1 * hole covered: %d/%d hole points fall inside %d triangles\n",
							fg.ID, cov, hp, ft)
					}
				}
				// * Reliable membrane sentinel: sum|triangle area| / expected. See the comment on triAreaAbs.
				if debugAreaAbs() && len(uvs) > 1 {
					if abs, neg := triAreaAbs(uvAll, tris); abs/want > 1.002 {
						console.Outf("[absarea] face #%d path1 sum|tri area| %.4f / expected %.4f = %.4f x (negative winding %d; inner loops %d, forced rejects %d)\n",
							fg.ID, abs, want, abs/want, neg, len(uvs)-1, earD.Forced)
					}
				}
				if diff := math.Abs(got - want); diff > want*earAnomalyRatio && diff > earAnomalyAbsFloor {
					noteEarAnomaly()
					if debugEar() {
						console.Outf("[ear] face #%d area anomaly: got %.3f, expected %.3f (deviation %.1f%%; holes %d, bridges without visible points %d, forced rejects %d)\n",
							fg.ID, got, want, (got-want)/want*100,
							earD.Merged, earD.NoVisible, earD.Forced)
					}
				}
			}
			_sT0 := time.Now()
			ctx.emitFromParam(tris)
			if el := time.Since(_sT0); el > 150*time.Millisecond {
				console.Outf("[slow] face #%d subdivision emit %v: %d ear triangles, %d subdivision calls, %d triangles out, max depth %d, %T (face size info: %d loop points, tolerance %.3g)\n",
					fg.ID, el.Round(time.Millisecond), len(tris)/3, ctx.splitCalls, ctx.tri,
					ctx.maxDepthHit, unwrapSurf(ctx.surf), len(ctx.uvPts), ctx.tol)
			}
			addT(&tSubdiv, time.Since(_sT0))
			if ctx.tri > 0 {
				notePath(1)
				return false, true, ""
			}
			fail = fmt.Sprintf("parameter domain emitted 0 triangles (%d ear triangles, %d emit calls, %d degenerate drops, %d loop points, tolerance %.3g)",
				len(tris)/3, ctx.emitCalls, ctx.rejArea, len(ctx.uvPts), ctx.tol)
		} else {
			fail = fmt.Sprintf("parameter-domain ear clipping failed (%d loop points, %d outer loop points, %d holes)",
				len(ctx.uvPts), len(uvs[0]), len(uvs)-1)
		}
	} else {
		fail = "parameter-domain projection failed: " + ctx.lastWhy
	}

	// --- Path 2 (degraded): project the loops onto the best-fit plane ---
	ctx.uvPts = nil
	ctx.tri = 0
	_pF0 := time.Now()
	okPf := ctx.emitPlanarFallback(outer, inners)
	addT(&tPlanar, time.Since(_pF0))
	if okPf {
		notePath(2)
		if uvFlat {
			return true, true, "SKIP: zero-area face, " + fail + " -> planar degradation"
		}
		return true, true, fail + " -> planar degradation"
	}
	// Both paths failed: distinguish "genuinely uncomputable" from "this face has no area at all".
	// A zero-area face (degenerate residue of CAD modeling) correctly emits no triangles and
	// must not be reported as a failure.
	if uvFlat || degeneratePoly(outer) {
		return false, false, "SKIP: zero-area degenerate face"
	}
	return true, false, fail + " -> planar degradation failed too"
}

// flatLoop reports whether a parameter-domain loop is degenerate (area negligible against its
// own size). A relative criterion is used so absolute thresholds do not break on large models.
func flatLoop(uv []P2) bool {
	if len(uv) < 3 {
		return true
	}
	var minX, minY, maxX, maxY float64
	minX, minY = math.Inf(1), math.Inf(1)
	maxX, maxY = math.Inf(-1), math.Inf(-1)
	for _, q := range uv {
		minX = math.Min(minX, q.X)
		minY = math.Min(minY, q.Y)
		maxX = math.Max(maxX, q.X)
		maxY = math.Max(maxY, q.Y)
	}
	w, h := maxX-minX, maxY-minY
	scale := math.Max(w, h)
	if scale <= 0 {
		return true
	}
	return math.Abs(shoelace(uv)) < 1e-6*scale*scale
}

// degeneratePoly reports whether a 3D loop degenerates into a line (used to tell a degenerate
// face from a real failure).
func degeneratePoly(p []Vec3) bool {
	if len(p) < 3 {
		return true
	}
	e1, e2, org, ok := bestFitFrame(p)
	if !ok {
		return true
	}
	var minU, minV, maxU, maxV float64
	minU, minV = math.Inf(1), math.Inf(1)
	maxU, maxV = math.Inf(-1), math.Inf(-1)
	for _, q := range p {
		rel := q.Sub(org)
		u, v := rel.Dot(e1), rel.Dot(e2)
		minU, maxU = math.Min(minU, u), math.Max(maxU, u)
		minV, maxV = math.Min(minV, v), math.Max(maxV, v)
	}
	w, h := maxU-minU, maxV-minV
	scale := math.Max(w, h)
	if scale <= 0 {
		return true
	}
	// shortest side far below the longest side => degenerates into a line
	return math.Min(w, h) < 1e-6*scale
}

// flattenLoops concatenates the loops into one point table whose order matches the
// Triangulate indices.
func flattenLoops(loops []paramLoop) []paramPoint {
	n := 0
	for _, l := range loops {
		n += len(l.UV)
	}
	out := make([]paramPoint, 0, n)
	for _, l := range loops {
		for i, q := range l.UV {
			out = append(out, paramPoint{U: q.X, V: q.Y, P: l.P[i]})
		}
	}
	return out
}

// ---------------------------------------------------------------------------
// Parameter-domain projection
// ---------------------------------------------------------------------------

func (c *faceCtx) projectAll(outer []Vec3, inners [][]Vec3, maxPts int) ([]paramLoop, bool) {
	lo, why, _ := c.projectLoop(outer, maxPts, true)
	if why != "" {
		c.lastWhy = why
		return nil, false
	}
	out := []paramLoop{lo}
	for _, in := range inners {
		l, w, degen := c.projectLoop(in, maxPts, true)
		if l.UV != nil {
			out = append(out, l)
			continue
		}
		if degen {
			// The loop collapses to <3 distinct points in the parameter domain, i.e. a
			// zero-area seam (CAD modeling residue). Dropping it does not affect the
			// appearance, and it should certainly not cost the whole face its
			// parameter-domain triangulation: a 72MB body-in-white measured 92 such
			// degenerate holes, and degrading them all would raise degraded faces from
			// 130 to 222.
			if debugHole() {
				dumpHole(c.fid, "degenerate collapse", w, in, true)
			}
			continue
		}
		// * A non-degenerate inner loop (a real cutout) must **never** be dropped when its
		// projection misses the criterion: dropping it fills the hole in and adds a spurious
		// plate to the model (measured: a whole cavity of a 218MB welding fixture was covered
		// by a membrane). First back off and reproject with a relaxed criterion, accepting it
		// as long as the UV loop still lies inside the outer loop.
		l2, w2, _ := c.projectLoop(in, maxPts, false)
		if l2.UV == nil || !loopInside(lo.UV, l2.UV) {
			// The relaxed result is not trustworthy either: give up the parameter-domain path
			// for the whole face and hand it to planar degradation (that path uses 3D loops,
			// so holes survive, at one notch lower accuracy).
			c.lastWhy = fmt.Sprintf("inner loop projection failed (strict: %s; relaxed: %s)", w, w2)
			if debugHole() {
				dumpHole(c.fid, "criterion not met", w+"; relaxed "+w2, in, true)
			}
			return nil, false
		}
		if debugHole() {
			dumpHole(c.fid, "accepted relaxed after strict failure", w2, in, false)
		}
		out = append(out, l2)
	}
	return out, true
}

// loopInside reports whether the UV bounding box of an inner loop lies inside the outer loop
// bounding box (with a 2% tolerance of the outer span). It confirms that a "relaxed projection"
// did not map the hole onto another periodic branch.
func loopInside(outer, inner []P2) bool {
	if len(outer) < 3 || len(inner) < 3 {
		return false
	}
	umn, umx, vmn, vmx := math.Inf(1), math.Inf(-1), math.Inf(1), math.Inf(-1)
	for _, q := range outer {
		umn, umx = math.Min(umn, q.X), math.Max(umx, q.X)
		vmn, vmx = math.Min(vmn, q.Y), math.Max(vmx, q.Y)
	}
	su, sv := umx-umn, vmx-vmn
	if su <= 0 || sv <= 0 {
		return false
	}
	tu, tv := su*0.02, sv*0.02
	for _, q := range inner {
		if q.X < umn-tu || q.X > umx+tu || q.Y < vmn-tv || q.Y > vmx+tv {
			return false
		}
	}
	return true
}

// projectLoop projects a 3D loop into the parameter domain while keeping a one-to-one
// correspondence with the 3D points.
// The second return value is the failure reason, empty on success.
// With strict=false the "projection success rate" criterion is relaxed (used for the inner
// loop fallback), but the UV loop must still be non-degenerate.
func (c *faceCtx) projectLoop(poly []Vec3, maxPts int, strict bool) (paramLoop, string, bool) {
	if len(poly) < 3 {
		return paramLoop{}, "loop has <3 points", true
	}
	if len(poly) > maxPts {
		poly = simplifyPoly(poly, maxPts)
	}
	uv := make([]P2, 0, len(poly))
	pos := make([]Vec3, 0, len(poly))
	gu, gv, ok := c.seedGuess(poly)
	if !ok {
		return paramLoop{}, "initial guess search failed", false
	}
	// The "trustworthy projection" test uses its own scale: the Tol carried by a surface is
	// calibrated on a small range (local coordinate frame), so judging global points with it
	// kills samples that have already converged.
	// The loop bounding box size is used as an upper bound -- a projection onto a wrong branch
	// leaves a residual of model scale.
	ptol := c.surfTol()
	if d := polyExtent(poly); d > 0 && ptol < d*1e-4 {
		ptol = d * 1e-4
	}
	good := 0
	worst := 0.0
	for _, p := range poly {
		u, v, _ := c.surf.Project(p, gu, gv)
		du := c.surf.Point(u, v).Dist(p)
		if du <= ptol {
			good++
		} else if du > worst {
			worst = du
		}
		uv = append(uv, P2{u, v})
		pos = append(pos, p)
		gu, gv = u, v
	}
	// Note: shifting the whole uv loop along v to rescue a wrong-turn solution on multi-turn
	// spiral surfaces was tried here, but the gain was tiny and the degradation cost high (one
	// part went from 1.7s to 2.9s triangulation, degraded faces 36 -> 34).
	// The reason is that such surfaces are parameterized across several turns (v is arc length,
	// 4 turns total 224), the same spatial point coincides at parameter values an integer
	// number of turns apart, and the shift each loop point needs is not the same, so no global
	// shift can rescue it. Falling back to planar degradation is the steadier choice here.
	//
	// It is enough that most points are trustworthy (threshold 50%): numerical inverse
	// evaluation is naturally imprecise at trimmed edges, poles and other degenerate places,
	// and as long as the overall direction of the loop is right, ear clipping is right.
	if strict && good*2 < len(poly) {
		return paramLoop{}, fmt.Sprintf("projection success rate %d/%d too low (max residual %.3g, criterion %.3g)",
			good, len(poly), worst, ptol), false
	}
	uv = unwrapPeriodic(c.surf, uv)
	uv, pos = dedupeLoop(uv, pos)
	if len(uv) < 3 {
		return paramLoop{}, fmt.Sprintf("only %d points after UV dedupe (original %d, projected ok %d)", len(uv), len(poly), good), true
	}
	return paramLoop{UV: uv, P: pos}, "", false
}

// seedGuess finds a reliable initial parameter guess for the first point of the loop.
func (c *faceCtx) seedGuess(poly []Vec3) (float64, float64, bool) {
	if _, isPlane := c.surf.(*PlaneSurf); isPlane {
		u, v, ok := c.surf.Project(poly[0], 0, 0)
		return u, v, ok
	}
	u0, u1 := c.surf.RangeU()
	v0, v1 := c.surf.RangeV()
	if !isFinite(u0) || !isFinite(u1) || !isFinite(v0) || !isFinite(v1) {
		u, v, ok := c.surf.Project(poly[0], 0, 0)
		return u, v, ok
	}
	bestU, bestV := (u0+u1)/2, (v0+v1)/2
	bestD := c.residual(poly[0], bestU, bestV)
	for i := 0; i < 3; i++ {
		for j := 0; j < 3; j++ {
			gu := u0 + (u1-u0)*float64(i)/2
			gv := v0 + (v1-v0)*float64(j)/2
			u, v, ok := c.surf.Project(poly[0], gu, gv)
			if !ok {
				continue
			}
			if d := c.residual(poly[0], u, v); d < bestD {
				bestD, bestU, bestV = d, u, v
			}
		}
	}
	return bestU, bestV, true
}

func (c *faceCtx) residual(p Vec3, u, v float64) float64 {
	return c.surf.Point(u, v).Dist(p)
}

// surfTol returns the acceptance tolerance for numerical inverse evaluation of the surface.
// Only spline surfaces need inverse evaluation; the rest (plane/cylinder/cone/sphere/torus)
// are analytic.
func (c *faceCtx) surfTol() float64 {
	s := c.surf
	for {
		xs, ok := s.(*XFormSurf)
		if !ok {
			break
		}
		s = xs.Base
	}
	if b, ok := s.(*BSplineSurf); ok && b.Tol > 0 {
		return b.Tol
	}
	return 1e-9
}

// unwrapPeriodic unwraps periodic parameters along the loop so adjacent differences are minimal.
func unwrapPeriodic(s Surface, pts []P2) []P2 {
	if len(pts) < 2 {
		return pts
	}
	pu, pv := s.PeriodicU(), s.PeriodicV()
	if !pu && !pv {
		return pts
	}
	const twoPi = 2 * math.Pi
	for i := 1; i < len(pts); i++ {
		if pu {
			for pts[i].X-pts[i-1].X > math.Pi {
				pts[i].X -= twoPi
			}
			for pts[i].X-pts[i-1].X < -math.Pi {
				pts[i].X += twoPi
			}
		}
		if pv {
			for pts[i].Y-pts[i-1].Y > math.Pi {
				pts[i].Y -= twoPi
			}
			for pts[i].Y-pts[i-1].Y < -math.Pi {
				pts[i].Y += twoPi
			}
		}
	}
	return pts
}

// dedupeLoop removes adjacent duplicate points and the closing duplicate in sync, keeping UV
// and 3D points aligned.
func dedupeLoop(uv []P2, pos []Vec3) ([]P2, []Vec3) {
	const eps = 1e-12
	ou := make([]P2, 0, len(uv))
	op := make([]Vec3, 0, len(pos))
	for i, q := range uv {
		if len(ou) > 0 {
			last := ou[len(ou)-1]
			if math.Abs(last.X-q.X) < eps && math.Abs(last.Y-q.Y) < eps {
				continue
			}
		}
		ou = append(ou, q)
		op = append(op, pos[i])
	}
	for len(ou) > 1 {
		if math.Abs(ou[0].X-ou[len(ou)-1].X) < eps && math.Abs(ou[0].Y-ou[len(ou)-1].Y) < eps {
			ou = ou[:len(ou)-1]
			op = op[:len(op)-1]
			continue
		}
		break
	}
	return ou, op
}

// simplifyPoly thins an over-long loop uniformly so ear clipping O(n^2) does not blow up.
func simplifyPoly(p []Vec3, maxPts int) []Vec3 {
	n := len(p)
	if n <= maxPts {
		return p
	}
	out := make([]Vec3, 0, maxPts)
	step := float64(n) / float64(maxPts)
	for i := 0; i < maxPts; i++ {
		out = append(out, p[int(float64(i)*step)])
	}
	return out
}

// ---------------------------------------------------------------------------
// Structured grid path
// ---------------------------------------------------------------------------

// gridTriangulate generates triangles from the structured grid formed by the loop own
// parameter coordinates. It returns whether it succeeded (on success ctx.tri > 0).
//
// It applies when the parameter domain follows grid lines: every edge of the outer loop and of
// all inner loops changes only u or only v. Cylinder/cone/sphere/torus/spline patches clipped by
// a plane normal to the parameter direction have exactly this shape; round holes in a plane or
// arbitrary oblique trims do not, and fall back to the ear clipping path without breaking the shape.
func (c *faceCtx) gridTriangulate(outer paramLoop, holes []paramLoop) bool {
	why := ""
	defer func() {
		if why != "" && debugFaceMatch(c.fid) {
			console.Outf("[grid] not used: %s\n", why)
		}
	}()
	why = "is planar"
	if _, isPlane := unwrapSurf(c.surf).(*PlaneSurf); isPlane {
		return false // a plane uses fewer triangles with ear clipping and has a more accurate boundary
	}
	why = "outer loop not grid aligned"
	if !isGridAligned(outer.UV) {
		return false
	}
	for _, h := range holes {
		why = "inner loop not grid aligned"
		if !isGridAligned(h.UV) {
			return false
		}
	}
	why = "too few grid lines"
	us := sortedUniqueParam(outer.UV, true)
	vs := sortedUniqueParam(outer.UV, false)
	if len(us) < 2 || len(vs) < 2 {
		return false
	}
	why = "too many grid lines"
	if len(us) > 512 || len(vs) > 512 {
		return false
	}
	protU, protV := protectedLines(outer.UV)
	// Re-lay the lines anchored on the true domain boundary lines: u is fixed first from the
	// loop v samples, then v from u, and finally u is rechecked against the new v.
	us = c.thinLines(us, protU, vs, true)
	vs = c.thinLines(vs, protV, us, false)
	us = c.thinLines(us, protU, vs, true)
	why = "too many grid lines after thinning"
	if len(us) > 1024 || len(vs) > 1024 {
		return false
	}
	why = "all cell centers fall outside the domain"
	if debugFaceMatch(c.fid) {
		console.Outf("[grid] us=%d vs=%d surf=%T\n", len(us), len(vs), unwrapSurf(c.surf))
	}
	// holeCells is allocated only when the diagnostic switch is on: it counts how many cells
	// each inner loop excluded. An inner loop excluding 0 cells => that hole is fully covered
	// by the grid (another cause of a "membrane").
	var holeCells []int
	if debugHoleCover() && len(holes) > 0 {
		holeCells = make([]int, len(holes))
	}
	for i := 0; i+1 < len(us); i++ {
		for j := 0; j+1 < len(vs); j++ {
			if c.tri >= c.maxTri {
				return c.tri > 0
			}
			cu := (us[i] + us[i+1]) / 2
			cv := (vs[j] + vs[j+1]) / 2
			if !pointInLoop(outer.UV, cu, cv) {
				continue
			}
			inHole := -1
			for hi, h := range holes {
				if pointInLoop(h.UV, cu, cv) {
					inHole = hi
					break
				}
			}
			if inHole >= 0 {
				if holeCells != nil {
					holeCells[inHole]++
				}
				continue
			}
			c.emitGridCell(us[i], us[i+1], vs[j], vs[j+1], 0)
		}
	}
	if holeCells != nil {
		for hi, n := range holeCells {
			if n == 0 {
				console.Outf("[hcover] face #%d path0 (grid) * inner loop %d excluded no cells\n", c.fid, hi)
			}
		}
	}
	if c.tri > 0 {
		why = ""
	}
	return c.tri > 0
}

// emitGridCell emits one grid cell (two triangles split along the p00-p11 diagonal).
// When the cell center deviates from that diagonal beyond tolerance the cell is quartered
// locally -- chord control in u and v separately is not enough to bound the deviation along
// the diagonal on doubly curved surfaces (sphere/spline).
func (c *faceCtx) emitGridCell(u0, u1, v0, v1 float64, depth int) {
	if c.tri >= c.maxTri {
		return
	}
	pt := func(u, v float64) paramPoint {
		return paramPoint{U: u, V: v, P: c.surf.Point(u, v)}
	}
	p00 := pt(u0, v0)
	p11 := pt(u1, v1)
	if depth < 6 {
		cu, cv := (u0+u1)/2, (v0+v1)/2
		// The center lies on the p00-p11 diagonal, where the actual grid position is just the
		// midpoint of the two ends
		pc := pt(cu, cv)
		if pc.P.Dist(p00.P.Add(p11.P).Mul(0.5)) > c.tol {
			c.emitGridCell(u0, cu, v0, cv, depth+1)
			c.emitGridCell(cu, u1, v0, cv, depth+1)
			c.emitGridCell(u0, cu, cv, v1, depth+1)
			c.emitGridCell(cu, u1, cv, v1, depth+1)
			return
		}
	}
	p10 := pt(u1, v0)
	p01 := pt(u0, v1)
	// The parameter domain is right-handed, so emit counter-clockwise; winding is handled by
	// same_sense inside emitTri
	c.emitTri(p00, p10, p11)
	c.emitTri(p00, p11, p01)
}

// isGridAligned reports whether a parameter-domain loop follows grid lines (each edge changes
// only u or only v).
func isGridAligned(uv []P2) bool {
	n := len(uv)
	if n < 4 {
		return false
	}
	var umn, umx, vmn, vmx float64
	umn, vmn = math.Inf(1), math.Inf(1)
	umx, vmx = math.Inf(-1), math.Inf(-1)
	for _, q := range uv {
		umn, umx = math.Min(umn, q.X), math.Max(umx, q.X)
		vmn, vmx = math.Min(vmn, q.Y), math.Max(vmx, q.Y)
	}
	su, sv := umx-umn, vmx-vmn
	if su <= 0 || sv <= 0 {
		return false
	}
	// The criterion must be looser than the accuracy the projection itself reaches: the
	// residual of spline inverse evaluation is about 1e-6 in the parameter domain, so 1e-9
	// would mark edges that "should be aligned" as misaligned (a 10x10 patch was rejected
	// outright). Taking 1e-4 of the parameter span is still far below the real spacing of
	// adjacent loop points.
	tu, tv := math.Max(su*1e-4, 1e-12), math.Max(sv*1e-4, 1e-12)
	aligned := 0
	for i := 0; i < n; i++ {
		j := (i + 1) % n
		if math.Abs(uv[j].X-uv[i].X) <= tu || math.Abs(uv[j].Y-uv[i].Y) <= tv {
			aligned++
		}
	}
	return aligned*20 >= n*19
}

// sortedUniqueParam returns the deduped ascending list of parameters along one direction of
// the loop.
func sortedUniqueParam(uv []P2, alongU bool) []float64 {
	get := func(p P2) float64 { return p.Y }
	if alongU {
		get = func(p P2) float64 { return p.X }
	}
	out := make([]float64, 0, len(uv))
	for _, q := range uv {
		out = append(out, get(q))
	}
	sort.Float64s(out)
	dst := out[:1]
	for _, v := range out[1:] {
		if v-dst[len(dst)-1] > 1e-12 {
			dst = append(dst, v)
		}
	}
	return dst
}

// protectedLines collects the other-direction coordinates fixed by the "grid-aligned" edges of
// the loop; these coordinates are the true boundaries of the parameter domain (for example the
// generatrices on both sides of a cylinder) and must be kept when thinning.
func protectedLines(uv []P2) (protU, protV []float64) {
	n := len(uv)
	if n < 4 {
		return nil, nil
	}
	var umn, umx, vmn, vmx float64
	umn, vmn = math.Inf(1), math.Inf(1)
	umx, vmx = math.Inf(-1), math.Inf(-1)
	for _, q := range uv {
		umn, umx = math.Min(umn, q.X), math.Max(umx, q.X)
		vmn, vmx = math.Min(vmn, q.Y), math.Max(vmx, q.Y)
	}
	tu := math.Max((umx-umn)*1e-4, 1e-12)
	tv := math.Max((vmx-vmn)*1e-4, 1e-12)
	for i := 0; i < n; i++ {
		j := (i + 1) % n
		if math.Abs(uv[j].X-uv[i].X) <= tu {
			protU = append(protU, uv[i].X)
		}
		if math.Abs(uv[j].Y-uv[i].Y) <= tv {
			protV = append(protV, uv[i].Y)
		}
	}
	return protU, protV
}

// thinLines re-spaces lines uniformly within each anchor interval to meet the tolerance, using
// the true parameter-domain boundary lines as anchors.
//
// Why not simply reuse the loop coordinates: the loop sampling density is set by the boundary
// extraction tolerance and in a large assembly can be 2-3 times finer than the triangulation
// tolerance (measured on a 72MB assembly: loops sampled at 2% of the face size while the
// triangulation tolerance was 5%), so reusing them inflates triangles several times over; and
// simple pairwise merging never merges anything (doubling the spacing raises the chord error
// four times). Only re-subdividing each anchor interval keeps the true boundaries while
// reaching the coarsest spacing the tolerance allows.
//
// The result always contains the first and last line.
func (c *faceCtx) thinLines(lines, protect, other []float64, alongU bool) []float64 {
	if len(lines) < 2 {
		return lines
	}
	lo, hi := lines[0], lines[len(lines)-1]
	anchors := make([]float64, 0, len(protect)+2)
	anchors = append(anchors, lo, hi)
	for _, v := range protect {
		if v > lo && v < hi {
			anchors = append(anchors, v)
		}
	}
	sort.Float64s(anchors)
	ded := anchors[:1]
	for _, v := range anchors[1:] {
		if v-ded[len(ded)-1] > 1e-12 {
			ded = append(ded, v)
		}
	}

	out := make([]float64, 0, len(ded)*4)
	out = append(out, ded[0])
	for i := 0; i+1 < len(ded); i++ {
		a, b := ded[i], ded[i+1]
		if !(b > a) {
			continue
		}
		n := 1
		for n < 512 && c.lineDeviation(a, b, other, alongU, n) > c.tol {
			n *= 2
		}
		for k := 1; k <= n; k++ {
			out = append(out, a+(b-a)*float64(k)/float64(n))
		}
	}
	return out
}

// lineDeviation returns the largest deviation of the surface from the chords after splitting
// [a,b] into n equal parts.
func (c *faceCtx) lineDeviation(a, b float64, other []float64, alongU bool, n int) float64 {
	if n < 1 {
		n = 1
	}
	worst := 0.0
	for _, o := range other {
		for k := 0; k < n; k++ {
			s := a + (b-a)*float64(k)/float64(n)
			e := a + (b-a)*float64(k+1)/float64(n)
			m := (s + e) / 2
			var ps, pe, pm Vec3
			if alongU {
				ps, pe, pm = c.surf.Point(s, o), c.surf.Point(e, o), c.surf.Point(m, o)
			} else {
				ps, pe, pm = c.surf.Point(o, s), c.surf.Point(o, e), c.surf.Point(o, m)
			}
			if d := pm.Dist(ps.Add(pe).Mul(0.5)); d > worst {
				worst = d
			}
		}
	}
	return worst
}

// pointInLoop uses a ray test to decide whether a parameter point lies inside the polygon.
func pointInLoop(uv []P2, x, y float64) bool {
	in := false
	n := len(uv)
	if n < 3 {
		return false
	}
	for i, j := 0, n-1; i < n; j, i = i, i+1 {
		yi, yj := uv[i].Y, uv[j].Y
		if (yi > y) == (yj > y) {
			continue
		}
		xi, xj := uv[i].X, uv[j].X
		if x < xi+(xj-xi)*(y-yi)/(yj-yi) {
			in = !in
		}
	}
	return in
}

// unwrapSurf peels off the transform wrappers to expose the real surface type.
func unwrapSurf(s Surface) Surface {
	for {
		xs, ok := s.(*XFormSurf)
		if !ok {
			return s
		}
		s = xs.Base
	}
}

// ---------------------------------------------------------------------------
// Adaptive subdivision and output
// ---------------------------------------------------------------------------

func (c *faceCtx) emitFromParam(tris []int) {
	maxIdx := len(c.uvPts) - 1
	for i := 0; i+2 < len(tris); i += 3 {
		if c.tri >= c.maxTri {
			return
		}
		ia, ib, ic := tris[i], tris[i+1], tris[i+2]
		if ia < 0 || ib < 0 || ic < 0 || ia > maxIdx || ib > maxIdx || ic > maxIdx {
			continue
		}
		c.subdivideTri(c.uvPts[ia], c.uvPts[ib], c.uvPts[ic], 0)
	}
}

func (c *faceCtx) subdivideTri(a, b, d paramPoint, depth int) {
	if c.tri >= c.maxTri {
		return
	}
	if depth > c.maxDepthHit {
		c.maxDepthHit = depth
	}
	if depth < c.maxDepth && c.needsSplit(a, b, d) {
		ab := c.midPt(a, b)
		bc := c.midPt(b, d)
		ca := c.midPt(d, a)
		c.subdivideTri(a, ab, ca, depth+1)
		c.subdivideTri(ab, b, bc, depth+1)
		c.subdivideTri(ca, bc, d, depth+1)
		c.subdivideTri(ab, bc, ca, depth+1)
		return
	}
	c.emitTri(a, b, d)
}

func (c *faceCtx) midPt(a, b paramPoint) paramPoint {
	u := (a.U + b.U) / 2
	v := (a.V + b.V) / 2
	return paramPoint{U: u, V: v, P: c.surf.Point(u, v)}
}

// needsSplit decides subdivision from the deviation between the true surface position and the
// linear interpolation.
//
// The angular criterion is deliberately **not** used here. It was tried: adding a 30 degree
// angular limit inside the surface took a 72 MB fixture from 831k to 2.09M triangles (1.26M
// more), while the visible "holes not round enough" problem is already solved by boundary
// sampling -- hole walls are meshed along the hole loop, so a dense loop makes the wall round.
func (c *faceCtx) needsSplit(a, b, d paramPoint) bool {
	c.splitCalls++
	if _, isPlane := c.surf.(*PlaneSurf); isPlane {
		return false
	}
	tol := c.tol
	if pm := c.midPt(a, b); pm.P.Dist(a.P.Add(b.P).Mul(0.5)) > tol {
		return true
	}
	if pm := c.midPt(b, d); pm.P.Dist(b.P.Add(d.P).Mul(0.5)) > tol {
		return true
	}
	if pm := c.midPt(d, a); pm.P.Dist(d.P.Add(a.P).Mul(0.5)) > tol {
		return true
	}
	cu := (a.U + b.U + d.U) / 3
	cv := (a.V + b.V + d.V) / 3
	pc := c.surf.Point(cu, cv)
	pl := a.P.Add(b.P).Add(d.P).Mul(1.0 / 3.0)
	return pc.Dist(pl) > tol
}

// surfaceNormal computes the normal at a parameter point (already oriented by same_sense).
func (c *faceCtx) surfaceNormal(u, v float64) (Vec3, bool) {
	_, du, dv := c.surf.D1(u, v)
	n := du.Cross(dv)
	l := n.Len()
	if l < 1e-18 {
		return Vec3{}, false
	}
	n = n.Mul(1 / l)
	if !c.same {
		n = n.Mul(-1)
	}
	return n, true
}

func (c *faceCtx) emitTri(a, b, d paramPoint) {
	if c.tri >= c.maxTri {
		return
	}
	c.emitCalls++
	area2 := b.P.Sub(a.P).Cross(d.P.Sub(a.P)).Len()
	if area2 < 1e-16 {
		c.rejArea++
		return
	}
	// Huge triangle sentinel: report the face ID once when the area exceeds the threshold,
	// used to catch "unexplained discs / giant slivers spanning the whole machine" (diverging
	// parameter evaluation or misaligned indices).
	c.noteBigTri(area2*0.5, a.P, b.P, d.P)
	na, ok1 := c.surfaceNormal(a.U, a.V)
	nb, ok2 := c.surfaceNormal(b.U, b.V)
	nd, ok3 := c.surfaceNormal(d.U, d.V)
	if !ok1 || !ok2 || !ok3 {
		g := b.P.Sub(a.P).Cross(d.P.Sub(a.P)).Normalize()
		if g.IsZero() {
			// Reaching here means the 3D cross product of the three points is < 1e-15 (length
			// threshold) while the area2 threshold above was 1e-16, so this degenerate crumb
			// has no usable normal. Drop it: its area is about 0 and it contributes nothing,
			// but writing it out would emit a zero-length normal and the Khronos validator
			// reports ACCESSOR_VECTOR3_NON_UNIT.
			c.rejArea++
			return
		}
		if !c.same {
			g = g.Mul(-1)
		}
		if !ok1 {
			na = g
		}
		if !ok2 {
			nb = g
		}
		if !ok3 {
			nd = g
		}
	}
	ia := c.mb.Add(a.P, na)
	ib := c.mb.Add(b.P, nb)
	ic := c.mb.Add(d.P, nd)
	// The parameter domain is counter-clockwise; flip the winding when same_sense is false
	c.mb.Tri(ia, ib, ic, !c.same)
	c.tri++
}

// ---------------------------------------------------------------------------
// Degraded paths
// ---------------------------------------------------------------------------

// noteBigTri records and (on first occurrence) reports huge triangles seen on this face.
// Both emit paths (emitTri / emitPlanarFallback) must call it, otherwise distortion on the
// planar degradation path slips past the sentinel.
func (c *faceCtx) noteBigTri(area float64, a, b, d Vec3) {
	thr := bigTriThresh()
	if thr <= 0 || area <= thr {
		return
	}
	if area > c.bigTriArea {
		c.bigTriArea = area
	}
	if c.bigTriLogged {
		return
	}
	c.bigTriLogged = true
	noteBigTriFace()
	console.Outf("[big] face #%d huge triangle %.1f (face own size %.1f, %d loop points, tolerance %.3g, %d triangles emitted so far): (%.4f,%.4f,%.4f) (%.4f,%.4f,%.4f) (%.4f,%.4f,%.4f)\n",
		c.fid, area, c.ext, len(c.uvPts), c.tol, c.tri,
		a.X, a.Y, a.Z, b.X, b.Y, b.Z, d.X, d.Y, d.Z)
}

// emitPlanarFallback projects the loops onto the best-fit plane and ear clips them.
// It is used for malformed surfaces whose parameter-domain projection failed, so the face is
// not lost as a whole.
func (c *faceCtx) emitPlanarFallback(outer []Vec3, inners [][]Vec3) bool {
	e1, e2, org, ok := bestFitFrame(outer)
	if !ok {
		return false
	}
	to2 := func(p Vec3) P2 {
		rel := p.Sub(org)
		return P2{rel.Dot(e1), rel.Dot(e2)}
	}

	// Filter out invalid loops with the same hole filter conditions Triangulate uses, so the
	// returned indices map back to the 3D points correctly.
	mkLoop := func(p []Vec3) ([]P2, []Vec3, bool) {
		uv := make([]P2, len(p))
		for i, q := range p {
			uv[i] = to2(q)
		}
		uv, pos := dedupeLoop(uv, p)
		if len(uv) < 3 {
			return nil, nil, false
		}
		if math.Abs(shoelace(uv)) < 1e-15 {
			return nil, nil, false
		}
		return uv, pos, true
	}

	ou, op, ok := mkLoop(outer)
	if !ok {
		return false
	}
	holesUV := make([][]P2, 0, len(inners))
	holesP := make([][]Vec3, 0, len(inners))
	for _, in := range inners {
		hu, hp, ok := mkLoop(in)
		if !ok {
			continue
		}
		holesUV = append(holesUV, hu)
		holesP = append(holesP, hp)
	}
	// Same as the parameter-domain path: bridging requires inner loops opposite to the outer
	// loop, otherwise holes are counted into the area. This must be done **before** allUV/allP
	// are assembled below, so the two places keep the same order.
	normalizeHoleWindingRaw(ou, holesUV, holesP)

	allUV := append([]P2{}, ou...)
	allP := append([]Vec3{}, op...)
	for i := range holesUV {
		allUV = append(allUV, holesUV[i]...)
		allP = append(allP, holesP[i]...)
	}

	tris := Triangulate(ou, holesUV)
	if len(tris) < 3 {
		return false
	}
	if len(holesUV) > 0 && (debugHoleArea() || debugHoleCover()) {
		all := append([][]P2{ou}, holesUV...)
		flat := concatP2(all)
		want := expectedLoopArea(all)
		got := math.Abs(triAreaSum(flat, tris))
		dev := 0.0
		if want > 0 {
			dev = (got - want) / want * 100
		}
		if debugHoleArea() {
			console.Outf("[hoarea] face #%d path2 (planar degradation) inner loops %d: got %.4f expected %.4f deviation %+.3f%%\n",
				c.fid, len(holesUV), got, want, dev)
		}
		if cov, hp, ft := holeCoverReport(flat, len(ou), tris); cov > 0 {
			console.Outf("[hcover] face #%d path2 (planar degradation) * hole covered: %d/%d hole points fall inside %d triangles\n",
				c.fid, cov, hp, ft)
		}
	}
	for i := 0; i+2 < len(tris); i += 3 {
		pa, ok1 := vecAt(allP, tris[i])
		pb, ok2 := vecAt(allP, tris[i+1])
		pc, ok3 := vecAt(allP, tris[i+2])
		if !ok1 || !ok2 || !ok3 {
			continue
		}
		cr := pb.Sub(pa).Cross(pc.Sub(pa))
		c.noteBigTri(0.5*cr.Len(), pa, pb, pc)
		n := cr.Normalize()
		if n.IsZero() {
			continue
		}
		if !c.same {
			n = n.Mul(-1)
		}
		ia := c.mb.Add(pa, n)
		ib := c.mb.Add(pb, n)
		ic := c.mb.Add(pc, n)
		c.mb.Tri(ia, ib, ic, false)
		c.tri++
		if c.tri >= c.maxTri {
			break
		}
	}
	return c.tri > 0
}

func vecAt(all []Vec3, i int) (Vec3, bool) {
	if i < 0 || i >= len(all) {
		return Vec3{}, false
	}
	return all[i], true
}

// bestFitFrame derives the best-fit plane frame of the outer loop via PCA.
func bestFitFrame(poly []Vec3) (Vec3, Vec3, Vec3, bool) {
	n := len(poly)
	if n < 3 {
		return Vec3{}, Vec3{}, Vec3{}, false
	}
	org := Vec3{}
	for _, p := range poly {
		org = org.Add(p)
	}
	org = org.Mul(1 / float64(n))

	var cxx, cxy, cxz, cyy, cyz, czz float64
	for _, p := range poly {
		d := p.Sub(org)
		cxx += d.X * d.X
		cxy += d.X * d.Y
		cxz += d.X * d.Z
		cyy += d.Y * d.Y
		cyz += d.Y * d.Z
		czz += d.Z * d.Z
	}
	apply := func(v Vec3) Vec3 {
		return Vec3{
			cxx*v.X + cxy*v.Y + cxz*v.Z,
			cxy*v.X + cyy*v.Y + cyz*v.Z,
			cxz*v.X + cyz*v.Y + czz*v.Z,
		}
	}
	e1 := powerIterate(apply, Vec3{1, 1, 1})
	if e1.IsZero() {
		return Vec3{}, Vec3{}, Vec3{}, false
	}
	// Deflate the principal direction before solving for the second one; their cross product
	// is the plane normal
	l1 := e1.Dot(apply(e1))
	apply2 := func(v Vec3) Vec3 {
		return apply(v).Sub(e1.Mul(l1 * v.Dot(e1)))
	}
	e2 := powerIterate(apply2, Vec3{e1.Y, e1.Z, e1.X})
	if e2.IsZero() {
		return Vec3{}, Vec3{}, Vec3{}, false
	}
	e2 = e2.Sub(e1.Mul(e2.Dot(e1)))
	if e2.Len() < 1e-12 {
		return Vec3{}, Vec3{}, Vec3{}, false
	}
	e2 = e2.Normalize()
	return e1, e2, org, true
}

func powerIterate(apply func(Vec3) Vec3, seed Vec3) Vec3 {
	v := seed
	for i := 0; i < 48; i++ {
		nv := apply(v)
		if nv.Len() < 1e-24 {
			return Vec3{}
		}
		v = nv.Normalize()
	}
	return v
}
