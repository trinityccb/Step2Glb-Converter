package step

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
	"testing"
)

// TestEarProbe reads the parameter-domain loops dumped by STP2GLB_DUMP_EAR and
// feeds them straight into ear clipping, printing the bridged polygon, the
// emitted triangles and all four area measures.
//
// Usage:
//
//	EARPROBE=_v8/ear.txt EARFACE=2124218 go test ./internal/step -run TestEarProbe -v
//
// This way a change to the ear-clipping logic can be verified in a second,
// without a 6.5-minute full conversion.
func TestEarProbe(t *testing.T) {
	path := os.Getenv("EARPROBE")
	if path == "" {
		t.Skip("EARPROBE not set")
	}
	want := map[int]bool{}
	for _, s := range strings.Split(os.Getenv("EARFACE"), ",") {
		if s = strings.TrimSpace(s); s != "" {
			if v, err := strconv.Atoi(s); err == nil {
				want[v] = true
			}
		}
	}

	for _, rec := range parseEarDump(t, path) {
		if len(want) > 0 && !want[rec.id] {
			continue
		}
		probeOne(t, rec)
	}
}

type earRec struct {
	id    int
	outer []P2
	holes [][]P2
	tris  []int
	extra []P2 // points created by boolean clipping (after "outer ++ holes")
}

func parseEarDump(t *testing.T, path string) []earRec {
	f, err := os.Open(path)
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	var out []earRec
	var cur *earRec
	var lens []int
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<20), 1<<22)
	for sc.Scan() {
		ln := sc.Text()
		if ln == "" {
			continue
		}
		parts := strings.Fields(ln[1:])
		switch ln[0] {
		case 'F':
			id, _ := strconv.Atoi(parts[0])
			nHoles, _ := strconv.Atoi(parts[2])
			lens = lens[:0]
			for i := 0; i < nHoles; i++ {
				v, _ := strconv.Atoi(parts[3+i])
				lens = append(lens, v)
			}
			out = append(out, earRec{id: id})
			cur = &out[len(out)-1]
		case 'P':
			cur.outer = nil
			for i := 0; i+1 < len(parts); i += 2 {
				x, _ := strconv.ParseFloat(parts[i], 64)
				y, _ := strconv.ParseFloat(parts[i+1], 64)
				cur.outer = append(cur.outer, P2{X: x, Y: y})
			}
		case 'H':
			var all []P2
			for i := 0; i+1 < len(parts); i += 2 {
				x, _ := strconv.ParseFloat(parts[i], 64)
				y, _ := strconv.ParseFloat(parts[i+1], 64)
				all = append(all, P2{X: x, Y: y})
			}
			cur.holes = nil
			k := 0
			for _, L := range lens {
				cur.holes = append(cur.holes, all[k:k+L])
				k += L
			}
		case 'X':
			// points created by boolean clipping (after "outer ++ holes")
			cur.extra = nil
			for i := 0; i+1 < len(parts); i += 2 {
				x, _ := strconv.ParseFloat(parts[i], 64)
				y, _ := strconv.ParseFloat(parts[i+1], 64)
				cur.extra = append(cur.extra, P2{X: x, Y: y})
			}
		case 'T':
			cur.tris = nil
			for _, s := range parts {
				v, _ := strconv.Atoi(s)
				cur.tris = append(cur.tris, v)
			}
		}
	}
	return out
}

// probeFlatP builds a fake "3D = parameter domain" point table for boolean
// clipping. Clipping computes areas only in the parameter domain and uses 3D
// purely for linear interpolation, so a valid correspondence is enough.
func probeFlatP(all []P2) []Vec3 {
	out := make([]Vec3, len(all))
	for i, q := range all {
		out[i] = Vec3{X: q.X, Y: q.Y}
	}
	return out
}

// extraUVOf extracts the parameter-domain coordinates of clip-added points (at
// the end of the point table).
func extraUVOf(ext []paramPoint) []P2 {
	out := make([]P2, len(ext))
	for i, e := range ext {
		out[i] = P2{X: e.U, Y: e.V}
	}
	return out
}

func probeOne(t *testing.T, rec earRec) {
	loops := append([][]P2{rec.outer}, rec.holes...)
	all := concatP2(loops)
	nReal := len(all)
	all = append(all, rec.extra...) // clip-added points follow the original table so indices line up
	want := expectedLoopArea(loops)

	fmt.Printf("\n========== face #%d ==========\n", rec.id)
	fmt.Printf("outer loop %d points (area %.3f), holes %d (area %.3f), all holes inside outer=%v\n",
		len(rec.outer), shoelace(rec.outer), len(rec.holes), holeAreaSum(rec.holes),
		holesContained(rec.outer, rec.holes))

	// Recompute the triangles read from the dumped data
	report("dumped result", all, len(rec.outer), nReal, rec.tris, want)

	// Re-run ear clipping to see whether the result reproduces
	tris2, d := triangulateDiag(rec.outer, rec.holes, -1)
	fmt.Printf("diagnostics: bridged holes %d, no visible point %d, forced removal %d, iterations %d, points %d, skipped %d, index shift %d\n",
		d.Merged, d.NoVisible, d.Forced, d.Iters, d.Pts, d.Skipped, d.IndexShift)
	report("re-run result", all, len(rec.outer), nReal, tris2, want)

	// Boolean clipping: only meaningful for faces where a hole pokes outside the outer loop
	if !holesContained(rec.outer, rec.holes) {
		if t3, ext, ok := clipRegionTri(rec.outer, rec.holes, probeFlatP(all)); ok {
			tbl := append(append([]P2{}, all...), extraUVOf(ext)...)
			// Note: want is only the right measure when every hole lies inside the
			// outer loop; it is too small when a hole crosses the boundary, so the
			// denominator for the clipped result must be the area clipping itself
			// computed (= the true region area).
			var clipArea float64
			for i := 0; i+2 < len(t3); i += 3 {
				clipArea += math.Abs(shoelace([]P2{tbl[t3[i]], tbl[t3[i+1]], tbl[t3[i+2]]}))
			}
			report("clip result", tbl, len(rec.outer), nReal, t3, clipArea)
			fmt.Printf("[clip correction] old expected %.4f -> true area %.4f (%.4f x)\n", want, clipArea, clipArea/want)
		} else {
			fmt.Println("[clip result] giving up (too many pieces or degenerate)")
		}
	}

	// Dump the triangles of the winning result (indices point into the
	// "outer ++ holes ++ clip-added points" table)
	if p := os.Getenv("EAROUT"); p != "" {
		t3, ext, _ := triangulateFull(rec.outer, rec.holes, probeFlatP(all), -1)
		tbl := append(append([]P2{}, all...), extraUVOf(ext)...)
		f, err := os.Create(fmt.Sprintf("%s.%d.txt", p, rec.id))
		if err == nil {
			w := bufio.NewWriter(f)
			fmt.Fprintf(w, "OUTER %d\nHOLES %d\n", len(rec.outer), len(rec.holes))
			for i, q := range tbl {
				fmt.Fprintf(w, "%d %d %.10g %.10g\n", i, i, q.X, q.Y)
			}
			fmt.Fprintf(w, "TRI")
			for _, v := range t3 {
				fmt.Fprintf(w, " %d", v)
			}
			fmt.Fprintln(w)
			w.Flush()
			f.Close()
			fmt.Printf("point table of %d (%d clip-added) written to %s.%d.txt\n", len(tbl), len(ext), p, rec.id)
		}
	}

	if os.Getenv("EARVERBOSE") != "" {
		probeHolesDebug(t, rec)
	}
}

func holeAreaSum(holes [][]P2) float64 {
	s := 0.0
	for _, h := range holes {
		s += math.Abs(shoelace(h))
	}
	return s
}

// probeHolesDebug replicates the per-hole flow of buildWithHoles and prints the
// candidate selection for every hole.
func probeHolesDebug(t *testing.T, rec earRec) {
	type href struct {
		idx   int
		right float64
	}
	refs := make([]href, 0, len(rec.holes))
	for i, h := range rec.holes {
		mx := -math.MaxFloat64
		for _, q := range h {
			if q.X > mx {
				mx = q.X
			}
		}
		refs = append(refs, href{i, mx})
	}
	for i := 1; i < len(refs); i++ {
		for j := i; j > 0 && refs[j].right > refs[j-1].right; j-- {
			refs[j], refs[j-1] = refs[j-1], refs[j]
		}
	}
	pts := append([]P2(nil), rec.outer...)
	merged := make([]bool, len(rec.holes))
	for step, r := range refs {
		h := rec.holes[r.idx]
		hi := 0
		for i, q := range h {
			if q.X > h[hi].X {
				hi = i
			}
		}
		hp := h[hi]
		var others [][]P2
		for k := range rec.holes {
			if k != r.idx && !merged[k] {
				others = append(others, rec.holes[k])
			}
		}
		var visOnly, holeOK, othersOK int
		best := -1
		bestD := math.MaxFloat64
		for i := range pts {
			q := pts[i]
			if !segmentVisible(pts, hp, q) {
				continue
			}
			visOnly++
			if !segmentClearOfHole(hp, q, h, hi) {
				continue
			}
			holeOK++
			if !segmentClearOfLoops(hp, q, others) {
				continue
			}
			othersOK++
			if d := dist2(pts[i], hp); d < bestD {
				bestD, best = d, i
			}
		}
		fmt.Printf("   step %2d hole%d (%d points, rightmost #%d (%.4f,%.4f)) in a %d point list: "+
			"visible %d, own-hole check %d, other holes %d -> picked %d\n",
			step, r.idx, len(h), hi, hp.X, hp.Y, len(pts), visOnly, holeOK, othersOK, best)
		if best < 0 {
			fmt.Printf("      - no usable candidate, per-point detail (d=distance, V=visible, H=clear of hole, O=clear of other holes)\n")
			for i := range pts {
				q := pts[i]
				v := segmentVisible(pts, hp, q)
				hh := segmentClearOfHole(hp, q, h, hi)
				oo := segmentClearOfLoops(hp, q, others)
				if !v && os.Getenv("EARALL") == "" {
					continue
				}
				fmt.Printf("         #%-3d (%.4f,%.4f) d=%.3f V=%v H=%v O=%v\n",
					i, q.X, q.Y, math.Sqrt(dist2(hp, q)), v, hh, oo)
			}
			continue
		}
		// Actually merge
		merged[r.idx] = true
		mergedSeq := make([]P2, 0, len(pts)+len(h)+2)
		mergedSeq = append(mergedSeq, pts[:best+1]...)
		mergedSeq = append(mergedSeq, hp)
		for k := 1; k < len(h); k++ {
			mergedSeq = append(mergedSeq, h[(hi+k)%len(h)])
		}
		mergedSeq = append(mergedSeq, hp, pts[best])
		mergedSeq = append(mergedSeq, pts[best+1:]...)
		pts = mergedSeq
	}
}

// report prints the four area measures of one triangulation result.
// nReal is the number of "real loop points" (outer + holes); any clip-added
// points after them are not counted in the hole point statistics.
func report(tag string, all []P2, outerLen, nReal int, tris []int, want float64) {
	var pos, neg float64
	var npos, nneg, nzero, oob int
	if nReal > len(all) {
		nReal = len(all)
	}
	covered, holePts, fromTris := holeCoverReport(all[:nReal], outerLen, tris)
	for i := 0; i+2 < len(tris); i += 3 {
		a, b, c := tris[i], tris[i+1], tris[i+2]
		if a < 0 || b < 0 || c < 0 || a >= len(all) || b >= len(all) || c >= len(all) {
			oob++
			continue
		}
		s := shoelace([]P2{all[a], all[b], all[c]})
		if s > 1e-12 {
			pos += s
			npos++
		} else if s < -1e-12 {
			neg += s
			nneg++
		} else {
			nzero++
		}
	}
	fmt.Printf("[%s] triangles %d (out of range %d): positive %d=%.3f  negative %d=%.3f  zero %d\n",
		tag, len(tris)/3, oob, npos, pos, nneg, neg, nzero)
	fmt.Printf("[%s] signed sum %.6f (expected %.6f, deviation %+.4f%%)  sum|dA| %.3f = %.3f x expected\n",
		tag, pos+neg, want, (pos+neg-want)/want*100, pos-neg, (pos-neg)/want)
	fmt.Printf("[%s] hole points covered %d (of %d hole points, from %d triangles)\n", tag, covered, holePts, fromTris)
}
