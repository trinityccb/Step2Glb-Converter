package step

import "math"

// Accessor helpers: every accessor stays silent on out-of-range indices and type mismatches and
// returns the zero value. STEP files come from many different CAD exporters, so parameter counts
// and optional slots differ often; lenient access is what keeps 17,000+ faces from collapsing.

func (e *Entity) Params1(i int) Value {
	if e == nil || i < 0 || i >= len(e.Params) {
		return Value{Kind: KindUndefined}
	}
	return e.Params[i]
}

func (e *Entity) Num(i int) float64 {
	v := e.Params1(i)
	if v.Kind == KindNumber {
		return v.Num
	}
	return 0
}

func (e *Entity) HasNum(i int) bool {
	v := e.Params1(i)
	return v.Kind == KindNumber
}

func (e *Entity) Str(i int) string {
	v := e.Params1(i)
	if v.Kind == KindString {
		return v.Str
	}
	return ""
}

func (e *Entity) Enum(i int) string {
	v := e.Params1(i)
	if v.Kind == KindEnum {
		return v.Str
	}
	return ""
}

func (e *Entity) Bool(i int) bool {
	return e.Enum(i) == "T"
}

// Ref returns the entity ID referenced by parameter i, or 0 when it is not a reference.
func (e *Entity) Ref(i int) int {
	v := e.Params1(i)
	if v.Kind == KindRef {
		return v.Ref
	}
	return 0
}

// List returns the elements of parameter i when it is a list.
func (e *Entity) List(i int) []Value {
	v := e.Params1(i)
	if v.Kind == KindList {
		return v.List
	}
	return nil
}

// Refs returns all reference IDs in the list held by parameter i.
func (e *Entity) Refs(i int) []int {
	lst := e.List(i)
	out := make([]int, 0, len(lst))
	for _, v := range lst {
		if v.Kind == KindRef {
			out = append(out, v.Ref)
		}
	}
	return out
}

// RefsAt returns all references in a nested list (such as the control_points_list of a
// B-spline surface).
func (e *Entity) RefsAt(i int) [][]int {
	lst := e.List(i)
	out := make([][]int, 0, len(lst))
	for _, outer := range lst {
		if outer.Kind != KindList {
			continue
		}
		inner := make([]int, 0, len(outer.List))
		for _, v := range outer.List {
			if v.Kind == KindRef {
				inner = append(inner, v.Ref)
			}
		}
		out = append(out, inner)
	}
	return out
}

// Ints reads an integer list (knot multiplicities and the like).
func (e *Entity) Ints(i int) []int {
	lst := e.List(i)
	out := make([]int, 0, len(lst))
	for _, v := range lst {
		if v.Kind == KindNumber {
			out = append(out, int(v.Num+0.5))
		}
	}
	return out
}

// Floats reads a real list (knot vector, weights and the like).
func (e *Entity) Floats(i int) []float64 {
	lst := e.List(i)
	out := make([]float64, 0, len(lst))
	for _, v := range lst {
		if v.Kind == KindNumber {
			out = append(out, v.Num)
		}
	}
	return out
}

// FloatsAt reads a nested real list (the weight matrix of a rational spline).
func (e *Entity) FloatsAt(i int) [][]float64 {
	lst := e.List(i)
	out := make([][]float64, 0, len(lst))
	for _, outer := range lst {
		row := make([]float64, 0, 8)
		if outer.Kind == KindList {
			for _, v := range outer.List {
				if v.Kind == KindNumber {
					row = append(row, v.Num)
				}
			}
		}
		out = append(out, row)
	}
	return out
}

// ---------------------------------------------------------------------------
// Geometry builders
// ---------------------------------------------------------------------------

// Geom interprets STEP entities as Curve / Surface and caches the results.
type Geom struct {
	F           *File
	place       map[int]Placement
	failedPlace map[int]bool
	curves      map[int]Curve
	surfaces    map[int]Surface
	failed      map[int]bool
	Stats       GeomStats
}

// GeomStats records degradations during geometry construction for the final report.
type GeomStats struct {
	UnknownCurves   map[string]int
	UnknownSurfaces map[string]int
}

// NewGeom creates a geometry builder.
func NewGeom(f *File) *Geom {
	return &Geom{
		F:           f,
		place:       make(map[int]Placement, 1<<12),
		failedPlace: make(map[int]bool),
		curves:      make(map[int]Curve, 1<<13),
		surfaces:    make(map[int]Surface, 1<<12),
		failed:      make(map[int]bool),
		Stats: GeomStats{
			UnknownCurves:   map[string]int{},
			UnknownSurfaces: map[string]int{},
		},
	}
}

// E returns an entity by ID.
func (g *Geom) E(id int) *Entity {
	if id <= 0 {
		return nil
	}
	return g.F.Entities[id]
}

// Point parses a point entity. Besides CARTESIAN_POINT it also transparently
// unwraps the VERTEX_POINT layer (EDGE_CURVE endpoints are VERTEX_POINTs).
func (g *Geom) Point(id int) (Vec3, bool) {
	return g.pointDepth(id, 0)
}

func (g *Geom) pointDepth(id int, depth int) (Vec3, bool) {
	if depth > 8 {
		return Vec3{}, false
	}
	e := g.E(id)
	if e == nil {
		return Vec3{}, false
	}
	switch e.Type {
	case "VERTEX_POINT":
		return g.pointDepth(e.Ref(1), depth+1)
	case "CARTESIAN_POINT":
		// normal path
	case "":
		return Vec3{}, false
	default:
		// other wrapper types (private wrappers of a few exporters): try to unwrap the first reference
		if r := e.Ref(1); r != 0 {
			if p, ok := g.pointDepth(r, depth+1); ok {
				return p, true
			}
		}
		return Vec3{}, false
	}
	nums := e.Floats(1)
	switch len(nums) {
	case 0:
		return Vec3{}, false
	case 1:
		return Vec3{nums[0], 0, 0}, true
	case 2:
		return Vec3{nums[0], nums[1], 0}, true
	default:
		return Vec3{nums[0], nums[1], nums[2]}, true
	}
}

// Dir parses a DIRECTION (a normalized direction).
func (g *Geom) Dir(id int) (Vec3, bool) {
	e := g.E(id)
	if e == nil {
		return Vec3{}, false
	}
	nums := e.Floats(1)
	switch len(nums) {
	case 0:
		return Vec3{}, false
	case 1:
		return Vec3{nums[0], 0, 0}.Normalize(), true
	case 2:
		return Vec3{nums[0], nums[1], 0}.Normalize(), true
	default:
		d := Vec3{nums[0], nums[1], nums[2]}
		if d.IsZero() {
			return Vec3{}, false
		}
		return d.Normalize(), true
	}
}

// Vector parses a VECTOR (direction plus magnitude).
func (g *Geom) Vector(id int) (Vec3, bool) {
	e := g.E(id)
	if e == nil {
		return Vec3{}, false
	}
	d, ok := g.Dir(e.Ref(1))
	if !ok {
		return Vec3{}, false
	}
	mag := e.Num(2)
	if !e.HasNum(2) {
		mag = 1
	}
	return d.Mul(mag), true
}

// Placement parses AXIS2_PLACEMENT_3D (with AXIS2_PLACEMENT_2D handled for compatibility)
// into a local coordinate frame.
// Indices follow the nameOff convention as well: location / axis / ref_direction are o, o+1, o+2.
func (g *Geom) Placement(id int) (Placement, bool) {
	if id == 0 {
		return Placement{}, false
	}
	if p, ok := g.place[id]; ok {
		return p, true
	}
	if g.failedPlace[id] {
		return Placement{}, false
	}
	e := g.E(id)
	if e == nil {
		g.failedPlace[id] = true
		return Placement{}, false
	}
	o := nameOff(e)
	org, ok := g.Point(e.Ref(o))
	if !ok {
		g.failedPlace[id] = true
		return Placement{}, false
	}
	var z, x Vec3
	if e.Ref(o+1) != 0 {
		z, _ = g.Dir(e.Ref(o + 1))
	}
	if e.Ref(o+2) != 0 {
		x, _ = g.Dir(e.Ref(o + 2))
	}
	p := NewPlacement(org, z, x)
	g.place[id] = p
	return p, true
}

// Curve interprets an entity as a parametric curve; the result is cached.
func (g *Geom) Curve(id int) Curve {
	if c, ok := g.curves[id]; ok {
		return c
	}
	if g.failed[id] {
		return nil
	}
	c := g.buildCurve(id)
	if c == nil {
		g.failed[id] = true
		if e := g.E(id); e != nil {
			g.Stats.UnknownCurves[e.Type]++
		}
		return nil
	}
	g.curves[id] = c
	return c
}

func (g *Geom) buildCurve(id int) Curve {
	e := g.E(id)
	if e == nil {
		return nil
	}
	// Complex instance: AP203 writes a curve as `#1=(BOUNDED_CURVE()B_SPLINE_CURVE(...)
	// B_SPLINE_CURVE_WITH_KNOTS(...)RATIONAL_B_SPLINE_CURVE(...))`, where degree and control
	// points, knot vector and weights are spread over different sub-entities and must be
	// merged before parsing.
	if e.Type == "(COMPLEX)" {
		subs := g.F.ComplexAll(id)
		if merged := mergeSplineSubs(subs, "CURVE"); merged != nil {
			if c := g.curveFromEntity(merged); c != nil {
				return c
			}
		}
		for _, sub := range subs {
			if c := g.curveFromEntity(sub); c != nil {
				return c
			}
		}
		return nil
	}
	return g.curveFromEntity(e)
}

// mergeSplineSubs merges the B-spline data scattered across a complex instance into one entity
// with a complete parameter list. kind is "CURVE" or "SURFACE".
func mergeSplineSubs(subs []*Entity, kind string) *Entity {
	baseName := "B_SPLINE_" + kind
	knotName := "B_SPLINE_" + kind + "_WITH_KNOTS"
	ratName := "RATIONAL_B_SPLINE_" + kind

	var base, knots, rational *Entity
	for _, s := range subs {
		switch s.Type {
		case baseName:
			base = s
		case knotName:
			knots = s
		case ratName:
			rational = s
		}
	}
	if base == nil {
		return nil
	}
	if knots == nil && rational == nil {
		return nil // no extra information, let the regular branch handle it
	}
	params := make([]Value, 0, len(base.Params)+16)
	params = append(params, base.Params...)
	if knots != nil {
		params = append(params, knots.Params...)
	}
	if rational != nil {
		params = append(params, rational.Params...)
	}
	return &Entity{ID: base.ID, Type: base.Type, Params: params}
}

// nameOff returns the index of the first non-name attribute in the parameter table.
//
// The STEP entity parameter table is always [name, a1, a2, ...]:
//   - a simple entity always carries name, which may be a string (`'#12'`) or `$`,
//     so a1 lands at index 1;
//   - in a complex instance (`#1=(BOUNDED_SURFACE()PLANE(#2))`) the name inherited from
//     representation_item is omitted entirely, so a1 lands at index 0.
//
// The convention follows: every attribute access uses `e.Xxx(o + k)`, with k the ordinal
// among the non-name attributes.
// Note that a1 is always a reference/number/enum/list and can never be a string or `$`,
// which makes this test reliable.
func nameOff(e *Entity) int {
	if len(e.Params) == 0 {
		return 0
	}
	switch e.Params[0].Kind {
	case KindString, KindUndefined, KindDerived:
		return 1
	}
	return 0
}

// curveFromEntity builds a curve by entity type (without the complex instance branch).
func (g *Geom) curveFromEntity(e *Entity) Curve {
	o := nameOff(e)
	switch e.Type {
	case "LINE":
		org, ok := g.Point(e.Ref(o))
		if !ok {
			return nil
		}
		dir, ok := g.Vector(e.Ref(o + 1))
		if !ok {
			return nil
		}
		return &LineCurve{Origin: org, Dir: dir}

	case "CIRCLE":
		pl, ok := g.Placement(e.Ref(o))
		if !ok {
			return nil
		}
		return NewCircle(pl, e.Num(o+1))

	case "ELLIPSE":
		pl, ok := g.Placement(e.Ref(o))
		if !ok {
			return nil
		}
		r1, r2 := e.Num(o+1), e.Num(o+2)
		if r1 <= 0 || r2 <= 0 {
			return nil
		}
		return NewEllipse(pl, r1, r2)

	case "B_SPLINE_CURVE", "B_SPLINE_CURVE_WITH_KNOTS",
		"RATIONAL_B_SPLINE_CURVE", "RATIONAL_B_SPLINE_CURVE_WITH_KNOTS",
		"BEZIER_CURVE", "UNIFORM_CURVE", "QUASI_UNIFORM_CURVE":
		return g.buildBSplineCurve(e, o)

	case "TRIMMED_CURVE":
		base := g.Curve(e.Ref(o))
		if base == nil {
			return nil
		}
		return g.applyTrim(base, e, o)

	case "COMPOSITE_CURVE":
		segRefs := e.Refs(o)
		var segs []Curve
		var rev []bool
		for _, sid := range segRefs {
			se := g.E(sid)
			if se == nil {
				continue
			}
			if se.Type == "(COMPLEX)" {
				for _, sub := range g.F.ComplexAll(sid) {
					if sub.Type != "COMPOSITE_CURVE_SEGMENT" {
						continue
					}
					if c, r, ok := g.compositeSegment(sub); ok {
						segs = append(segs, c)
						rev = append(rev, r)
					}
				}
				continue
			}
			if c, r, ok := g.compositeSegment(se); ok {
				segs = append(segs, c)
				rev = append(rev, r)
			}
		}
		if len(segs) == 0 {
			return nil
		}
		return &CompositeCurve{Segs: segs, Rev: rev}

	case "POLYLINE":
		pts := g.pointList(e.Refs(o))
		if len(pts) < 2 {
			return nil
		}
		return &PolylineCurve{Pts: pts}

	case "SURFACE_CURVE", "SEAM_CURVE", "INTERSECTION_CURVE", "BOUNDED_CURVE":
		// the 3D curve itself is the first attribute
		return g.Curve(e.Ref(o))
	}
	return nil
}

// compositeSegment parses COMPOSITE_CURVE_SEGMENT(name, transition,
// same_sense, parent_curve) and returns the sub-curve plus whether it must be reversed.
func (g *Geom) compositeSegment(se *Entity) (Curve, bool, bool) {
	so := nameOff(se)
	c := g.Curve(se.Ref(so + 2))
	if c == nil {
		return nil, false, false
	}
	return c, !se.Bool(so + 1), true
}

func (g *Geom) pointList(refs []int) []Vec3 {
	out := make([]Vec3, 0, len(refs))
	for _, r := range refs {
		if p, ok := g.Point(r); ok {
			out = append(out, p)
		}
	}
	return out
}

// applyTrim clamps a trimmed curve to a parameter interval. o is the name offset.
func (g *Geom) applyTrim(base Curve, e *Entity, o int) Curve {
	t1, ok1 := g.trimParamOf(e.Ref(o+1), base)
	t2, ok2 := g.trimParamOf(e.Ref(o+2), base)
	if !ok1 || !ok2 {
		return base
	}
	sense := true
	if len(e.Params) > o+3 {
		sense = e.Bool(o + 3)
	}
	if t1 == t2 {
		return base
	}
	return &TrimmedCurve{
		Base:     base,
		T0:       math.Min(t1, t2),
		T1:       math.Max(t1, t2),
		Reversed: sense == (t1 > t2),
	}
}

// trimParamOf reads a parameter from a TRIMMING_SELECT: it may be the parameter value itself,
// or a point, in which case it is projected onto the base curve to obtain the parameter.
func (g *Geom) trimParamOf(id int, base Curve) (float64, bool) {
	e := g.E(id)
	if e == nil {
		return 0, false
	}
	if v, ok := g.scanNumbers(e); ok {
		return v, true
	}
	// point reference: project to obtain the parameter
	if p, ok := g.Point(id); ok {
		t0, t1 := base.Range()
		guess := 0.0
		if isFinite(t0) && isFinite(t1) {
			guess = (t0 + t1) / 2
		}
		return base.ClosestParam(p, guess)
	}
	return 0, false
}

// scanNumbers finds the first number among the entity parameters (one nesting level included).
func (g *Geom) scanNumbers(e *Entity) (float64, bool) {
	for i := 0; i < len(e.Params); i++ {
		if e.HasNum(i) {
			return e.Num(i), true
		}
		if lst := e.List(i); lst != nil {
			for _, v := range lst {
				if v.Kind == KindNumber {
					return v.Num, true
				}
			}
		}
	}
	return 0, false
}

// buildBSplineCurve parses the various B-spline curves, adapting the layout to the parameter count.
// o is the name attribute offset (name is omitted in complex instances, where o is 0).
func (g *Geom) buildBSplineCurve(e *Entity, o int) Curve {
	degree := int(e.Num(o))
	cpRefs := e.Refs(o + 1)
	if len(cpRefs) < 2 || degree < 1 {
		return nil
	}
	cps := g.pointList(cpRefs)
	if len(cps) < 2 {
		return nil
	}
	if degree > len(cps)-1 {
		degree = len(cps) - 1
	}
	c := &BSplineCurve{Degree: degree, CP: cps}

	// locate the "(multiplicity, knot)" parameter pair and the weights
	var mults []int
	var knots []float64
	var weights []float64
	for i := o + 2; i < len(e.Params); i++ {
		v := e.Params[i]
		if v.Kind != KindList || len(v.List) == 0 {
			continue
		}
		// knot multiplicities: integer list; knot vector: real list
		allInt, allNum := true, true
		hasRef := false
		for _, it := range v.List {
			switch it.Kind {
			case KindNumber:
				if it.Num != math.Trunc(it.Num) {
					allInt = false
				}
			case KindRef:
				hasRef = true
			default:
				allInt, allNum = false, false
			}
		}
		if hasRef || (!allInt && !allNum) {
			continue
		}
		if allInt && mults == nil && len(v.List) >= 2 {
			m := make([]int, 0, len(v.List))
			for _, it := range v.List {
				m = append(m, int(it.Num+0.5))
			}
			// a single multiplicity value may also be the curve own data, so sanity check it
			if sumInts(m) >= len(cps)+degree+1-2 {
				mults = m
			}
			continue
		}
		if allNum && knots == nil && len(v.List) >= 2 {
			k := make([]float64, 0, len(v.List))
			for _, it := range v.List {
				k = append(k, it.Num)
			}
			knots = k
			continue
		}
		// weight list of a rational spline (reals, same length as the control points)
		if allNum && len(v.List) == len(cps) && weights == nil && len(v.List) >= 2 {
			w := make([]float64, 0, len(v.List))
			for _, it := range v.List {
				w = append(w, it.Num)
			}
			weights = w
		}
	}

	if knots != nil {
		if mults != nil && len(mults) == len(knots) {
			c.Knots = expandKnots(mults, knots)
		} else if len(knots) == len(cps)+degree+1 {
			c.Knots = knots
		} else if len(knots) == len(cps)-degree+1 {
			// only unique knots given: expand them with uniform multiplicity 1 and pad degree+1 at the ends
			c.Knots = expandUniform(knots, degree, len(cps))
		}
	}
	if c.Knots == nil {
		c.Knots = uniformKnots(len(cps), degree)
	}
	if len(c.Knots) != len(cps)+degree+1 {
		// if it still does not line up, use uniform knots so evaluation works
		c.Knots = uniformKnots(len(cps), degree)
	}
	if weights != nil && len(weights) == len(cps) {
		c.W = weights
	}
	c.Closed = e.Bool(o + 3) // b_spline_curve(name, degree, cps, form, closed, self_intersect)
	return c
}

func sumInts(a []int) int {
	s := 0
	for _, v := range a {
		s += v
	}
	return s
}

func expandKnots(mults []int, knots []float64) []float64 {
	var out []float64
	for i, m := range mults {
		if i >= len(knots) {
			break
		}
		if m < 0 {
			m = 0
		}
		if m > 64 {
			m = 64
		}
		for j := 0; j < m; j++ {
			out = append(out, knots[i])
		}
	}
	return out
}

func expandUniform(knots []float64, degree, ncp int) []float64 {
	if len(knots) == 0 {
		return uniformKnots(ncp, degree)
	}
	out := make([]float64, 0, ncp+degree+1)
	for i := 0; i <= degree; i++ {
		out = append(out, knots[0])
	}
	for i := 1; i < len(knots)-1; i++ {
		out = append(out, knots[i])
	}
	for i := 0; i <= degree; i++ {
		out = append(out, knots[len(knots)-1])
	}
	return out
}

func uniformKnots(ncp, degree int) []float64 {
	n := ncp - 1
	m := n + degree + 1
	out := make([]float64, m+1)
	for i := 0; i <= degree; i++ {
		out[i] = 0
	}
	inner := m - 2*degree
	for i := 1; i < inner; i++ {
		out[degree+i] = float64(i) / float64(inner)
	}
	for i := m - degree; i <= m; i++ {
		out[i] = 1
	}
	return out
}

// Surface interprets an entity as a parametric surface; the result is cached.
func (g *Geom) Surface(id int) Surface {
	if s, ok := g.surfaces[id]; ok {
		return s
	}
	if g.failed[id] {
		return nil
	}
	s := g.buildSurface(id)
	if s == nil {
		g.failed[id] = true
		if e := g.E(id); e != nil {
			g.Stats.UnknownSurfaces[e.Type]++
		}
		return nil
	}
	g.surfaces[id] = s
	return s
}

func (g *Geom) buildSurface(id int) Surface {
	e := g.E(id)
	if e == nil {
		return nil
	}
	// Complex instance: AP203 writes a surface in combined forms such as
	// `#1=(BOUNDED_SURFACE()B_SPLINE_SURFACE(...)B_SPLINE_SURFACE_WITH_KNOTS(...)
	//   RATIONAL_B_SPLINE_SURFACE(...))`.
	// Degree and control points, knot vector and weights are spread over different sub-entities,
	// so merge them before parsing; otherwise only the first sub-entity is read and the result
	// degrades to a plane fit.
	if e.Type == "(COMPLEX)" {
		subs := g.F.ComplexAll(id)
		if merged := mergeSplineSubs(subs, "SURFACE"); merged != nil {
			if s := g.surfaceFromEntity(merged); s != nil {
				return s
			}
		}
		for _, sub := range subs {
			if s := g.surfaceFromEntity(sub); s != nil {
				return s
			}
		}
		return nil
	}
	return g.surfaceFromEntity(e)
}

// surfaceFromEntity builds a surface by entity type (without the complex instance branch).
func (g *Geom) surfaceFromEntity(e *Entity) Surface {
	o := nameOff(e)
	switch e.Type {
	case "PLANE":
		pl, ok := g.Placement(e.Ref(o))
		if !ok {
			return nil
		}
		return &PlaneSurf{Pl: pl}

	case "CYLINDRICAL_SURFACE":
		pl, ok := g.Placement(e.Ref(o))
		if !ok {
			return nil
		}
		r := e.Num(o + 1)
		if r <= 0 {
			return nil
		}
		return &CylSurf{Pl: pl, Radius: r}

	case "CONICAL_SURFACE":
		pl, ok := g.Placement(e.Ref(o))
		if !ok {
			return nil
		}
		return &ConeSurf{Pl: pl, Radius: e.Num(o + 1), SemiAngle: e.Num(o + 2)}

	case "SPHERICAL_SURFACE":
		pl, ok := g.Placement(e.Ref(o))
		if !ok {
			return nil
		}
		r := e.Num(o + 1)
		if r <= 0 {
			return nil
		}
		return &SphereSurf{Pl: pl, Radius: r}

	case "TOROIDAL_SURFACE":
		pl, ok := g.Placement(e.Ref(o))
		if !ok {
			return nil
		}
		return &TorusSurf{Pl: pl, Major: e.Num(o + 1), Minor: e.Num(o + 2)}

	case "B_SPLINE_SURFACE", "B_SPLINE_SURFACE_WITH_KNOTS",
		"RATIONAL_B_SPLINE_SURFACE", "RATIONAL_B_SPLINE_SURFACE_WITH_KNOTS",
		"BEZIER_SURFACE", "UNIFORM_SURFACE", "QUASI_UNIFORM_SURFACE":
		return g.buildBSplineSurface(e, o)

	case "SURFACE_OF_LINEAR_EXTRUSION":
		c := g.Curve(e.Ref(o))
		if c == nil {
			return nil
		}
		d, ok := g.Vector(e.Ref(o + 1))
		if !ok {
			return nil
		}
		return &LinExtrusionSurf{C: c, Dir: d}

	case "SURFACE_OF_REVOLUTION":
		c := g.Curve(e.Ref(o))
		if c == nil {
			return nil
		}
		pl, ok := g.Placement(e.Ref(o + 1))
		if !ok {
			return nil
		}
		return &RevolutionSurf{C: c, Origin: pl.Origin, Axis: pl.Z}

	case "RECTANGULAR_TRIMMED_SURFACE", "CURVE_BOUNDED_SURFACE", "BOUNDED_SURFACE":
		return g.Surface(e.Ref(o))

	case "OFFSET_SURFACE":
		// offset surface: approximated by the base surface (no true offsetting, so geometry is still emitted)
		return g.Surface(e.Ref(o))
	}
	return nil
}

// buildBSplineSurface parses a bivariate B-spline, adapting the layout to the parameter count.
// A STEP b_spline_surface uses two separate attributes u_degree / v_degree (not a list), and
// name is omitted in complex instances as well, hence the offset o.
func (g *Geom) buildBSplineSurface(e *Entity, o int) Surface {
	du := int(e.Num(o))
	dv := int(e.Num(o + 1))
	cpRefs := e.RefsAt(o + 2)
	if len(cpRefs) == 0 || du < 1 || dv < 1 {
		return nil
	}
	nu := len(cpRefs)
	cp := make([][]Vec3, nu)
	for i, col := range cpRefs {
		row := make([]Vec3, 0, len(col))
		for _, r := range col {
			if p, ok := g.Point(r); ok {
				row = append(row, p)
			}
		}
		cp[i] = row
	}
	nv := len(cp[0])
	if nv < 2 || nu < 2 {
		return nil
	}
	for i := range cp {
		if len(cp[i]) != nv {
			return nil
		}
	}
	if du > nu-1 {
		du = nu - 1
	}
	if dv > nv-1 {
		dv = nv - 1
	}
	s := &BSplineSurf{DegU: du, DegV: dv, CP: cp}

	// parse umults/vmults/uknots/vknots: they usually appear consecutively
	var intLists [][]int
	var floatLists [][]float64
	var weights [][]float64
	for i := o + 3; i < len(e.Params); i++ {
		v := e.Params[i]
		if v.Kind != KindList || len(v.List) == 0 {
			continue
		}
		nested, allNum, allInt, hasRef := false, true, true, false
		for _, it := range v.List {
			switch it.Kind {
			case KindList:
				nested = true
				for _, q := range it.List {
					if q.Kind == KindNumber {
						if q.Num != math.Trunc(q.Num) {
							allInt = false
						}
					} else {
						allNum, allInt = false, false
					}
				}
			case KindNumber:
				if it.Num != math.Trunc(it.Num) {
					allInt = false
				}
			case KindRef:
				hasRef = true
			default:
				allNum, allInt = false, false
			}
		}
		if hasRef {
			continue
		}
		if nested {
			// two-dimensional real list: the weight matrix of a rational spline
			f := make([][]float64, 0, len(v.List))
			for _, outer := range v.List {
				if outer.Kind != KindList {
					continue
				}
				row := make([]float64, 0, len(outer.List))
				for _, q := range outer.List {
					if q.Kind == KindNumber {
						row = append(row, q.Num)
					}
				}
				f = append(f, row)
			}
			if len(f) == nu && weights == nil {
				weights = f
			}
			continue
		}
		if !allNum {
			continue
		}
		if allInt {
			m := make([]int, 0, len(v.List))
			for _, it := range v.List {
				m = append(m, int(it.Num+0.5))
			}
			intLists = append(intLists, m)
		} else {
			f := make([]float64, 0, len(v.List))
			for _, it := range v.List {
				f = append(f, it.Num)
			}
			floatLists = append(floatLists, f)
		}
	}

	// umults, vmults come first; uknots, vknots after them
	if len(intLists) >= 2 && len(floatLists) >= 2 {
		um, vm := intLists[0], intLists[1]
		uk, vk := floatLists[0], floatLists[1]
		if len(um) == len(uk) {
			s.KnotsU = expandKnots(um, uk)
		}
		if len(vm) == len(vk) {
			s.KnotsV = expandKnots(vm, vk)
		}
	}
	// fallback: use uniform knots when the lengths do not match
	if len(s.KnotsU) != nu+du+1 {
		if len(floatLists) >= 1 && len(floatLists[0]) == nu+du+1 {
			s.KnotsU = floatLists[0]
		} else {
			s.KnotsU = uniformKnots(nu, du)
		}
	}
	if len(s.KnotsV) != nv+dv+1 {
		if len(floatLists) >= 2 && len(floatLists[1]) == nv+dv+1 {
			s.KnotsV = floatLists[1]
		} else {
			s.KnotsV = uniformKnots(nv, dv)
		}
	}
	if weights != nil && len(weights) == nu {
		ok := true
		for _, row := range weights {
			if len(row) != nv {
				ok = false
				break
			}
		}
		if ok {
			s.W = weights
		}
	}
	s.ClosedU = e.Bool(o + 4)
	s.ClosedV = e.Bool(o + 5)
	s.Tol = splineProjTol(cp)
	return s
}

// splineProjTol gives the acceptable residual bound for inverse projection on this spline surface.
// An absolute threshold (such as 1e-6) marks a correct solution converged to 1e-5 as a failure on
// large models, so the bound is relaxed in proportion to the control point bounding box size,
// while keeping a lower bound to avoid degeneracy.
func splineProjTol(cp [][]Vec3) float64 {
	if len(cp) == 0 {
		return 1e-9
	}
	mn := Vec3{math.Inf(1), math.Inf(1), math.Inf(1)}
	mx := Vec3{math.Inf(-1), math.Inf(-1), math.Inf(-1)}
	for _, row := range cp {
		for _, q := range row {
			mn = mn.Min(q)
			mx = mx.Max(q)
		}
	}
	d := mx.Sub(mn).Len()
	t := d * 1e-6
	if t < 1e-9 {
		t = 1e-9
	}
	if t > 1e-3 {
		t = 1e-3
	}
	return t
}

// TrimmedCurve is a curve clipped to the parameter interval [T0, T1].
type TrimmedCurve struct {
	Base     Curve
	T0, T1   float64
	Reversed bool
}

func (c *TrimmedCurve) Point(t float64) Vec3 {
	t = clampF(t, c.T0, c.T1)
	if c.Reversed {
		return c.Base.Point(c.T1 - (t - c.T0))
	}
	return c.Base.Point(t)
}

func (c *TrimmedCurve) Range() (float64, float64) { return c.T0, c.T1 }

func (c *TrimmedCurve) Periodic() bool { return false }

func (c *TrimmedCurve) ClosestParam(p Vec3, guess float64) (float64, bool) {
	t, ok := c.Base.ClosestParam(p, guess)
	if !ok {
		return c.T0, false
	}
	return clampF(t, c.T0, c.T1), true
}
