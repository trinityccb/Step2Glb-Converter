module stp2glb-lite

go 1.23.4
