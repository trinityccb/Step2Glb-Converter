#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Aggregate a batch regression straight from the output directory of e2e.sh, producing
every number needed by README section 2.

Usage:
    python tools/e2e-pairs.py <e2e output dir>

Reads from that directory:
    _result.tsv   columns: index TAB status TAB milliseconds TAB STP bytes TAB GLB bytes
                      TAB total faces TAB ok TAB failed TAB degraded TAB triangles TAB volume ratio%
    _detail.tsv   columns: file name TAB reason TAB error       (aligned row by row with _result.tsv)

More reliable than parsing the console log (the log has no source file sizes, so the real
overall volume ratio cannot be computed).
"""
import os
import sys


def read_tsv(path):
    rows = []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.rstrip("\n")
            if line:
                rows.append(line.split("\t"))
    return rows


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    d = sys.argv[1]
    rp = os.path.join(d, "_result.tsv")
    dp = os.path.join(d, "_detail.tsv")
    if not os.path.exists(rp):
        print("not found", rp)
        return 1
    res = read_tsv(rp)
    det = read_tsv(dp) if os.path.exists(dp) else []

    ok = fail = 0
    faces = ffail = fdeg = tris = 0
    ts = tg = 0
    slow = []
    rows = []
    for r in res:
        if len(r) < 11:
            continue
        name = det[len(rows)][0] if len(det) > len(rows) else ("#%s" % r[0])
        ms = int(r[2])
        s = int(r[3])
        g = int(r[4])
        face, fok, fbad, fdg = int(r[5]), int(r[6]), int(r[7]), int(r[8])
        tri = int(r[9])
        pct = float(r[10])
        if r[1] == "OK":
            ok += 1
        else:
            fail += 1
        faces += face
        ffail += fbad
        fdeg += fdg
        tris += tri
        ts += s
        tg += g
        slow.append((ms, name, tri))
        rows.append((pct, name, s, g, ms))

    n = len(rows)
    print("=" * 78)
    print("ok / failed          : %d / %d" % (ok, fail))
    print("face instances/failed/degraded : %d / %d / %d  (degraded rate %.2f%%)"
          % (faces, ffail, fdeg, 100.0 * fdeg / faces if faces else 0))
    print("triangles total      : %d" % tris)
    print("source total         : %.1f MB" % (ts / 1048576))
    print("GLB total            : %.1f MB" % (tg / 1048576))
    print("overall volume ratio : %.1f%%" % (100.0 * tg / ts if ts else 0))
    print("mean volume ratio    : %.1f%%" % (sum(r[0] for r in rows) / n))
    print("min / max            : %.1f%% / %.1f%%" % (min(r[0] for r in rows), max(r[0] for r in rows)))
    over = [r for r in rows if r[0] >= 100]
    print("above source size    : %d" % len(over))
    for pct, name, s, g, _ms in sorted(over, key=lambda x: -x[0])[:10]:
        print("   %6.1f%%  %.1f MB -> %.1f MB  %s" % (pct, s / 1048576, g / 1048576, name))
    print("-" * 78)
    slow.sort(reverse=True)
    print("5 slowest:")
    for ms, name, tri in slow[:5]:
        print("   %7d ms  tri %-8d %s" % (ms, tri, name))
    print("5 largest source files:")
    for pct, name, s, g, ms in sorted(rows, key=lambda x: -x[2])[:5]:
        print("   %6.1f MB -> %6.1f MB  (%5.1f%%)  %6d ms  %s"
              % (s / 1048576, g / 1048576, pct, ms, name))
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
