#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pin down the disagreement between glb-view and glb-dump on node transforms: compute the
accumulated matrix and bounding box for the same node with each of the two implementations."""
import json
import struct
import sys

path = sys.argv[1]

with open(path, "rb") as f:
    data = f.read()
off = 12
js = None
blob = b""
while off < len(data):
    clen, ctype = struct.unpack_from("<II", data, off)
    ch = data[off + 8:off + 8 + clen]
    if ctype == 0x4E4F534A:
        js = json.loads(ch.decode("utf-8"))
    else:
        blob = ch
    off += 8 + clen

nodes = js["nodes"]


# ---------- Implementation A: glb-dump (column-major array, row-major style multiply) ----------
def node_mat_col(nd):
    if "matrix" in nd:
        return list(nd["matrix"])
    t = nd.get("translation", [0, 0, 0])
    x, y, z, w = nd.get("rotation", [0, 0, 0, 1])
    s = nd.get("scale", [1, 1, 1])
    rm = [
        1 - 2 * (y * y + z * z), 2 * (x * y + z * w), 2 * (x * z - y * w), 0,
        2 * (x * y - z * w), 1 - 2 * (x * x + z * z), 2 * (y * z + x * w), 0,
        2 * (x * z + y * w), 2 * (y * z - x * w), 1 - 2 * (x * x + y * y), 0,
        0, 0, 0, 1,
    ]
    for col in range(3):
        for row in range(3):
            rm[col * 4 + row] *= s[col]
    rm[12], rm[13], rm[14] = t[0], t[1], t[2]
    return rm


def mul_col(a, b):
    r = [0.0] * 16
    for i in range(4):
        for j in range(4):
            r[i * 4 + j] = sum(a[i * 4 + k] * b[k * 4 + j] for k in range(4))
    return r


def apply_col(m, x, y, z):
    return (m[0] * x + m[4] * y + m[8] * z + m[12],
            m[1] * x + m[5] * y + m[9] * z + m[13],
            m[2] * x + m[6] * y + m[10] * z + m[14])


# ---------- Implementation B: glb-view (row-major) ----------
def node_mat_row(nd):
    if "matrix" in nd:
        c = nd["matrix"]
        return [c[0], c[4], c[8], c[12], c[1], c[5], c[9], c[13],
                c[2], c[6], c[10], c[14], c[3], c[7], c[11], c[15]]
    t = nd.get("translation", [0, 0, 0])
    x, y, z, w = nd.get("rotation", [0, 0, 0, 1])
    s = nd.get("scale", [1, 1, 1])
    rm = [
        1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w), 0,
        2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w), 0,
        2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y), 0,
        0, 0, 0, 1,
    ]
    for row in range(3):
        for col in range(3):
            rm[row * 4 + col] *= s[col]
    rm[3], rm[7], rm[11] = t[0], t[1], t[2]
    return rm


def mul_row(a, b):
    r = [0.0] * 16
    for i in range(4):
        for j in range(4):
            r[i * 4 + j] = sum(a[i * 4 + k] * b[k * 4 + j] for k in range(4))
    return r


def apply_row(m, x, y, z):
    return (m[0] * x + m[1] * y + m[2] * z + m[3],
            m[4] * x + m[5] * y + m[6] * z + m[7],
            m[8] * x + m[9] * y + m[10] * z + m[11])


I4 = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]

print("per-node accumulated matrix comparison (col=glb-dump, row=glb-view, colT=transposed col)")
scene = js["scenes"][js.get("scene", 0)]
order = []


def walk(ni, mc, mr, depth):
    nd = nodes[ni]
    mc2 = mul_col(mc, node_mat_col(nd))
    mr2 = mul_row(mr, node_mat_row(nd))
    if "mesh" in nd:
        order.append((nd.get("name", "?"), mc2, mr2, depth))
    for c in nd.get("children", []):
        walk(c, mc2, mr2, depth + 1)


for ni in scene["nodes"]:
    walk(ni, I4, I4, 0)

print("%d nodes with a mesh in total" % len(order))
for name, mc, mr, d in order[:5]:
    # Transpose the col version into row-major, then compare
    mct = [mc[0], mc[4], mc[8], mc[12], mc[1], mc[5], mc[9], mc[13],
           mc[2], mc[6], mc[10], mc[14], mc[3], mc[7], mc[11], mc[15]]
    same = all(abs(mct[i] - mr[i]) < 1e-9 for i in range(16))
    print("  depth=%d %-28s row-major equivalent=%s" % (d, name[:28], same))
    if not same:
        print("     col^T =", ["%.4f" % v for v in mct])
        print("     row   =", ["%.4f" % v for v in mr])


def bbox_apply(apply_fn, mat_getter):
    accs = js["accessors"]
    bvs = js["bufferViews"]
    mn = [1e30] * 3
    mx = [-1e30] * 3
    for name, mc, mr, d in order:
        m = mc if mat_getter == "col" else mr
        me = None
        for nd in nodes:
            if nd.get("name") == name and "mesh" in nd:
                me = js["meshes"][nd["mesh"]]
                break
        if me is None:
            continue
        for pr in me["primitives"]:
            a = accs[pr["attributes"]["POSITION"]]
            bv = bvs[a["bufferView"]]
            st = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
            for i in range(a["count"]):
                o = st + i * 12
                x, y, z = struct.unpack_from("<fff", blob, o)
                p = apply_fn(m, x, y, z)
                for k in range(3):
                    mn[k] = min(mn[k], p[k])
                    mx[k] = max(mx[k], p[k])
    return mn, mx


for tag, fn, which in (("col", apply_col, "col"), ("row", apply_row, "row")):
    mn, mx = bbox_apply(fn, which)
    sz = sorted(mx[k] - mn[k] for k in range(3))
    print("[%s] min=(%.4f,%.4f,%.4f) max=(%.4f,%.4f,%.4f) size (sorted)=%.4f x %.4f x %.4f"
          % (tag, mn[0], mn[1], mn[2], mx[0], mx[1], mx[2], sz[0], sz[1], sz[2]))
