#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Compose several PNGs side by side into one comparison image, with text labels
(standard library only).

Only 8bit/RGB/non-interlaced PNGs are supported (the output format of glb-view.py), which
is enough and needs zero dependencies.

Usage:
  python png-side.py out.png --gap 24 --pad 16 \
      "before fix|a.png" "after fix|b.png"
"""
import struct
import sys
import zlib

# 5x7 bitmap font, covering the characters needed by comparison-image labels
FONT = {
    ' ': ["00000"] * 7,
    '(': ["00110", "01100", "01000", "01000", "01000", "01100", "00110"],
    ')': ["01100", "00110", "00010", "00010", "00010", "00110", "01100"],
    '-': ["00000", "00000", "00000", "11111", "00000", "00000", "00000"],
    '0': ["01110", "10001", "10011", "10101", "11001", "10001", "01110"],
    '1': ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
    '2': ["01110", "10001", "00001", "00110", "01000", "10000", "11111"],
    '3': ["11111", "00010", "00100", "00010", "00001", "10001", "01110"],
    '4': ["00010", "00110", "01010", "10010", "11111", "00010", "00010"],
    '5': ["11111", "10000", "11110", "00001", "00001", "10001", "01110"],
    '6': ["00110", "01000", "10000", "11110", "10001", "10001", "01110"],
    '7': ["11111", "00001", "00010", "00100", "01000", "01000", "01000"],
    '8': ["01110", "10001", "10001", "01110", "10001", "10001", "01110"],
    '9': ["01110", "10001", "10001", "01111", "00001", "00010", "01100"],
    'A': ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
    'B': ["11110", "10001", "10001", "11110", "10001", "10001", "11110"],
    'C': ["01110", "10001", "10000", "10000", "10000", "10001", "01110"],
    'D': ["11110", "10001", "10001", "10001", "10001", "10001", "11110"],
    'E': ["11111", "10000", "10000", "11110", "10000", "10000", "11111"],
    'F': ["11111", "10000", "10000", "11110", "10000", "10000", "10000"],
    'G': ["01110", "10001", "10000", "10111", "10001", "10001", "01111"],
    'H': ["10001", "10001", "10001", "11111", "10001", "10001", "10001"],
    'I': ["01110", "00100", "00100", "00100", "00100", "00100", "01110"],
    'J': ["00111", "00010", "00010", "00010", "00010", "10010", "01100"],
    'K': ["10001", "10010", "10100", "11000", "10100", "10010", "10001"],
    'L': ["10000", "10000", "10000", "10000", "10000", "10000", "11111"],
    'M': ["10001", "11011", "10101", "10101", "10001", "10001", "10001"],
    'N': ["10001", "11001", "10101", "10011", "10001", "10001", "10001"],
    'O': ["01110", "10001", "10001", "10001", "10001", "10001", "01110"],
    'P': ["11110", "10001", "10001", "11110", "10000", "10000", "10000"],
    'Q': ["01110", "10001", "10001", "10001", "10101", "10010", "01101"],
    'R': ["11110", "10001", "10001", "11110", "10100", "10010", "10001"],
    'S': ["01111", "10000", "10000", "01110", "00001", "00001", "11110"],
    'T': ["11111", "00100", "00100", "00100", "00100", "00100", "00100"],
    'U': ["10001", "10001", "10001", "10001", "10001", "10001", "01110"],
    'V': ["10001", "10001", "10001", "10001", "10001", "01010", "00100"],
    'W': ["10001", "10001", "10001", "10101", "10101", "11011", "10001"],
    'X': ["10001", "10001", "01010", "00100", "01010", "10001", "10001"],
    'Y': ["10001", "10001", "01010", "00100", "00100", "00100", "00100"],
    'Z': ["11111", "00001", "00010", "00100", "01000", "10000", "11111"],
}


def read_png(path):
    data = open(path, 'rb').read()
    assert data[:8] == b"\x89PNG\r\n\x1a\n", "not a PNG: " + path
    off, W = 8, 0
    idat, H, depth, ctype = b"", 0, 0, 0
    while off < len(data):
        ln = struct.unpack_from(">I", data, off)[0]
        tag = data[off + 4:off + 8]
        payload = data[off + 8:off + 8 + ln]
        if tag == b"IHDR":
            W, H, depth, ctype = struct.unpack_from(">IIBB", payload, 0)
            # Support 8bit RGB(2) and 8bit RGBA(6); RGBA is read and the alpha dropped.
            # The output of png-zoom.py is RGBA, and the compositor must accept it directly.
            assert depth == 8 and ctype in (2, 6), "only 8bit RGB/RGBA is supported"
        elif tag == b"IDAT":
            idat += payload
        off += 12 + ln
    raw = zlib.decompress(idat)
    nch = 3 if ctype == 2 else 4
    stride = W * nch
    out = bytearray(W * H * 3)
    prev = bytearray(stride)
    for y in range(H):
        f = raw[y * (stride + 1)]
        line = bytearray(raw[y * (stride + 1) + 1:(y + 1) * (stride + 1)])
        if f == 1:
            for i in range(nch, stride):
                line[i] = (line[i] + line[i - nch]) & 0xFF
        elif f == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 0xFF
        elif f == 3:
            for i in range(stride):
                a = line[i - nch] if i >= nch else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 0xFF
        elif f == 4:
            for i in range(stride):
                a = line[i - nch] if i >= nch else 0
                b = prev[i]
                c = prev[i - nch] if i >= nch else 0
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 0xFF
        if nch == 3:
            out[y * W * 3:(y + 1) * W * 3] = line
        else:
            # Drop the alpha channel (bytearray slices are copies, so the whole row must be written back to out)
            row = bytearray(W * 3)
            for x in range(W):
                row[x * 3:x * 3 + 3] = line[x * 4:x * 4 + 3]
            out[y * W * 3:(y + 1) * W * 3] = row
        prev = line
    return W, H, out


def write_png(path, W, H, img):
    raw = b"".join(b"\x00" + bytes(img[y * W * 3:(y + 1) * W * 3]) for y in range(H))
    png = b"\x89PNG\r\n\x1a\n"
    for tag, payload in ((b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 2, 0, 0, 0)),
                         (b"IDAT", zlib.compress(raw, 6)),
                         (b"IEND", b"")):
        png += struct.pack(">I", len(payload)) + tag + payload + \
            struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF)
    open(path, 'wb').write(png)


def draw_text(img, W, H, x, y, text, scale, rgb):
    for ch in text.upper():
        glyph = FONT.get(ch)
        if glyph is None:
            x += 6 * scale
            continue
        for ry, row in enumerate(glyph):
            for rx, bit in enumerate(row):
                if bit != '1':
                    continue
                for dy in range(scale):
                    for dx in range(scale):
                        px, py = x + rx * scale + dx, y + ry * scale + dy
                        if 0 <= px < W and 0 <= py < H:
                            o = (py * W + px) * 3
                            img[o:o + 3] = bytes(rgb)
        x += 6 * scale
    return x


def main():
    out = sys.argv[1]
    rest = sys.argv[2:]
    gap, pad, scale = 24, 16, 3
    if '--gap' in rest:
        i = rest.index('--gap'); gap = int(rest[i + 1]); del rest[i:i + 2]
    if '--pad' in rest:
        i = rest.index('--pad'); pad = int(rest[i + 1]); del rest[i:i + 2]
    if '--scale' in rest:
        i = rest.index('--scale'); scale = int(rest[i + 1]); del rest[i:i + 2]
    items = []
    for a in rest:
        label, path = a.split('|', 1)
        items.append((label, path))

    panels = [read_png(p) for _, p in items]
    W = sum(p[0] for p in panels) + gap * (len(panels) - 1) + pad * 2
    labelH = 7 * scale + 12
    H = max(p[1] for p in panels) + labelH + pad * 2
    img = bytearray(b"\x20\x20\x20" * (W * H))

    x = pad
    for (label, _), (pw, ph, px) in zip(items, panels):
        draw_text(img, W, H, x, pad, label, scale, (0xE8, 0xE8, 0xE8))
        for y in range(ph):
            o = ((y + labelH + pad) * W + x) * 3
            img[o:o + pw * 3] = px[y * pw * 3:(y + 1) * pw * 3]
        x += pw + gap
    write_png(out, W, H, img)
    print("composed %s (%d x %d)" % (out, W, H))


main()
