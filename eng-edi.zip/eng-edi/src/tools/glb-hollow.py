# -*- coding: utf-8 -*-
"""Audit a GLB mesh: find the two root causes of "solid turned hollow".

    python tools/glb-hollow.py a.glb [--tol=0.01] [--top=15] [--all]

For the triangle primitives (mode=4) of every mesh:
  1. Normalize vertices with **tolerance welding** (spatial hash, 0.01 mm by default --
     float32 plus two faces each evaluating the same curve can put the same point 1e-5
     apart, so a strict equality weld fails).
  2. Union-find links triangles into connected components. A solid part should normally
     be a closed shell with **positive signed volume and zero boundary edges**.
  3. Per component compute: triangle count / area / signed volume (divergence theorem) /
     edges used by only one triangle (= hole boundaries) / longest boundary edge.
  4. Raise flags:
       INVERTED  signed volume < 0 and the shell is closed -> winding flipped, invisible
                 with backface culling
       OPEN      boundary edges > 0                        -> shell not closed (faces missing)
"""
import json
import math
import struct
import sys


def load(path):
    d = open(path, 'rb').read()
    off, js, bn = 12, None, None
    while off < len(d):
        ln, ty = struct.unpack_from('<II', d, off)
        off += 8
        ch = d[off:off + ln]
        off += ln
        if ty == 0x4E4F534A:
            js = json.loads(ch.decode('utf-8'))
        elif ty == 0x004E4942:
            bn = ch
    return d, js, bn


def reader(js, bn):
    cache = {}

    def acc(i):
        if i in cache:
            return cache[i]
        a = js['accessors'][i]
        bv = js['bufferViews'][a['bufferView']]
        o = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        nc = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}[a['type']]
        cf = {5126: ('f', 4), 5125: ('I', 4), 5123: ('H', 2), 5121: ('B', 1)}[a['componentType']]
        v = struct.unpack_from('<' + str(a['count'] * nc) + cf[0], bn, o)
        out = [v[k * nc:(k + 1) * nc] for k in range(a['count'])]
        cache[i] = out
        return out

    return acc


def weld_vertices(pos, tol):
    """Tolerance welding. Returns (table of weld coordinates, map from original vertex to welded point)."""
    cell = max(tol, 1e-9)
    grid = {}
    remap = [0] * len(pos)
    weld = []
    tol2 = tol * tol
    for i, p in enumerate(pos):
        cx = int(math.floor(p[0] / cell))
        cy = int(math.floor(p[1] / cell))
        cz = int(math.floor(p[2] / cell))
        hit = -1
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    for j in grid.get((cx + dx, cy + dy, cz + dz), ()):
                        q = weld[j]
                        d2 = (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2
                        if d2 <= tol2:
                            hit = j
                            break
                    if hit >= 0:
                        break
                if hit >= 0:
                    break
            if hit >= 0:
                break
        if hit < 0:
            hit = len(weld)
            weld.append(p)
            grid.setdefault((cx, cy, cz), []).append(hit)
        remap[i] = hit
    return weld, remap


def audit_mesh(js, acc, mi, m, tol, minarea):
    out = dict(tri=0, area=0.0, vol=0.0, comps=[], open_edges=0, inv_area=0.0, open_area=0.0)
    for pi, pr in enumerate(m['primitives']):
        if pr.get('mode', 4) != 4:
            continue
        pos = acc(pr['attributes']['POSITION'])
        idx = [v[0] for v in acc(pr['indices'])]
        nt = len(idx) // 3
        weld, remap = weld_vertices(pos, tol)

        par = list(range(len(weld)))

        def find(x):
            while par[x] != x:
                par[x] = par[par[x]]
                x = par[x]
            return x

        def uni(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                par[rb] = ra

        tri = []
        for k in range(0, nt * 3, 3):
            a, b, c = remap[idx[k]], remap[idx[k + 1]], remap[idx[k + 2]]
            if a == b or b == c or a == c:
                continue
            tri.append((a, b, c))
            uni(a, b)
            uni(b, c)

        area = [0.0] * len(tri)
        vol = [0.0] * len(tri)
        for t, (a, b, c) in enumerate(tri):
            p, q, r = weld[a], weld[b], weld[c]
            u = (q[0] - p[0], q[1] - p[1], q[2] - p[2])
            w = (r[0] - p[0], r[1] - p[1], r[2] - p[2])
            cr = (u[1] * w[2] - u[2] * w[1],
                  u[2] * w[0] - u[0] * w[2],
                  u[0] * w[1] - u[1] * w[0])
            area[t] = 0.5 * math.sqrt(cr[0] ** 2 + cr[1] ** 2 + cr[2] ** 2)
            vol[t] = (p[0] * cr[0] + p[1] * cr[1] + p[2] * cr[2]) / 6.0

        ec = {}
        for (a, b, c) in tri:
            for e in ((a, b), (b, c), (c, a)):
                k = (e[0], e[1]) if e[0] < e[1] else (e[1], e[0])
                ec[k] = ec.get(k, 0) + 1

        comp = {}
        for t, (a, b, c) in enumerate(tri):
            r = find(a)
            g = comp.get(r)
            if g is None:
                g = comp[r] = dict(tri=0, area=0.0, vol=0.0, oe=0, maxedge=0.0)
            g['tri'] += 1
            g['area'] += area[t]
            g['vol'] += vol[t]
        for (a, b), n in ec.items():
            if n == 1:
                r = find(a)
                g = comp.get(r)
                if g is not None:
                    g['oe'] += 1
                    p, q = weld[a], weld[b]
                    d = math.sqrt((p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2)
                    if d > g['maxedge']:
                        g['maxedge'] = d

        out['tri'] += len(tri)
        for r, g in comp.items():
            out['area'] += g['area']
            out['vol'] += g['vol']
            out['open_edges'] += g['oe']
            if g['area'] < minarea:
                continue
            flag = ''
            if g['vol'] < 0:
                flag += 'INVERTED '
                out['inv_area'] += g['area']
            if g['oe']:
                flag += 'OPEN '
                out['open_area'] += g['area']
            out['comps'].append((g['area'], g['tri'], g['vol'], g['oe'], g['maxedge'], flag, r))
    return out


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    if not args:
        print(__doc__)
        return
    top, minarea, tol, verbose = 15, 1.0, 0.01, False
    for a in sys.argv[1:]:
        if a.startswith('--top='):
            top = int(a.split('=')[1])
        elif a.startswith('--minarea='):
            minarea = float(a.split('=')[1])
        elif a.startswith('--tol='):
            tol = float(a.split('=')[1])
        elif a == '--all':
            verbose = True

    path = args[0]
    d, js, bn = load(path)
    acc = reader(js, bn)
    used = sorted({n['mesh'] for n in js.get('nodes', []) if 'mesh' in n})
    print('file %s (%.1f MB)  meshes %d, referenced %d, weld tolerance %g mm'
          % (path, len(d) / 1048576.0, len(js.get('meshes', [])), len(used), tol))

    tot = dict(tri=0, area=0.0, vol=0.0, open_edges=0, inv_area=0.0, open_area=0.0)
    rows, allc = [], []
    for mi in used:
        t = audit_mesh(js, acc, mi, js['meshes'][mi], tol, minarea)
        for k in tot:
            tot[k] += t[k]
        nm = js['meshes'][mi].get('name', '') or js['meshes'][mi].get('extras', {}).get('name', '')
        rows.append((mi, nm, t))
        for c in t['comps']:
            allc.append((mi, nm) + c)
        if verbose:
            for c in t['comps']:
                print('    mesh%-5d %-28s tri=%-6d area=%-11.2f vol=%-13.2f oe=%-5d %s'
                      % (mi, nm[:28], c[1], c[0], c[2], c[3], c[5]))

    print('  triangles %d  total area %.2f  total signed volume %.2f  unmatched edges %d'
          % (tot['tri'], tot['area'], tot['vol'], tot['open_edges']))
    print('  inverted area %.2f (%.2f%%)   open area %.2f (%.2f%%)'
          % (tot['inv_area'], 100.0 * tot['inv_area'] / max(tot['area'], 1e-9),
             tot['open_area'], 100.0 * tot['open_area'] / max(tot['area'], 1e-9)))

    bad = [c for c in allc if c[7].strip()]
    if bad:
        print('\n  == top %d problem components ==' % top)
        for c in sorted(bad, key=lambda x: -x[2])[:top]:
            print('    mesh%-5d %-30s area=%-11.2f tri=%-6d vol=%-13.2f oe=%-5d maxedge=%-8.2f %s'
                  % (c[0], str(c[1])[:30], c[2], c[3], c[4], c[5], c[6], c[7]))

    print('\n  == top %d parts with the worst open area ==' % top)
    for mi, nm, t in sorted(rows, key=lambda x: -x[2]['open_area'])[:top]:
        if t['open_area'] <= 0:
            continue
        print('    mesh%-5d %-32s tri=%-7d area=%-11.2f open area=%-11.2f unmatched edges=%d'
              % (mi, str(nm)[:32], t['tri'], t['area'], t['open_area'], t['open_edges']))


if __name__ == '__main__':
    main()
