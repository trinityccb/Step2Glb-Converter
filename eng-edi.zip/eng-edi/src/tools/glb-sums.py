# -*- coding: utf-8 -*-
"""List the SHA-256 of the GLB JSON/BIN chunks plus material flags, for geometry A/B between versions."""
import hashlib
import json
import struct
import sys

for path in sys.argv[1:]:
    d = open(path, 'rb').read()
    off, js, bn = 12, None, None
    while off < len(d):
        ln, ty = struct.unpack_from('<II', d, off)
        off += 8
        ch = d[off:off + ln]
        off += ln
        if ty == 0x4E4F534A:
            js = json.loads(ch.decode('utf-8'))
        elif ty == 0x004E4942:
            bn = ch
    print('%s' % path)
    print('  bytes %d   BIN %d bytes  SHA-256 %s'
          % (len(d), len(bn or b''), hashlib.sha256(bn or b'').hexdigest()[:32]))
    for i, mt in enumerate(js.get('materials', [])):
        print('  material%d %-10s doubleSided=%s' % (i, mt.get('name', ''), mt.get('doubleSided', False)))
    prims = [p for m in js.get('meshes', []) for p in m['primitives']]
    tri = [p for p in prims if p.get('mode', 4) == 4]
    withmat = [p for p in tri if 'material' in p]
    print('  triangle primitives %d, with material %d, triangles %d'
          % (len(tri), len(withmat),
             sum(js['accessors'][p['indices']]['count'] // 3 for p in tri)))
