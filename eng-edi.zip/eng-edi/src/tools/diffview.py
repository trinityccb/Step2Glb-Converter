# -*- coding: utf-8 -*-
"""Render the differing triangles of two GLBs on their own -- see at a glance "what changed".

Left image: triangles that only appear in A (old version)
Right image: triangles that only appear in B (new version)
Optionally a flat outline of a full mesh is layered in the background, to make the
location easier to judge.

Usage:
  python diffview.py a.glb b.glb out.png [--size 620] [--view 0.55,-1,0.3] [--bg b.glb]
"""
import json
import math
import struct
import sys
import zlib

CT = {5121: ("B", 1), 5123: ("H", 2), 5125: ("I", 4), 5126: ("f", 4)}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}


def load(path):
    d = open(path, "rb").read()
    total = struct.unpack_from("<I", d, 8)[0]
    off, js, bin_ = 12, None, None
    while off < total:
        clen, ctype = struct.unpack_from("<II", d, off)
        chunk = d[off + 8: off + 8 + clen]
        if ctype == 0x4E4F534A:
            js = json.loads(chunk.decode("utf-8"))
        elif ctype == 0x004E4942:
            bin_ = chunk
        off += 8 + clen + ((4 - clen % 4) % 4 if clen % 4 else 0)
    return js, bin_


def acc(js, bin_, i):
    a = js["accessors"][i]
    fmt, sz = CT[a["componentType"]]
    n = NC[a["type"]]
    bv = js["bufferViews"][a["bufferView"]]
    base = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    stride = bv.get("byteStride") or n * sz
    return [struct.unpack_from("<" + fmt * n, bin_, base + k * stride) for k in range(a["count"])]


def mesh(path):
    js, bin_ = load(path)
    V, T = [], []
    for m in js["meshes"]:
        for p in m["primitives"]:
            v = acc(js, bin_, p["attributes"]["POSITION"])
            base = len(V)
            V.extend(v)
            idx = [t[0] for t in acc(js, bin_, p["indices"])]
            for k in range(0, len(idx), 3):
                T.append((base + idx[k], base + idx[k + 1], base + idx[k + 2]))
    return V, T


def key(V, t, q):
    pts = []
    for vi in t:
        x, y, z = V[vi]
        pts.append((round(x * q), round(y * q), round(z * q)))
    pts.sort()
    return tuple(pts)


def main():
    args = sys.argv[1:]
    size = 620
    if "--size" in args:
        i = args.index("--size")
        size = int(args[i + 1])
        del args[i:i + 2]
    view = (0.55, -1.0, 0.3)
    if "--view" in args:
        i = args.index("--view")
        view = tuple(float(x) for x in args[i + 1].split(","))
        del args[i:i + 2]
    bgpath = None
    if "--bg" in args:
        i = args.index("--bg")
        bgpath = args[i + 1]
        del args[i:i + 2]
    A, B, out = args[0], args[1], args[2]

    box = None
    if "--box" in args:
        i = args.index("--box")
        box = [float(x) for x in args[i + 1].split(",")]
        del args[i:i + 2]

    def crop(V, T):
        if not box:
            return T
        x0, y0, z0, x1, y1, z1 = box
        r = []
        for t in T:
            ok = True
            for vi in t:
                x, y, z = V[vi]
                if not (x0 <= x <= x1 and y0 <= y <= y1 and z0 <= z <= z1):
                    ok = False
                    break
            if ok:
                r.append(t)
        return r

    q = 1e4
    VA, TA = mesh(A)
    VB, TB = mesh(B)
    ka = {}
    for t in TA:
        ka.setdefault(key(VA, t, q), []).append(t)
    kb = {}
    for t in TB:
        kb.setdefault(key(VB, t, q), []).append(t)

    onlyA, onlyB = [], []
    for k, ts in ka.items():
        m = kb.get(k)
        n0 = len(ts)
        n1 = len(m) if m else 0
        for i in range(max(n0 - n1, 0)):
            onlyA.append(ts[i])
    for k, ts in kb.items():
        if k in ka:
            continue
        onlyB.extend(ts)
    print("only in A (old): %d triangles; only in B (new): %d" % (len(onlyA), len(onlyB)))

    bgV, bgT = ([], [])
    if bgpath:
        bgV, bgT = mesh(bgpath)

    if box:
        onlyVA = crop(VA, onlyA)
        onlyVB = crop(VB, onlyB)
        bgT = crop(bgV, bgT)
    else:
        onlyVA, onlyVB = onlyA, onlyB
    print("after cropping, A/B differences %d / %d triangles (background %d)" % (len(onlyVA), len(onlyVB), len(bgT)))

    allpts = []
    for V, T in ((VA, onlyVA), (VB, onlyVB)):
        for t in T:
            for vi in t:
                allpts.append(V[vi])
    if box:
        ctr = [(box[i] + box[i + 3]) / 2 for i in range(3)]
        ext = max(box[i + 3] - box[i] for i in range(3))
    else:
        ctr = [sum(p[i] for p in allpts) / len(allpts) for i in range(3)]
        ext = max(max(p[i] for p in allpts) - min(p[i] for p in allpts) for i in range(3))
    print("difference region center (%.1f, %.1f, %.1f)  scale %.1f" % (ctr[0], ctr[1], ctr[2], ext))

    dl = math.sqrt(sum(c * c for c in view)) or 1
    fw = tuple(c / dl for c in view)
    up = (0, 0, 1)
    if abs(fw[2]) > 0.95:
        up = (0, 1, 0)
    rx = (fw[1] * up[2] - fw[2] * up[1], fw[2] * up[0] - fw[0] * up[2], fw[0] * up[1] - fw[1] * up[0])
    rl = math.sqrt(sum(c * c for c in rx)) or 1
    rx = tuple(c / rl for c in rx)
    ry = (rx[1] * fw[2] - rx[2] * fw[1], rx[2] * fw[0] - rx[0] * fw[2], rx[0] * fw[1] - rx[1] * fw[0])

    W, H = size * 2, size
    img = bytearray(b"\x20" * (W * H * 3))
    scale = ext * 1.5
    focal = size / (2 * math.tan(math.radians(22.5)))
    cam_dist = scale * 1.6
    light = (0.4, -0.5, 0.76)

    def panel(ox, V, T, col):
        zbuf = [math.inf] * (size * size)
        for a, b, c in T:
            prj = []
            for vi in (a, b, c):
                p = V[vi]
                x, y, z = p[0] - ctr[0], p[1] - ctr[1], p[2] - ctr[2]
                cx = x * rx[0] + y * rx[1] + z * rx[2]
                cy = x * ry[0] + y * ry[1] + z * ry[2]
                cz = x * fw[0] + y * fw[1] + z * fw[2] + cam_dist
                if cz <= 1e-6:
                    prj = None
                    break
                prj.append((cx / cz * focal + size / 2, cy / cz * focal + size / 2, cz))
            if not prj:
                continue
            pa, pb, pc = prj
            minx = max(int(min(pa[0], pb[0], pc[0])), 0)
            maxx = min(int(max(pa[0], pb[0], pc[0])) + 1, size - 1)
            miny = max(int(min(pa[1], pb[1], pc[1])), 0)
            maxy = min(int(max(pa[1], pb[1], pc[1])) + 1, size - 1)
            d = (pb[0] - pa[0]) * (pc[1] - pa[1]) - (pb[1] - pa[1]) * (pc[0] - pa[0])
            if d == 0:
                continue
            for py in range(miny, maxy + 1):
                for px in range(minx, maxx + 1):
                    w0 = (pb[0] - pa[0]) * (py + .5 - pa[1]) - (pb[1] - pa[1]) * (px + .5 - pa[0])
                    w1 = (pc[0] - pb[0]) * (py + .5 - pb[1]) - (pc[1] - pb[1]) * (px + .5 - pb[0])
                    w2 = (pa[0] - pc[0]) * (py + .5 - pc[1]) - (pa[1] - pc[1]) * (px + .5 - pc[0])
                    if not (w0 <= 0 and w1 <= 0 and w2 <= 0):
                        continue
                    z = pa[2] * (w1 / d) + pb[2] * (w2 / d) + pc[2] * (w0 / d)
                    o = py * size + px
                    if z < zbuf[o]:
                        zbuf[o] = z
                        o3 = (py * W + ox + px) * 3
                        img[o3:o3 + 3] = bytes(col)

    # Background: light-grey outline of the full mesh (flat fill, no lighting, outline only)
    if bgT:
        panel(0, bgV, bgT, (74, 74, 78))
        panel(size, bgV, bgT, (74, 74, 78))
    panel(0, VA, onlyVA, (235, 80, 60))
    panel(size, VB, onlyVB, (70, 200, 120))

    raw = b"".join(b"\x00" + bytes(img[y * W * 3:(y + 1) * W * 3]) for y in range(H))
    png = b"\x89PNG\r\n\x1a\n"
    for tag, payload in ((b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 2, 0, 0, 0)),
                         (b"IDAT", zlib.compress(raw, 6)), (b"IEND", b"")):
        png += struct.pack(">I", len(payload)) + tag + payload + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF)
    open(out, "wb").write(png)
    print("wrote image %s (left = only in old / right = only in new)" % out)


main()
