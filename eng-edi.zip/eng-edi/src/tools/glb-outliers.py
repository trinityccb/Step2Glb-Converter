"""Find geometry in a GLB that "escaped the expected range" or "is spatially isolated" --
a locator for the fragments produced by a conversion.

Two ways to use it:

1) When the bounding box the model should have is known, see directly what ran outside
   (the most sensitive check):
     python glb-outliers.py x.glb --outside x0,y0,z0,x1,y1,z1
   It lists the number of triangles whose bounding box lies completely outside the frame,
   plus their own bounding box and area. The test is "even the largest extent is below
   x0", i.e. fully-outside, so triangles straddling the boundary are not counted.

2) When the expected extent is unknown, look for spatially isolated clusters:
     python glb-outliers.py x.glb [--radius 250] [--cell 10]
   Mark occupancy on a coarse grid (edge length = radius); cells whose 26 neighbours are
   all empty count as isolated regions. Each isolated region is then refined with a fine
   grid (cell) listing sub-cell triangle counts and exact bounding boxes.
   radius must exceed "the gap between the fragment and the main body" to hit; start at
   250 and lower it if nothing is found.

Typical symptoms:
  - A string of small debris next to an assembly -> some part instance never received
    its assembly transform and the geometry fell back to its original coordinates
    (obvious in --outside mode).
  - A large disc appearing out of nowhere -> a periodic curve edge was complemented
    from min/max.
"""
import json
import struct
import sys

CT = {5121: 'B', 5123: 'H', 5125: 'I', 5126: 'f'}
NC = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}


def load(path):
    d = open(path, 'rb').read()
    if d[:4] != b'glTF':
        raise SystemExit('%s is not a GLB file' % path)
    off, js, bin_ = 12, None, None
    while off < len(d):
        ln, ty = struct.unpack_from('<II', d, off)
        off += 8
        c = d[off:off + ln]
        off += ln
        if ty == 0x4E4F534A:
            js = json.loads(c.decode('utf-8'))
        elif ty == 0x004E4942:
            bin_ = c
    return js, bin_


def read(js, bin_, ai):
    acc = js['accessors'][ai]
    bv = js['bufferViews'][acc['bufferView']]
    ncomp = NC[acc['type']]
    fmt = CT[acc['componentType']]
    size = struct.calcsize(fmt) * ncomp
    stride = bv.get('byteStride', size)
    start = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
    out = []
    for k in range(acc['count']):
        v = struct.unpack_from('<' + fmt * ncomp, bin_, start + k * stride)
        out.append(v if ncomp > 1 else v[0])
    return out


def iter_tris(js, bin_):
    """Yield (min corner, max corner, area) per triangle."""
    for m in js['meshes']:
        for pr in m['primitives']:
            pos = read(js, bin_, pr['attributes']['POSITION'])
            idx = read(js, bin_, pr['indices'])
            for i in range(0, len(idx), 3):
                a, b, c = pos[idx[i]], pos[idx[i + 1]], pos[idx[i + 2]]
                mn = [min(a[k], b[k], c[k]) for k in range(3)]
                mx = [max(a[k], b[k], c[k]) for k in range(3)]
                ux, uy, uz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
                vx, vy, vz = c[0] - a[0], c[1] - a[1], c[2] - a[2]
                cx = uy * vz - uz * vy
                cy = uz * vx - ux * vz
                cz = ux * vy - uy * vx
                yield mn, mx, 0.5 * (cx * cx + cy * cy + cz * cz) ** 0.5


def mode_outside(tris, box):
    x0, y0, z0, x1, y1, z1 = box
    n = 0
    area = 0.0
    mn = [1e30] * 3
    mx = [-1e30] * 3
    tot = 0
    for tmn, tmx, a in tris:
        tot += 1
        # Completely outside the frame: one axis fully out of range is enough
        if not (tmx[0] < x0 or tmn[0] > x1 or
                tmx[1] < y0 or tmn[1] > y1 or
                tmx[2] < z0 or tmn[2] > z1):
            continue
        n += 1
        area += a
        for k in range(3):
            if tmn[k] < mn[k]:
                mn[k] = tmn[k]
            if tmx[k] > mx[k]:
                mx[k] = tmx[k]
    print('triangles total %d' % tot)
    print('triangles outside the frame %d   area total %.3f mm2' % (n, area))
    if n:
        print('outside range (%.2f,%.2f,%.2f) ~ (%.2f,%.2f,%.2f)  size (%.2f,%.2f,%.2f)'
              % (*mn, *mx, mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]))


def mode_isolated(tris, rad, cell, topn):
    bucket = {}
    lo = [1e30] * 3
    hi = [-1e30] * 3
    n = 0
    for tmn, tmx, a in tris:
        n += 1
        cen = [(tmn[k] + tmx[k]) / 2 for k in range(3)]
        for k in range(3):
            if tmn[k] < lo[k]:
                lo[k] = tmn[k]
            if tmx[k] > hi[k]:
                hi[k] = tmx[k]
        bucket.setdefault((int(cen[0] // rad), int(cen[1] // rad), int(cen[2] // rad)),
                          []).append((tmn, tmx, a))
    print('triangles total %d' % n)
    print('bounding box (%.2f,%.2f,%.2f) ~ (%.2f,%.2f,%.2f)' % (*lo, *hi))
    coarse = set(bucket)
    iso = []
    for k in coarse:
        x, y, z = k
        nb = 0
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    if (dx or dy or dz) and (x + dx, y + dy, z + dz) in coarse:
                        nb += 1
                        break
                if nb:
                    break
            if nb:
                break
        if nb == 0:
            iso.append(k)
    print('coarse cells %d (edge %g mm), isolated cells %d' % (len(coarse), rad, len(iso)))
    if not iso:
        print('no isolated regions. Try one step smaller --radius.')
        return
    for k in sorted(iso, key=lambda k: (k[0], k[1], k[2]))[:topn]:
        sub = bucket[k]
        mn = [min(t[0][a] for t in sub) for a in range(3)]
        mx = [max(t[1][a] for t in sub) for a in range(3)]
        print('  isolated cell(%d,%d,%d) tris %d area %.3f  bbox (%.2f,%.2f,%.2f)~(%.2f,%.2f,%.2f)'
              % (k[0], k[1], k[2], len(sub), sum(t[2] for t in sub), *mn, *mx))


def main():
    args = sys.argv[1:]
    if not args:
        raise SystemExit(__doc__)
    src = args[0]
    rest = args[1:]
    box = None
    rad, cell, topn = 250.0, 10.0, 8
    i = 0
    while i < len(rest):
        a = rest[i]
        if a == '--outside':
            box = [float(v) for v in rest[i + 1].split(',')]
            i += 2
            continue
        if a == '--radius':
            rad = float(rest[i + 1])
            i += 2
            continue
        if a == '--cell':
            cell = float(rest[i + 1])
            i += 2
            continue
        if a == '--top':
            topn = int(rest[i + 1])
            i += 2
            continue
        raise SystemExit('unknown argument %s' % a)
    js, bin_ = load(src)
    print(src)
    if box:
        mode_outside(iter_tris(js, bin_), box)
    else:
        mode_isolated(iter_tris(js, bin_), rad, cell, topn)


if __name__ == '__main__':
    main()
