/* Validate the generated GLB with the official Khronos glTF-Validator */
const fs = require('fs');
const path = require('path');
const validator = require('gltf-validator');

(async () => {
  // Arguments may be files or directories (a directory validates every .glb inside it,
  // which keeps non-ASCII/spaced file names from being split apart by the shell)
  const targets = [];
  for (const a of process.argv.slice(2)) {
    let st = null;
    try {
      st = fs.statSync(a);
    } catch (_) {
      console.log(`skipped (does not exist): ${a}`);
      continue;
    }
    if (st.isDirectory()) {
      // The e2e output has a "top directory / one subdirectory per file" layout, so it must recurse
      const walk = (d) => {
        for (const e of fs.readdirSync(d, { withFileTypes: true })) {
          const p = path.join(d, e.name);
          if (e.isDirectory()) walk(p);
          else if (/\.glb$/i.test(e.name)) targets.push(p);
        }
      };
      walk(a);
    } else {
      targets.push(a);
    }
  }

  let bad = 0;
  for (const f of targets) {
    const data = new Uint8Array(fs.readFileSync(f));
    const r = await validator.validateBytes(data, { uri: path.basename(f), maxIssues: 50 });
    const { numErrors, numWarnings, numInfos, numHints } = r.issues;
    const ok = numErrors === 0 && numWarnings === 0;
    if (!ok) bad += 1;
    console.log(
      `${ok ? 'PASS' : 'FAIL'}  ${path.basename(f).padEnd(24)} errors=${numErrors} warnings=${numWarnings} infos=${numInfos} hints=${numHints}`,
    );
    for (const m of r.issues.messages) {
      if (m.severity <= 1) console.log(`        [${m.severity}] ${m.code} ${m.pointer || ''} ${m.message}`);
    }
  }
  console.log(`\nvalidated ${targets.length} files -- ${bad === 0 ? 'all passed Khronos glTF-Validator (0 error / 0 warning)' : bad + ' have problems'}`);
  process.exit(bad === 0 ? 0 : 1);
})();
