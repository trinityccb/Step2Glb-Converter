#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Extract the triangles in a GLB whose "area exceeds a threshold" and draw them as
three-view ASCII maps.

Purpose: locate local distortions such as "unidentified discs / giant triangles /
membranes". After filtering by area threshold, the triangles are raster-projected onto the
XY / YZ / XZ planes, so the spatial shape of the distortion is obvious at a glance (a disc
shows up as a regular circular/elliptical outline).

Usage:
  python glb-bigmap.py x.glb              # default threshold = 0.02% of the total area
  python glb-bigmap.py x.glb 2000         # absolute area threshold
  python glb-bigmap.py x.glb 2000 90       # map 90 columns wide
"""
import json
import math
import struct
import sys

COMP = {5120: ("b", 1), 5121: ("B", 1), 5122: ("h", 2),
        5123: ("H", 2), 5125: ("I", 4), 5126: ("f", 4)}
NCOMP = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


def read_glb(path):
    with open(path, "rb") as f:
        data = f.read()
    magic, _ver, total = struct.unpack_from("<III", data, 0)
    assert magic == 0x46546C67, "not a GLB: " + path
    off, js, blob = 12, None, b""
    while off < total:
        clen, ctype = struct.unpack_from("<II", data, off)
        chunk = data[off + 8: off + 8 + clen]
        if ctype == 0x4E4F534A:
            js = json.loads(chunk.decode("utf-8"))
        elif ctype == 0x004E4942:
            blob = chunk
        off += 8 + clen
    return js, blob


def acc(g, b, i):
    a = g["accessors"][i]
    bv = g["bufferViews"][a["bufferView"]]
    fmt, size = COMP[a["componentType"]]
    n = NCOMP[a["type"]]
    base = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    stride = bv.get("byteStride") or size * n
    return [struct.unpack_from("<" + fmt * n, b, base + k * stride) for k in range(a["count"])]


def mat_of(nd):
    t = nd.get("translation", [0, 0, 0])
    r = nd.get("rotation", [0, 0, 0, 1])
    s = nd.get("scale", [1, 1, 1])
    x, y, z, w = r
    rm = [[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
          [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
          [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]]
    return [[rm[i][j] * s[j] for j in range(3)] + [t[i]] for i in range(3)]


def load(path):
    """Return (list of vertex triples of all triangles, list of per-triangle areas)"""
    g, b = read_glb(path)
    nodes = g.get("nodes", [])
    parent = {}
    for i, nd in enumerate(nodes):
        for c in nd.get("children", []):
            parent[c] = i

    def chain(ni):
        m = mat_of(nodes[ni])
        p = parent.get(ni)
        while p is not None:
            pm = mat_of(nodes[p])
            m = [[sum(pm[i][k] * m[k][j] for k in range(3)) for j in range(3)] +
                 [sum(pm[i][k] * m[k][3] for k in range(3)) + pm[i][3]] for i in range(3)]
            p = parent.get(p)
        return m

    tri, area = [], []
    for ni, nd in enumerate(nodes):
        if "mesh" not in nd:
            continue
        M = chain(ni)

        def xf(v):
            return (M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2] + M[0][3],
                    M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2] + M[1][3],
                    M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2] + M[2][3])

        for prim in g["meshes"][nd["mesh"]]["primitives"]:
            P = acc(g, b, prim["attributes"]["POSITION"])
            I = [v[0] for v in acc(g, b, prim["indices"])] if "indices" in prim else list(range(len(P)))
            for k in range(0, len(I) - 2, 3):
                a, c, d = xf(P[I[k]]), xf(P[I[k + 1]]), xf(P[I[k + 2]])
                ux, uy, uz = c[0] - a[0], c[1] - a[1], c[2] - a[2]
                vx, vy, vz = d[0] - a[0], d[1] - a[1], d[2] - a[2]
                nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
                tri.append((a, c, d))
                area.append(0.5 * math.sqrt(nx * nx + ny * ny + nz * nz))
    return tri, area


def ascii_map(tris, ax, ay, cols=100, rows=34, title=""):
    pts = [v for t in tris for v in t]
    xs = [p[ax] for p in pts]
    ys = [p[ay] for p in pts]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    dx = (x1 - x0) or 1.0
    dy = (y1 - y0) or 1.0
    grid = [[" "] * cols for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            pass
    for t in tris:
        for p in t:
            j = int((p[ax] - x0) / dx * (cols - 1))
            i = int((p[ay] - y0) / dy * (rows - 1))
            grid[rows - 1 - i][j] = "#"
    axis = "XYZ"
    print("  %s  horizontal axis %s [%.1f, %.1f]  vertical axis %s [%.1f, %.1f]"
          % (title, axis[ax], x0, x1, axis[ay], y0, y1))
    print("  +" + "-" * cols + "+")
    for r in grid:
        print("  |" + "".join(r) + "|")
    print("  +" + "-" * cols + "+")


def main():
    path = sys.argv[1]
    thr = float(sys.argv[2]) if len(sys.argv) > 2 else 0.0
    cols = int(sys.argv[3]) if len(sys.argv) > 3 else 100
    tri, area = load(path)
    tot = sum(area)
    if thr <= 0:
        thr = tot * 0.0002
    sel = [t for t, a in zip(tri, area) if a >= thr]
    # Sort by descending area and draw the first 400, so the map does not turn into one blob
    order = sorted(range(len(tri)), key=lambda i: -area[i])
    top = [tri[i] for i in order if area[i] >= thr]
    print("%s" % path)
    print("  triangles %d  total area %.2f  threshold %.4f  hits %d  share of area hit %.2f%%"
          % (len(tri), tot, thr, len(sel), 100.0 * sum(a for a in area if a >= thr) / tot))
    for a in order[:1]:
        pass
    if not top:
        print("  (no triangles above the threshold)")
        return
    vmax = max(abs(v) for t in top for p in t for v in p)
    print("  max absolute coordinate among hit triangles %.1f" % vmax)
    ascii_map(top[:400], 0, 1, cols=cols, title="view XY (top)")
    ascii_map(top[:400], 1, 2, cols=cols, title="view YZ (side, looking along X)")
    ascii_map(top[:400], 0, 2, cols=cols, title="view XZ (front, looking along Y)")


if __name__ == "__main__":
    main()
