#!/usr/bin/env python3
"""Replay the ear-clipping algorithm from the Go side and find the exact reason for
"no valid ear found".

The input is the output file of STP2GLB_DEBUG_FACE=<id> STP2GLB_DEBUG_RAW=1.

Usage:
  python tools/ear-debug.py face407358.txt
"""
import math
import re
import sys


def shoelace(p):
    n = len(p)
    if n < 3:
        return 0.0
    s = 0.0
    for i in range(n):
        j = (i + 1) % n
        s += p[i][0] * p[j][1] - p[j][0] * p[i][1]
    return s * 0.5


def cross2(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def point_in_tri(p, a, b, c, eps=1e-14):
    d1, d2, d3 = cross2(a, b, p), cross2(b, c, p), cross2(c, a, p)
    has_neg = d1 < -eps or d2 < -eps or d3 < -eps
    has_pos = d1 > eps or d2 > eps or d3 > eps
    return not (has_neg and has_pos)


def parse(path):
    """Return [(loop list, ...), ...]; each loop is [(u,v), ...]."""
    insts, cur = [], []
    loops, lp = [], None
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for ln in f:
            if ln.startswith("[dbg face"):
                if lp is not None:
                    loops.append(lp)
                if loops:
                    insts.append(loops)
                loops, lp = [], None
                continue
            m = re.match(r"^\s+loop(\d+) points", ln)
            if m:
                if lp is not None:
                    loops.append(lp)
                lp = []
                continue
            m = re.match(r"^\s+#\s*\d+ u=([+-][\d.e+-]+) v=([+-][\d.e+-]+)", ln)
            if m and lp is not None:
                lp.append((float(m.group(1)), float(m.group(2))))
    if lp is not None:
        loops.append(lp)
    if loops:
        insts.append(loops)
    return insts


def ear_clip(pts, org, label):
    n = len(pts)
    work = list(pts)
    ord_ = list(range(n))
    reversed_ = False
    if shoelace(work) < 0:
        work.reverse()
        org = org[::-1]
        reversed_ = True
    out = []
    guard, max_guard = 0, n * n + 64
    forced_events = []
    while len(ord_) > 3 and guard < max_guard:
        guard += 1
        m = len(ord_)
        clipped = False
        rejects = []
        for i in range(m):
            ia, ib, ic = ord_[(i + m - 1) % m], ord_[i], ord_[(i + 1) % m]
            a, b, c = work[ia], work[ib], work[ic]
            cr = cross2(a, b, c)
            if cr <= 1e-18:
                rejects.append((i, "not convex cross=%.3g" % cr))
                continue
            bad = None
            for j in range(m):
                k = ord_[j]
                if k in (ia, ib, ic):
                    continue
                if point_in_tri(work[k], a, b, c):
                    bad = k
                    break
            if bad is not None:
                rejects.append((i, "contains vertex idx=%d %s" % (bad, work[bad])))
                continue
            out += [org[ia], org[ib], org[ic]]
            del ord_[i]
            clipped = True
            break
        if not clipped:
            mi, mv = 0, math.inf
            for i in range(m):
                a = work[ord_[(i + m - 1) % m]]
                b = work[ord_[i]]
                c = work[ord_[(i + 1) % m]]
                v = abs(cross2(a, b, c))
                if v < mv:
                    mv, mi = v, i
            forced_events.append((len(ord_), rejects, mv))
            del ord_[mi]
    if len(ord_) == 3:
        out += [org[ord_[0]], org[ord_[1]], org[ord_[2]]]
    return out, reversed_, forced_events


def main():
    path = sys.argv[1]
    insts = parse(path)
    print("instance count {}, loops per instance {}".format(len(insts), [len(x) for x in insts]))
    for si, loops in enumerate(insts[:1]):
        outer = loops[0]
        print("\n--- instance {} ---".format(si))
        print("outer loop shoelace = %.6f  ({} points)".format(shoelace(outer), len(outer)))
        for i, h in enumerate(loops[1:], 1):
            print("  hole{} shoelace = %.6f  ({} points)".format(i, shoelace(h), len(h)))
        # Degeneracy checks
        for li, L in enumerate(loops):
            dup = 0
            for i in range(len(L)):
                j = (i + 1) % len(L)
                if abs(L[i][0] - L[j][0]) < 1e-9 and abs(L[i][1] - L[j][1]) < 1e-9:
                    dup += 1
            # Non-adjacent duplicate points
            nd = 0
            for i in range(len(L)):
                for j in range(i + 1, len(L)):
                    if abs(L[i][0] - L[j][0]) < 1e-9 and abs(L[i][1] - L[j][1]) < 1e-9:
                        nd += 1
            col = 0
            for i in range(len(L)):
                a = L[(i - 1) % len(L)]
                b = L[i]
                c = L[(i + 1) % len(L)]
                if abs(cross2(a, b, c)) < 1e-12:
                    col += 1
            print("  loop{}: adjacent duplicate points {}, any duplicate point pairs {}, collinear vertices {}".format(li, dup, nd, col))
        # Ear-clip the outer loop alone, to see whether that fails too
        pts = list(outer)
        org = list(range(len(outer)))
        out, rev, forced = ear_clip(pts, org, "outer")
        print("  outer-loop-only ear clip: reversed={} forced removals {} output triangles {}".format(rev, len(forced), len(out) // 3))
        if forced:
            print("    points left at the first forced removal {}, thinnest cross={:.6g}".format(forced[0][0], forced[0][2]))
            print("    first 4 rejection reasons:")
            for f in forced[0][1][:4]:
                print("      i={} {}".format(f[0], f[1]))
        # Full ear clipping including holes
        allpts = [q for L in loops for q in L]
        org2 = list(range(len(allpts)))
        out2, rev2, forced2 = ear_clip(allpts, org2, "all")
        want = abs(shoelace(outer)) - sum(abs(shoelace(h)) for h in loops[1:])
        got = 0.0
        for k in range(0, len(out2) - 2, 3):
            got += shoelace([allpts[out2[k]], allpts[out2[k + 1]], allpts[out2[k + 2]]])
        print("  all-loop ear clip: forced removals {}, area got {:.3f} expected {:.3f} (deviation {:.1f}%)".format(
            len(forced2), got, want, (got - want) / want * 100 if want else 0))

        # Experiment: flip the holes that wind the same way as the outer loop and run again
        osign = 1.0 if shoelace(outer) > 0 else -1.0
        fixed = [outer]
        flipped = []
        for i, h in enumerate(loops[1:], 1):
            s = shoelace(h)
            if s * osign > 0:
                fixed.append(h[::-1])
                flipped.append(i)
            else:
                fixed.append(h)
        print("  holes winding the same way as the outer loop: {}".format(flipped if flipped else "none"))
        allp = [q for L in fixed for q in L]
        out3, _, forced3 = ear_clip(allp, list(range(len(allp))), "fixed")
        got3 = 0.0
        for k in range(0, len(out3) - 2, 3):
            got3 += shoelace([allp[out3[k]], allp[out3[k + 1]], allp[out3[k + 2]]])
        print("  ear clip after flipping: forced removals {}, area got {:.3f} expected {:.3f} (deviation {:.1f}%)".format(
            len(forced3), got3, want, (got3 - want) / want * 100 if want else 0))


if __name__ == "__main__":
    main()
