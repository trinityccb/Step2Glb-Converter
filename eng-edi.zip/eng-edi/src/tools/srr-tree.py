#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Reconstruct the relationship graph between shape representations (multi-line complex
instances supported).

Both kinds of relationship are parsed:
  * SHAPE_REPRESENTATION_RELATIONSHIP[_WITH_TRANSFORMATION]
  * CONTEXT_DEPENDENT_SHAPE_REPRESENTATION

Usage:
  python srr-tree.py <file.stp>                 # summary + grouping
  python srr-tree.py <file.stp> --parent 32     # only the children of one parent
  python srr-tree.py <file.stp> --ctx           # group by REPRESENTATION_CONTEXT
"""
import re
import sys
import collections

TY_RE = re.compile(r'^#(\d+)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*;\s*$', re.S)
CX_RE = re.compile(r'^#(\d+)\s*=\s*\((.*)\)\s*;\s*$', re.S)
XREF = re.compile(r'#(\d+)')
QUOTED = re.compile(r"'[^']*'")

GEOM_TYPES = ("ADVANCED_BREP_SHAPE_REPRESENTATION",
              "MANIFOLD_SURFACE_SHAPE_REPRESENTATION",
              "GEOMETRICALLY_BOUNDED_SURFACE_SHAPE_REPRESENTATION",
              "GEOMETRICALLY_BOUNDED_WIREFRAME_SHAPE_REPRESENTATION",
              "FACETED_BREP_SHAPE_REPRESENTATION")
ALL_SR = GEOM_TYPES + ("SHAPE_REPRESENTATION", "SHAPE_REPRESENTATION_WITH_PARAMETERS")


def read_raw(path):
    """Split entity definitions on ';' (newline-safe), but ignore semicolons inside quoted strings."""
    buf = []
    for line in open(path, 'r', encoding='utf-8', errors='replace'):
        if not line.startswith('#'):
            continue
        buf.append(line.rstrip('\r\n'))
        if buf[-1].rstrip().endswith(';'):
            yield ' '.join(buf)
            buf = []


def parse_arg_parts(body):
    """Split a complex instance body into [(type, args), ...]"""
    out = []
    depth = 0
    cur = []
    i = 0
    n = len(body)
    while i < n:
        ch = body[i]
        if ch == '(':
            if depth == 0:
                cur = []
            depth += 1
        elif ch == ')':
            depth -= 1
            if depth == 0:
                s = ''.join(cur)
                m = re.match(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*$', s, re.S)
                if m:
                    out.append((m.group(1), m.group(2)))
        else:
            if depth >= 1:
                cur.append(ch)
        i += 1
    return out


def load(path):
    ents = {}
    cx = collections.defaultdict(list)
    for s in read_raw(path):
        m = TY_RE.match(s)
        if m:
            ents[int(m.group(1))] = (m.group(2), m.group(3))
            continue
        m = CX_RE.match(s)
        if m:
            i = int(m.group(1))
            parts = parse_arg_parts(m.group(2))
            if parts:
                ents[i] = parts[0]
                cx[i] = parts
    return ents, cx


def stripped_refs(argstr):
    return [int(x) for x in XREF.findall(QUOTED.sub("''", argstr))]


def sub_parts(a):
    """The (type(...) type(...)) sub-structure embedded in one argument"""
    out = []
    for m in re.finditer(r'[A-Za-z_][A-Za-z0-9_]*\s*\(', a):
        start = m.end() - 1
        depth = 0
        for j in range(start, len(a)):
            if a[j] == '(':
                depth += 1
            elif a[j] == ')':
                depth -= 1
                if depth == 0:
                    ty = a[m.start():m.end() - 1].strip()
                    out.append((ty, a[start + 1:j]))
                    break
    return out


def main():
    path = sys.argv[1]
    ents, cx = load(path)
    filt_parent = int(sys.argv[sys.argv.index('--parent') + 1]) if '--parent' in sys.argv else None
    show_ctx = '--ctx' in sys.argv

    def kind(sr):
        e = ents.get(sr)
        return e[0] if e else '?'

    def nitems(sr):
        e = ents.get(sr)
        if not e or e[0] not in ALL_SR:
            return -1
        m = re.search(r'\((.*?)\)\s*,', e[1], re.S)
        return len(XREF.findall(m.group(1))) if m else 0

    def ctxof(sr):
        e = ents.get(sr)
        if not e or e[0] not in ALL_SR:
            return 0
        r = stripped_refs(e[1])
        return r[-1] if r else 0

    edges = []
    for i, (t, a) in sorted(ents.items()):
        if t == "CONTEXT_DEPENDENT_SHAPE_REPRESENTATION":
            dr = stripped_refs(a)
            if not dr:
                continue
            rel = dr[0]
            cand = list(cx.get(rel, []))
            e2 = ents.get(rel)
            if e2:
                cand.insert(0, e2)
            hit = False
            for (ct, ca) in cand:
                if ct in ("REPRESENTATION_RELATIONSHIP",
                          "REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION"):
                    r = stripped_refs(ca)
                    if len(r) >= 2:
                        edges.append(("CDSR/" + ct.split('_')[-1], r[0], r[1], i))
                        hit = True
                    break
            if not hit:
                edges.append(("CDSR?", 0, rel, i))
        elif t in ("SHAPE_REPRESENTATION_RELATIONSHIP",
                   "SHAPE_REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION"):
            r = stripped_refs(a)
            if len(r) >= 2:
                edges.append((t, r[0], r[1], i))
        else:
            for (ct, ca) in cx.get(i, []):
                if ct in ("SHAPE_REPRESENTATION_RELATIONSHIP",
                          "SHAPE_REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION"):
                    r = stripped_refs(ca)
                    if len(r) >= 2:
                        edges.append((ct, r[0], r[1], i))

    print("entities %d, relationship edges %d" % (len(ents), len(edges)))
    cnt = collections.Counter(e[0] for e in edges)
    for k, v in sorted(cnt.items()):
        print("   %-50s %d" % (k, v))

    def note(sr):
        c = ctxof(sr)
        return "#%d(%s,%di,ctx#%d)" % (sr, kind(sr), nitems(sr), c)

    if filt_parent is not None:
        print("\n== all children of parent %s ==" % note(filt_parent))
        n = 0
        for (k, p, ch, rid) in edges:
            if p == filt_parent:
                print("   %-6s relation#%-9d -> %s" % (k, rid, note(ch)))
                n += 1
        print("   total %d" % n)
        return

    # Count the children of every parent by child type
    print("\n== parent overview (descending child count, first 25) ==")
    byp = collections.defaultdict(list)
    for (k, p, ch, rid) in edges:
        byp[p].append((k, ch))
    for p, kids in sorted(byp.items(), key=lambda kv: -len(kv[1]))[:25]:
        tk = collections.Counter(k for k, _ in kids)
        print("   parent %-34s children%2d  %s" %
              (note(p), len(kids), dict(tk)))

    if show_ctx:
        print("\n== grouped by REPRESENTATION_CONTEXT (geometry/frame) ==")
        byc = collections.defaultdict(list)
        for sr, (t, a) in sorted(ents.items()):
            if t in ALL_SR:
                byc[ctxof(sr)].append(sr)
        for c, members in sorted(byc.items()):
            tag = []
            for m in members:
                tag.append("#%d:%s/%di" % (m, kind(m).replace('_SHAPE_REPRESENTATION', ''), nitems(m)))
            print("   ctx#%-9d %s" % (c, '  |  '.join(tag)))


main()
