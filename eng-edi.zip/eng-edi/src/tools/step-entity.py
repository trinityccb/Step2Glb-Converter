#!/usr/bin/env python3
"""Print STEP entity definitions by id (multi-line complex instances supported).

Usage:
  python tools/step-entity.py file.stp 44546 44375 6643
  python tools/step-entity.py file.stp --grep MANIFOLD_SURFACE_SHAPE_REPRESENTATION

The environment is native Windows Python; write paths as C:/...
"""
import re
import sys

ENT_RE = re.compile(r"#(\d+)\s*=")


def load(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def split_entities(text):
    """Split on ';' while skipping semicolons inside strings. Returns {id: definition}."""
    out = {}
    i, n = 0, len(text)
    start = 0
    in_str = False
    while i < n:
        c = text[i]
        if c == "'":
            in_str = not in_str
        elif c == ";" and not in_str:
            chunk = text[start:i]
            m = ENT_RE.search(chunk)
            if m:
                out[int(m.group(1))] = " ".join(chunk.split())
            start = i + 1
        i += 1
    return out


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    path = sys.argv[1]
    ents = split_entities(load(path))
    print("entities parsed : {}".format(len(ents)))

    if sys.argv[2] == "--grep":
        pat = sys.argv[3]
        hits = [(k, v) for k, v in ents.items() if pat in v.split("=", 1)[1][:80]]
        hits.sort()
        print("{:d} matches".format(len(hits)))
        for k, v in hits[:60]:
            print("  #{} = {}".format(k, v[:200]))
        return 0

    for a in sys.argv[2:]:
        eid = int(a.lstrip("#"))
        v = ents.get(eid)
        print("\n#{:<10} {}".format(eid, v if v else "(not found)"))
        # Also print the types of the first few entities it references
        if v:
            refs = [int(x) for x in re.findall(r"#(\d+)", v)]
            for r in refs[:12]:
                rv = ents.get(r)
                if rv:
                    head = rv.split("=", 1)[1].strip()
                    print("    -> #{:<10} {}".format(r, head[:150]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
