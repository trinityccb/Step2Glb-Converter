#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""hole-probe.py -- measure how many sides a given circular hole was discretized into
in a GLB.

Purpose: verify problems like "a small round hole drawn as a diamond hole". The criterion
is not "does it look round", but **the maximum central angle between adjacent points on
the hole rim**:
    <=30 deg  -> essentially circular (12 or more sides)
    45 deg    -> octagon, the facets are visible
    90 deg    -> quadrilateral, i.e. a "diamond hole"
    180 deg   -> triangle (degenerate)

Standard library only, independent of the Go kernel reading the GLB back.

Usage:
    python tools/hole-probe.py output.glb --z 20 --hole 200,150,4 --hole 400,150,6 ...
    (--hole is center x, center y, hole diameter in turn; z selects the end face at --z)
    --tol  tolerance on the radius from the point to the center, defaults to 8% of the diameter
    --band half-width of the end-face z band, defaults to 10% of the diameter
"""
import json
import math
import struct
import sys


def load(path):
    d = open(path, "rb").read()
    if d[:4] != b"glTF":
        raise ValueError("not a GLB")
    pos = 12
    js = None
    bin_ = b""
    while pos < len(d):
        ln, ty = struct.unpack("<II", d[pos:pos + 8])
        body = d[pos + 8:pos + 8 + ln]
        if ty == 0x4E4F534A:
            js = json.loads(body)
        elif ty == 0x004E4942:
            bin_ = body
        pos += 8 + ln
    return js, bin_


CT = {5120: ("b", 1), 5121: ("B", 1), 5122: ("h", 2), 5123: ("H", 2),
      5125: ("I", 4), 5126: ("f", 4)}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}


def read_acc(js, bin_, i):
    a = js["accessors"][i]
    fmt, sz = CT[a["componentType"]]
    n = NC[a["type"]]
    bv = js["bufferViews"][a["bufferView"]]
    base = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    stride = bv.get("byteStride") or sz * n
    out = []
    for k in range(a["count"]):
        off = base + k * stride
        out.append(struct.unpack_from("<" + fmt * n, bin_, off))
    return out


def collect(js, bin_):
    """Return (triangle vertex list, line segment endpoint list). Node matrices are applied here too."""
    tri, lin = [], []

    def walk(ni, m):
        node = js["nodes"][ni]
        if "matrix" in node:
            e = node["matrix"]
            loc = [[e[c * 4 + r] for c in range(4)] for r in range(4)]
        else:
            t = node.get("translation", [0, 0, 0])
            s = node.get("scale", [1, 1, 1])
            q = node.get("rotation", [0, 0, 0, 1])
            x, y, z, w = q
            rot = [[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                   [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                   [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]]
            loc = [[rot[r][0] * s[0], rot[r][1] * s[1], rot[r][2] * s[2], t[r]] for r in range(3)]
            loc.append([0, 0, 0, 1])
        nm = [[sum(m[r][k] * loc[k][c] for k in range(4)) for c in range(4)] for r in range(4)]
        if "mesh" in node:
            for pr in js["meshes"][node["mesh"]].get("primitives", []):
                ap = pr["attributes"].get("POSITION")
                if ap is None:
                    continue
                pts = read_acc(js, bin_, ap)
                mode = pr.get("mode", 4)
                if mode == 1:
                    idx = read_acc(js, bin_, pr["indices"]) if "indices" in pr else [(i,) for i in range(len(pts))]
                    lin.extend(_xf(nm, pts[i[0]]) for i in idx)
                elif mode == 4:
                    idx = read_acc(js, bin_, pr["indices"]) if "indices" in pr else [(i,) for i in range(len(pts))]
                    tri.extend(_xf(nm, pts[i[0]]) for i in idx)
        for c in node.get("children", []):
            walk(c, nm)

    ident = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
    for sc in js.get("scenes", []):
        for ni in sc.get("nodes", []):
            walk(ni, ident)
    return tri, lin


def _xf(m, p):
    return (m[0][0] * p[0] + m[0][1] * p[1] + m[0][2] * p[2] + m[0][3],
            m[1][0] * p[0] + m[1][1] * p[1] + m[1][2] * p[2] + m[1][3],
            m[2][0] * p[0] + m[2][1] * p[1] + m[2][2] * p[2] + m[2][3])


def rim_angles(pts, cx, cy, z0, r, rtol, band):
    """Pick the points on the circle of radius r with z within z0 +/- band, return the de-duplicated angle list."""
    angs = set()
    for x, y, z in pts:
        if abs(z - z0) > band:
            continue
        rad = math.hypot(x - cx, y - cy)
        if abs(rad - r) > rtol:
            continue
        a = math.degrees(math.atan2(y - cy, x - cx)) % 360.0
        angs.add(round(a, 1))
    return sorted(angs)


def max_gap(angs):
    if len(angs) < 2:
        return None
    g = [angs[i + 1] - angs[i] for i in range(len(angs) - 1)]
    g.append(360.0 - angs[-1] + angs[0])
    return max(g)


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 2
    glb = args[0]
    z0 = 0.0
    holes = []
    rtol = band = None
    i = 1
    while i < len(args):
        a = args[i]
        if a == "--z":
            z0 = float(args[i + 1]); i += 2
        elif a == "--hole":
            x, y, d = [float(v) for v in args[i + 1].split(",")]
            holes.append((x, y, d)); i += 2
        elif a == "--rtol":
            rtol = float(args[i + 1]); i += 2
        elif a == "--band":
            band = float(args[i + 1]); i += 2
        else:
            print("unknown argument %s" % a); return 2
    if not holes:
        print("at least one --hole x,y,diameter is required")
        return 2

    js, bin_ = load(glb)
    tri, lin = collect(js, bin_)
    print("=" * 70)
    print("%s" % glb)
    print("  triangle vertices %d / outline points %d" % (len(tri), len(lin)))
    bad = 0
    for (cx, cy, d) in holes:
        r = d / 2.0
        rt = rtol if rtol is not None else max(r * 0.08, 0.05)
        bd = band if band is not None else max(r * 0.10, 0.05)
        at = rim_angles(tri, cx, cy, z0, r, rt, bd)
        al = rim_angles(lin, cx, cy, z0, r, rt, bd)
        gt, gl = max_gap(at), max_gap(al)
        mark = ""
        if gt is not None and gt > 46:
            mark = "  <- faces: diamond/coarse polygon"
            bad += 1
        elif gl is not None and gl > 46:
            mark = "  <- outline: diamond/coarse polygon"
            bad += 1
        print("  dia%-5g center(%.0f,%.0f)  faces %2d pts/max angle %5s deg   lines %2d pts/max angle %5s deg%s"
              % (d, cx, cy, len(at), "-" if gt is None else "%.1f" % gt,
                 len(al), "-" if gl is None else "%.1f" % gl, mark))
    print("  criterion: a maximum rim central angle > 46 deg counts as not round enough (90 deg = diamond)")
    print("  bad holes %d / %d" % (bad, len(holes)))
    print("=" * 70)
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
