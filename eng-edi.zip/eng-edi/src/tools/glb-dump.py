#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""List the bounding box of every mesh/primitive in a GLB, for part-by-part comparison
across implementations.

Usage: python glb-dump.py <file.glb> [--json]
"""
import json
import struct
import sys

COMP = {5120: ("b", 1), 5121: ("B", 1), 5122: ("h", 2), 5123: ("H", 2),
        5125: ("I", 4), 5126: ("f", 4)}
NCOMP = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


def read_glb(path):
    with open(path, "rb") as f:
        data = f.read()
    magic, ver, length = struct.unpack_from("<III", data, 0)
    assert magic == 0x46546C67, "not a GLB"
    off = 12
    js = None
    blob = b""
    while off < length:
        clen, ctype = struct.unpack_from("<II", data, off)
        payload = data[off + 8: off + 8 + clen]
        if ctype == 0x4E4F534A:
            js = json.loads(payload.decode("utf-8"))
        elif ctype == 0x004E4942:
            blob = payload
        off += 8 + clen
    return js, blob


def accessor(js, blob, idx):
    acc = js["accessors"][idx]
    n = NCOMP[acc["type"]]
    fmt, size = COMP[acc["componentType"]]
    base = js["bufferViews"][acc["bufferView"]]
    start = base.get("byteOffset", 0) + acc.get("byteOffset", 0)
    stride = base.get("byteStride") or n * size
    out = []
    for i in range(acc["count"]):
        o = start + i * stride
        out.append(struct.unpack_from("<" + fmt * n, blob, o))
    return out


def mul4(a, b):
    """a . b (apply b first, then a), row-major."""
    r = [0.0] * 16
    for i in range(4):
        for j in range(4):
            r[i * 4 + j] = sum(a[i * 4 + k] * b[k * 4 + j] for k in range(4))
    return r


def ident():
    return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]


def node_mat(nd):
    """Node local transform, row-major.

    Note: glTF's node.matrix is stored **column-major**, so it must be transposed to
    row-major before use. Feeding a column-major array straight into a row-major
    multiply makes the rotation match by the coincidence of the transpose while the
    translation is completely wrong -- such a bug is very hard to spot (it once flipped
    the conclusions of a whole round of assembly pose comparisons).
    """
    if "matrix" in nd:
        c = nd["matrix"]
        return [c[0], c[4], c[8], c[12],
                c[1], c[5], c[9], c[13],
                c[2], c[6], c[10], c[14],
                c[3], c[7], c[11], c[15]]
    t = nd.get("translation", [0, 0, 0])
    r = nd.get("rotation", [0, 0, 0, 1])
    s = nd.get("scale", [1, 1, 1])
    x, y, z, w = r
    rm = [
        1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w), 0,
        2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w), 0,
        2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y), 0,
        0, 0, 0, 1,
    ]
    for row in range(3):
        for col in range(3):
            rm[row * 4 + col] *= s[col]
    rm[3], rm[7], rm[11] = t[0], t[1], t[2]
    return rm


def xform(m, p):
    x, y, z = p[0], p[1], p[2]
    return (m[0] * x + m[1] * y + m[2] * z + m[3],
            m[4] * x + m[5] * y + m[6] * z + m[7],
            m[8] * x + m[9] * y + m[10] * z + m[11])


def main():
    path = sys.argv[1]
    js, blob = read_glb(path)
    nodes = js.get("nodes", [])
    meshes = js.get("meshes", [])
    scene = js.get("scenes", [{}])[js.get("scene", 0)]

    overall = None
    rows = []

    def visit(ni, parent_m):
        nonlocal overall
        nd = nodes[ni]
        m = mul4(parent_m, node_mat(nd))
        if "mesh" in nd:
            me = meshes[nd["mesh"]]
            for pi, pr in enumerate(me.get("primitives", [])):
                pa = pr["attributes"]["POSITION"]
                pts = [xform(m, p) for p in accessor(js, blob, pa)]
                if not pts:
                    continue
                mn = [min(p[i] for p in pts) for i in range(3)]
                mx = [max(p[i] for p in pts) for i in range(3)]
                tri = 0
                if "indices" in pr:
                    tri = js["accessors"][pr["indices"]]["count"] // 3
                rows.append((nd.get("name", "#%d" % ni), pi, len(pts), tri, mn, mx))
                if overall is None:
                    overall = [list(mn), list(mx)]
                else:
                    for i in range(3):
                        overall[0][i] = min(overall[0][i], mn[i])
                        overall[1][i] = max(overall[1][i], mx[i])
        for c in nd.get("children", []):
            visit(c, m)

    for ni in scene.get("nodes", []):
        visit(ni, ident())

    print("=" * 96)
    print("file:", path)
    print("nodes %d  meshes %d  parts %d" % (len(nodes), len(meshes), len(rows)))
    print("-" * 96)
    for name, pi, nv, tri, mn, mx in sorted(rows, key=lambda r: r[0]):
        print("%-34s p%-3d pts%-6d tri%-7d min=(%9.3f,%9.3f,%9.3f) max=(%9.3f,%9.3f,%9.3f) size=(%8.3f,%8.3f,%8.3f)"
              % (name[:34], pi, nv, tri, mn[0], mn[1], mn[2], mx[0], mx[1], mx[2],
                 mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]))
    if overall:
        mn, mx = overall
        size = sorted(mx[i] - mn[i] for i in range(3))
        print("-" * 96)
        print("overall: min=(%.4f,%.4f,%.4f) max=(%.4f,%.4f,%.4f)" % (mn[0], mn[1], mn[2], mx[0], mx[1], mx[2]))
        print("overall size (sorted): %.4f x %.4f x %.4f" % (size[0], size[1], size[2]))


if __name__ == "__main__":
    main()
