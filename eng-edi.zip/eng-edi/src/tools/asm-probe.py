#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Independently recompute STEP assembly transforms (without the C++/Go implementation), to
settle the direction convention of ITEM_DEFINED_TRANSFORMATION. It prints the overall
bounding box under three conventions, for comparison with the OCC baseline.

Usage: python asm-probe.py <file.stp>
"""
import re
import sys
import math

# ---------------------------------------------------------------- parsing

TOK_REF = re.compile(r"#(\d+)")
FLOAT = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?")


def split_entities(text):
    """Split into {id: body}, where body is the content between '#id = ' and ';' (newlines preserved)."""
    out = {}
    i = 0
    n = len(text)
    while True:
        j = text.find("#", i)
        if j < 0:
            break
        k = j + 1
        while k < n and text[k].isdigit():
            k += 1
        if k == j + 1:
            i = j + 1
            continue
        eid = int(text[j + 1:k])
        # Skip the whitespace between #id and '=
        m = k
        while m < n and text[m] in " \t\r\n":
            m += 1
        if m >= n or text[m] != "=":
            i = k
            continue
        m += 1
        # Find the terminating semicolon (ignoring semicolons inside strings; STEP strings may contain ';', so a simple state machine is used)
        in_str = False
        p = m
        while p < n:
            c = text[p]
            if in_str:
                if c == "'":
                    if p + 1 < n and text[p + 1] == "'":
                        p += 2
                        continue
                    in_str = False
            else:
                if c == "'":
                    in_str = True
                elif c == ";":
                    break
            p += 1
        out[eid] = text[m:p]
        i = p + 1
    return out


class Ent(object):
    __slots__ = ("id", "typ", "body", "refs")

    def __init__(self, eid, body):
        self.id = eid
        self.body = body
        self.refs = [int(x) for x in TOK_REF.findall(body)]
        # Type name: take the first identifier
        m = re.match(r"\s*!?([A-Za-z_][A-Za-z_0-9]*)", body)
        self.typ = m.group(1).upper() if m else "?"


def load(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    raw = split_entities(text)
    ents = {}
    for eid, body in raw.items():
        ents[eid] = Ent(eid, body)
    return ents


def sub_instances(ents, eid):
    """Split a complex instance '#id = ( A(...) B(...) ... );' into [(type, args, body), ...]"""
    e = ents.get(eid)
    if e is None:
        return []
    body = e.body.strip()
    if not body.startswith("("):
        return [(e.typ, parse_items(e.body), e.body)]
    out = []
    i = 1
    n = len(body)
    while i < n:
        while i < n and body[i] in " \t\r\n,)":
            i += 1
        if i >= n:
            break
        m = re.match(r"([A-Za-z_][A-Za-z_0-9]*)\s*\(", body[i:])
        if not m:
            break
        typ = m.group(1).upper()
        j = i + m.end() - 1
        depth = 0
        p = j
        while p < n:
            if body[p] == "(":
                depth += 1
            elif body[p] == ")":
                depth -= 1
                if depth == 0:
                    break
            p += 1
        seg = body[j:p + 1]
        out.append((typ, parse_items(seg), seg))
        i = p + 1
    return out


def sub_instance(ents, eid, typ):
    """Return the sub-instance of the given type inside a complex instance as (type, args, body)."""
    for t, args, seg in sub_instances(ents, eid):
        if t == typ:
            return (t, args, seg)
    return None


def ref_of(args, i):
    """Return the reference at argument position i (0 if it is not a reference)."""
    if i >= len(args):
        return 0
    m = TOK_REF.match(args[i].strip())
    return int(m.group(1)) if m else 0


# ---------------------------------------------------------------- linear algebra

def mat_identity():
    return ([1.0, 0, 0, 0, 1, 0, 0, 0, 1], [0.0, 0.0, 0.0])


def mat_mul(a, b):
    """a . b: apply b first, then a."""
    ra, ta = a
    rb, tb = b
    r = [0.0] * 9
    for i in range(3):
        for j in range(3):
            r[i * 3 + j] = sum(ra[i * 3 + k] * rb[k * 3 + j] for k in range(3))
    t = [sum(ra[i * 3 + k] * tb[k] for k in range(3)) + ta[i] for i in range(3)]
    return (r, t)


def mat_apply(m, p):
    r, t = m
    return [sum(r[i * 3 + k] * p[k] for k in range(3)) + t[i] for i in range(3)]


def mat_inv_rigid(m):
    r, t = m
    ri = [r[0], r[3], r[6], r[1], r[4], r[7], r[2], r[5], r[8]]
    ti = [-sum(ri[i * 3 + k] * t[k] for k in range(3)) for i in range(3)]
    return (ri, ti)


def vec(ents, pid):
    e = ents.get(pid)
    if e is None:
        return None
    nums = [float(v) for v in FLOAT.findall(e.body)]
    return nums[:3] if len(nums) >= 3 else None


def placement(ents, aid):
    """AXIS2_PLACEMENT_3D -> (R, T); None means it is absent."""
    e = ents.get(aid)
    if e is None:
        return None
    if e.typ not in ("AXIS2_PLACEMENT_3D", "AXIS2_PLACEMENT_2D"):
        return None
    org = vec(ents, e.refs[0]) if len(e.refs) > 0 else None
    zax = vec(ents, e.refs[1]) if len(e.refs) > 1 else None
    xax = vec(ents, e.refs[2]) if len(e.refs) > 2 else None
    if org is None:
        org = [0.0, 0.0, 0.0]
    if zax is None:
        zax = [0.0, 0.0, 1.0]
    z = norm(zax)
    if xax is None:
        xax = [1.0, 0.0, 0.0] if abs(z[0]) < 0.9 else [0.0, 1.0, 0.0]
    x = norm(xax)
    # Gram-Schmidt orthogonalization
    d = dot(x, z)
    x = [x[i] - d * z[i] for i in range(3)]
    if norm_len(x) < 1e-12:
        x = [1.0, 0.0, 0.0] if abs(z[0]) < 0.9 else [0.0, 1.0, 0.0]
        d = dot(x, z)
        x = [x[i] - d * z[i] for i in range(3)]
    x = norm(x)
    y = cross(z, x)
    r = [x[0], y[0], z[0], x[1], y[1], z[1], x[2], y[2], z[2]]
    return (r, list(org))


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def norm_len(a):
    return math.sqrt(dot(a, a))


def norm(a):
    l = norm_len(a)
    if l < 1e-18:
        return [0.0, 0.0, 1.0]
    return [a[i] / l for i in range(3)]


# ---------------------------------------------------------------- assembly graph

def build(ents, convention, order="fwd"):
    """Return (xform_of_sr, items_of_sr, rels)
    order: fwd = parent . child (standard nesting); rev = child . parent (the behaviour
    measured on OCC/occt-import-js)"""
    items_of = {}
    for eid, e in ents.items():
        if "SHAPE_REPRESENTATION" in e.typ and not e.typ.endswith("RELATIONSHIP"):
            args = parse_items(e.body)
            items_of[eid] = args[1] if len(args) > 1 else ""

    rels = {}
    for eid, e in ents.items():
        if e.typ != "CONTEXT_DEPENDENT_SHAPE_REPRESENTATION":
            continue
        if not e.refs:
            continue
        rr = e.refs[0]
        base = ents.get(rr)
        if base is None:
            continue
        # Complex instance: pull out the REPRESENTATION_RELATIONSHIP sub-instance and take child/parent by argument position
        sub = sub_instance(ents, rr, "REPRESENTATION_RELATIONSHIP")
        if sub is None:
            sub = (base.typ, parse_items(base.body), base.body)
        _, sargs, _ = sub
        child = ref_of(sargs, 2)
        parent = ref_of(sargs, 3)
        if child == 0 or parent == 0:
            continue
        # Find the transformation operator (indexed by argument position: #52 = ITEM_DEFINED_TRANSFORMATION('','',#11,#15))
        tr = None
        trArgs = None
        for t in ents[rr].refs:
            te = ents.get(t)
            if te is not None and te.typ == "ITEM_DEFINED_TRANSFORMATION":
                tr = te
                trArgs = parse_items(te.body)
                break
        if tr is None:
            rels[child] = (parent, mat_identity())
            continue
        p1 = placement(ents, ref_of(trArgs, 2))
        p2 = placement(ents, ref_of(trArgs, 3))
        if p1 is None or p2 is None:
            rels[child] = (parent, mat_identity())
            continue
        if convention == "p2_p1i":
            m = mat_mul(p2, mat_inv_rigid(p1))
        elif convention == "p1_p2i":
            m = mat_mul(p1, mat_inv_rigid(p2))
        elif convention == "p2":
            m = p2
        elif convention == "ident":
            m = mat_identity()
        else:
            raise SystemExit("bad convention")
        rels[child] = (parent, m)

    xf = {}

    def resolve(sr, depth=0):
        if sr in xf:
            return xf[sr]
        if depth > 64 or sr not in rels:
            xf[sr] = mat_identity()
            return xf[sr]
        parent, m = rels[sr]
        pm = resolve(parent, depth + 1)
        if order == "rev":
            xf[sr] = mat_mul(m, pm)
        else:
            xf[sr] = mat_mul(pm, m)
        return xf[sr]

    for sr in items_of:
        resolve(sr)
    return xf, items_of, rels


def parse_items(body):
    """Split the arguments of SHAPE_REPRESENTATION(...) and return the list of argument fragments."""
    i = body.find("(")
    if i < 0:
        return []
    depth = 0
    inner = ""
    j = i
    while j < len(body):
        c = body[j]
        if c == "(":
            depth += 1
            if depth == 1:
                inner = ""
                j += 1
                continue
        elif c == ")":
            depth -= 1
            if depth == 0:
                break
        if depth >= 1:
            inner += c
        j += 1
    res = []
    depth = 0
    cur = ""
    for c in inner:
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        if c == "," and depth == 0:
            res.append(cur)
            cur = ""
        else:
            cur += c
    if cur.strip():
        res.append(cur)
    return res


def reachable_points(ents, root_ids, skip):
    """BFS-collect the coordinates of all reachable CARTESIAN_POINTs."""
    seen = set()
    stack = list(root_ids)
    pts = []
    while stack:
        rid = stack.pop()
        if rid in seen or rid == skip:
            continue
        seen.add(rid)
        e = ents.get(rid)
        if e is None:
            continue
        if e.typ == "CARTESIAN_POINT":
            v = vec(ents, rid)
            if v:
                pts.append(v)
            continue
        for r in e.refs:
            if r not in seen:
                stack.append(r)
    return pts


def main():
    path = sys.argv[1]
    ents = load(path)

    print("=" * 72)
    print("file:", path)
    print("total entities:", len(ents))

    # ---- list placements ----
    print("-" * 72)
    print("AXIS2_PLACEMENT_3D:")
    for eid in sorted(ents):
        e = ents[eid]
        if e.typ == "AXIS2_PLACEMENT_3D":
            org = vec(ents, e.refs[0]) if e.refs else None
            z = vec(ents, e.refs[1]) if len(e.refs) > 1 else None
            x = vec(ents, e.refs[2]) if len(e.refs) > 2 else None
            print("  #%-6d org=%-28s z=%-24s x=%s" % (eid, fmt(org), fmt(z), fmt(x)))

    # ---- list CDSRs ----
    print("-" * 72)
    print("CONTEXT_DEPENDENT_SHAPE_REPRESENTATION:")
    for eid in sorted(ents):
        e = ents[eid]
        if e.typ != "CONTEXT_DEPENDENT_SHAPE_REPRESENTATION":
            continue
        rr = e.refs[0] if e.refs else 0
        sub = sub_instance(ents, rr, "REPRESENTATION_RELATIONSHIP")
        child, parent = (0, 0)
        if sub is not None:
            child = ref_of(sub[1], 2)
            parent = ref_of(sub[1], 3)
        tr = None
        trArgs = None
        for t in ents[rr].refs if rr in ents else []:
            te = ents.get(t)
            if te is not None and te.typ == "ITEM_DEFINED_TRANSFORMATION":
                tr = te
                trArgs = parse_items(te.body)
        extra = ""
        if tr is not None:
            extra = "item1=#%d item2=#%d" % (ref_of(trArgs, 2), ref_of(trArgs, 3))
        print("  #%-6d child(SR)=#%-6d parent(SR)=#%-6d %s" % (eid, child, parent, extra))

    # ---- items of each SR ----
    print("-" * 72)
    print("SHAPE_REPRESENTATION items:")
    _, items_of, _ = build(ents, "ident")
    for eid in sorted(items_of):
        e = ents[eid]
        refs = TOK_REF.findall(items_of[eid])
        print("  #%-6d %-42s items=%s" % (eid, e.typ, ",".join("#" + r for r in refs)))

    # ---- bounding boxes under the three conventions ----
    breps = [eid for eid, e in ents.items() if "ADVANCED_BREP_SHAPE_REPRESENTATION" in e.typ]
    print("-" * 72)
    print("ADVANCED_BREP_SHAPE_REPRESENTATION:", ["#%d" % b for b in sorted(breps)])

    orders = ["fwd", "rev"] if ("--both" in sys.argv or "--rev" in sys.argv) else ["fwd"]
    cases = []
    for o in orders:
        if o == "fwd" or "--rev" in sys.argv or "--both" in sys.argv:
            cases.append((o, "p2_p1i"))
    for order, conv in cases:
        xf, items_of, rels = build(ents, conv, order)
        tag = "%s" % order
        if "--dbg" in sys.argv:
            print("  [dbg %s] rels=%s" % (tag, sorted(rels.items())))
            print("  [dbg %s] xf keys=%s" % (tag, sorted(xf.keys())))
            for k in sorted(xf):
                if k in (86, 393, 32, 63, 365, 10):
                    print("      xf[#%d] T=%s" % (k, xf[k][1]))
        allpts = []
        per = []
        for b in sorted(breps):
            m = xf.get(b, mat_identity())
            # Take only the geometry part of the two items (skip AXIS2_PLACEMENT_3D)
            geo_roots = []
            for n in [int(x) for x in TOK_REF.findall(items_of.get(b, ""))]:
                ie = ents.get(n)
                if ie is not None and ie.typ == "AXIS2_PLACEMENT_3D":
                    continue
                geo_roots.append(n)
            pts = reachable_points(ents, geo_roots, None)
            tp = [mat_apply(m, p) for p in pts]
            if tp:
                bmin = [min(p[i] for p in tp) for i in range(3)]
                bmax = [max(p[i] for p in tp) for i in range(3)]
                per.append((b, len(tp), bmin, bmax))
            allpts.extend(tp)
        if not allpts:
            print("  [%s] no points" % tag)
            continue
        mn = [min(p[i] for p in allpts) for i in range(3)]
        mx = [max(p[i] for p in allpts) for i in range(3)]
        size = [mx[i] - mn[i] for i in range(3)]
        srt = sorted(size)
        print("  [%-8s] points=%-6d bbox(mm) = %.3f x %.3f x %.3f   size (sorted) %.3f x %.3f x %.3f"
              % (tag, len(allpts), mn[0], mn[1], mn[2], srt[0], srt[1], srt[2]))
        print("             min=(%.3f, %.3f, %.3f) max=(%.3f, %.3f, %.3f)"
              % (mn[0], mn[1], mn[2], mx[0], mx[1], mx[2]))
        for b, c, bmin, bmax in per:
            print("             #%-6d points=%-6d min=(%.3f,%.3f,%.3f) max=(%.3f,%.3f,%.3f)"
                  % (b, c, bmin[0], bmin[1], bmin[2], bmax[0], bmax[1], bmax[2]))


def fmt(v):
    if v is None:
        return "None"
    return "(%.6g, %.6g, %.6g)" % (v[0], v[1], v[2])


if __name__ == "__main__":
    main()
