#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Shape representation overview: list every SHAPE_REPRESENTATION in a STEP file grouped by
REPRESENTATION_CONTEXT, and mark whether it appears in an assembly relationship (CDSR).

Used to decide whether the rule "frame SR + geometry SR paired by context" applies to the
current file: the pairing only holds when a context group contains **both** "a frame that
is inside the assembly graph but has no geometry" and "a sibling representation that has
geometry"; otherwise the kernel must not touch anything.

Usage: python sr-report.py <file.stp>
"""
import re
import sys
import collections

REF_RE = re.compile(r'#(\d+)')
NUM_RE = re.compile(r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?')
TY_RE = re.compile(r'^#(\d+)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*;\s*$', re.S)
CX_RE = re.compile(r'^#(\d+)\s*=\s*\((.*)\)\s*;\s*$', re.S)


def load(path):
    ents = {}
    for line in open(path, 'r', encoding='utf-8', errors='replace'):
        if not line.startswith('#'):
            continue
        s = line.rstrip('\r\n')
        m = TY_RE.match(s)
        if m:
            ents[int(m.group(1))] = [m.group(2), m.group(3)]
            continue
        m = CX_RE.match(s)
        if m:
            ents[int(m.group(1))] = [None, m.group(2)]
    return ents


def refs(b):
    return [int(x) for x in REF_RE.findall(b)]


def split_parts(body):
    out, i, n = [], 0, len(body)
    rx = re.compile(r'([A-Za-z_][A-Za-z0-9_]*)\s*\(')
    while i < n:
        m = rx.match(body, i)
        if not m:
            i += 1
            continue
        j, d, ins = m.end(), 1, False
        while j < n and d:
            c = body[j]
            if ins:
                if c == "'":
                    ins = False
            else:
                if c == "'":
                    ins = True
                elif c == '(':
                    d += 1
                elif c == ')':
                    d -= 1
            j += 1
        out.append((m.group(1), body[m.end():j - 1]))
        i = j
    return out


def main():
    path = sys.argv[1]
    ents = load(path)
    print('reading %s: %d entities' % (path, len(ents)))

    # Assembly relationship graph
    children = collections.defaultdict(list)
    is_child = set()
    for i, (t, b) in ents.items():
        if t != 'CONTEXT_DEPENDENT_SHAPE_REPRESENTATION':
            continue
        r = refs(b)
        if not r:
            continue
        rr = ents.get(r[0])
        if not rr:
            continue
        parts = dict(split_parts(rr[1]))
        rel = parts.get('REPRESENTATION_RELATIONSHIP')
        if rel is None:
            continue
        q = refs(rel)
        if len(q) >= 2:
            children[q[1]].append(q[0])
            is_child.add(q[0])

    def is_sr(t):
        if t is None:
            return False
        if 'RELATIONSHIP' in t or t.startswith('CONTEXT_DEPENDENT'):
            return False
        return 'SHAPE_REPRESENTATION' in t

    def is_ctx(i):
        e = ents.get(i)
        return bool(e and e[0] is None and 'REPRESENTATION_CONTEXT' in e[1])

    def args(b):
        out, d, cur, ins = [], 0, [], False
        for c in b:
            if ins:
                cur.append(c)
                if c == "'":
                    ins = False
                continue
            if c == "'":
                ins = True
                cur.append(c)
            elif c == '(':
                d += 1
                cur.append(c)
            elif c == ')':
                d -= 1
                cur.append(c)
            elif c == ',' and d == 0:
                out.append(''.join(cur).strip())
                cur = []
            else:
                cur.append(c)
        out.append(''.join(cur).strip())
        return out

    # Vertex counts (an approximate measure of geometry)
    pts = {}
    for i, (t, b) in ents.items():
        if t == 'CARTESIAN_POINT':
            n = [float(x) for x in NUM_RE.findall(args(b)[-1])]
            if len(n) >= 3:
                pts[i] = tuple(round(v, 3) for v in n[:3])
    vtx = {}
    for i, (t, b) in ents.items():
        if t == 'VERTEX_POINT':
            r = refs(b)
            if r and r[0] in pts:
                vtx[i] = pts[r[0]]
    oe = {}
    for i, (t, b) in ents.items():
        if t == 'ORIENTED_EDGE':
            r = refs(b)
            if r:
                oe[i] = r[0]
    ev = {}
    for i, (t, b) in ents.items():
        if t == 'EDGE_CURVE':
            r = refs(b)
            ev[i] = [vtx.get(r[0]), vtx.get(r[1])] if len(r) >= 2 else []
    le = collections.defaultdict(list)
    for i, (t, b) in ents.items():
        if t == 'EDGE_LOOP':
            for r in refs(b):
                if r in oe:
                    le[i].extend(x for x in ev.get(oe[r], []) if x)
    bl = {}
    for i, (t, b) in ents.items():
        if t in ('FACE_OUTER_BOUND', 'FACE_BOUND'):
            r = refs(b)
            if r:
                bl[i] = r[0]
    fp = {}
    for i, (t, b) in ents.items():
        if t == 'ADVANCED_FACE':
            vs = []
            for r in refs(b):
                if r in bl:
                    vs.extend(le.get(bl[r], []))
            fp[i] = vs
    shell_faces = {}
    for i, (t, b) in ents.items():
        if t in ('CLOSED_SHELL', 'OPEN_SHELL'):
            shell_faces[i] = [r for r in refs(b) if r in fp]
    holder = {}
    for i, (t, b) in ents.items():
        if t in ('SHELL_BASED_SURFACE_MODEL', 'MANIFOLD_SOLID_BREP'):
            vs = []
            for r in refs(b):
                vs.extend(shell_faces.get(r, []))
            holder[i] = vs

    def faces_of_item(it):
        if it in fp:
            return [it]
        return holder.get(it, [])

    srs = {}
    for i, (t, b) in ents.items():
        if not is_sr(t):
            continue
        r = refs(b)
        ctx = r[-1] if r else 0
        items = [x for x in r if not is_ctx(x)]
        kinds = collections.Counter(ents.get(x, [None])[0] or '(complex)' for x in items)
        fs, seen = [], set()
        for it in items:
            for f in faces_of_item(it):
                if f not in seen:
                    seen.add(f)
                    fs.append(f)
        v = set()
        for f in fs:
            v |= set(fp.get(f, []))
        srs[i] = dict(type=t, ctx=ctx, kinds=dict(kinds),
                      faces=len(fs), verts=len(v),
                      in_graph=(i in is_child or bool(children.get(i))),
                      nchild=len(children.get(i, [])))

    groups = collections.defaultdict(list)
    for sr, d in srs.items():
        if d['ctx']:
            groups[d['ctx']].append(sr)

    print('\nSR total %d, of which %d appear in an assembly relationship'
          % (len(srs), sum(1 for d in srs.values() if d['in_graph'])))
    print('\n=== grouped by context (only groups with >=2 SRs) ===')
    mixed = 0
    for c, members in sorted(groups.items(), key=lambda kv: -len(kv[1])):
        if len(members) < 2:
            continue
        frames = [s for s in members if srs[s]['faces'] == 0 and srs[s]['in_graph']]
        geoms = [s for s in members if srs[s]['faces'] > 0]
        flag = '* paired' if (frames and geoms) else '(not paired)'
        if frames and geoms:
            mixed += 1
        print('\ncontext #%-9s %d SRs  %s  frames(in graph, no geometry)=%d  geometry=%d'
              % (c, len(members), flag, len(frames), len(geoms)))
        for s in sorted(members):
            d = srs[s]
            kinds = ', '.join('%s x%d' % (k, n) for k, n in sorted(d['kinds'].items())) or 'none'
            print('    #%-9d %-46s in graph=%-5s faces=%-6d vertices=%-6d items: %s'
                  % (s, d['type'], d['in_graph'], d['faces'], d['verts'], kinds[:90]))
    print('\ncontext groups that pair up: %d' % mixed)


if __name__ == '__main__':
    main()
