#!/usr/bin/env python3
"""List the largest triangles in a GLB (top 25 by default), to locate "a membrane that came out of nowhere".

Usage:
  python tools/glb-big.py model.glb [N]
"""
import json
import math
import struct
import sys

COMP = {5120: ("b", 1), 5121: ("B", 1), 5122: ("h", 2),
        5123: ("H", 2), 5125: ("I", 4), 5126: ("f", 4)}
NCOMP = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


def read_glb(path):
    with open(path, "rb") as f:
        data = f.read()
    magic, ver, total = struct.unpack_from("<III", data, 0)
    assert magic == 0x46546C67, "not a GLB"
    off, js, bin_ = 12, None, None
    while off < total:
        clen, ctype = struct.unpack_from("<II", data, off)
        chunk = data[off + 8: off + 8 + clen]
        if ctype == 0x4E4F534A:
            js = json.loads(chunk.decode("utf-8"))
        elif ctype == 0x004E4942:
            bin_ = chunk
        off += 8 + clen + ((4 - clen % 4) % 4 if clen % 4 else 0)
    return js, bin_


def acc(g, b, i):
    a = g["accessors"][i]
    bv = g["bufferViews"][a["bufferView"]]
    fmt, size = COMP[a["componentType"]]
    n = NCOMP[a["type"]]
    base = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    stride = bv.get("byteStride") or size * n
    out = []
    for k in range(a["count"]):
        o = base + k * stride
        out.append(struct.unpack_from("<" + fmt * n, b, o))
    return out


def main():
    path = sys.argv[1]
    topn = int(sys.argv[2]) if len(sys.argv) > 2 else 25
    g, b = read_glb(path)

    # Node world transforms
    nodes = g.get("nodes", [])
    parent = {}
    for i, nd in enumerate(nodes):
        for c in nd.get("children", []):
            parent[c] = i

    def mat_of(nd):
        if "matrix" in nd:
            m = nd["matrix"]
            return [[m[0], m[4], m[8], m[12]], [m[1], m[5], m[9], m[13]],
                    [m[2], m[6], m[10], m[14]], [m[3], m[7], m[11], m[15]]]
        t = nd.get("translation", [0, 0, 0])
        r = nd.get("rotation", [0, 0, 0, 1])
        s = nd.get("scale", [1, 1, 1])
        x, y, z, w = r
        rm = [[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
              [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
              [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]]
        return [[rm[i][j] * s[j] for j in range(3)] + [t[i]] for i in range(3)] + [[0, 0, 0, 1]]

    def mul(a, m):
        return [[sum(a[i][k] * m[k][j] for k in range(4)) for j in range(4)] for i in range(4)]

    def chain(ni):
        m = mat_of(nodes[ni])
        p = parent.get(ni)
        while p is not None:
            m = mul(mat_of(nodes[p]), m)
            p = parent.get(p)
        return m

    def xf(m, v):
        return (m[0][0] * v[0] + m[0][1] * v[1] + m[0][2] * v[2] + m[0][3],
                m[1][0] * v[0] + m[1][1] * v[1] + m[1][2] * v[2] + m[1][3],
                m[2][0] * v[0] + m[2][1] * v[1] + m[2][2] * v[2] + m[2][3])

    tris = []
    for ni, nd in enumerate(nodes):
        if "mesh" not in nd:
            continue
        M = chain(ni)
        ms = g["meshes"][nd["mesh"]]
        for pi, prim in enumerate(ms["primitives"]):
            P = acc(g, b, prim["attributes"]["POSITION"])
            I = [x[0] for x in acc(g, b, prim["indices"])] if "indices" in prim else list(range(len(P)))
            for k in range(0, len(I) - 2, 3):
                a = xf(M, P[I[k]])
                c = xf(M, P[I[k + 1]])
                d = xf(M, P[I[k + 2]])
                ux, uy, uz = c[0] - a[0], c[1] - a[1], c[2] - a[2]
                vx, vy, vz = d[0] - a[0], d[1] - a[1], d[2] - a[2]
                nx = uy * vz - uz * vy
                ny = uz * vx - ux * vz
                nz = ux * vy - uy * vx
                area = 0.5 * math.sqrt(nx * nx + ny * ny + nz * nz)
                tris.append((area, (a[0] + c[0] + d[0]) / 3, (a[1] + c[1] + d[1]) / 3,
                             (a[2] + c[2] + d[2]) / 3,
                             round(a[0], 1), round(a[1], 1), round(a[2], 1),
                             round(d[0], 1), round(d[1], 1), round(d[2], 1)))

    tris.sort(reverse=True)
    total = sum(t[0] for t in tris)
    print("triangles total {}   total area {:.1f}".format(len(tris), total))
    print("the {} largest by area:".format(topn))
    print("  area        centroid(x,y,z)                 start(x,y,z)           end(x,y,z)")
    for t in tris[:topn]:
        print("  {:10.1f}  ({:9.1f},{:9.1f},{:9.1f})   ({:9.1f},{:9.1f},{:9.1f})  ({:9.1f},{:9.1f},{:9.1f})"
              .format(t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8], t[9]))
    # Cumulative area share
    for frac in (0.1, 0.25, 0.5):
        c, s = 0, 0.0
        for t in tris:
            s += t[0]
            c += 1
            if s >= total * frac:
                break
        print("first {:5d} triangles ({:.0f}%) cover {:.0f}% of the area".format(c, c * 100.0 / len(tris), frac * 100))


if __name__ == "__main__":
    main()
