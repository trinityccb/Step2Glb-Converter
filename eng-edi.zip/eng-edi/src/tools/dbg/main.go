// dbg is an internal diagnostic tool: it runs the full parse + face extraction +
// tessellation pipeline and prints the real reasons for degradation/failure, so
// the weak spots of the geometry kernel can be located.
//
// Usage: dbg <file.stp> [tolRatio] [--sample N]
//
//	tolRatio    chord tolerance as a fraction of the model diagonal (default 0.0015)
//	--sample N  additionally print details of the first N failed faces (default 0)
package main

import (
	"fmt"
	"math"
	"os"
	"sort"
	"strconv"
	"time"

	"stp2glb-lite/internal/step"
)

func main() {
	args := os.Args[1:]
	sample := 0
	pts := 0
	var pos []string
	for i := 0; i < len(args); i++ {
		if args[i] == "--sample" && i+1 < len(args) {
			sample, _ = strconv.Atoi(args[i+1])
			i++
			continue
		}
		if args[i] == "--pts" && i+1 < len(args) {
			pts, _ = strconv.Atoi(args[i+1])
			i++
			continue
		}
		pos = append(pos, args[i])
	}
	if len(pos) < 1 {
		fmt.Println("usage: dbg <file.stp> [tolRatio] [--sample N]")
		os.Exit(2)
	}
	ratio := 0.0015
	if len(pos) > 1 {
		if v, err := strconv.ParseFloat(pos[1], 64); err == nil {
			ratio = v
		}
	}

	data, err := os.ReadFile(pos[0])
	if err != nil {
		fmt.Println("read failed:", err)
		os.Exit(1)
	}
	t0 := time.Now()
	f, err := step.Parse(data)
	if err != nil {
		fmt.Println("parse failed:", err)
		os.Exit(1)
	}
	data = nil
	fmt.Printf("entities %d  schema %s  parse %.0fms\n", len(f.Entities), f.Schema, ms(t0))

	g := step.NewGeom(f)
	plan := g.PlanAssembly()
	mn, mx := plan.Min, plan.Max
	diag := mx.Sub(mn).Len()
	tol := diag * ratio
	fmt.Printf("bounding box (%g, %g, %g) ~ (%g, %g, %g)\ndiagonal %.1f  tolerance %.5f\n",
		mn.X, mn.Y, mn.Z, mx.X, mx.Y, mx.Z, diag, tol)
	if rd := plan.RawMax.Sub(plan.RawMin).Len(); rd > diag*2 {
		fmt.Printf("(raw vertex diagonal %.0f, collapsed by assembly transforms)\n", rd)
	}

	t1 := time.Now()
	faces, est := plan.Extract(step.SampleOpts{Tol: tol})
	fmt.Printf("extracted faces %d (shells %d, assembly %d/%d instances, duplicates removed %d)  %.0fms\n",
		est.FaceInstances, est.Shells, est.AssemblyNodes, est.AssemblyInstances,
		est.DuplicateShapes, ms(t1))
	fmt.Printf("unknown curves %v\nunknown surfaces %v\n", g.Stats.UnknownCurves, g.Stats.UnknownSurfaces)

	t2 := time.Now()
	mesh, ts := step.Tessellate(faces, step.TessOpts{
		Tol: tol, MaxDepth: 6, MaxLoopPts: 6000, MaxPerFace: 500000,
	})
	fmt.Printf("tessellation %.0fms  ok %d failed %d degraded %d  triangles %d\n",
		ms(t2), ts.FacesOK, ts.FacesFailed, ts.FacesDegraded, len(mesh.Indices)/3)

	fmt.Println("\n=== face type distribution ===")
	printTop(ts.BySurface, 20)
	fmt.Println("\n=== degradation/failure reasons ===")
	printTop(ts.DegradedByReason, 30)

	// Per-face triangle ranking: locate the source of the density behind "volume ratio >100%".
	byID2 := map[int]*step.FaceGeom{}
	for _, fg := range faces {
		byID2[fg.ID] = fg
	}
	dense := make([]faceStat, 0, len(ts.FaceTris))
	for id, n := range ts.FaceTris {
		dense = append(dense, faceStat{id, n})
	}
	sort.Slice(dense, func(i, j int) bool {
		if dense[i].tris != dense[j].tris {
			return dense[i].tris > dense[j].tris
		}
		return dense[i].id < dense[j].id
	})
	fmt.Println("\n=== 15 faces with the most triangles ===")
	for i, e := range dense {
		if i >= 15 {
			break
		}
		fg := byID2[e.id]
		if fg == nil {
			continue
		}
		fmt.Printf("  %7d tris  #%-7d %-26s outer %4d inner %2d\n",
			e.tris, e.id, fg.SurfaceType, len(fg.Outer), len(fg.Inners))
	}
	tot := 0
	for _, e := range dense {
		tot += e.tris
	}
	fmt.Printf("  total %d faces / %d triangles, mean %.1f, median face %.1f\n",
		len(dense), tot, float64(tot)/float64(max(1, len(dense))),
		medianTris(dense))

	if sample > 0 {
		byID := map[int]*step.FaceGeom{}
		for _, fg := range faces {
			byID[fg.ID] = fg
		}
		ids := make([]int, 0, len(ts.FaceReason))
		for id := range ts.FaceReason {
			ids = append(ids, id)
		}
		sort.Ints(ids)
		fmt.Printf("\n=== details (first %d / %d) ===\n", sample, len(ids))
		for i, id := range ids {
			if i >= sample {
				break
			}
			fg := byID[id]
			if fg == nil {
				continue
			}
			fmt.Printf("#%-8d %-26s outer %4d inner %2d  %s\n",
				id, fg.SurfaceType, len(fg.Outer), len(fg.Inners), ts.FaceReason[id])
			if fg.Surface != nil {
				u0, u1 := fg.Surface.RangeU()
				v0, v1 := fg.Surface.RangeV()
				fmt.Printf("    %T u=[%.4f,%.4f] v=[%.4f,%.4f] periodic %v/%v\n",
					fg.Surface, u0, u1, v0, v1, fg.Surface.PeriodicU(), fg.Surface.PeriodicV())
				fmt.Printf("    surface sample bbox %v  loop bbox %v\n",
					sampleBox(fg.Surface, 9), loopBox(fg.Outer))
				if pts > 0 {
					gu, gv := (u0+u1)/2, (v0+v1)/2
					n := 0
					for _, p := range fg.Outer {
						if n >= pts {
							break
						}
						n++
						u, v, _ := fg.Surface.Project(p, gu, gv)
						d := fg.Surface.Point(u, v).Dist(p)
						bu, bv, bd := brute(fg.Surface, p, 60)
						fmt.Printf("      p=(%12.4f,%12.4f,%12.4f) -> uv=(%12.6f,%12.6f) residual %.5g   brute uv=(%.6f,%.6f) %.5g\n",
							p.X, p.Y, p.Z, u, v, d, bu, bv, bd)
						gu, gv = u, v
					}
				}
			}
		}
	}
}

func ms(t time.Time) float64 { return float64(time.Since(t).Microseconds()) / 1000 }

// sampleBox samples the surface uniformly in the parameter domain and reports the
// spatial extent it actually covers.
func sampleBox(s step.Surface, n int) string {
	u0, u1 := s.RangeU()
	v0, v1 := s.RangeV()
	if !isF(u0) || !isF(u1) || !isF(v0) || !isF(v1) {
		return "(unbounded parameter domain)"
	}
	mn := step.Vec3{X: 1e300, Y: 1e300, Z: 1e300}
	mx := step.Vec3{X: -1e300, Y: -1e300, Z: -1e300}
	for i := 0; i <= n; i++ {
		for j := 0; j <= n; j++ {
			p := s.Point(u0+(u1-u0)*float64(i)/float64(n), v0+(v1-v0)*float64(j)/float64(n))
			mn, mx = mn.Min(p), mx.Max(p)
		}
	}
	return fmt.Sprintf("(%g,%g,%g)~(%g,%g,%g)", mn.X, mn.Y, mn.Z, mx.X, mx.Y, mx.Z)
}

func loopBox(pts []step.Vec3) string {
	if len(pts) == 0 {
		return "(empty)"
	}
	mn, mx := pts[0], pts[0]
	for _, p := range pts[1:] {
		mn, mx = mn.Min(p), mx.Max(p)
	}
	return fmt.Sprintf("(%g,%g,%g)~(%g,%g,%g)  span %g", mn.X, mn.Y, mn.Z, mx.X, mx.Y, mx.Z,
		mx.Sub(mn).Len())
}

func isF(f float64) bool { return !math.IsNaN(f) && !math.IsInf(f, 0) }

// brute runs a coarse grid brute-force search over the whole parameter domain and
// then refines locally, giving "the true shortest distance from the point to the
// surface". It is used to tell "Gauss-Newton did not converge" apart from "this
// point is simply not on the surface".
func brute(s step.Surface, p step.Vec3, n int) (float64, float64, float64) {
	u0, u1 := s.RangeU()
	v0, v1 := s.RangeV()
	if !isF(u0) || !isF(u1) || !isF(v0) || !isF(v1) {
		return 0, 0, math.Inf(1)
	}
	bu, bv, bd := u0, v0, math.Inf(1)
	for i := 0; i <= n; i++ {
		for j := 0; j <= n; j++ {
			u := u0 + (u1-u0)*float64(i)/float64(n)
			v := v0 + (v1-v0)*float64(j)/float64(n)
			if d := s.Point(u, v).Dist(p); d < bd {
				bu, bv, bd = u, v, d
			}
		}
	}
	// Local refinement: start from the best grid point and halve the step repeatedly.
	su, sv := (u1-u0)/float64(n), (v1-v0)/float64(n)
	for k := 0; k < 40; k++ {
		improved := false
		for di := -1; di <= 1; di++ {
			for dj := -1; dj <= 1; dj++ {
				u := clamp(bu+float64(di)*su, u0, u1)
				v := clamp(bv+float64(dj)*sv, v0, v1)
				if d := s.Point(u, v).Dist(p); d < bd {
					bu, bv, bd, improved = u, v, d, true
				}
			}
		}
		if !improved {
			su, sv = su/2, sv/2
		}
	}
	return bu, bv, bd
}

func clamp(x, lo, hi float64) float64 {
	if x < lo {
		return lo
	}
	if x > hi {
		return hi
	}
	return x
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func medianTris(d []faceStat) float64 {
	if len(d) == 0 {
		return 0
	}
	v := make([]int, len(d))
	for i, e := range d {
		v[i] = e.tris
	}
	sort.Ints(v)
	return float64(v[len(v)/2])
}

// faceStat is the per-face triangle statistics entry.
type faceStat struct {
	id   int
	tris int
}

func printTop(m map[string]int, n int) {
	type kv struct {
		k string
		v int
	}
	arr := make([]kv, 0, len(m))
	for k, v := range m {
		arr = append(arr, kv{k, v})
	}
	sort.Slice(arr, func(i, j int) bool {
		if arr[i].v != arr[j].v {
			return arr[i].v > arr[j].v
		}
		return arr[i].k < arr[j].k
	})
	if len(arr) == 0 {
		fmt.Println("  (none)")
	}
	for i, e := range arr {
		if i >= n {
			break
		}
		fmt.Printf("  %7d  %s\n", e.v, e.k)
	}
}
