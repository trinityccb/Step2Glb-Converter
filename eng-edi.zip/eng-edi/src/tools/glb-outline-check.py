"""GLB outline structure checker (pure standard library, independent of the Go kernel's
read-back validation).

Usage:
    python tools/glb-outline-check.py <file.glb> [more.glb ...]

Checks:
  1. the primitive makeup of each mesh (mode / attributes / material)
  2. whether LINES primitives have an even number of indices and whether they are in range
  3. whether line vertices fall inside the bounding box of the triangle vertices
     (lines must not float outside the model)
  4. segment length distribution (share of degenerate zero-length segments)
  5. whether materials only appear when lines exist (otherwise Khronos reports UNUSED_OBJECT)
"""

import json
import math
import struct
import sys


def load_glb(path):
    data = open(path, "rb").read()
    if data[:4] != b"glTF":
        raise SystemExit("%s is not a GLB" % path)
    off, js, bin_ = 12, None, b""
    while off + 8 <= len(data):
        ln, ty = struct.unpack_from("<II", data, off)
        body = data[off + 8:off + 8 + ln]
        if ty == 0x4E4F534A:
            js = json.loads(body.decode("utf-8"))
        elif ty == 0x004E4942:
            bin_ = body
        off += 8 + ln + ((4 - ln % 4) % 4 if ln % 4 else 0)
    return js, bin_, data


def read_acc(g, bin_, i):
    a = g["accessors"][i]
    bv = g["bufferViews"][a["bufferView"]]
    fmt, size = {5126: ("f", 4), 5125: ("I", 4), 5123: ("H", 2)}[a["componentType"]]
    n = {"SCALAR": 1, "VEC3": 3}[a["type"]]
    start = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    vals = struct.unpack_from("<%d%s" % (a["count"] * n, fmt), bin_, start)
    return [vals[k * n:(k + 1) * n] for k in range(a["count"])]


def check(path):
    g, bin_, raw = load_glb(path)
    problems = []
    mats = g.get("materials") or []
    used_mat = set()
    n_tri = n_line = 0
    tri_bbox = None
    line_bbox = None
    seg_lens = []
    line_hits = []

    for mi, m in enumerate(g.get("meshes", [])):
        tri_pts = None
        for pr in m.get("primitives", []):
            mode = pr.get("mode", 4)
            if "material" in pr:
                used_mat.add(pr["material"])
            if mode == 4:
                n_tri += 1
                pos = read_acc(g, bin_, pr["attributes"]["POSITION"])
                if tri_pts is None:
                    tri_pts = pos
                else:
                    tri_pts = tri_pts + pos
                lo = [min(p[k] for p in pos) for k in range(3)]
                hi = [max(p[k] for p in pos) for k in range(3)]
                tri_bbox = _merge(tri_bbox, (lo, hi))
            elif mode == 1:
                n_line += 1
                pos = read_acc(g, bin_, pr["attributes"]["POSITION"])
                idx = [v[0] for v in read_acc(g, bin_, pr["indices"])]
                if len(idx) % 2:
                    problems.append("mesh[%d] LINES index count is odd: %d" % (mi, len(idx)))
                if idx and (min(idx) < 0 or max(idx) >= len(pos)):
                    problems.append("mesh[%d] LINES index out of range (max=%d, vertices=%d)"
                                    % (mi, max(idx), len(pos)))
                lo = [min(p[k] for p in pos) for k in range(3)]
                hi = [max(p[k] for p in pos) for k in range(3)]
                line_bbox = _merge(line_bbox, (lo, hi))
                for k in range(0, len(idx) - 1, 2):
                    a, b = pos[idx[k]], pos[idx[k + 1]]
                    seg_lens.append(math.dist(a, b))
                if tri_pts:
                    hit = _vertex_hit_rate(pos, tri_pts)
                    line_hits.append((m.get("name", "mesh%d" % mi), hit, len(pos)))
            else:
                problems.append("mesh[%d] unknown mode=%d" % (mi, mode))

    if not mats and n_line:
        problems.append("LINES primitives exist but there are no materials")
    if mats and len(used_mat) < len(mats):
        problems.append("%d materials are not referenced by any primitive" % (len(mats) - len(used_mat)))

    # Lines must stay inside the triangle bounding box (1% margin to absorb float32 rounding)
    if line_bbox and tri_bbox:
        diag = math.dist(tri_bbox[0], tri_bbox[1]) or 1.0
        pad = diag * 0.01
        for k in range(3):
            if line_bbox[0][k] < tri_bbox[0][k] - pad or line_bbox[1][k] > tri_bbox[1][k] + pad:
                problems.append("line bounding box exceeds the triangle bounding box: axis %d line[%.3f,%.3f] face[%.3f,%.3f]"
                                % (k, line_bbox[0][k], line_bbox[1][k],
                                   tri_bbox[0][k], tri_bbox[1][k]))

    zero = sum(1 for l in seg_lens if l < 1e-9)
    stat = "triangle primitives %d / line primitives %d / segments %d / materials %d" % (
        n_tri, n_line, len(seg_lens), len(mats))
    if seg_lens:
        stat += " / segment length %.4g~%.4g, zero-length %d" % (min(seg_lens), max(seg_lens), zero)
    print("  " + stat)
    print("  GLB %.1f KB (JSON %.1f KB + BIN %.1f KB)"
          % (len(raw) / 1024, 0, len(bin_) / 1024))
    # How many line vertices land exactly on a triangle vertex: the endpoints of a B-Rep
    # edge necessarily become mesh vertices when tessellating, so a high ratio means the
    # lines really do follow the surface rather than float in the air. Intermediate points
    # of curved edges (arcs etc.) are not mesh vertices, which is normal, so this only
    # warns, it does not fail.
    if line_hits:
        tot_n = sum(h[2] for h in line_hits)
        tot_hit = sum(h[1] * h[2] for h in line_hits)
        rate = tot_hit / tot_n if tot_n else 0.0
        print("  line points hitting triangle vertices: %.1f%% (%d / %d points; intermediate points of curved edges not hitting is normal)"
              % (rate * 100, int(tot_hit), tot_n))
        if rate < 0.30:
            problems.append("only %.1f%% of line points hit triangle vertices, coordinate spaces look inconsistent"
                            % (rate * 100))
    return problems


def _vertex_hit_rate(line_pts, tri_pts, eps=1e-3):
    """How many line points land exactly on some triangle vertex (compared after quantizing by eps)."""
    q = 1.0 / eps
    key = lambda p: (round(p[0] * q), round(p[1] * q), round(p[2] * q))
    have = {key(p) for p in tri_pts}
    hit = sum(1 for p in line_pts if key(p) in have)
    return hit / len(line_pts) if line_pts else 0.0


def _merge(cur, new):
    if cur is None:
        return new
    return ([min(a, b) for a, b in zip(cur[0], new[0])],
            [max(a, b) for a, b in zip(cur[1], new[1])])


def main():
    files = sys.argv[1:]
    if not files:
        print(__doc__)
        return 1
    bad = 0
    for p in files:
        print("=" * 66)
        print(p)
        try:
            probs = check(p)
        except Exception as e:
            print("  [error] %r" % (e,))
            bad += 1
            continue
        if probs:
            bad += 1
            for q in probs:
                print("  [problem] " + q)
        else:
            print("  OK: structure check passed")
    print("=" * 66)
    print("%d files, %d with problems" % (len(files), bad))
    return 0 if bad == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
