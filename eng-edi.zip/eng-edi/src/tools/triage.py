# -*- coding: utf-8 -*-
"""Turn the [hoarea] / [hcover] / [holes] / [ear] diagnostic output into sortable tables."""
import re
import sys

LOG = sys.argv[1] if len(sys.argv) > 1 else "run.log"

hoarea = re.compile(
    r"\[hoarea\] face #(\d+) (\S+) inner loops (\d+) got ([\d.eE+-]+) expected ([\d.eE+-]+) deviation ([+-][\d.]+)%")
hcover = re.compile(
    r"\[hcover\] face #(\d+) (\S+) \* hole covered: (\d+)/(\d+) hole points fall inside (\d+) triangles")
holes = re.compile(r"\[holes\] face #(\d+) 3D inner loops (\d+) -> parameter-domain inner loops (\d+) \((\S+)\)")
ear = re.compile(r"\[ear\] face #(\d+) area anomaly: got ([\d.]+), expected ([\d.]+) \(deviation ([+-][\d.]+)%; holes (\d+), bridges without visible points (\d+), forced rejects (\d+)\)")

rows = []
covered_by = {}
hole_mismatch = {}
ear_rows = []

for line in open(LOG, encoding="utf-8", errors="replace"):
    m = hoarea.search(line)
    if m:
        rows.append(dict(fid=int(m.group(1)), path=m.group(2), nh=int(m.group(3)),
                         got=float(m.group(4)), want=float(m.group(5)), dev=float(m.group(6))))
        continue
    m = hcover.search(line)
    if m:
        covered_by[int(m.group(1))] = (int(m.group(3)), int(m.group(4)), int(m.group(5)), m.group(2))
        continue
    m = holes.search(line)
    if m:
        f3, f2 = int(m.group(2)), int(m.group(3))
        if f3 > f2:
            hole_mismatch[int(m.group(1))] = (f3, f2, m.group(4))
        continue
    m = ear.search(line)
    if m:
        ear_rows.append(dict(fid=int(m.group(1)), got=float(m.group(2)), want=float(m.group(3)),
                             dev=float(m.group(4)), nh=int(m.group(5)),
                             novis=int(m.group(6)), forced=int(m.group(7))))

print("faces with holes recorded %d; hcover hits %d faces; inner loops dropped %d faces; [ear] >2%% anomalies %d faces"
      % (len(rows), len(covered_by), len(hole_mismatch), len(ear_rows)))

pos = sorted([r for r in rows if r["dev"] > 2.0], key=lambda r: -r["dev"])
print("")
print("=== area too large > +2pct (holes not subtracted), %d faces ===" % len(pos))
for r in pos[:30]:
    extra = covered_by.get(r["fid"])
    tag = ""
    if extra:
        tag = "  hcover %d/%d pts/%d tris" % extra[:3]
    if r["fid"] in hole_mismatch:
        tag += "  inner loops %d->%d" % hole_mismatch[r["fid"]][:2]
    print("  face #%-9d %-22s inner%-3d deviation %+8.2f%%  excess area %12.3f%s"
          % (r["fid"], r["path"], r["nh"], r["dev"], abs(r["got"] - r["want"]), tag))

neg = sorted([r for r in rows if r["dev"] < -2.0], key=lambda r: r["dev"])
print("")
print("=== area too small < -2pct (faces lost triangles), %d faces, first 15 ===" % len(neg))
for r in neg[:15]:
    print("  face #%-9d %-22s inner%-3d deviation %+8.2f%%" % (r["fid"], r["path"], r["nh"], r["dev"]))

print("")
print("=== hcover sorted by severity (highest share of covered hole points first) ===")
sev = sorted(covered_by.items(), key=lambda kv: -(kv[1][0] / max(1, kv[1][1])))
for fid, (cov, hp, ft, path) in sev[:30]:
    r = next((x for x in rows if x["fid"] == fid), None)
    dev = ("%+8.2f%%" % r["dev"]) if r else "   n/a "
    print("  face #%-9d %-22s covers %3d/%-3d points (%5.1f%%) inside %2d triangles  area deviation %s"
          % (fid, path, cov, hp, 100.0 * cov / max(1, hp), ft, dev))
