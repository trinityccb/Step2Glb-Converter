#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Check whether the geometric representations in the same REPRESENTATION_CONTEXT group really
are repeated versions of the same part.

The kernel discards the lower-priority geometric representation in the same context group as
an "alternative representation". Before discarding it, one must confirm that it **coincides
geometrically** with the primary one: if a discarded representation actually contains
faces/vertices the primary one lacks, that is lost geometry, not de-duplication.

Criteria:
  - Jaccard coefficient of the vertex sets (intersection/union)
  - whether the primary contains the alternative (subset relation)
  - whether the local bounding boxes of the two agree

Usage: python alt-check.py <file.stp>
"""
import re
import sys
import collections

REF_RE = re.compile(r'#(\d+)')
NUM_RE = re.compile(r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?')
TY_RE = re.compile(r'^#(\d+)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*;\s*$', re.S)
CX_RE = re.compile(r'^#(\d+)\s*=\s*\((.*)\)\s*;\s*$', re.S)


def main():
    path = sys.argv[1]
    ents = {}
    for line in open(path, 'r', encoding='utf-8', errors='replace'):
        if not line.startswith('#'):
            continue
        s = line.rstrip('\r\n')
        m = TY_RE.match(s)
        if m:
            ents[int(m.group(1))] = [m.group(2), m.group(3)]
        else:
            m = CX_RE.match(s)
            if m:
                ents[int(m.group(1))] = [None, m.group(2)]

    def refs(b):
        return [int(x) for x in REF_RE.findall(b)]

    def args(b):
        out, d, cur, ins = [], 0, [], False
        for c in b:
            if ins:
                cur.append(c)
                if c == "'":
                    ins = False
                continue
            if c == "'":
                ins = True
                cur.append(c)
            elif c == '(':
                d += 1
                cur.append(c)
            elif c == ')':
                d -= 1
                cur.append(c)
            elif c == ',' and d == 0:
                out.append(''.join(cur).strip())
                cur = []
            else:
                cur.append(c)
        out.append(''.join(cur).strip())
        return out

    pts = {}
    for i, (t, b) in ents.items():
        if t == 'CARTESIAN_POINT':
            n = [float(x) for x in NUM_RE.findall(args(b)[-1])]
            if len(n) >= 3:
                pts[i] = tuple(round(v, 3) for v in n[:3])
    vtx = {}
    for i, (t, b) in ents.items():
        if t == 'VERTEX_POINT':
            r = refs(b)
            if r and r[0] in pts:
                vtx[i] = pts[r[0]]
    oe = {}
    for i, (t, b) in ents.items():
        if t == 'ORIENTED_EDGE':
            r = refs(b)
            if r:
                oe[i] = r[0]
    ev = {}
    for i, (t, b) in ents.items():
        if t == 'EDGE_CURVE':
            r = refs(b)
            ev[i] = [vtx.get(r[0]), vtx.get(r[1])] if len(r) >= 2 else []
    le = collections.defaultdict(list)
    for i, (t, b) in ents.items():
        if t == 'EDGE_LOOP':
            for r in refs(b):
                if r in oe:
                    le[i].extend(x for x in ev.get(oe[r], []) if x)
    bl = {}
    for i, (t, b) in ents.items():
        if t in ('FACE_OUTER_BOUND', 'FACE_BOUND'):
            r = refs(b)
            if r:
                bl[i] = r[0]
    fp = {}
    for i, (t, b) in ents.items():
        if t == 'ADVANCED_FACE':
            vs = []
            for r in refs(b):
                if r in bl:
                    vs.extend(le.get(bl[r], []))
            fp[i] = vs

    shell_faces = {}
    for i, (t, b) in ents.items():
        if t in ('CLOSED_SHELL', 'OPEN_SHELL'):
            shell_faces[i] = [r for r in refs(b) if r in fp]
    size = {}
    for i, (t, b) in ents.items():
        if t == 'SHELL_BASED_SURFACE_MODEL':
            vs = []
            for r in refs(b):
                vs.extend(shell_faces.get(r, []))
            size[i] = vs
        elif t == 'MANIFOLD_SOLID_BREP':
            vs = []
            for r in refs(b):
                vs.extend(shell_faces.get(r, []))
            size[i] = vs

    def faces_of_item(it):
        if it in fp:
            return [it]
        return size.get(it, [])

    def is_sr(t):
        if t is None:
            return False
        if 'RELATIONSHIP' in t or t.startswith('CONTEXT_DEPENDENT'):
            return False
        return 'SHAPE_REPRESENTATION' in t

    def is_ctx(i):
        e = ents.get(i)
        return bool(e and e[0] is None and 'REPRESENTATION_CONTEXT' in e[1])

    srs, ctx_of, verts_of, box_of = {}, {}, {}, {}
    for i, (t, b) in ents.items():
        if not is_sr(t):
            continue
        srs[i] = t
        r = refs(b)
        ctx_of[i] = r[-1] if r else 0
        fs, seen = [], set()
        for it in [x for x in r if not is_ctx(x)]:
            for f in faces_of_item(it):
                if f not in seen:
                    seen.add(f)
                    fs.append(f)
        v = set()
        lo = [1e30] * 3
        hi = [-1e30] * 3
        for f in fs:
            for p in fp.get(f, []):
                v.add(p)
                for k in range(3):
                    lo[k] = min(lo[k], p[k])
                    hi[k] = max(hi[k], p[k])
        verts_of[i] = v
        box_of[i] = (tuple(lo), tuple(hi)) if v else None

    def rank(t):
        return {'ADVANCED_BREP_SHAPE_REPRESENTATION': 4,
                'MANIFOLD_SURFACE_SHAPE_REPRESENTATION': 3,
                'GEOMETRICALLY_BOUNDED_SURFACE_SHAPE_REPRESENTATION': 2,
                'GEOMETRICALLY_BOUNDED_WIREFRAME_SHAPE_REPRESENTATION': 2,
                'SHAPE_REPRESENTATION': 1}.get(t, 0)

    groups = collections.defaultdict(list)
    for sr, c in ctx_of.items():
        if c:
            groups[c].append(sr)

    bad = 0
    total_dropped_faces = 0
    print('=== same-context group check ===')
    for c, members in sorted(groups.items()):
        if len(members) < 2:
            continue
        geoms = [s for s in members if verts_of[s]]
        frames = [s for s in members if not verts_of[s]]
        if len(geoms) < 2 or not frames:
            continue          # only one geometry, or no frame: the kernel leaves it alone
        best = max(geoms, key=lambda s: (rank(srs[s]), len(verts_of[s])))
        bv = verts_of[best]
        bl_, bh = box_of[best]
        for g in geoms:
            if g == best:
                continue
            gv = verts_of[g]
            inter = len(bv & gv)
            union = len(bv | gv)
            sub = gv <= bv
            gl, gh = box_of[g]
            same_box = all(abs(bl_[k] - gl[k]) < 1e-6 and abs(bh[k] - gh[k]) < 1e-6
                           for k in range(3))
            tag = 'OK' if (sub or inter / max(union, 1) > 0.6) else '**SUSPICIOUS**'
            if tag != 'OK':
                bad += 1
            boxdelta = max(max(abs(bl_[k] - gl[k]), abs(bh[k] - gh[k])) for k in range(3))
            print('  context #%-8s primary #%-8d(%s, %d vertices)  '
                  'alt #%-8d(%s, %d vertices)  Jaccard=%.2f subset=%s box delta=%.4f  %s'
                  % (c, best, srs[best], len(bv), g, srs[g], len(gv),
                     inter / max(union, 1), sub, boxdelta, tag))
            if boxdelta > 0.5:
                print('        primary box %s ~ %s' % (tuple(round(v, 3) for v in bl_),
                                                       tuple(round(v, 3) for v in bh)))
                print('        alt box %s ~ %s' % (tuple(round(v, 3) for v in gl),
                                                   tuple(round(v, 3) for v in gh)))
    print('\nsuspicious alternative representations: %d' % bad)


if __name__ == '__main__':
    main()
