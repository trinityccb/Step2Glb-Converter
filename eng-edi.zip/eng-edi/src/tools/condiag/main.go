//go:build windows

// condiag -- run a command in a real console and read the console **screen contents** back.
//
// Purpose: verify "what Chinese text actually looks like in a Windows console". Plain
// output redirection only yields a byte stream and never shows the final rendering of
// the terminal (encoding mismatches and missing font glyphs only surface on screen).
// Here ReadConsoleOutputCharacterW reads the screen buffer directly, so what we get is
// "the very characters the user's eyes see".
//
// Usage:
//
//	condiag [-cp N] [-out file] <exe> [args...]
//
//	cp  0 (default) = leave the code page alone; otherwise SetConsoleOutputCP(N) first
//
// Output file contents: a console status block first, then the characters on screen.
package main

import (
	"fmt"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"syscall"
	"unsafe"
)

var (
	k32 = syscall.NewLazyDLL("kernel32.dll")

	pAllocConsole                = k32.NewProc("AllocConsole")
	pFreeConsole                 = k32.NewProc("FreeConsole")
	pGetConsoleMode              = k32.NewProc("GetConsoleMode")
	pGetConsoleOutputCP          = k32.NewProc("GetConsoleOutputCP")
	pSetConsoleOutputCP          = k32.NewProc("SetConsoleOutputCP")
	pGetConsoleScreenBufferInfo  = k32.NewProc("GetConsoleScreenBufferInfo")
	pSetConsoleScreenBufferSize  = k32.NewProc("SetConsoleScreenBufferSize")
	pReadConsoleOutputCharacterW = k32.NewProc("ReadConsoleOutputCharacterW")
)

type coord struct{ X, Y int16 }

type smallRect struct{ Left, Top, Right, Bottom int16 }

type consoleScreenBufferInfo struct {
	Size              coord
	CursorPosition    coord
	Attributes        uint16
	Window            smallRect
	MaximumWindowSize coord
}

func main() {
	args := os.Args[1:]
	cp := 0
	out := "condiag-screen.txt"
	cols := int16(160)
	for len(args) >= 2 {
		switch args[0] {
		case "-cp":
			cp, _ = strconv.Atoi(args[1])
			args = args[2:]
			continue
		case "-out":
			out = args[1]
			args = args[2:]
			continue
		case "-cols":
			n, _ := strconv.Atoi(args[1])
			cols = int16(n)
			args = args[2:]
			continue
		}
		break
	}
	if len(args) == 0 {
		fmt.Fprintln(os.Stderr, "usage: condiag [-cp N] [-out file] <exe> [args...]")
		os.Exit(2)
	}

	// 1) Get a console: reuse an existing one, otherwise allocate our own.
	con, err := os.OpenFile("CONOUT$", os.O_RDWR, 0)
	if err != nil {
		if r, _, e := pAllocConsole.Call(); r == 0 {
			fmt.Fprintln(os.Stderr, "no console and AllocConsole failed:", e)
			os.Exit(2)
		}
		defer pFreeConsole.Call()
		con, err = os.OpenFile("CONOUT$", os.O_RDWR, 0)
		if err != nil {
			fmt.Fprintln(os.Stderr, "still cannot open CONOUT$ after allocating a console:", err)
			os.Exit(2)
		}
	}
	defer con.Close()

	h := con.Fd()
	var mode uint32
	_, _, _ = pGetConsoleMode.Call(h, uintptr(unsafe.Pointer(&mode)))

	// 2) Enlarge the buffer so content is not scrolled out of view.
	_, _, _ = pSetConsoleScreenBufferSize.Call(h, uintptr(uint32(cols)|uint32(400)<<16))

	var sb consoleScreenBufferInfo
	_, _, _ = pGetConsoleScreenBufferInfo.Call(h, uintptr(unsafe.Pointer(&sb)))

	origCP, _, _ := pGetConsoleOutputCP.Call()
	if cp != 0 {
		if r, _, _ := pSetConsoleOutputCP.Call(uintptr(cp)); r == 0 {
			fmt.Fprintln(os.Stderr, "SetConsoleOutputCP failed")
		}
	}
	nowCP, _, _ := pGetConsoleOutputCP.Call()

	// 3) Run the child process and let it inherit this console.
	cin, _ := os.OpenFile("CONIN$", os.O_RDWR, 0)
	c := exec.Command(args[0], args[1:]...)
	c.Stdout, c.Stderr = con, con
	if cin != nil {
		c.Stdin = cin
	}
	runErr := c.Run()

	// 4) Read the screen back.
	_, _, _ = pGetConsoleScreenBufferInfo.Call(h, uintptr(unsafe.Pointer(&sb)))
	width := int(sb.Window.Right - sb.Window.Left + 1)
	height := int(sb.Window.Bottom - sb.Window.Top + 1)
	if width <= 0 {
		width = int(cols)
	}
	if height <= 0 {
		height = 400
	}
	var lines []string
	buf := make([]uint16, width)
	for y := 0; y < height; y++ {
		var n uint32
		// COORD is passed by value: two int16s packed into one register.
		packed := uintptr(uint16(0)) | uintptr(uint16(y))<<16
		r, _, _ := pReadConsoleOutputCharacterW.Call(h,
			uintptr(unsafe.Pointer(&buf[0])), uintptr(width),
			packed, uintptr(unsafe.Pointer(&n)))
		if r == 0 || n == 0 {
			break
		}
		lines = append(lines, syscall.UTF16ToString(buf[:n]))
	}
	for len(lines) > 0 && strings.TrimSpace(lines[len(lines)-1]) == "" {
		lines = lines[:len(lines)-1]
	}

	// 5) Write to disk (UTF-8).
	var b strings.Builder
	fmt.Fprintf(&b, "[condiag] original code page=%d  requested=%d  actual code page=%d  mode=0x%04X\n",
		origCP, cp, nowCP, mode)
	fmt.Fprintf(&b, "[condiag] child process %v  exit=%v\n", args, runErr)
	fmt.Fprintf(&b, "[condiag] screen window %dx%d, read %d lines\n", width, height, len(lines))
	b.WriteString("[condiag] ---------- screen contents (ReadConsoleOutputCharacterW) ----------\n")
	for _, l := range lines {
		b.WriteString(l)
		b.WriteString("\n")
	}
	if err := os.WriteFile(out, []byte(b.String()), 0o644); err != nil {
		fmt.Fprintln(os.Stderr, "write failed:", err)
		os.Exit(1)
	}
	fmt.Printf("wrote %s (%d lines)\n", out, len(lines))
}
