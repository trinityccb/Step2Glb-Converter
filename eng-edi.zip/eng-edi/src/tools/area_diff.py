"""Area accounting for A/B differing triangles: split the total area difference into
"only in A", "only in B" and "common" parts.

Usage: python area_diff.py old.glb new.glb [--digits 4] [--top 10]
"""
import struct, json, math, sys
from collections import Counter


def load(path):
    d = open(path, 'rb').read()
    assert d[:4] == b'glTF', path
    ln = struct.unpack('<I', d[12:16])[0]
    js = json.loads(d[20:20 + ln])
    off = 20 + ln
    bl = struct.unpack('<I', d[off:off + 4])[0]
    bin_ = d[off + 8:off + 8 + bl]

    def acc(i):
        a = js['accessors'][i]
        bv = js['bufferViews'][a['bufferView']]
        return bv.get('byteOffset', 0) + a.get('byteOffset', 0), a['componentType'], a['count']

    tris = []
    for m in js['meshes']:
        for p in m['primitives']:
            if p.get('mode', 4) != 4 or 'indices' not in p:
                continue
            ps, _, pn = acc(p['attributes']['POSITION'])
            is_, ict, ic = acc(p['indices'])
            pts = [struct.unpack('<3f', bin_[ps + i * 12: ps + i * 12 + 12]) for i in range(pn)]
            fmt = {5121: ('B', 1), 5123: ('H', 2), 5125: ('I', 4)}[ict]
            idx = [struct.unpack('<' + fmt[0], bin_[is_ + i * fmt[1]: is_ + i * fmt[1] + fmt[1]])[0]
                   for i in range(ic)]
            for i in range(0, len(idx) - 2, 3):
                a, b, c = idx[i], idx[i + 1], idx[i + 2]
                tris.append((pts[a], pts[b], pts[c]))
    return tris


def key(t, digits):
    return tuple(sorted(tuple(round(v, digits) for v in p) for p in t))


def area(t):
    ax, ay, az = t[0]
    bx, by, bz = t[1]
    cx, cy, cz = t[2]
    ux, uy, uz = bx - ax, by - ay, bz - az
    vx, vy, vz = cx - ax, cy - ay, cz - az
    nx = uy * vz - uz * vy
    ny = uz * vx - ux * vz
    nz = ux * vy - uy * vx
    return 0.5 * math.sqrt(nx * nx + ny * ny + nz * nz)


def main():
    a = sys.argv[1]
    b = sys.argv[2]
    digits = 4
    top = 8
    if '--digits' in sys.argv:
        digits = int(sys.argv[sys.argv.index('--digits') + 1])
    if '--top' in sys.argv:
        top = int(sys.argv[sys.argv.index('--top') + 1])

    A = load(a)
    B = load(b)
    ka = Counter(key(t, digits) for t in A)
    kb = Counter(key(t, digits) for t in B)
    onlyA = ka - kb
    onlyB = kb - ka
    common = ka & kb
    sa = sum(area(k) * n for k, n in onlyA.items())
    sb = sum(area(k) * n for k, n in onlyB.items())
    ca = sum(area(k) * n for k, n in common.items())
    print("A = %s" % a)
    print("B = %s" % b)
    print()
    print("only in A : %8d triangles  area %14.1f mm^2" % (sum(onlyA.values()), sa))
    print("only in B : %8d triangles  area %14.1f mm^2" % (sum(onlyB.values()), sb))
    print("common    : %8d triangles  area %14.1f mm^2" % (sum(common.values()), ca))
    print("A total   : %8d triangles  area %14.1f mm^2" % (len(A), ca + sa))
    print("B total   : %8d triangles  area %14.1f mm^2" % (len(B), ca + sb))
    ta, tb = ca + sa, ca + sb
    print("area diff : %+.1f mm^2 (%+.3f%%)" % (tb - ta, (tb - ta) / ta * 100))
    print()
    print("largest %d triangles only in A (these are the 'extra geometry that disappeared'):" % top)
    for k, n in sorted(onlyA.items(), key=lambda kv: -area(kv[0]) * kv[1])[:top]:
        print("   x%-3d area %13.1f   %s" % (n, area(k), k))
    print()
    print("largest %d triangles only in B (these are the 'newly grown geometry'):" % top)
    for k, n in sorted(onlyB.items(), key=lambda kv: -area(kv[0]) * kv[1])[:top]:
        print("   x%-3d area %13.1f   %s" % (n, area(k), k))


if __name__ == '__main__':
    main()
