#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""png-zoom.py -- pure standard library PNG crop + nearest-neighbor upscale, used to
enlarge garbled text in a screenshot until it can be read character by character.

Usage:
    python png-zoom.py <in.png> <out.png> [--box x,y,w,h] [--zoom N] [--gray]

    --box   crop region, defaults to the whole image; coordinates start at the top-left
    --zoom  upscale factor, default 4
    --gray  convert to grayscale before upscaling (easier to read at small font sizes)

Depends only on zlib/struct, no Pillow.
"""
import sys
import zlib
import struct


def read_png(path):
    """Return (w, h, pix, has_alpha), where pix is a per-pixel (r,g,b,a) byte sequence."""
    data = open(path, "rb").read()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG file")
    pos = 8
    w = h = bitdepth = colortype = None
    idat = bytearray()
    palette = None
    trns = None
    while pos < len(data):
        ln, = struct.unpack(">I", data[pos:pos + 4])
        typ = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        if typ == b"IHDR":
            w, h, bitdepth, colortype, comp, filt, interlace = struct.unpack(">IIBBBBB", body)
            if interlace:
                raise ValueError("interlaced PNG is not supported")
        elif typ == b"PLTE":
            palette = body
        elif typ == b"tRNS":
            trns = body
        elif typ == b"IDAT":
            idat += body
        elif typ == b"IEND":
            break
    raw = zlib.decompress(bytes(idat))

    # Bytes per pixel
    chan = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[colortype]
    if bitdepth == 8:
        bpp_bits = chan * 8
    elif bitdepth in (1, 2, 4):
        bpp_bits = bitdepth
    else:
        raise ValueError("unsupported bit depth %d" % bitdepth)
    stride_bits = w * bpp_bits
    stride = (stride_bits + 7) // 8
    bpp = max(1, (bpp_bits + 7) // 8)   # number of "pixel" bytes used by filtering (at least 1)

    out = bytearray(stride * h)
    prev = bytearray(stride)
    p = 0
    for y in range(h):
        f = raw[p]
        p += 1
        line = bytearray(raw[p:p + stride])
        p += stride
        if f == 1:
            for i in range(bpp, stride):
                line[i] = (line[i] + line[i - bpp]) & 0xFF
        elif f == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 0xFF
        elif f == 3:
            for i in range(stride):
                a = line[i - bpp] if i >= bpp else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 0xFF
        elif f == 4:
            for i in range(stride):
                a = line[i - bpp] if i >= bpp else 0
                b = prev[i]
                c = prev[i - bpp] if i >= bpp else 0
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 0xFF
        elif f != 0:
            raise ValueError("unknown filter type %d" % f)
        out[y * stride:(y + 1) * stride] = line
        prev = line

    # Unpack into RGB(A)
    pix = bytearray()
    has_alpha = colortype in (4, 6) or (colortype == 3 and trns is not None)
    if bitdepth == 8:
        for y in range(h):
            row = out[y * stride:(y + 1) * stride]
            for x in range(w):
                px = row[x * chan:(x + 1) * chan]
                if colortype == 0:
                    pix += bytes((px[0], px[0], px[0], 255))
                elif colortype == 2:
                    pix += bytes((px[0], px[1], px[2], 255))
                elif colortype == 3:
                    i = px[0]
                    a = trns[i] if (trns and i < len(trns)) else 255
                    pix += bytes((palette[i * 3], palette[i * 3 + 1], palette[i * 3 + 2], a))
                elif colortype == 4:
                    pix += bytes((px[0], px[0], px[0], px[1]))
                else:
                    pix += px
    else:
        per = 8 // bitdepth
        mask = (1 << bitdepth) - 1
        for y in range(h):
            row = out[y * stride:(y + 1) * stride]
            for x in range(w):
                bi = x // per
                shift = 8 - bitdepth * (x % per + 1)
                v = (row[bi] >> shift) & mask
                if colortype == 3:
                    a = trns[v] if (trns and v < len(trns)) else 255
                    pix += bytes((palette[v * 3], palette[v * 3 + 1], palette[v * 3 + 2], a))
                else:
                    g = v * 255 // mask
                    pix += bytes((g, g, g, 255))
    return w, h, pix, has_alpha


def write_png(path, w, h, pix):
    """Always writes 8bit RGBA; the input pix is a per-pixel RGBA byte sequence."""
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        raw += pix[y * w * 4:(y + 1) * w * 4]

    def chunk(typ, body):
        return (struct.pack(">I", len(body)) + typ + body +
                struct.pack(">I", zlib.crc32(typ + body) & 0xFFFFFFFF))

    ihdr = struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)
    data = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) +
            chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b""))
    open(path, "wb").write(data)


def main():
    args = sys.argv[1:]
    if len(args) < 2:
        print(__doc__)
        return 1
    src, dst = args[0], args[1]
    box = None
    zoom = 4
    gray = False
    i = 2
    while i < len(args):
        if args[i] == "--box" and i + 1 < len(args):
            box = tuple(int(v) for v in args[i + 1].split(","))
            i += 2
        elif args[i] == "--zoom" and i + 1 < len(args):
            zoom = int(args[i + 1])
            i += 2
        elif args[i] == "--gray":
            gray = True
            i += 1
        else:
            raise SystemExit("unknown argument " + args[i])
    w, h, pix, alpha = read_png(src)
    x0, y0, cw, ch = box if box else (0, 0, w, h)
    x0, y0 = max(0, x0), max(0, y0)
    cw, ch = min(cw, w - x0), min(ch, h - y0)
    if gray:
        for p in range(w * h):
            q = p * 4
            g = (pix[q] * 299 + pix[q + 1] * 587 + pix[q + 2] * 114) // 1000
            pix[q] = pix[q + 1] = pix[q + 2] = g
    ow, oh = cw * zoom, ch * zoom
    opix = bytearray(ow * oh * 4)
    for oy in range(oh):
        sy = y0 + oy // zoom
        for ox in range(ow):
            sx = x0 + ox // zoom
            s = (sy * w + sx) * 4
            d = (oy * ow + ox) * 4
            opix[d:d + 4] = pix[s:s + 4]
    write_png(dst, ow, oh, opix)
    print("crop (%d,%d) %dx%d  -> zoom %dx = %dx%d  ->  %s" % (x0, y0, cw, ch, zoom, ow, oh, dst))
    return 0


if __name__ == "__main__":
    sys.exit(main())
