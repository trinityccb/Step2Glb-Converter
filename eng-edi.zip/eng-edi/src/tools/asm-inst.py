#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Instance-level geometry diagnostic: independently recompute every instance of a STEP
assembly and print **its bounding box in assembly coordinates**.

It answers questions like "this part should appear N times, why do I only see M":
if the bounding boxes of the N instances are all at different places, the geometry is in
fact all there (the problem is on the display side); if several instance boxes share the
same center, the transform never took effect (the problem is on the assembly expansion
side).

Usage: python asm-inst.py <file.stp> [--top N]
"""
import re
import sys
import collections

REF_RE = re.compile(r'#(\d+)')
NUM_RE = re.compile(r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?')


# ---------------------------------------------------------------- linear algebra
def m_id():
    return [[1.0, 0, 0, 0], [0, 1.0, 0, 0], [0, 0, 1.0, 0], [0, 0, 0, 1.0]]


def m_mul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]


def m_apply(m, p):
    x, y, z = p
    return (m[0][0] * x + m[0][1] * y + m[0][2] * z + m[0][3],
            m[1][0] * x + m[1][1] * y + m[1][2] * z + m[1][3],
            m[2][0] * x + m[2][1] * y + m[2][2] * z + m[2][3])


def m_inv_rigid(m):
    r = [[m[j][i] for j in range(3)] for i in range(3)]
    t = (m[0][3], m[1][3], m[2][3])
    nt = (-sum(r[0][k] * t[k] for k in range(3)),
          -sum(r[1][k] * t[k] for k in range(3)),
          -sum(r[2][k] * t[k] for k in range(3)))
    return [[r[0][0], r[0][1], r[0][2], nt[0]],
            [r[1][0], r[1][1], r[1][2], nt[1]],
            [r[2][0], r[2][1], r[2][2], nt[2]],
            [0, 0, 0, 1.0]]


def norm(v):
    l = (v[0] ** 2 + v[1] ** 2 + v[2] ** 2) ** 0.5
    return (0.0, 0.0, 0.0) if l < 1e-15 else (v[0] / l, v[1] / l, v[2] / l)


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def placement_mat(org, z, x):
    zz = norm(z)
    if zz == (0.0, 0.0, 0.0):
        zz = (0.0, 0.0, 1.0)
    xx = norm(x)
    if xx == (0.0, 0.0, 0.0):
        xx = (1.0, 0.0, 0.0) if abs(zz[0]) < 0.9 else (0.0, 1.0, 0.0)
    d = dot(xx, zz)
    xx = (xx[0] - zz[0] * d, xx[1] - zz[1] * d, xx[2] - zz[2] * d)
    if (xx[0] ** 2 + xx[1] ** 2 + xx[2] ** 2) ** 0.5 < 1e-12:
        xx = (1.0, 0.0, 0.0) if abs(zz[0]) < 0.9 else (0.0, 1.0, 0.0)
        d = dot(xx, zz)
        xx = (xx[0] - zz[0] * d, xx[1] - zz[1] * d, xx[2] - zz[2] * d)
    xx = norm(xx)
    yy = cross(zz, xx)
    return [[xx[0], yy[0], zz[0], org[0]],
            [xx[1], yy[1], zz[1], org[1]],
            [xx[2], yy[2], zz[2], org[2]],
            [0, 0, 0, 1.0]]


# ---------------------------------------------------------------- parsing
def load(path):
    ents = {}
    typer = re.compile(r'^#(\d+)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*;\s*$', re.S)
    cxr = re.compile(r'^#(\d+)\s*=\s*\((.*)\)\s*;\s*$', re.S)
    for line in open(path, 'r', encoding='utf-8', errors='replace'):
        if not line.startswith('#'):
            continue
        s = line.rstrip('\r\n')
        m = typer.match(s)
        if m:
            ents[int(m.group(1))] = [m.group(2), m.group(3)]
            continue
        m = cxr.match(s)
        if m:
            ents[int(m.group(1))] = [None, m.group(2)]
    return ents


def refs(body):
    return [int(x) for x in REF_RE.findall(body)]


def args_of(body):
    """Split `a,b,c` into a top-level argument list (commas inside parentheses do not count)."""
    out, depth, cur, in_str = [], 0, [], False
    for c in body:
        if in_str:
            cur.append(c)
            if c == "'":
                in_str = False
            continue
        if c == "'":
            in_str = True
            cur.append(c)
        elif c == '(':
            depth += 1
            cur.append(c)
        elif c == ')':
            depth -= 1
            cur.append(c)
        elif c == ',' and depth == 0:
            out.append(''.join(cur).strip())
            cur = []
        else:
            cur.append(c)
    out.append(''.join(cur).strip())
    return out


def split_parts(body):
    out, i, n = [], 0, len(body)
    rx = re.compile(r'([A-Za-z_][A-Za-z0-9_]*)\s*\(')
    while i < n:
        m = rx.match(body, i)
        if not m:
            i += 1
            continue
        t = m.group(1)
        j, depth, in_str = m.end(), 1, False
        while j < n and depth:
            c = body[j]
            if in_str:
                if c == "'":
                    in_str = False
            else:
                if c == "'":
                    in_str = True
                elif c == '(':
                    depth += 1
                elif c == ')':
                    depth -= 1
            j += 1
        out.append((t, body[m.end():j - 1]))
        i = j
    return out


def main():
    path = sys.argv[1]
    top = 40
    if '--top' in sys.argv:
        top = int(sys.argv[sys.argv.index('--top') + 1])

    print('reading %s ...' % path)
    ents = load(path)
    print('entities %d' % len(ents))

    def e(i):
        return ents.get(i)

    # --- points ---
    pts = {}
    for i, (t, b) in ents.items():
        if t == 'CARTESIAN_POINT':
            nums = [float(x) for x in NUM_RE.findall(args_of(b)[-1])]
            if len(nums) >= 3:
                pts[i] = tuple(nums[:3])
    print('CARTESIAN_POINT %d' % len(pts))

    # --- frames ---
    def placement(i):
        ent = e(i)
        if not ent or ent[0] != 'AXIS2_PLACEMENT_3D':
            return None
        # AXIS2_PLACEMENT_3D(name, location, axis, ref_direction)
        r = refs(ent[1])
        org = pts.get(r[0] if r else 0, (0.0, 0.0, 0.0))
        z = (0.0, 0.0, 1.0)
        x = (1.0, 0.0, 0.0)
        if len(r) > 1:
            d = e(r[1])
            if d and d[0] == 'DIRECTION':
                nn = [float(v) for v in NUM_RE.findall(args_of(d[1])[-1])]
                if len(nn) >= 3:
                    z = tuple(nn[:3])
        if len(r) > 2:
            d = e(r[2])
            if d and d[0] == 'DIRECTION':
                nn = [float(v) for v in NUM_RE.findall(args_of(d[1])[-1])]
                if len(nn) >= 3:
                    x = tuple(nn[:3])
        return placement_mat(org, z, x)

    # --- vertices / edges / loops / faces ---
    # Note: in STEP the name/description fields are strings, not #refs, so refs() returns
    # a compact list starting at the "first reference-typed argument". The indices below
    # are corrected for that for every entity.
    vtx = {}
    for i, (t, b) in ents.items():
        if t == 'VERTEX_POINT':
            r = refs(b)
            if r and r[0] in pts:
                vtx[i] = pts[r[0]]
    print('VERTEX_POINT %d' % len(vtx))

    edge_v = {}
    for i, (t, b) in ents.items():
        if t == 'EDGE_CURVE':
            # EDGE_CURVE(name, v1, v2, curve, same_sense)
            r = refs(b)
            vs = [vtx.get(r[0]), vtx.get(r[1])] if len(r) >= 2 else []
            edge_v[i] = [v for v in vs if v]
    oe_edge = {}
    for i, (t, b) in ents.items():
        if t == 'ORIENTED_EDGE':
            # ORIENTED_EDGE(name, *, *, edge_element, orientation)
            r = refs(b)
            if r:
                oe_edge[i] = r[0]
    loop_edges = collections.defaultdict(list)
    for i, (t, b) in ents.items():
        if t == 'EDGE_LOOP':
            # EDGE_LOOP(name, (oriented_edges...))
            for r in refs(b):
                ec = oe_edge.get(r)
                if ec:
                    loop_edges[i].extend(edge_v.get(ec, []))
    bound_loop = {}
    for i, (t, b) in ents.items():
        if t in ('FACE_OUTER_BOUND', 'FACE_BOUND'):
            # FACE_OUTER_BOUND(name, edge_loop, orientation)
            r = refs(b)
            if r:
                bound_loop[i] = r[0]
    face_pts = {}
    for i, (t, b) in ents.items():
        if t == 'ADVANCED_FACE':
            # ADVANCED_FACE(name, (bounds...), surface, same_sense)
            vs = []
            for r in refs(b):
                if r in bound_loop:
                    vs.extend(loop_edges.get(bound_loop[r], []))
            if vs:
                face_pts[i] = vs
    print('ADVANCED_FACE(with vertices) %d' % len(face_pts))

    # --- containers: shell / solid / SR ---
    shell_faces = {}
    for i, (t, b) in ents.items():
        if t in ('CLOSED_SHELL', 'OPEN_SHELL'):
            # <SHELL>(name, (faces...))
            shell_faces[i] = [r for r in refs(b) if r in face_pts]
    sb = {}
    for i, (t, b) in ents.items():
        if t == 'SHELL_BASED_SURFACE_MODEL':
            # SHELL_BASED_SURFACE_MODEL(name, (shells...))
            vs = []
            for r in refs(b):
                vs.extend(shell_faces.get(r, []))
            sb[i] = vs
    msb = {}
    for i, (t, b) in ents.items():
        if t == 'MANIFOLD_SOLID_BREP':
            # MANIFOLD_SOLID_BREP(name, outer_shell)
            vs = []
            for r in refs(b):
                vs.extend(shell_faces.get(r, []))
            msb[i] = vs

    def is_context(i):
        ent = e(i)
        return bool(ent and ent[0] is None and 'REPRESENTATION_CONTEXT' in ent[1])

    def faces_of_item(it):
        if it in face_pts:
            return [it]
        if it in shell_faces:
            return shell_faces[it]
        if it in sb:
            return sb[it]
        if it in msb:
            return msb[it]
        return []

    def is_sr(t):
        if t is None:
            return False
        if 'RELATIONSHIP' in t or t.startswith('CONTEXT_DEPENDENT'):
            return False
        return 'SHAPE_REPRESENTATION' in t

    srs, sr_items, sr_ctx = {}, {}, {}
    for i, (t, b) in ents.items():
        if is_sr(t):
            srs[i] = t
            # SHAPE_REPRESENTATION(name, (items...), context)
            r = refs(b)
            sr_ctx[i] = r[-1] if r else 0
            sr_items[i] = [x for x in r if not is_context(x)]

    # --- pair "frame SR + geometry SR" by REPRESENTATION_CONTEXT -----------------
    # Datakit/CATIA convention: the SHAPE_REPRESENTATION referenced by the assembly tree
    # holds only AXIS2_PLACEMENT_3D (a pure coordinate frame), while the real geometry
    # sits in a sibling representation under the same REPRESENTATION_CONTEXT. Both share
    # the same local coordinate system.
    geom_of = {}          # frame SR -> geometry SR
    by_ctx = collections.defaultdict(list)
    for sr, c in sr_ctx.items():
        by_ctx[c].append(sr)

    # The faces of each SR must be computed first to know which one "really has geometry"
    sr_faces, sr_bbox = {}, {}
    for sr, items in sr_items.items():
        fs = []
        seen = set()
        for it in items:
            for f in faces_of_item(it):
                if f not in seen:
                    seen.add(f)
                    fs.append(f)
        sr_faces[sr] = fs
        lo = [1e30] * 3
        hi = [-1e30] * 3
        for f in fs:
            for p in face_pts[f]:
                for k in range(3):
                    lo[k] = min(lo[k], p[k])
                    hi[k] = max(hi[k], p[k])
        sr_bbox[sr] = (tuple(lo), tuple(hi)) if fs else None

    print('\n--- same-context groups (basis for pairing) ---')
    for c, members in sorted(by_ctx.items()):
        if len(members) < 2:
            continue
        print('  context #%s' % c)
        for sr in sorted(members):
            print('      #%-9d %-48s faces=%-6d %s'
                  % (sr, srs[sr], len(sr_faces[sr]),
                     ('geometry' if sr_faces[sr] else 'frame (no geometry)')))
        frames = [s for s in members if not sr_faces[s]]
        geoms = [s for s in members if sr_faces[s]]
        for f in frames:
            if geoms:
                # Prefer the one with the most faces (a BREP solid over a surface-patch copy)
                best = max(geoms, key=lambda s: len(sr_faces[s]))
                geom_of[f] = best

    print('\n--- frame -> geometry pairing result ---')
    for f, g in sorted(geom_of.items()):
        print('  #%-9d -> #%-9d  faces %d' % (f, g, len(sr_faces[g])))

    print('\n--- local bounding box of each SR (untransformed) ---')
    for sr in sorted(sr_bbox):
        bb = sr_bbox[sr]
        if not bb:
            print('  #%-9d %-46s no faces' % (sr, srs[sr]))
            continue
        lo, hi = bb
        print('  #%-9d %-46s faces=%-5d size %.1f x %.1f x %.1f  origin(%.1f,%.1f,%.1f)'
              % (sr, srs[sr], len(sr_faces[sr]), hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2],
                 lo[0], lo[1], lo[2]))

    # --- CDSR edges ---
    edges = []
    for i, (t, b) in ents.items():
        if t != 'CONTEXT_DEPENDENT_SHAPE_REPRESENTATION':
            continue
        r = refs(b)
        if not r:
            continue
        rr = e(r[0])
        if not rr:
            continue
        parts = dict(split_parts(rr[1]))
        rel = parts.get('REPRESENTATION_RELATIONSHIP')
        if rel is None:
            continue
        q = refs(rel)
        child, parent = (q[0], q[1]) if len(q) >= 2 else (0, 0)
        M = m_id()
        wt = parts.get('REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION')
        if wt:
            tr = refs(wt)
            te = e(tr[0]) if tr else None
            if te and te[0] == 'ITEM_DEFINED_TRANSFORMATION':
                # ITEM_DEFINED_TRANSFORMATION(name, desc, item_1, item_2)
                mm = refs(te[1])
                if len(mm) >= 2:
                    p1, p2 = placement(mm[0]), placement(mm[1])
                    if p1 and p2:
                        M = m_mul(p2, m_inv_rigid(p1))
        edges.append((parent, child, i, M))

    children = collections.defaultdict(list)
    is_child = set()
    for parent, child, cdsr, M in edges:
        children[parent].append((child, M, cdsr))
        is_child.add(child)

    roots = [s for s in srs if s not in is_child]
    print('\n--- roots ---')
    for r in roots:
        print('  #%d %s  in assembly graph=%s' % (r, srs[r], r in children))

    insts = []

    def walk(sr, acc, depth, path):
        insts.append((sr, acc, path))
        if depth > 64:
            return
        for ch, M, cdsr in children[sr]:
            walk(ch, m_mul(acc, M), depth + 1, path + '>' + str(ch))
    for r in roots:
        walk(r, m_id(), 0, str(r))

    print('\n--- instance expansion (%d) ---' % len(insts))
    cnt = collections.Counter(s for s, _, _ in insts)
    for sr in sorted(cnt, key=lambda x: -cnt[x]):
        if cnt[sr] > 1:
            print('  #%-9d x%-3d %s' % (sr, cnt[sr], srs[sr]))

    # --- count how often each part should really appear, via the frame's paired geometry ---
    eff = collections.Counter()          # geometry SR -> expected occurrence count
    for sr, acc, path in insts:
        g = geom_of.get(sr)
        if g:
            eff[g] += 1
    # Unpaired geometry SRs (not in any frame's context group) count as 1
    for sr in sr_faces:
        if sr_faces[sr] and sr not in eff and sr not in geom_of.values():
            eff[sr] += 1

    print('\n--- how often each geometric representation should appear after the fix ---')
    total = 0
    for g, n in sorted(eff.items(), key=lambda kv: -kv[1]):
        total += n * len(sr_faces[g])
        print('  #%-9d x%-3d faces/copy=%-6d %s' % (g, n, len(sr_faces[g]), srs[g]))
    print('  total face instances = %d' % total)

    # --- the key part: where the multi-instance parts actually are ---
    print('\n--- actual positions of multi-instance parts (bounding box centers in assembly coordinates) ---')
    warned = 0
    for g in sorted(eff, key=lambda x: -eff[x]):
        n = eff[g]
        if n <= 1:
            continue
        bb = sr_bbox.get(g)
        if not bb:
            continue
        lo, hi = bb
        corners = [(lo[0] if a else hi[0], lo[1] if b else hi[1], lo[2] if c else hi[2])
                   for a in (0, 1) for b in (0, 1) for c in (0, 1)]
        print('  #%-9d %s  x%d  local size %.1f x %.1f x %.1f'
              % (g, srs[g], n, hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]))
        centers = []
        for sr, acc, path in insts:
            if geom_of.get(sr) != g:
                continue
            ws = [m_apply(acc, c) for c in corners]
            wlo = tuple(min(w[i] for w in ws) for i in range(3))
            whi = tuple(max(w[i] for w in ws) for i in range(3))
            ctr = tuple((wlo[i] + whi[i]) / 2 for i in range(3))
            centers.append(ctr)
            print('      %2d) center (%9.1f,%9.1f,%9.1f)  size %.1f x %.1f x %.1f  path %s'
                  % (len(centers), ctr[0], ctr[1], ctr[2],
                     whi[0] - wlo[0], whi[1] - wlo[1], whi[2] - wlo[2], path[:40]))
        uniq = set(tuple(round(v, 1) for v in c) for c in centers)
        if len(uniq) < len(centers):
            warned += 1
            print('      >>> WARNING: %d instances have only %d distinct positions (they coincide)'
                  % (len(centers), len(uniq)))
    print('\n%d multi-instance parts, %d of them with coinciding positions'
          % (len([g for g in eff if eff[g] > 1]), warned))

    # --- export the assembly bounding box of every instance, for glb-inbox.py to cross-check against the GLB ---
    if '--boxes' in sys.argv:
        out = sys.argv[sys.argv.index('--boxes') + 1]
        rows = []
        for sr, acc, path in insts:
            g = geom_of.get(sr, sr)
            bb = sr_bbox.get(g)
            if not bb:
                continue
            lo, hi = bb
            corners = [(lo[0] if a else hi[0], lo[1] if b else hi[1], lo[2] if c else hi[2])
                       for a in (0, 1) for b in (0, 1) for c in (0, 1)]
            ws = [m_apply(acc, c) for c in corners]
            wlo = tuple(min(w[i] for w in ws) for i in range(3))
            whi = tuple(max(w[i] for w in ws) for i in range(3))
            rows.append('SR#%d %s %.4f %.4f %.4f %.4f %.4f %.4f'
                        % (g, path, wlo[0], wlo[1], wlo[2], whi[0], whi[1], whi[2]))
        with open(out, 'w', encoding='utf-8') as fh:
            fh.write('\n'.join(rows) + '\n')
        print('\nexported %d instance bounding boxes -> %s' % (len(rows), out))


if __name__ == '__main__':
    main()
