import json,struct,math,sys
def stat(p):
    d=open(p,'rb').read()
    off=12; js=None; bn=None
    while off < len(d):
        ln,ty=struct.unpack_from('<II',d,off); off+=8
        ch=d[off:off+ln]; off+=ln
        if ty==0x4E4F534A: js=json.loads(ch.decode('utf-8'))
        elif ty==0x004E4942: bn=ch
    def acc(i):
        a=js['accessors'][i]; bv=js['bufferViews'][a['bufferView']]
        o=bv.get('byteOffset',0)+a.get('byteOffset',0)
        nc={'SCALAR':1,'VEC2':2,'VEC3':3}[a['type']]
        cf={5126:('f',4),5125:('I',4),5123:('H',2)}[a['componentType']]
        v=struct.unpack_from('<'+str(a['count']*nc)+cf[0],bn,o)
        return [v[k*nc:(k+1)*nc] for k in range(a['count'])]
    ntri=0; area=0.0; nv=0
    mins=[1e30]*3; maxs=[-1e30]*3
    for m in js['meshes']:
        for pr in m['primitives']:
            pos=acc(pr['attributes']['POSITION']); nv+=len(pos)
            idx=[v[0] for v in acc(pr['indices'])]
            for v in pos:
                for k in range(3):
                    if v[k]<mins[k]: mins[k]=v[k]
                    if v[k]>maxs[k]: maxs[k]=v[k]
            for k in range(0,len(idx),3):
                a,b,c=pos[idx[k]],pos[idx[k+1]],pos[idx[k+2]]
                u=[b[i]-a[i] for i in range(3)]; w=[c[i]-a[i] for i in range(3)]
                cr=[u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0]]
                area+=0.5*math.sqrt(sum(x*x for x in cr)); ntri+=1
    print(f"file {p}")
    print(f"  bytes {len(d)}  vertices {nv}  triangles {ntri}")
    print(f"  surface area {area:.4f}")
    print(f"  bounding box {[round(x,2) for x in mins]} ~ {[round(x,2) for x in maxs]}")
    return ntri, area, len(d)
if __name__=="__main__":
    stat(sys.argv[1])
