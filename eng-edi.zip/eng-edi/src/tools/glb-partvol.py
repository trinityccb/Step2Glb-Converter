# -*- coding: utf-8 -*-
"""Diagnostic: sign of the **signed volume** of every part.

For a closed shell the signed volume = sum (p x q).r / 6, and its sign expresses the winding:
positive = outward normals point outside, negative = the whole part is turned inside out (a
viewer with backface culling draws it as "edges only").

    python tools/glb-partvol.py a.glb [--top=20] [--neg]
"""
import json
import math
import struct
import sys


def load(path):
    d = open(path, 'rb').read()
    off, js, bn = 12, None, None
    while off < len(d):
        ln, ty = struct.unpack_from('<II', d, off)
        off += 8
        ch = d[off:off + ln]
        off += ln
        if ty == 0x4E4F534A:
            js = json.loads(ch.decode('utf-8'))
        elif ty == 0x004E4942:
            bn = ch
    return d, js, bn


def reader(js, bn):
    cache = {}

    def acc(i):
        if i in cache:
            return cache[i]
        a = js['accessors'][i]
        bv = js['bufferViews'][a['bufferView']]
        o = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        nc = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}[a['type']]
        cf = {5126: ('f', 4), 5125: ('I', 4), 5123: ('H', 2), 5121: ('B', 1)}[a['componentType']]
        v = struct.unpack_from('<' + str(a['count'] * nc) + cf[0], bn, o)
        out = [v[k * nc:(k + 1) * nc] for k in range(a['count'])]
        cache[i] = out
        return out

    return acc


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    top = 20
    onlyneg = '--neg' in sys.argv
    for a in sys.argv[1:]:
        if a.startswith('--top='):
            top = int(a.split('=')[1])
    path = args[0]
    d, js, bn = load(path)
    acc = reader(js, bn)

    rows = []
    for mi, m in enumerate(js.get('meshes', [])):
        nm = m.get('name', '')
        vol = 0.0
        area = 0.0
        ntri = 0
        for pr in m['primitives']:
            if pr.get('mode', 4) != 4:
                continue
            pos = acc(pr['attributes']['POSITION'])
            idx = [v[0] for v in acc(pr['indices'])]
            for k in range(0, len(idx) - 2, 3):
                p, q, r = pos[idx[k]], pos[idx[k + 1]], pos[idx[k + 2]]
                ux, uy, uz = q[0] - p[0], q[1] - p[1], q[2] - p[2]
                vx, vy, vz = r[0] - p[0], r[1] - p[1], r[2] - p[2]
                cx = uy * vz - uz * vy
                cy = uz * vx - ux * vz
                cz = ux * vy - uy * vx
                area += 0.5 * math.sqrt(cx * cx + cy * cy + cz * cz)
                vol += (p[0] * cx + p[1] * cy + p[2] * cz) / 6.0
                ntri += 1
        rows.append((vol, mi, nm, area, ntri))

    negs = [r for r in rows if r[0] < 0]
    print('file %s' % path)
    print('  parts %d, with negative signed volume %d (total area %.2f)'
          % (len(rows), len(negs), sum(r[3] for r in negs)))
    pool = negs if onlyneg else rows
    print('\n  == top %d parts with the most negative signed volume ==' % top)
    for vol, mi, nm, area, ntri in sorted(pool, key=lambda x: x[0])[:top]:
        print('    mesh%-5d %-40s vol=%-16.2f area=%-12.2f tri=%d'
              % (mi, str(nm)[:40], vol, area, ntri))


if __name__ == '__main__':
    main()
