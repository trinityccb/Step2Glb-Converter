#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Screen faces.tsv by bounding-box size / triangle count to find faces that are
"far larger than usual" or that "explode in triangles".

Usage:
  python faces-big.py faces.tsv [min size (default 1500)] [min triangles (default 500)]
"""
import sys

path = sys.argv[1]
min_ext = float(sys.argv[2]) if len(sys.argv) > 2 else 1500.0
min_tri = int(sys.argv[3]) if len(sys.argv) > 3 else 500

rows = []
bad = 0
with open(path, encoding="utf-8", errors="replace") as fh:
    head = fh.readline()
    for line in fh:
        f = line.rstrip("\n").split("\t")
        if len(f) < 14:
            bad += 1
            continue
        try:
            ex, ey, ez = float(f[5]), float(f[6]), float(f[7])
            nt = int(f[4])
        except ValueError:
            bad += 1
            continue
        rows.append((f[0], f[1], int(f[2]), int(f[3]), nt, ex, ey, ez))

print("total rows %d (skipped %d)" % (len(rows), bad))

big = [r for r in rows if max(r[5], r[6], r[7]) >= min_ext]
big.sort(key=lambda r: -max(r[5], r[6], r[7]))
print("\n=== faces with max bounding-box extent >= %.0f: %d ===" % (min_ext, len(big)))
print("%-10s %-30s %4s %4s %8s %10s %10s %10s" %
      ("id", "surface", "nOut", "nIn", "nTris", "extX", "extY", "extZ"))
for r in big[:30]:
    print("%-10s %-30s %4d %4d %8d %10.2f %10.2f %10.2f" % r)

tri = [r for r in rows if r[4] >= min_tri]
tri.sort(key=lambda r: -r[4])
print("\n=== faces with triangle count >= %d: %d ===" % (min_tri, len(tri)))
print("%-10s %-30s %4s %4s %8s %10s %10s %10s" %
      ("id", "surface", "nOut", "nIn", "nTris", "extX", "extY", "extZ"))
for r in tri[:30]:
    print("%-10s %-30s %4d %4d %8d %10.2f %10.2f %10.2f" % r)

print("\ntotal triangles %d" % sum(r[4] for r in rows))
