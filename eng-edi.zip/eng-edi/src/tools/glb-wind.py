# -*- coding: utf-8 -*-
"""Diagnostic: does the triangle winding agree with the vertex NORMAL?

A viewer with backface culling only draws triangles that are "counter-clockwise (front
facing the camera)". If the winding of the triangles in some region is opposite to their
outward normal, the fill of that patch disappears entirely and only the edges drawn by the
outline primitives remain -- what the eye sees is "solid turned hollow, wireframe only".

    python tools/glb-wind.py a.glb [--top=20]

Statistics per mesh:
  area          total triangle area
  reversed area area of the triangles whose geometric winding dot NORMAL < 0
  reversed share reversed area / area
"""
import json
import math
import struct
import sys


def load(path):
    d = open(path, 'rb').read()
    off, js, bn = 12, None, None
    while off < len(d):
        ln, ty = struct.unpack_from('<II', d, off)
        off += 8
        ch = d[off:off + ln]
        off += ln
        if ty == 0x4E4F534A:
            js = json.loads(ch.decode('utf-8'))
        elif ty == 0x004E4942:
            bn = ch
    return d, js, bn


def reader(js, bn):
    cache = {}

    def acc(i):
        if i in cache:
            return cache[i]
        a = js['accessors'][i]
        bv = js['bufferViews'][a['bufferView']]
        o = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        nc = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}[a['type']]
        cf = {5126: ('f', 4), 5125: ('I', 4), 5123: ('H', 2), 5121: ('B', 1)}[a['componentType']]
        v = struct.unpack_from('<' + str(a['count'] * nc) + cf[0], bn, o)
        out = [v[k * nc:(k + 1) * nc] for k in range(a['count'])]
        cache[i] = out
        return out

    return acc


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    top = 20
    for a in sys.argv[1:]:
        if a.startswith('--top='):
            top = int(a.split('=')[1])
    path = args[0]
    d, js, bn = load(path)
    acc = reader(js, bn)

    total_a = 0.0
    total_bad = 0.0
    rows = []
    for mi, m in enumerate(js.get('meshes', [])):
        nm = m.get('name', '')
        for pr in m['primitives']:
            if pr.get('mode', 4) != 4:
                continue
            if 'NORMAL' not in pr['attributes']:
                continue
            pos = acc(pr['attributes']['POSITION'])
            nrm = acc(pr['attributes']['NORMAL'])
            idx = [v[0] for v in acc(pr['indices'])]
            a_all = a_bad = 0.0
            n_bad = n_all = 0
            for k in range(0, len(idx) - 2, 3):
                ia, ib, ic = idx[k], idx[k + 1], idx[k + 2]
                p, q, r = pos[ia], pos[ib], pos[ic]
                u = (q[0] - p[0], q[1] - p[1], q[2] - p[2])
                w = (r[0] - p[0], r[1] - p[1], r[2] - p[2])
                cr = (u[1] * w[2] - u[2] * w[1],
                      u[2] * w[0] - u[0] * w[2],
                      u[0] * w[1] - u[1] * w[0])
                ln = math.sqrt(cr[0] ** 2 + cr[1] ** 2 + cr[2] ** 2)
                if ln <= 1e-12:
                    continue
                area = 0.5 * ln
                n = nrm[ia]
                dot = (cr[0] * n[0] + cr[1] * n[1] + cr[2] * n[2]) / ln
                a_all += area
                n_all += 1
                if dot < 0:
                    a_bad += area
                    n_bad += 1
            total_a += a_all
            total_bad += a_bad
            if a_bad > 0:
                rows.append((a_bad, mi, nm, a_all, n_bad, n_all))

    print('file %s' % path)
    print('  total triangle area %.2f   area whose winding opposes the normal %.2f (%.2f%%)'
          % (total_a, total_bad, 100.0 * total_bad / max(total_a, 1e-9)))
    print('\n  == top %d meshes with the most reversed area ==' % top)
    for a_bad, mi, nm, a_all, n_bad, n_all in sorted(rows, key=lambda x: -x[0])[:top]:
        print('    mesh%-5d %-34s reversed area=%-11.2f / %-11.2f (%5.1f%%)  reversed triangles %d/%d'
              % (mi, str(nm)[:34], a_bad, a_all, 100.0 * a_bad / max(a_all, 1e-9), n_bad, n_all))


if __name__ == '__main__':
    main()
