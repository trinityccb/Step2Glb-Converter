# -*- coding: utf-8 -*-
"""Diagnostic: print the determinant of each GLB node matrix (negative = mirrored instance)."""
import json
import struct
import sys


def load(path):
    d = open(path, 'rb').read()
    off, js, bn = 12, None, None
    while off < len(d):
        ln, ty = struct.unpack_from('<II', d, off)
        off += 8
        ch = d[off:off + ln]
        off += ln
        if ty == 0x4E4F534A:
            js = json.loads(ch.decode('utf-8'))
        elif ty == 0x004E4942:
            bn = ch
    return d, js, bn


def det3(m):
    a, b, c = m[0], m[1], m[2]
    d_, e, f = m[4], m[5], m[6]
    g, h, i = m[8], m[9], m[10]
    return a * (e * i - f * h) - d_ * (b * i - c * h) + g * (b * f - c * e)


path = sys.argv[1]
d, js, bn = load(path)
nodes = js.get('nodes', [])
neg, noMat, mesh_nodes = [], 0, 0
for i, n in enumerate(nodes):
    m = n.get('matrix')
    if m is None:
        noMat += 1
        continue
    t = det3(m)
    if t < 0:
        neg.append((i, n.get('name', ''), n.get('mesh'), t))
    if 'mesh' in n:
        mesh_nodes += 1
print('nodes %d (without matrix %d) / negative-determinant nodes %d' % (len(nodes), noMat, len(neg)))
for i, nm, mi, t in neg[:20]:
    print('  node%-5d mesh%-5s det=%+.6f  name=%s' % (i, mi, t, nm))
for k, mt in enumerate(js.get('materials', [])[:20]):
    print('  material%d doubleSided=%s' % (k, mt.get('doubleSided', False)))
