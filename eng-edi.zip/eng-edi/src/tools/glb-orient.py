# -*- coding: utf-8 -*-
"""Diagnostic: **local consistency** of triangle winding (independent of normals and of
any external ground truth).

In a correctly oriented closed / single-sided mesh, every interior edge is traversed by
exactly two triangles, in opposite directions. If two adjacent triangles traverse the
same edge in the same direction, their windings contradict each other -- one of the two
must be flipped, and that patch simply vanishes under backface culling ("solid turned
hollow").

    python tools/glb-orient.py a.glb [--tol=0.01] [--top=20]

Output per mesh:
  same-direction shared edges  count of directed edges traversed by 2+ triangles
                               (= winding conflicts)
  conflict area                area of the triangles involved in conflicts
  conflict share               conflict area / mesh area
"""
import json
import math
import struct
import sys


def load(path):
    d = open(path, 'rb').read()
    off, js, bn = 12, None, None
    while off < len(d):
        ln, ty = struct.unpack_from('<II', d, off)
        off += 8
        ch = d[off:off + ln]
        off += ln
        if ty == 0x4E4F534A:
            js = json.loads(ch.decode('utf-8'))
        elif ty == 0x004E4942:
            bn = ch
    return d, js, bn


def reader(js, bn):
    cache = {}

    def acc(i):
        if i in cache:
            return cache[i]
        a = js['accessors'][i]
        bv = js['bufferViews'][a['bufferView']]
        o = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        nc = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}[a['type']]
        cf = {5126: ('f', 4), 5125: ('I', 4), 5123: ('H', 2), 5121: ('B', 1)}[a['componentType']]
        v = struct.unpack_from('<' + str(a['count'] * nc) + cf[0], bn, o)
        out = [v[k * nc:(k + 1) * nc] for k in range(a['count'])]
        cache[i] = out
        return out

    return acc


def weld(pos, tol):
    cell = max(tol, 1e-9)
    grid, remap, weld = {}, [0] * len(pos), []
    tol2 = tol * tol
    for i, p in enumerate(pos):
        cx, cy, cz = (int(math.floor(p[0] / cell)), int(math.floor(p[1] / cell)),
                      int(math.floor(p[2] / cell)))
        hit = -1
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    for j in grid.get((cx + dx, cy + dy, cz + dz), ()):
                        q = weld[j]
                        if (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2 <= tol2:
                            hit = j
                            break
                    if hit >= 0:
                        break
                if hit >= 0:
                    break
            if hit >= 0:
                break
        if hit < 0:
            hit = len(weld)
            weld.append(p)
            grid.setdefault((cx, cy, cz), []).append(hit)
        remap[i] = hit
    return weld, remap


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    top, tol = 20, 0.01
    for a in sys.argv[1:]:
        if a.startswith('--top='):
            top = int(a.split('=')[1])
        elif a.startswith('--tol='):
            tol = float(a.split('=')[1])
    path = args[0]
    d, js, bn = load(path)
    acc = reader(js, bn)

    tot_a = tot_bad = 0.0
    rows = []
    for mi, m in enumerate(js.get('meshes', [])):
        nm = m.get('name', '')
        for pr in m['primitives']:
            if pr.get('mode', 4) != 4:
                continue
            pos = acc(pr['attributes']['POSITION'])
            idx = [v[0] for v in acc(pr['indices'])]
            weldv, rm = weld(pos, tol)
            de = {}
            tri_area = {}
            for k in range(0, len(idx) - 2, 3):
                ia, ib, ic = rm[idx[k]], rm[idx[k + 1]], rm[idx[k + 2]]
                if ia == ib or ib == ic or ia == ic:
                    continue
                p, q, r = weldv[ia], weldv[ib], weldv[ic]
                ux, uy, uz = q[0] - p[0], q[1] - p[1], q[2] - p[2]
                vx, vy, vz = r[0] - p[0], r[1] - p[1], r[2] - p[2]
                cx = uy * vz - uz * vy
                cy = uz * vx - ux * vz
                cz = ux * vy - uy * vx
                a = 0.5 * math.sqrt(cx * cx + cy * cy + cz * cz)
                tri_area[k] = a
                for e in ((ia, ib), (ib, ic), (ic, ia)):
                    de[e] = de.get(e, 0) + 1
            bad_tris = set()
            dup = 0
            for (ia, ib), n in de.items():
                if n > 1:
                    dup += 1
                    # Count both triangles of a same-direction shared edge into the conflict area
                    for k, a in tri_area.items():
                        pass
            # Recompute: locate the triangles owning the same-direction shared edges
            edge2tri = {}
            for k in range(0, len(idx) - 2, 3):
                ia, ib, ic = rm[idx[k]], rm[idx[k + 1]], rm[idx[k + 2]]
                if ia == ib or ib == ic or ia == ic:
                    continue
                for e in ((ia, ib), (ib, ic), (ic, ia)):
                    edge2tri.setdefault(e, []).append(k)
            for e, ts in edge2tri.items():
                if len(ts) > 1:
                    for k in ts:
                        bad_tris.add(k)
            a_all = sum(tri_area.values())
            a_bad = sum(tri_area[k] for k in bad_tris)
            tot_a += a_all
            tot_bad += a_bad
            if dup:
                rows.append((a_bad, mi, nm, a_all, dup, len(bad_tris), len(tri_area)))

    print('file %s  weld tolerance %g mm' % (path, tol))
    print('  total area %.2f   area of winding-conflict triangles %.2f (%.2f%%)'
          % (tot_a, tot_bad, 100.0 * tot_bad / max(tot_a, 1e-9)))
    print('\n  == top %d meshes with the worst winding conflicts ==' % top)
    for a_bad, mi, nm, a_all, dup, nbad, nall in sorted(rows, key=lambda x: -x[0])[:top]:
        print('    mesh%-5d %-34s conflict area=%-11.2f / %-11.2f (%5.1f%%)  same-dir shared edges=%-6d conflict triangles %d/%d'
              % (mi, str(nm)[:34], a_bad, a_all, 100.0 * a_bad / max(a_all, 1e-9), dup, nbad, nall))


if __name__ == '__main__':
    main()
