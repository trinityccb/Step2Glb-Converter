# -*- coding: utf-8 -*-
"""Diagnostic: are same-direction shared edges "duplicate faces" or "winding conflicts"?

When the same directed edge (a,b) is traversed by two triangles:
  - the two triangle normals point the **same way** -> the same patch was tessellated
    twice (duplicate faces; harmless visually, just wasted triangles);
  - the two triangle normals point **opposite ways** -> a real winding conflict, and one
    of them disappears as soon as backface culling is on.

    python tools/glb-dupface.py a.glb [--mesh N] [--tol=0.01] [--top=10]
"""
import json
import math
import struct
import sys


def load(path):
    d = open(path, 'rb').read()
    off, js, bn = 12, None, None
    while off < len(d):
        ln, ty = struct.unpack_from('<II', d, off)
        off += 8
        ch = d[off:off + ln]
        off += ln
        if ty == 0x4E4F534A:
            js = json.loads(ch.decode('utf-8'))
        elif ty == 0x004E4942:
            bn = ch
    return d, js, bn


def reader(js, bn):
    cache = {}

    def acc(i):
        if i in cache:
            return cache[i]
        a = js['accessors'][i]
        bv = js['bufferViews'][a['bufferView']]
        o = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        nc = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}[a['type']]
        cf = {5126: ('f', 4), 5125: ('I', 4), 5123: ('H', 2), 5121: ('B', 1)}[a['componentType']]
        v = struct.unpack_from('<' + str(a['count'] * nc) + cf[0], bn, o)
        out = [v[k * nc:(k + 1) * nc] for k in range(a['count'])]
        cache[i] = out
        return out

    return acc


def weld(pos, tol):
    cell = max(tol, 1e-9)
    grid, remap, weld = {}, [0] * len(pos), []
    tol2 = tol * tol
    for i, p in enumerate(pos):
        cx, cy, cz = (int(math.floor(p[0] / cell)), int(math.floor(p[1] / cell)),
                      int(math.floor(p[2] / cell)))
        hit = -1
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    for j in grid.get((cx + dx, cy + dy, cz + dz), ()):
                        q = weld[j]
                        if (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2 <= tol2:
                            hit = j
                            break
                    if hit >= 0:
                        break
                if hit >= 0:
                    break
            if hit >= 0:
                break
        if hit < 0:
            hit = len(weld)
            weld.append(p)
            grid.setdefault((cx, cy, cz), []).append(hit)
        remap[i] = hit
    return weld, remap


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    top, tol, only = 10, 0.01, None
    for a in sys.argv[1:]:
        if a.startswith('--top='):
            top = int(a.split('=')[1])
        elif a.startswith('--tol='):
            tol = float(a.split('=')[1])
        elif a.startswith('--mesh='):
            only = int(a.split('=')[1])
    path = args[0]
    d, js, bn = load(path)
    acc = reader(js, bn)

    targets = [only] if only is not None else [
        i for i in range(len(js.get('meshes', [])))
        if any(pr.get('mode', 4) == 4 for pr in js['meshes'][i]['primitives'])]

    for mi in targets:
        m = js['meshes'][mi]
        nm = m.get('name', '')
        for pr in m['primitives']:
            if pr.get('mode', 4) != 4:
                continue
            pos = acc(pr['attributes']['POSITION'])
            idx = [v[0] for v in acc(pr['indices'])]
            weldv, rm = weld(pos, tol)
            tris, area, nrm = [], [], []
            for k in range(0, len(idx) - 2, 3):
                ia, ib, ic = rm[idx[k]], rm[idx[k + 1]], rm[idx[k + 2]]
                if ia == ib or ib == ic or ia == ic:
                    continue
                p, q, r = weldv[ia], weldv[ib], weldv[ic]
                ux, uy, uz = q[0] - p[0], q[1] - p[1], q[2] - p[2]
                vx, vy, vz = r[0] - p[0], r[1] - p[1], r[2] - p[2]
                cx = uy * vz - uz * vy
                cy = uz * vx - ux * vz
                cz = ux * vy - uy * vx
                ln = math.sqrt(cx * cx + cy * cy + cz * cz)
                tris.append((ia, ib, ic))
                area.append(0.5 * ln)
                nrm.append((cx / ln, cy / ln, cz / ln) if ln > 0 else (0.0, 0.0, 0.0))
            e2t = {}
            for t, (ia, ib, ic) in enumerate(tris):
                for e in ((ia, ib), (ib, ic), (ic, ia)):
                    e2t.setdefault(e, []).append(t)
            dup_same = dup_opp = 0
            a_same = a_opp = 0.0
            seen = set()
            for e, ts in e2t.items():
                if len(ts) < 2:
                    continue
                for x in range(len(ts)):
                    for y in range(x + 1, len(ts)):
                        t1, t2 = ts[x], ts[y]
                        key = (min(t1, t2), max(t1, t2))
                        dot = sum(nrm[t1][k] * nrm[t2][k] for k in range(3))
                        if dot > 0.5:
                            dup_same += 1
                            if key not in seen:
                                seen.add(key)
                                a_same += area[t1]
                        else:
                            dup_opp += 1
                            if key not in seen:
                                seen.add(key)
                                a_opp += area[t1]
                            else:
                                pass
            tot = sum(area)
            print('mesh%-5d %-34s area=%12.2f  same-dir shared edges=%5d (duplicate faces, area %.1f)  opposite shared edges=%5d (winding conflict, area %.1f)'
                  % (mi, str(nm)[:34], tot, dup_same, a_same, dup_opp, a_opp))
            if a_opp > 0 and only is not None:
                print('  ---- winding conflict samples (world-space centroids of the first %d triangles) ----' % top)
                c = 0
                for e, ts in e2t.items():
                    if len(ts) < 2:
                        continue
                    t1, t2 = ts[0], ts[1]
                    dot = sum(nrm[t1][k] * nrm[t2][k] for k in range(3))
                    if dot <= 0.5:
                        p, q, r = weldv[tris[t1][0]], weldv[tris[t1][1]], weldv[tris[t1][2]]
                        ctr = tuple((p[k] + q[k] + r[k]) / 3.0 for k in range(3))
                        print('    T%-6d area=%9.3f n=(%.2f,%.2f,%.2f) ctr=(%.2f,%.2f,%.2f)'
                              % (t1, area[t1], nrm[t1][0], nrm[t1][1], nrm[t1][2], *ctr))
                        c += 1
                        if c >= top:
                            break


if __name__ == '__main__':
    main()
