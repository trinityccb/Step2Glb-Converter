"""Scan a batch of STEP files for ORIENTED_*_SHELL / BREP_WITH_VOIDS (void shells).

Why a dedicated tool: the void slots of BREP_WITH_VOIDS hold ORIENTED_CLOSED_SHELL, which
only wraps a shell with an orientation and is not itself a container of faces. If the
conversion kernel only recognises CLOSED_SHELL, those faces neither enter the "shape
representation -> faces" mapping nor receive the assembly transform, and end up pushed
back to the part's original coordinates by the identity transform -- visually a pile of
floating debris next to the model. (Fixed in v1.4.0, see README section 13.)

Run this before/after a code change to learn "which files are affected", or on a new part
to decide how closely it needs to be inspected.

Usage: python step-voids.py <file or directory> [...]
Pure byte scan, no STEP parsing, so even GB-sized files take seconds.
"""
import os
import sys

NEEDLES = [('ORIENTED_CLOSED_SHELL', b'ORIENTED_CLOSED_SHELL'),
           ('ORIENTED_OPEN_SHELL', b'ORIENTED_OPEN_SHELL'),
           ('BREP_WITH_VOIDS', b'BREP_WITH_VOIDS')]


def count(path):
    res = {n: 0 for n, _ in NEEDLES}
    with open(path, 'rb') as fh:
        tail = b''
        while True:
            chunk = fh.read(1 << 22)
            if not chunk:
                break
            buf = tail + chunk
            for name, pat in NEEDLES:
                res[name] += buf.count(pat)
            tail = buf[-32:]   # avoid missing keywords that straddle a chunk boundary
    return res


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    files = []
    for a in sys.argv[1:]:
        if os.path.isdir(a):
            for dp, _dn, fn in os.walk(a):
                for f in fn:
                    if f.lower().endswith(('.stp', '.step')):
                        files.append(os.path.join(dp, f))
        else:
            files.append(a)
    files.sort()
    hit = 0
    print('%-8s %-11s %-9s %s' % ('total', 'ORIENTED_CS', 'BWV', 'file'))
    for p in files:
        r = count(p)
        tot = sum(r.values())
        if not tot:
            continue
        hit += 1
        print('%-8d %-11d %-9d %s'
              % (tot, r['ORIENTED_CLOSED_SHELL'] + r['ORIENTED_OPEN_SHELL'],
                 r['BREP_WITH_VOIDS'], os.path.basename(p)))
    print('---- %d files, %d hits ----' % (len(files), hit))


if __name__ == '__main__':
    main()
