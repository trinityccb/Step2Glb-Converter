#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Independently reconstruct the STEP AP214 assembly tree (without the Go kernel), used to
adjudicate "lost instance" problems.

Output:
  - every CDSR relationship: (parent SR, child SR, transform)
  - the assembly tree (root -> children), plus the reference count of each SR
  - the items of each SR and the number of ADVANCED_FACE entities expanded from it
  - a comparison against the "shapes/instances" numbers in the Go kernel log

Usage: python asm-tree.py <file.stp> [--faces]
"""
import re
import sys
import collections

TYPE_RE = re.compile(r'^\s*#(\d+)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*;\s*$', re.S)
COMPLEX_RE = re.compile(r'^\s*#(\d+)\s*=\s*\((.*)\)\s*;\s*$', re.S)
REF_RE = re.compile(r'#(\d+)')


def load(path):
    """Return {id: (type, body)}; for complex instances type is None and body is the raw parenthesized content."""
    ents = {}
    with open(path, 'r', encoding='utf-8', errors='replace') as fh:
        for line in fh:
            if not line.startswith('#'):
                continue
            m = TYPE_RE.match(line.rstrip('\r\n'))
            if m:
                ents[int(m.group(1))] = (m.group(2), m.group(3))
                continue
            m = COMPLEX_RE.match(line.rstrip('\r\n'))
            if m:
                # Complex instance: #1=(A(..)B(..))
                ents[int(m.group(1))] = (None, m.group(2))
    return ents


def refs(body):
    return [int(x) for x in REF_RE.findall(body)]


def split_parts(body):
    """Split a complex instance body into [(TYPE, body), ...]"""
    out = []
    i = 0
    n = len(body)
    while i < n:
        m = re.compile(r'([A-Za-z_][A-Za-z0-9_]*)\s*\(').match(body, i)
        if not m:
            i += 1
            continue
        t = m.group(1)
        j = m.end()
        depth = 1
        in_str = False
        while j < n and depth:
            c = body[j]
            if in_str:
                if c == "'":
                    if j + 1 < n and body[j + 1] == "'":
                        j += 2
                        continue
                    in_str = False
            else:
                if c == "'":
                    in_str = True
                elif c == '(':
                    depth += 1
                elif c == ')':
                    depth -= 1
            j += 1
        out.append((t, body[m.end():j - 1]))
        i = j
    return out


def is_shape_repr(t):
    if t is None:
        return False
    if 'RELATIONSHIP' in t or t.startswith('CONTEXT_DEPENDENT'):
        return False
    return 'SHAPE_REPRESENTATION' in t


def main():
    path = sys.argv[1]
    show_faces = '--faces' in sys.argv
    print('reading %s ...' % path)
    ents = load(path)
    print('total entities %d' % len(ents))

    cnt = collections.Counter(t for t, _ in ents.values() if t)
    cnt[None] = sum(1 for t, _ in ents.values() if t is None)
    print('\n--- all entity types ---')
    for t, c in cnt.most_common():
        print('  %-52s %d' % (t if t else '(complex instance)', c))

    # --- shape representations ---
    srs = {}
    for i, (t, body) in ents.items():
        if is_shape_repr(t):
            srs[i] = (t, refs(body)[1:])  # the first reference is usually the context
    print('\n--- shape representations SR (%d) ---' % len(srs))
    for i, (t, items) in sorted(srs.items()):
        print('  #%-8d %-42s items=%s' % (i, t or '', items[:8]))

    # --- CDSR -> parent/child relations ---
    edges = []   # (parent, child, tr_id, m1, m2)
    n_cdsr = 0
    for i, (t, body) in ents.items():
        if t != 'CONTEXT_DEPENDENT_SHAPE_REPRESENTATION':
            continue
        n_cdsr += 1
        rr = refs(body)[0] if refs(body) else 0
        if not rr or rr not in ents:
            edges.append((0, 0, 0, 0, 0))
            continue
        parts = dict(split_parts(ents[rr][1]))
        rel = parts.get('REPRESENTATION_RELATIONSHIP')
        if rel is None:
            edges.append((0, 0, 0, 0, 0))
            continue
        # SHAPE_REPRESENTATION_RELATIONSHIP(name, description, rep_1, rep_2)
        # The first two arguments are strings, so refs() only picks up rep_1 / rep_2.
        r = refs(rel)
        child, parent = (r[0], r[1]) if len(r) >= 2 else (0, 0)
        tr = 0
        m1 = m2 = 0
        wt = parts.get('REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION')
        if wt:
            trr = refs(wt)
            tr = trr[0] if trr else 0
            tb = ents.get(tr)
            if tb and tb[0] == 'ITEM_DEFINED_TRANSFORMATION':
                mm = refs(tb[1])
                if len(mm) >= 4:
                    m1, m2 = mm[2], mm[3]
        edges.append((parent, child, tr, m1, m2))

    print('\n--- CDSR relationships (%d) ---' % n_cdsr)
    child_count = collections.Counter()
    for parent, child, tr, m1, m2 in edges:
        child_count[child] += 1
    for k, (parent, child, tr, m1, m2) in enumerate(edges):
        print('  %2d) parent=#%-8s child=#%-8s tr=#%-8s axis1=#%-7s axis2=#%-7s  %s/%s'
              % (k + 1, parent or '-', child or '-', tr or '-', m1 or '-', m2 or '-',
                 (srs.get(parent) or ('?',))[0], (srs.get(child) or ('?',))[0]))

    # --- tree ---
    children = collections.defaultdict(list)
    is_child = set()
    for parent, child, *_ in edges:
        if parent and child:
            children[parent].append(child)
            is_child.add(child)
    roots = [s for s in srs if s not in is_child]
    print('\n--- assembly tree roots (%d) ---' % len(roots))
    for r in roots:
        print('  #%d %s' % (r, srs[r][0]))

    insts = []
    def walk(sr, acc_depth, path):
        insts.append(sr)
        if acc_depth > 256:
            return
        for c in children[sr]:
            walk(c, acc_depth + 1, path + '>' + str(c))
    for r in roots:
        walk(r, 0, str(r))

    c2 = collections.Counter(insts)
    print('\n--- expansion result ---')
    print('  node type count (Nodes) = %d' % len(srs))
    print('  expanded instance count (Instances) = %d' % len(insts))
    multi = {k: v for k, v in c2.items() if v > 1}
    print('  SRs referenced more than once = %d, extra instances = %d'
          % (len(multi), sum(v - 1 for v in multi.values())))
    print('\n--- instance count per SR ---')
    for sr in sorted(c2, key=lambda x: -c2[x]):
        print('  #%-8d x%-4d %s' % (sr, c2[sr], srs[sr][0]))
    print('\n  root list: %s' % roots)


if __name__ == '__main__':
    main()
