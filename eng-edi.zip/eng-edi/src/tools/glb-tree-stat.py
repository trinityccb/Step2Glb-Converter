# -*- coding: utf-8 -*-
"""Expand the GLB node tree and count "how much geometry the renderer will see".

Purpose: the assembly-tree version turns "the same part assembled N times" into "one copy
of geometry + N node matrices", so the triangles/surface area counted by glb-stat.py are
only the **static data volume**, not what is actually displayed. This tool walks
scene -> nodes, multiplying the node matrices, expands every mesh-bearing node by its
world transform and only then counts -- those are the numbers directly comparable with
the old "flattened" output.

    python tools/glb-tree-stat.py a.glb [b.glb]

Output: node count / depth / nodes with geometry / expanded triangle count / world-space
surface area / world bounding box.
"""
import json
import math
import struct
import sys


def load(path):
    d = open(path, 'rb').read()
    off, js, bn = 12, None, None
    while off < len(d):
        ln, ty = struct.unpack_from('<II', d, off)
        off += 8
        ch = d[off:off + ln]
        off += ln
        if ty == 0x4E4F534A:
            js = json.loads(ch.decode('utf-8'))
        elif ty == 0x004E4942:
            bn = ch
    return d, js, bn


def make_reader(js, bn):
    cache = {}

    def acc(i):
        if i in cache:
            return cache[i]
        a = js['accessors'][i]
        bv = js['bufferViews'][a['bufferView']]
        o = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        nc = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}[a['type']]
        cf = {5126: ('f', 4), 5125: ('I', 4), 5123: ('H', 2)}[a['componentType']]
        v = struct.unpack_from('<' + str(a['count'] * nc) + cf[0], bn, o)
        out = [v[k * nc:(k + 1) * nc] for k in range(a['count'])]
        cache[i] = out
        return out

    return acc


def ident():
    return [1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0]


def mul(a, b):
    """Multiply two column-major 4x4 matrices: returns a.b (apply b first, then a)."""
    o = [0.0] * 16
    for c in range(4):
        for r in range(4):
            s = 0.0
            for k in range(4):
                s += a[k * 4 + r] * b[c * 4 + k]
            o[c * 4 + r] = s
    return o


def apply(m, p):
    x, y, z = p
    return (m[0] * x + m[4] * y + m[8] * z + m[12],
            m[1] * x + m[5] * y + m[9] * z + m[13],
            m[2] * x + m[6] * y + m[10] * z + m[14])


def area_scale(m):
    """A rigid transform has det=1; the area is still scaled by the mean length of the
    three basis vectors, just in case."""
    sx = math.sqrt(m[0] ** 2 + m[1] ** 2 + m[2] ** 2)
    sy = math.sqrt(m[4] ** 2 + m[5] ** 2 + m[6] ** 2)
    sz = math.sqrt(m[8] ** 2 + m[9] ** 2 + m[10] ** 2)
    return ((sx + sy + sz) / 3.0) ** 2


def stat(path):
    d, js, bn = load(path)
    acc = make_reader(js, bn)

    nodes = js.get('nodes', [])
    parent = [-2] * len(nodes)
    for i, n in enumerate(nodes):
        for c in n.get('children', []):
            parent[c] = i
    roots = js['scenes'][js.get('scene', 0)].get('nodes') or \
        [i for i in range(len(nodes)) if parent[i] == -2]

    # Compute the local triangles and area of each mesh once (a mesh may be referenced by several nodes)
    tri_of, area_of = {}, {}
    for mi, m in enumerate(js.get('meshes', [])):
        t, a = 0, 0.0
        for pr in m['primitives']:
            # Since v1.8.0 the outline is a mode=1 LINES primitive: it counts towards
            # neither area nor triangles, and its index count is not a multiple of 3, so
            # reading it as triangles would run out of range.
            if pr.get('mode', 4) != 4:
                continue
            pos = acc(pr['attributes']['POSITION'])
            idx = [v[0] for v in acc(pr['indices'])]
            t += len(idx) // 3
            for k in range(0, len(idx), 3):
                p, q, r = pos[idx[k]], pos[idx[k + 1]], pos[idx[k + 2]]
                u = [q[i] - p[i] for i in range(3)]
                w = [r[i] - p[i] for i in range(3)]
                cr = [u[1] * w[2] - u[2] * w[1],
                      u[2] * w[0] - u[0] * w[2],
                      u[0] * w[1] - u[1] * w[0]]
                a += 0.5 * math.sqrt(sum(x * x for x in cr))
        tri_of[mi], area_of[mi] = t, a

    mins = [1e30] * 3
    maxs = [-1e30] * 3
    seen = set()          # expanded mesh instances: de-duplicated by world matrix + mesh
    drawn_tri = 0
    drawn_area = 0.0
    mesh_nodes = 0
    depth_max = 0
    stack = [(r, ident(), 1) for r in roots]
    while stack:
        nid, w, dep = stack.pop()
        depth_max = max(depth_max, dep)
        n = nodes[nid]
        if 'matrix' in n:
            # Track whether translation/rotation is already included, for the statistics below
            w = mul(w, n['matrix'])
        if 'mesh' in n:
            mesh_nodes += 1
            mi = n['mesh']
            key = tuple(round(v, 6) for v in w) + (mi,)
            if key not in seen:
                seen.add(key)
                drawn_tri += tri_of.get(mi, 0)
                drawn_area += area_of.get(mi, 0.0) * area_scale(w)
            # Merge the mesh bounding box into the overall box after the world transform:
            # the 8 corners are enough (the POSITION accessor carries min/max, so reading
            # every vertex is unnecessary)
            for pr in js['meshes'][mi]['primitives']:
                a = js['accessors'][pr['attributes']['POSITION']]
                if 'min' in a and 'max' in a:
                    mn, mx = a['min'], a['max']
                    for bx in (mn[0], mx[0]):
                        for by in (mn[1], mx[1]):
                            for bz in (mn[2], mx[2]):
                                p = apply(w, (bx, by, bz))
                                for k in range(3):
                                    if p[k] < mins[k]:
                                        mins[k] = p[k]
                                    if p[k] > maxs[k]:
                                        maxs[k] = p[k]
                else:
                    for p0 in acc(pr['attributes']['POSITION']):
                        p = apply(w, p0)
                        for k in range(3):
                            if p[k] < mins[k]:
                                mins[k] = p[k]
                            if p[k] > maxs[k]:
                                maxs[k] = p[k]
        for c in n.get('children', []):
            stack.append((c, w, dep + 1))

    names = [n.get('name', '') for n in nodes]
    named = sum(1 for x in names if x)
    print("file %s" % path)
    print("  bytes %d" % len(d))
    print("  nodes %d (named %d) / scene roots %d / max depth %d"
          % (len(nodes), named, len(roots), depth_max))
    print("  nodes with geometry %d (expanded %d after de-duplication)" % (mesh_nodes, len(seen)))
    print("  meshes %d" % len(js.get('meshes', [])))
    print("  expanded triangles %d" % drawn_tri)
    print("  world surface area %.4f" % drawn_area)
    print("  world bounding box %s ~ %s" % ([round(x, 2) for x in mins],
                                   [round(x, 2) for x in maxs]))
    return drawn_tri, drawn_area, mins, maxs, len(d)


if __name__ == "__main__":
    for p in sys.argv[1:]:
        stat(p)
        print("")
