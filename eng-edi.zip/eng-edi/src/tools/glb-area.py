#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Measure a GLB's surface area and bounding box as an independent sentinel for
"holes filled in / an extra membrane".

Principle: for a correctly tessellated solid, the sum of the triangle areas equals the true
surface area. When ear clipping drops a hole (the hole gets filled in), the total area grows
out of nowhere, which makes this one of the most sensitive checks. It also reports "the
largest few triangles": a membrane-like bad triangle is usually obvious at a glance.

Usage: python glb-area.py a.glb [b.glb ...]
"""
import json
import math
import struct
import sys

COMP = {5120: ("b", 1), 5121: ("B", 1), 5122: ("h", 2),
        5123: ("H", 2), 5125: ("I", 4), 5126: ("f", 4)}
NCOMP = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


def read_glb(path):
    with open(path, "rb") as f:
        data = f.read()
    magic, _ver, total = struct.unpack_from("<III", data, 0)
    assert magic == 0x46546C67, "not a GLB: " + path
    off, js, blob = 12, None, b""
    while off < total:
        clen, ctype = struct.unpack_from("<II", data, off)
        chunk = data[off + 8: off + 8 + clen]
        if ctype == 0x4E4F534A:
            js = json.loads(chunk.decode("utf-8"))
        elif ctype == 0x004E4942:
            blob = chunk
        off += 8 + clen
    return js, blob


def acc(g, b, i):
    a = g["accessors"][i]
    bv = g["bufferViews"][a["bufferView"]]
    fmt, size = COMP[a["componentType"]]
    n = NCOMP[a["type"]]
    base = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    stride = bv.get("byteStride") or size * n
    return [struct.unpack_from("<" + fmt * n, b, base + k * stride) for k in range(a["count"])]


def stat(path, topn=3):
    g, b = read_glb(path)
    nodes = g.get("nodes", [])
    parent = {}
    for i, nd in enumerate(nodes):
        for c in nd.get("children", []):
            parent[c] = i

    def mat_of(nd):
        t = nd.get("translation", [0, 0, 0])
        r = nd.get("rotation", [0, 0, 0, 1])
        s = nd.get("scale", [1, 1, 1])
        x, y, z, w = r
        rm = [[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
              [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
              [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]]
        return [[rm[i][j] * s[j] for j in range(3)] + [t[i]] for i in range(3)]

    def chain(ni):
        m = mat_of(nodes[ni])
        acc_m = m
        p = parent.get(ni)
        while p is not None:
            pm = mat_of(nodes[p])
            acc_m = [[sum(pm[i][k] * acc_m[k][j] for k in range(3)) for j in range(3)] +
                     [sum(pm[i][k] * acc_m[k][3] for k in range(3)) + pm[i][3]] for i in range(3)]
            p = parent.get(p)
        return acc_m

    total = 0.0
    ntris = 0
    biggest = []
    mn = [1e300] * 3
    mx = [-1e300] * 3
    for ni, nd in enumerate(nodes):
        if "mesh" not in nd:
            continue
        M = chain(ni)
        for prim in g["meshes"][nd["mesh"]]["primitives"]:
            P = acc(g, b, prim["attributes"]["POSITION"])
            I = [v[0] for v in acc(g, b, prim["indices"])] if "indices" in prim else list(range(len(P)))
            for v in P:
                w = (M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2] + M[0][3],
                     M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2] + M[1][3],
                     M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2] + M[2][3])
                for k in range(3):
                    mn[k] = min(mn[k], w[k])
                    mx[k] = max(mx[k], w[k])
            for k in range(0, len(I) - 2, 3):
                a, c, d = P[I[k]], P[I[k + 1]], P[I[k + 2]]
                wa = (M[0][0] * a[0] + M[0][1] * a[1] + M[0][2] * a[2] + M[0][3],
                      M[1][0] * a[0] + M[1][1] * a[1] + M[1][2] * a[2] + M[1][3],
                      M[2][0] * a[0] + M[2][1] * a[1] + M[2][2] * a[2] + M[2][3])
                ux, uy, uz = c[0] - a[0], c[1] - a[1], c[2] - a[2]
                vx, vy, vz = d[0] - a[0], d[1] - a[1], d[2] - a[2]
                nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
                ar = 0.5 * math.sqrt(nx * nx + ny * ny + nz * nz)
                total += ar
                ntris += 1
                biggest.append((ar, wa))
    biggest.sort(reverse=True)
    print("%s" % path)
    print("  triangles %-10d total area %.4f   bbox (%.4f,%.4f,%.4f)~(%.4f,%.4f,%.4f)  size %.4f x %.4f x %.4f"
          % (ntris, total, mn[0], mn[1], mn[2], mx[0], mx[1], mx[2],
             mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]))
    for ar, wa in biggest[:topn]:
        print("  largest triangle %.4f  vertex (%.4f,%.4f,%.4f)" % (ar, wa[0], wa[1], wa[2]))
    return total, ntris


if __name__ == "__main__":
    for p in sys.argv[1:]:
        stat(p)
