#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Aggregate the e2e batch regression log, producing every number the README
"batch regression" table needs.

Usage:
    python tools/e2e-summary.py _v3/e2e90b.log

Reads lines of this shape (label text before each number is skipped, so the log may be
in any language):

    [ 28/ 90] OK               7150ms <faces 2687/0/4> <tris 156601> <volume 66.0%>  HF_4_....stp
    [ 47/ 90] OK               7220ms <faces 13051/0/4> <tris 177937> <volume 6.4%>  GUARD_....stp
    [ 12/ 90] FAIL             1200ms <reason>  xxx.stp

Only lines starting with `[ n/ m]` are counted; indented continuation lines (degradation
reasons) are ignored. "faces a/b/c" = face instances / failed faces / degraded faces.
The volume ratio is GLB bytes / STP bytes.

Note: the log does not carry the source file sizes, so the volume ratio can only be
summarized from the percentages given in the log:
    GLB bytes = STP bytes x pct  -- STP bytes unknown, hence only "how many files did not
shrink" and the percentage extremes can be aggregated.

If a TSV (the raw output of e2e.sh) sits in the same directory, prefer its exact totals.
"""
import re
import sys
import os

LINE = re.compile(
    r"^\[\s*(\d+)/\s*(\d+)\]\s+(\S+)\s+(\d+)ms\s+"
    r"\D*?(\d+)/(\d+)/(\d+)\s+\D*?(\d+)\s+\D*?([\d.]+)%\s+(.*)$"
)


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    path = sys.argv[1]
    if not os.path.exists(path):
        print("log not found:", path)
        return 1

    tot_idx = ok = fail = 0
    faces = ffail = fdeg = tris = 0
    pcts = []            # (pct, name, ms)
    slow = []
    biggest = []
    for raw in open(path, "r", encoding="utf-8", errors="replace"):
        if not raw.startswith("["):
            continue
        m = LINE.match(raw.rstrip("\n"))
        if not m:
            continue
        idx, tot = int(m.group(1)), int(m.group(2))
        status = m.group(3)
        ms = int(m.group(4))
        fa, fb, fc = int(m.group(5)), int(m.group(6)), int(m.group(7))
        tri = int(m.group(8))
        pct = float(m.group(9))
        name = m.group(10).strip()
        tot_idx = max(tot_idx, idx)
        if status == "OK":
            ok += 1
        else:
            fail += 1
        faces += fa
        ffail += fb
        fdeg += fc
        tris += tri
        pcts.append((pct, name))
        slow.append((ms, name, tri))
        biggest.append((pct, name))

    if not pcts:
        print("no countable lines in the log (it may not have started yet).")
        return 1

    slow.sort(reverse=True)
    biggest.sort(reverse=True)
    avg = sum(p for p, _ in pcts) / len(pcts)

    print("=" * 78)
    print("regression progress : %d / %d" % (tot_idx, tot_idx and (ok + fail) and tot_idx or tot_idx))
    print("ok / failed         : %d / %d" % (ok, fail))
    print("face instances / failed / degraded : %d / %d / %d  (degraded rate %.2f%%)"
          % (faces, ffail, fdeg, 100.0 * fdeg / faces if faces else 0))
    print("triangles total     : %d" % tris)
    print("volume ratio  mean  : %.1f%%   min %.1f%%   max %.1f%%" % (avg, min(pcts)[0], max(pcts)[0]))
    print("above source size   : %d" % sum(1 for p, _ in pcts if p > 100))
    print("-" * 78)
    print("5 slowest:")
    for ms, name, tri in slow[:5]:
        print("   %7d ms  tri %-8d %s" % (ms, tri, name))
    print("5 highest volume ratios:")
    for p, name in biggest[:5]:
        print("   %6.1f%%   %s" % (p, name))
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
