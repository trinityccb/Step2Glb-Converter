#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Count the GLB triangle centroids that fall inside a given bounding box.

Purpose: take the "box each instance should occupy in assembly coordinates" exported by
asm-inst.py --boxes and check it against the GLB -- if a box contains zero triangles,
the geometry of that instance was never emitted (this is exactly how "only 3 of the 8
columns came out" is decided). All geometry in the GLB already carries the assembly
transform, so comparing world coordinates directly is enough, no extra transform needed.

Usage:
  python glb-inbox.py <file.glb> <boxes.txt> [--min N]

boxes.txt, one per line: <name> <x0> <y0> <z0> <x1> <y1> <z1>
"""
import struct
import sys

COMP = {5120: ("b", 1), 5121: ("B", 1), 5122: ("h", 2), 5123: ("H", 2),
        5125: ("I", 4), 5126: ("f", 4)}
NCOMP = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


def read_glb(path):
    with open(path, "rb") as f:
        data = f.read()
    magic, ver, length = struct.unpack_from("<III", data, 0)
    assert magic == 0x46546C67, "not a GLB"
    off, js, blob = 12, None, b""
    while off < length:
        clen, ctype = struct.unpack_from("<II", data, off)
        payload = data[off + 8: off + 8 + clen]
        if ctype == 0x4E4F534A:
            import json
            js = json.loads(payload.decode("utf-8"))
        elif ctype == 0x004E4942:
            blob = payload
        off += 8 + clen
    return js, blob


def accessor(js, blob, idx):
    acc = js["accessors"][idx]
    n = NCOMP[acc["type"]]
    fmt, size = COMP[acc["componentType"]]
    base = js["bufferViews"][acc["bufferView"]]
    start = base.get("byteOffset", 0) + acc.get("byteOffset", 0)
    stride = base.get("byteStride") or n * size
    for i in range(acc["count"]):
        o = start + i * stride
        yield struct.unpack_from("<" + fmt * n, blob, o)


def world_positions(js, blob):
    """Expand the POSITION of every primitive into world coordinates (including the node transform chain)."""
    out = []
    parents = {}
    for ni, node in enumerate(js.get("nodes", [])):
        for ch in node.get("children", []):
            parents[ch] = ni

    def chain(ni):
        ms = []
        while ni is not None:
            node = js["nodes"][ni]
            if "matrix" in node:
                m = node["matrix"]
                ms.append([[m[0], m[4], m[8], m[12]], [m[1], m[5], m[9], m[13]],
                           [m[2], m[6], m[10], m[14]], [m[3], m[7], m[11], m[15]]])
            elif "translation" in node or "scale" in node or "rotation" in node:
                t = node.get("translation", [0, 0, 0])
                s = node.get("scale", [1, 1, 1])
                ms.append([[s[0], 0, 0, t[0]], [0, s[1], 0, t[1]],
                           [0, 0, s[2], t[2]], [0, 0, 0, 1]])
            ni = parents.get(ni)
        m = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
        for k in reversed(ms):
            m = [[sum(m[i][x] * k[x][j] for x in range(4)) for j in range(4)] for i in range(4)]
        return m

    for ni, node in enumerate(js.get("nodes", [])):
        if "mesh" not in node:
            continue
        M = chain(ni)
        for p in js["meshes"][node["mesh"]].get("primitives", []):
            if "attributes" not in p or "POSITION" not in p["attributes"]:
                continue
            pts = list(accessor(js, blob, p["attributes"]["POSITION"]))
            for (x, y, z) in pts:
                yield (M[0][0] * x + M[0][1] * y + M[0][2] * z + M[0][3],
                       M[1][0] * x + M[1][1] * y + M[1][2] * z + M[1][3],
                       M[2][0] * x + M[2][1] * y + M[2][2] * z + M[2][3])


def main():
    glb = sys.argv[1]
    boxes = sys.argv[2]
    minv = int(sys.argv[sys.argv.index('--min') + 1]) if '--min' in sys.argv else 1
    # --shrink f: shrink the box towards its center by a factor f before counting.
    # Used to rule out interference from "stray geometry left at the local origin by an
    # identity transform and happening to land inside some instance box"; real geometry
    # always has points near the part center, misplaced geometry usually does not.
    shrink = float(sys.argv[sys.argv.index('--shrink') + 1]) if '--shrink' in sys.argv else 1.0

    js, blob = read_glb(glb)
    pts = list(world_positions(js, blob))
    print('GLB vertices (world coordinates) %d%s' % (len(pts), (', boxes shrunk to %.2f' % shrink) if shrink < 1 else ''))

    rows = []
    for line in open(boxes, 'r', encoding='utf-8'):
        parts = line.split()
        if len(parts) < 7:
            continue
        name = ' '.join(parts[:-6])
        x0, y0, z0, x1, y1, z1 = (float(v) for v in parts[-6:])
        if shrink < 1.0:
            cx, cy, cz = (x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2
            x0, x1 = cx + (x0 - cx) * shrink, cx + (x1 - cx) * shrink
            y0, y1 = cy + (y0 - cy) * shrink, cy + (y1 - cy) * shrink
            z0, z1 = cz + (z0 - cz) * shrink, cz + (z1 - cz) * shrink
        # When the box is very flat (plate parts), pad it slightly to avoid float boundary problems
        pad = max(0.2, 0.001 * max(x1 - x0, y1 - y0, z1 - z0))
        n = 0
        for (x, y, z) in pts:
            if x0 - pad <= x <= x1 + pad and y0 - pad <= y <= y1 + pad and z0 - pad <= z <= z1 + pad:
                n += 1
        rows.append((name, n, x0, y0, z0, x1, y1, z1))

    empty = [r for r in rows if r[1] < minv]
    print('\n%-26s %10s   %s' % ('instance', 'points in box', 'bounding box'))
    for (name, n, x0, y0, z0, x1, y1, z1) in rows:
        flag = '  <== empty!' if n < minv else ''
        print('%-26s %10d   (%.1f,%.1f,%.1f)~(%.1f,%.1f,%.1f)%s'
              % (name, n, x0, y0, z0, x1, y1, z1, flag))
    print('\n%d instance boxes in total, %d of them empty' % (len(rows), len(empty)))


main()
