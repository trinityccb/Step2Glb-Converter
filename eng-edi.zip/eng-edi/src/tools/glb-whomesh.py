# -*- coding: utf-8 -*-
"""Print which nodes reference a given mesh (including node names and ancestor chains)."""
import json
import struct
import sys


def load(path):
    d = open(path, 'rb').read()
    off, js, bn = 12, None, None
    while off < len(d):
        ln, ty = struct.unpack_from('<II', d, off)
        off += 8
        ch = d[off:off + ln]
        off += ln
        if ty == 0x4E4F534A:
            js = json.loads(ch.decode('utf-8'))
        elif ty == 0x004E4942:
            bn = ch
    return d, js, bn


path = sys.argv[1]
want = int(sys.argv[2])
d, js, bn = load(path)
nodes = js['nodes']
par = {}
for i, n in enumerate(nodes):
    for c in n.get('children', []):
        par[c] = i


def chain(i):
    out = []
    while i in par:
        i = par[i]
        out.append(nodes[i].get('name', '<%d>' % i))
    return ' / '.join(reversed(out))


print('mesh%d name=%r' % (want, js['meshes'][want].get('name', '')))
for i, n in enumerate(nodes):
    if n.get('mesh') == want:
        print('  node%-5d name=%-40s ancestors=%s' % (i, n.get('name', ''), chain(i)))
