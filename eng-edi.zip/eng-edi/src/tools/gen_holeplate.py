#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_holeplate.py -- build a STEP with small circular holes of various diameters in a
large plate, to reproduce the "round hole drawn as a diamond hole" problem.

Why generate one: the real fixture from this session (2000 mm class, hole diameter
6~10 mm) is inconvenient to convert over and over; and the cause of the problem is
directly related to the ratio of "model scale / hole diameter", so a controllable
2000x300x20 plate plus a row of dia4~dia50 holes reproduces it completely, with known
hole positions that make counting points easy.

Usage (requires OCP/OpenCASCADE):
    PYTHONPATH=".../.occt-venv/Lib/site-packages" python gen_holeplate.py out.step [--split N]

--split N cuts every closed circular edge (full circle) into N arcs. **This is the key
to reproducing the problem**: a full circle takes the "closed edge" branch in
sampleEdge with a floor of 16 segments, so it draws round enough; but many CAD systems
(CATIA/UG/some SolidWorks exports) write the hole outline as 2~4 arcs, and those arcs
are only subdivided by the chord tolerance -- when the tolerance is larger than the hole
radius only 1~2 segments remain, which looks like a "diamond hole / hexagonal hole".
"""
import sys

from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox, BRepPrimAPI_MakeCylinder
from OCP.gp import gp_Ax2, gp_Dir, gp_Pnt
from OCP.STEPControl import STEPControl_AsIs, STEPControl_Writer

# Plate dimensions (mm)
PLATE_W, PLATE_D, PLATE_H = 2000.0, 300.0, 20.0
# Diameter of each hole (mm), spread out along X
DIAS = [4.0, 6.0, 8.0, 10.0, 14.0, 20.0, 30.0, 50.0]


def split_closed(shape, n):
    """Cut every closed edge (full circle) into n arcs, mimicking how common CAD systems export."""
    from OCP.ShapeUpgrade import ShapeUpgrade_ShapeDivideClosed

    sd = ShapeUpgrade_ShapeDivideClosed(shape)
    sd.SetNbSplitPoints(n)
    sd.Perform()
    return sd.Result()


def main() -> int:
    args = sys.argv[1:]
    out = args[0] if args else "holeplate.step"
    nsplit = 0
    if "--split" in args:
        nsplit = int(args[args.index("--split") + 1])

    shape = BRepPrimAPI_MakeBox(gp_Pnt(0, 0, 0), PLATE_W, PLATE_D, PLATE_H).Shape()
    x = 200.0
    for d in DIAS:
        # The cylinder goes through along +Z; the start is sunk 1 mm to guarantee a clean cut
        ax = gp_Ax2(gp_Pnt(x, PLATE_D / 2.0, -1.0), gp_Dir(0, 0, 1))
        cyl = BRepPrimAPI_MakeCylinder(ax, d / 2.0, PLATE_H + 2.0).Shape()
        cut = BRepAlgoAPI_Cut(shape, cyl)
        cut.Build()
        if not cut.IsDone():
            print("boolean cut failed: dia%g" % d)
            return 1
        shape = cut.Shape()
        x += 200.0

    if nsplit:
        shape = split_closed(shape, nsplit)

    w = STEPControl_Writer()
    w.Transfer(shape, STEPControl_AsIs)
    w.Write(out)
    print("wrote %s  hole diameters %s  closed-edge split %s"
          % (out, ", ".join("dia%g" % d for d in DIAS), "%d segments" % nsplit if nsplit else "none"))
    for i, d in enumerate(DIAS):
        print("  dia%-4g center x=%.1f  y=%.1f" % (d, 200.0 + i * 200.0, PLATE_D / 2.0))
    return 0


if __name__ == "__main__":
    sys.exit(main())
