#!/usr/bin/env bash
# Batch regression: convert a batch of STEP files and summarize success rate, face
# statistics and volume ratio.
# Usage: bash tools/e2e.sh <directory or file...>
#
# Note: in the local sandbox node cannot spawn a native exe (EBUSY) and /usr/bin/sort is
# disabled, so this is implemented in pure bash + awk with no dependency on sort.
#
# WARNING: never run this script with MSYS2_ARG_CONV_EXCL='*' exported.
# That variable turns off Git Bash path conversion, so the output path handed to the exe
# keeps the MSYS form /c/Users/..., and Go on Windows reads it as "\c\Users\... under the
# current drive root"; the GLB then lands in C:\c\Users\... and looking for $dest/*.glb
# here naturally finds nothing, so everything reports FAIL(no-glb) -- which looks like a
# conversion failure although the conversion was perfectly fine.
# If one script must both call the native tool (which needs that variable) and run this
# regression, split them into two commands.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EXE="${EXE:-$ROOT/stp2glb-lite.exe}"
OUT="${OUT:-$ROOT/out-e2e}"
TSV="$OUT/_result.tsv"
JOBS="${JOBS:-1}"

mkdir -p "$OUT"

# ---- collect files ----
# Prefer find; in some restricted environments find is unavailable, so fall back to bash
# globstar (bash 4+).
FILES="$OUT/_files.txt"
: > "$FILES"

collect_dir() {
  local d="$1" f
  if find "$d" -type f \( -iname '*.stp' -o -iname '*.step' \) 2>/dev/null >> "$FILES"; then
    return
  fi
  shopt -s nullglob nocaseglob globstar
  for f in "$d"/**/*.stp "$d"/**/*.step; do
    [ -f "$f" ] && printf '%s\n' "$f" >> "$FILES"
  done
  shopt -u nullglob nocaseglob globstar
}

for t in "$@"; do
  if [ -d "$t" ]; then
    collect_dir "$t"
  elif [ -f "$t" ]; then
    printf '%s\n' "$t" >> "$FILES"
  fi
done
TOTAL=$(wc -l < "$FILES" | tr -d ' ')
if [ "$TOTAL" = "0" ]; then echo "no STEP files found"; exit 2; fi
echo "$TOTAL files in total, output to $OUT"
echo

: > "$TSV"
i=0
while IFS= read -r f; do
  i=$((i + 1))
  name="$(basename "$f")"
  stp_size=$(stat -c %s "$f" 2>/dev/null || echo 0)
  safe=$(printf '%s' "$f" | sed 's/[^A-Za-z0-9]/_/g' | tail -c 40)
  dest="$OUT/${i}_${safe}"
  mkdir -p "$dest"

  t0=$(date +%s%N)
  log="$("$EXE" "$f" "$dest" --log-dir "$dest/logs" 2>&1)"
  code=$?
  t1=$(date +%s%N)
  wall=$(( (t1 - t0) / 1000000 ))
  # Trust the elapsed time the program reports itself: outer timing fluctuates a lot
  # because of antivirus/disk sync interference
  inner=$(printf '%s\n' "$log" | sed -n 's/.*Elapsed *: *\([0-9.]*\)s.*/\1/p' | head -1)
  if [ -n "$inner" ]; then
    ms=$(awk -v s="$inner" 'BEGIN{printf "%d", s*1000}')
  else
    ms=$wall
  fi

  glb=""
  for g in "$dest"/*.glb; do [ -f "$g" ] && glb="$g"; done
  glb_size=0
  [ -n "$glb" ] && glb_size=$(stat -c %s "$glb")

  # Every pattern below reads the "Conversion result" block printed at the end of a
  # successful run, e.g.
  #     Faces    : ok 53 / failed 0 / degraded 0 (total 53)
  #     Triangles: 930
  #     Ratio    : 10.3%  (well below the source file)
  # sed is case sensitive, so "Faces" must stay capitalised; the label is padded to a
  # fixed width with spaces, hence the " *" between the label and the colon.
  faces=$(printf '%s\n' "$log" | sed -n 's/.*Faces *: *ok [0-9,]* \/ failed [0-9,]* \/ degraded [0-9,]* (total \([0-9,]*\)).*/\1/p' | tr -d ',')
  ok=$(printf '%s\n' "$log" | sed -n 's/.*Faces *: *ok \([0-9,]*\) \/ failed.*/\1/p' | tr -d ',')
  bad=$(printf '%s\n' "$log" | sed -n 's/.*Faces *: *ok [0-9,]* \/ failed \([0-9,]*\).*/\1/p' | tr -d ',')
  deg=$(printf '%s\n' "$log" | sed -n 's/.*Faces *: *ok [0-9,]* \/ failed [0-9,]* \/ degraded \([0-9,]*\).*/\1/p' | tr -d ',')
  tris=$(printf '%s\n' "$log" | sed -n 's/.*Triangles *: *\([0-9,]*\).*/\1/p' | tr -d ',')
  ratio=$(printf '%s\n' "$log" | sed -n 's/.*Ratio *: *\([0-9.]*\)%.*/\1/p')
  reason=$(printf '%s\n' "$log" | sed -n 's/.*degraded\/failed reasons: //p' | head -1)
  err=$(printf '%s\n' "$log" | sed -n 's/.*\[error\] //p' | head -1)

  status=OK
  [ "$code" != "0" ] && status="FAIL(code=$code)"
  [ "$glb_size" = "0" ] && status="FAIL(no-glb)"

  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$i" "$status" "$ms" "$stp_size" "$glb_size" \
    "${faces:-0}" "${ok:-0}" "${bad:-0}" "${deg:-0}" "${tris:-0}" "${ratio:-0}" >> "$TSV"
  printf '%s\t%s\t%s\n' "$name" "${reason:-}" "${err:-}" >> "$OUT/_detail.tsv"

  printf '[%3d/%3d] %-14s %6dms faces %s/%s/%s tris %s volume %s%%  %s\n' \
    "$i" "$TOTAL" "$status" "$ms" "${ok:-?}" "${bad:-?}" "${deg:-?}" "${tris:-?}" "${ratio:-?}" "$name"
  if [ "${deg:-0}" != "0" ] || [ "${bad:-0}" != "0" ]; then
    printf '        -> %s\n' "${reason:-}"
  fi
  if [ "$status" != "OK" ]; then
    printf '        -> %s\n' "${err:-}"
    printf '%s\n' "$log" | tail -12 | sed 's/^/          | /'
  fi
done < "$FILES"

# ---- summary ----
printf '\n'
awk -F'\t' '
  { n++; if ($2=="OK") ok++; else { bad++; badname=badname "\n  " $2 "  " } 
    stp+=$4; glb+=$5; tris+=$10
    if ($2=="OK" && $9>0) deg++
    if ($2=="OK" && $11>=100) big++
    if ($2=="OK" && $11+0>maxr && $11!="-" ) { } }
  END {
    printf "==============================================================================\n"
    printf "ok %d/%d    failed %d    faces degraded %d    GLB not smaller %d\n", ok, n, bad, deg, big
    if (stp>0) printf "overall volume ratio %.1f%%  (%.1f MB -> %.1f MB)   triangles total %s\n", glb/stp*100, stp/1048576, glb/1048576, tris
  }
' "$TSV"

# Failure details
awk -F'\t' '$2!="OK"{c++} END{if(c>0) printf "\n%d failed (see the log above)\n", c}' "$TSV"

# Degradation details
degcnt=$(awk -F'\t' '$2=="OK" && $9>0' "$TSV" | wc -l | tr -d ' ')
if [ "$degcnt" != "0" ]; then
  echo
  echo "--- with degraded faces (first 20) ---"
  paste "$TSV" "$OUT/_detail.tsv" | awk -F'\t' '$2=="OK" && $9>0 {print "  "$12"  degraded "$9"  reason "$13}' | head -20
fi

# Volume did not shrink
bigcnt=$(awk -F'\t' '$2=="OK" && $11>=100' "$TSV" | wc -l | tr -d ' ')
if [ "$bigcnt" != "0" ]; then
  echo
  echo "--- GLB not smaller than the source (first 20) ---"
  paste "$TSV" "$OUT/_detail.tsv" | awk -F'\t' '$2=="OK" && $11>=100 {print "  "$12"  "$11"%  STP "$4"  GLB "$5}' | head -20
fi

badcnt=$(awk -F'\t' '$2!="OK"' "$TSV" | wc -l | tr -d ' ')
[ "$badcnt" != "0" ] && exit 1
exit 0
