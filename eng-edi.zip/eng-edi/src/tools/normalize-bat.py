#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Normalize a .bat file to "GBK encoding + CRLF line endings", and change chcp 65001 to 936.

Usage: python tools/normalize-bat.py <file or directory...>
"""
import sys
from pathlib import Path


def normalize(raw: bytes) -> bytes:
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("gbk")
    # Unify line endings to CRLF: collapse everything to LF first, then expand, to avoid \r\r\n
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "\r\n")
    text = text.replace("chcp 65001", "chcp 936")
    return text.encode("gbk")


def main(argv):
    targets = []
    for a in argv:
        p = Path(a)
        if p.is_dir():
            targets.extend(sorted(p.rglob("*.bat")))
        elif p.is_file():
            targets.append(p)
    if not targets:
        print("no .bat files found")
        return 2
    changed = 0
    for p in targets:
        raw = p.read_bytes()
        out = normalize(raw)
        crlf = raw.count(b"\r\n")
        if out != raw:
            p.write_bytes(out)
            changed += 1
            print(f"normalized  {p.name}  (CRLF {crlf} -> {out.count(chr(13).encode()+chr(10).encode())})")
        else:
            print(f"unchanged  {p.name}  (already GBK + CRLF)")
    print(f"\n{len(targets)} files in total, {changed} changed")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
