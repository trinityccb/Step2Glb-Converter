#!/usr/bin/env python3
"""GLB viewer: parse + statistics + software rasterized image (standard library only,
no third-party dependencies).

Usage:
  python tools/glb-view.py model.glb [out.png] [--size 700]

Its purpose is visual verification before delivery: numbers like triangle count and
volume ratio can all be right while the model geometry is still wrong (whole patches
missing, flipped normals, parameter-domain misalignment, etc.). Rendering an image that
can be compared directly with the human eye is the only reliable way to catch these.
"""
import json
import math
import struct
import sys
import zlib


def read_glb(path):
    with open(path, "rb") as f:
        data = f.read()
    magic, ver, total = struct.unpack_from("<III", data, 0)
    assert magic == 0x46546C67, "not a GLB file"
    off, js, bin_ = 12, None, None
    while off < total:
        clen, ctype = struct.unpack_from("<II", data, off)
        chunk = data[off + 8: off + 8 + clen]
        if ctype == 0x4E4F534A:
            js = json.loads(chunk.decode("utf-8"))
        elif ctype == 0x004E4942:
            bin_ = chunk
        off += 8 + clen + ((4 - clen % 4) % 4 if clen % 4 else 0)
    return js, bin_, len(data)


COMP = {5120: ("b", 1), 5121: ("B", 1), 5122: ("h", 2),
        5123: ("H", 2), 5125: ("I", 4), 5126: ("f", 4)}
NCOMP = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


def read_accessor(g, bin_, idx):
    acc = g["accessors"][idx]
    fmt, size = COMP[acc["componentType"]]
    n = NCOMP[acc["type"]]
    count = acc["count"]
    out = []
    if "bufferView" not in acc:
        return [0.0] * (count * n)
    bv = g["bufferViews"][acc["bufferView"]]
    base = bv.get("byteOffset", 0) + acc.get("byteOffset", 0)
    stride = bv.get("byteStride") or size * n
    for i in range(count):
        o = base + i * stride
        out.extend(struct.unpack_from("<" + fmt * n, bin_, o))
    return out


def mat_mul(a, b):
    """a . b (apply b first, then a), 4x4 row-major."""
    r = [0.0] * 16
    for i in range(4):
        for j in range(4):
            r[i * 4 + j] = sum(a[i * 4 + k] * b[k * 4 + j] for k in range(4))
    return r


def node_mat(nd):
    """Return the node's local matrix (glTF matrix is column-major; converted to row-major here)."""
    if "matrix" in nd:
        c = nd["matrix"]
        return [c[0], c[4], c[8], c[12],
                c[1], c[5], c[9], c[13],
                c[2], c[6], c[10], c[14],
                c[3], c[7], c[11], c[15]]
    t = nd.get("translation", [0, 0, 0])
    x, y, z, w = nd.get("rotation", [0, 0, 0, 1])
    s = nd.get("scale", [1, 1, 1])
    rm = [
        1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w), 0,
        2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w), 0,
        2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y), 0,
        0, 0, 0, 1,
    ]
    for row in range(3):
        for col in range(3):
            rm[row * 4 + col] *= s[col]
    rm[3], rm[7], rm[11] = t[0], t[1], t[2]
    return rm


def xform_pt(m, x, y, z):
    return (m[0] * x + m[1] * y + m[2] * z + m[3],
            m[4] * x + m[5] * y + m[6] * z + m[7],
            m[8] * x + m[9] * y + m[10] * z + m[11])


def load_mesh(path):
    """Load all meshes, **including the node hierarchy transforms**.

    This step is essential: implementations such as occt-import-js store the assembly pose
    in node.matrix and the vertices themselves are local coordinates. Ignoring the
    transform yields a wrong model with completely different dimensions.

    mode=1 (LINES, outlines are emitted since v1.8.0) primitives **must be handled
    separately**: reading indices three at a time as triangles produces a pile of garbage
    triangles.
    """
    g, bin_, nbytes = read_glb(path)
    tris, verts, segs = [], [], []
    nodes = g.get("nodes", [])
    meshes = g.get("meshes", [])
    scene = g.get("scenes", [{}])[g.get("scene", 0)]

    def emit(mesh_idx, m):
        mesh = meshes[mesh_idx]
        for prim in mesh.get("primitives", []):
            mode = prim.get("mode", 4)
            pos = read_accessor(g, bin_, prim["attributes"]["POSITION"])
            idx = read_accessor(g, bin_, prim["indices"]) if "indices" in prim else \
                list(range(len(pos) // 3))
            base = len(verts) // 3
            for i in range(0, len(pos) - 2, 3):
                verts.extend(xform_pt(m, pos[i], pos[i + 1], pos[i + 2]))
            if mode == 1:
                for i in range(0, len(idx) - 1, 2):
                    segs.append((idx[i] + base, idx[i + 1] + base))
            elif mode == 4:
                for i in range(0, len(idx) - 2, 3):
                    tris.append((idx[i] + base, idx[i + 1] + base, idx[i + 2] + base))

    def visit(ni, parent_m):
        nd = nodes[ni]
        m = mat_mul(parent_m, node_mat(nd))
        if "mesh" in nd:
            emit(nd["mesh"], m)
        for c in nd.get("children", []):
            visit(c, m)

    ident = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    roots = scene.get("nodes", list(range(len(nodes)))) if nodes else []
    for ni in roots:
        visit(ni, ident)
    return g, verts, tris, segs, nbytes


def stats(verts, tris, nbytes):
    mn = [math.inf] * 3
    mx = [-math.inf] * 3
    for i in range(0, len(verts), 3):
        for k in range(3):
            v = verts[i + k]
            if v < mn[k]:
                mn[k] = v
            if v > mx[k]:
                mx[k] = v
    area, deg = 0.0, 0
    vol = 0.0
    edges = {}
    for a, b, c in tris:
        ax, ay, az = verts[a * 3:a * 3 + 3]
        bx, by, bz = verts[b * 3:b * 3 + 3]
        cx, cy, cz = verts[c * 3:c * 3 + 3]
        ux, uy, uz = bx - ax, by - ay, bz - az
        vx, vy, vz = cx - ax, cy - ay, cz - az
        nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
        l = math.sqrt(nx * nx + ny * ny + nz * nz)
        if l < 1e-12:
            deg += 1
            continue
        area += 0.5 * l
        # Sum of signed tetrahedron volumes (equals the solid volume for a closed shell,
        # invariant under rigid transforms)
        vol += (ax * (by * cz - bz * cy) - ay * (bx * cz - bz * cx) +
                az * (bx * cy - by * cx)) / 6.0
        for p, q in ((a, b), (b, c), (c, a)):
            px, py, pz = verts[p * 3:p * 3 + 3]
            qx, qy, qz = verts[q * 3:q * 3 + 3]
            keys = tuple(sorted([(round(px, 6), round(py, 6), round(pz, 6)),
                                 (round(qx, 6), round(qy, 6), round(qz, 6))]))
            edges[keys] = True
    # Edge length distribution: like volume, a rigid-transform invariant, so it can be
    # compared directly across implementations
    lens = []
    for (p, q) in edges:
        d = math.dist(p, q)
        if d > 1e-9:
            lens.append(d)
    lens.sort()
    n = len(lens)
    med = lens[n // 2] if n else 0.0
    return mn, mx, area, deg, vol, (n, med)





def render(verts, tris, size, out_png, views=4, views_dirs=None, frame=None,
           segs=None, draw_lines=True, cull=True):
    mn = [math.inf] * 3
    mx = [-math.inf] * 3
    for i in range(0, len(verts), 3):
        for k in range(3):
            v = verts[i + k]
            mn[k] = min(mn[k], v)
            mx[k] = max(mx[k], v)
    if frame:
        # --frame x0,y0,z0,x1,y1,z1: force the camera framing.
        # It is mandatory for A/B comparison images, otherwise the camera adapts to "each
        # model's own bounding box" and two images with different content extents come out
        # scaled/off-center, looking as if the geometry changed.
        mn = [min(frame[0], frame[3]), min(frame[1], frame[4]), min(frame[2], frame[5])]
        mx = [max(frame[0], frame[3]), max(frame[1], frame[4]), max(frame[2], frame[5])]
    ctr = [(mn[k] + mx[k]) / 2 for k in range(3)]
    ext = max(mx[k] - mn[k] for k in range(3)) or 1.0
    scale = ext * 1.15

    # Four views: isometric, front, top, right
    dirs = views_dirs or [(1, -1, 0.8), (0, -1, 0.05), (0.05, -0.05, -1), (1, 0.05, 0.05)]
    cols = 2
    rows = (views + cols - 1) // cols
    W = size * cols
    H = size * rows
    img = bytearray(b"\x20" * (W * H * 3))

    up_ref = (0, 0, 1)
    for vi in range(views):
        d = dirs[vi % len(dirs)]
        dl = math.sqrt(sum(c * c for c in d)) or 1
        fw = tuple(c / dl for c in d)          # camera direction (from outside towards the model)
        up = up_ref
        if abs(fw[2]) > 0.95:
            up = (0, 1, 0)
        rx = (fw[1] * up[2] - fw[2] * up[1],
              fw[2] * up[0] - fw[0] * up[2],
              fw[0] * up[1] - fw[1] * up[0])
        rl = math.sqrt(sum(c * c for c in rx)) or 1
        rx = tuple(c / rl for c in rx)
        ry = (rx[1] * fw[2] - rx[2] * fw[1],
              rx[2] * fw[0] - rx[0] * fw[2],
              rx[0] * fw[1] - rx[1] * fw[0])

        ox = (vi % cols) * size
        oy = (vi // cols) * size
        zbuf = [math.inf] * (size * size)
        # 45 degree perspective, same frustum as the original code
        focal = size / (2 * math.tan(math.radians(22.5)))
        cam_dist = scale * 1.6
        light = (0.4, -0.5, 0.76)

        def project(p):
            x = p[0] - ctr[0]
            y = p[1] - ctr[1]
            z = p[2] - ctr[2]
            cx = x * rx[0] + y * rx[1] + z * rx[2]
            cy = x * ry[0] + y * ry[1] + z * ry[2]
            cz = x * fw[0] + y * fw[1] + z * fw[2] + cam_dist
            if cz <= 1e-6:
                return None
            return (cx / cz * focal + size / 2, cy / cz * focal + size / 2, cz)

        for a, b, c in tris:
            pa = project(verts[a * 3:a * 3 + 3])
            pb = project(verts[b * 3:b * 3 + 3])
            pc = project(verts[c * 3:c * 3 + 3])
            if not pa or not pb or not pc:
                continue
            # Backface culling
            area = (pb[0] - pa[0]) * (pc[1] - pa[1]) - (pc[0] - pa[0]) * (pb[1] - pa[1])
            if cull and area >= 0:
                continue
            if area == 0:
                continue
            minx = max(0, int(min(pa[0], pb[0], pc[0])))
            maxx = min(size - 1, int(max(pa[0], pb[0], pc[0])) + 1)
            miny = max(0, int(min(pa[1], pb[1], pc[1])))
            maxy = min(size - 1, int(max(pa[1], pb[1], pc[1])) + 1)
            if minx > maxx or miny > maxy:
                continue
            ax, ay, az = verts[a * 3:a * 3 + 3]
            bx, by, bz = verts[b * 3:b * 3 + 3]
            cx2, cy2, cz2 = verts[c * 3:c * 3 + 3]
            ux, uy, uz = bx - ax, by - ay, bz - az
            vx, vy, vz = cx2 - ax, cy2 - ay, cz2 - az
            nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
            nl = math.sqrt(nx * nx + ny * ny + nz * nz) or 1
            nx, ny, nz = nx / nl, ny / nl, nz / nl
            lam = abs(nx * light[0] + ny * light[1] + nz * light[2])
            sh = 40 + 195 * (0.35 + 0.65 * lam)
            col = (int(sh), int(sh * 0.97), int(sh * 0.9))
            d = area
            for py in range(miny, maxy + 1):
                for px in range(minx, maxx + 1):
                    w0 = ((pb[0] - pa[0]) * (py + 0.5 - pa[1]) -
                          (py * 0 + pb[1] - pa[1]) * (px + 0.5 - pa[0]))
                    w0 = ((pb[0] - pa[0]) * (py + 0.5 - pa[1]) -
                          (pb[1] - pa[1]) * (px + 0.5 - pa[0]))
                    w1 = ((pc[0] - pb[0]) * (py + 0.5 - pb[1]) -
                          (pc[1] - pb[1]) * (px + 0.5 - pb[0]))
                    w2 = ((pa[0] - pc[0]) * (py + 0.5 - pc[1]) -
                          (pa[1] - pc[1]) * (px + 0.5 - pc[0]))
                    if cull:
                        if not (w0 <= 0 and w1 <= 0 and w2 <= 0):
                            continue
                    else:
                        if not ((w0 <= 0 and w1 <= 0 and w2 <= 0) or
                                (w0 >= 0 and w1 >= 0 and w2 >= 0)):
                            continue
                    if d == 0:
                        continue
                    l0, l1, l2 = w1 / d, w2 / d, w0 / d
                    z = pa[2] * l0 + pb[2] * l1 + pc[2] * l2
                    o = py * size + px
                    if z < zbuf[o]:
                        zbuf[o] = z
                        o3 = ((oy + py) * W + ox + px) * 3
                        img[o3] = col[0]
                        img[o3 + 1] = col[1]
                        img[o3 + 2] = col[2]

        # Outline (LINES): project, then draw point by point with DDA, sharing the same
        # z-buffer as the triangles. z gets a tiny forward bias -- the lines sit right on
        # the surface, so with exactly equal depth they z-fight with the triangles, half
        # the pixels get eaten and it looks like a dashed line.
        if draw_lines and segs:
            bias = 1.0 - 1e-3
            for a, b in segs:
                pa = project(verts[a * 3:a * 3 + 3])
                pb = project(verts[b * 3:b * 3 + 3])
                if not pa or not pb:
                    continue
                x0, y0, z0 = pa
                x1, y1, z1 = pb
                dx, dy = x1 - x0, y1 - y0
                n = int(max(abs(dx), abs(dy))) + 1
                if n < 1:
                    n = 1
                if n > size * 4:
                    n = size * 4
                for s in range(n + 1):
                    t = s / n
                    px = int(x0 + dx * t)
                    py = int(y0 + dy * t)
                    if px < 0 or py < 0 or px >= size or py >= size:
                        continue
                    z = (z0 + (z1 - z0) * t) * bias
                    o = py * size + px
                    if z < zbuf[o]:
                        zbuf[o] = z
                        o3 = ((oy + py) * W + ox + px) * 3
                        img[o3] = 26
                        img[o3 + 1] = 26
                        img[o3 + 2] = 34

    # Panel separator lines
    for vi in range(1, views):
        if vi % cols:
            x = vi % cols * size
            for y in range(H):
                o = (y * W + x) * 3
                img[o:o + 3] = b"\x60\x60\x60"
        else:
            y = vi // cols * size
            for x in range(W):
                o = (y * W + x) * 3
                img[o:o + 3] = b"\x60\x60\x60"

    raw = b"".join(b"\x00" + bytes(img[y * W * 3:(y + 1) * W * 3]) for y in range(H))
    png = b"\x89PNG\r\n\x1a\n"
    for tag, payload in ((b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 2, 0, 0, 0)),
                         (b"IDAT", zlib.compress(raw, 6)),
                         (b"IEND", b"")):
        png += struct.pack(">I", len(payload)) + tag + payload + \
            struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF)
    with open(out_png, "wb") as f:
        f.write(png)
    return W, H


def filter_box(verts, tris, box, segs=None):
    """Crop the triangle subset by bounding box (keeping only triangles whose vertices all
    fall inside the box).

    Purpose: at full-machine scale, locating pins and support posts a few tens of
    millimeters across are only a few pixels in the four views, so the count cannot be
    judged visually. Cropping a small patch and rendering it on its own makes the count
    verifiable by eye.

    Outlines (segs) must be cropped by the same box too, otherwise the lines float in from
    outside the frame when zooming in. Segment vertices are independent of triangle
    vertices (in a GLB they are stored separately), so they must be appended at the end --
    the triangle indices must **not** be reused.
    """
    x0, y0, z0, x1, y1, z1 = box

    def inside(vi):
        x, y, z = verts[vi * 3:vi * 3 + 3]
        return x0 <= x <= x1 and y0 <= y <= y1 and z0 <= z <= z1

    used = {}
    nv = []
    out = []
    for t in tris:
        if not all(inside(vi) for vi in t):
            continue
        nt = []
        for vi in t:
            if vi not in used:
                used[vi] = len(used)
                nv.extend(verts[vi * 3:vi * 3 + 3])
            nt.append(used[vi])
        out.append(tuple(nt))

    osegs = []
    for a, b in (segs or []):
        if not (inside(a) and inside(b)):
            continue
        pair = []
        for vi in (a, b):
            if vi not in used:
                used[vi] = len(used)
                nv.extend(verts[vi * 3:vi * 3 + 3])
            pair.append(used[vi])
        osegs.append(tuple(pair))
    return nv, out, osegs


def main():
    args = [a for a in sys.argv[1:]]
    size = 700
    if "--size" in args:
        i = args.index("--size")
        size = int(args[i + 1])
        del args[i:i + 2]
    box = None
    if "--box" in args:
        i = args.index("--box")
        box = [float(v) for v in args[i + 1].split(",")]
        del args[i:i + 2]
    dirs = None
    if "--view" in args:
        i = args.index("--view")
        dirs = [[float(v) for v in d.split(",")] for d in args[i + 1].split(";")]
        del args[i:i + 2]
    frame = None
    if "--frame" in args:
        i = args.index("--frame")
        frame = [float(v) for v in args[i + 1].split(",")]
        del args[i:i + 2]
    draw_lines = "--no-lines" not in args
    if not draw_lines:
        args.remove("--no-lines")
    cull = "--no-cull" not in args
    if not cull:
        args.remove("--no-cull")
    src = args[0]
    out = args[1] if len(args) > 1 else src.rsplit(".", 1)[0] + ".png"
    g, verts, tris, segs, nbytes = load_mesh(src)
    if box:
        verts, tris, segs = filter_box(verts, tris, box, segs)
        print(f"  crop {box} -> triangles {len(tris):,}  outline segments {len(segs):,}")
        if not tris:
            print("  no triangles left after cropping, check the --box argument")
            return
    mn, mx, area, deg, vol, (ne, med) = stats(verts, tris, nbytes)
    dim = sorted(mx[k] - mn[k] for k in range(3))
    print(f"{src}")
    print(f"  file {nbytes/1048576:.2f} MB  triangles {len(tris):,}  vertices {len(verts)//3:,}  degenerate {deg}"
          f"  outline segments {len(segs):,}")
    print(f"  bounding box size (sorted) {dim[0]:.3f} x {dim[1]:.3f} x {dim[2]:.3f}")
    print(f"  surface area {area:.4f}   volume {abs(vol):.4f}")
    print(f"  unique edges {ne:,}  median edge length {med:.4f}")
    w, h = render(verts, tris, size, out, views=len(dirs) if dirs else 4,
                  views_dirs=dirs, frame=frame, segs=segs, draw_lines=draw_lines,
                  cull=cull)
    print(f"  wrote image {out} ({w}x{h})")


if __name__ == "__main__":
    main()
