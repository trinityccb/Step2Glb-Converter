# -*- coding: utf-8 -*-
"""png-diff.py -- pure standard library PNG pixel comparison, used to quantify A/B visual
verification.

    python tools/png-diff.py a.png b.png [--out diff.png] [--thr 12]

Output: the non-background pixel counts of both images, the differing pixel count, the
difference bounding box, and optionally a saved difference image (differing pixels in red,
everything else dimmed). Only 8-bit RGB/RGBA non-interlaced PNGs are supported (which is
what this project produces).
"""
import struct
import sys
import zlib


def read_png(path):
    data = open(path, 'rb').read()
    if data[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('not a PNG: ' + path)
    pos = 8
    w = h = ct = None
    idat = bytearray()
    while pos < len(data):
        ln, = struct.unpack('>I', data[pos:pos + 4])
        typ = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        if typ == b'IHDR':
            w, h, bd, ct, comp, filt, il = struct.unpack('>IIBBBBB', body)
            if bd != 8 or il or ct not in (2, 6):
                raise ValueError('only 8-bit RGB/RGBA non-interlaced is supported')
        elif typ == b'IDAT':
            idat += body
        elif typ == b'IEND':
            break
    nch = 4 if ct == 6 else 3
    raw = zlib.decompress(bytes(idat))
    stride = w * nch
    out = bytearray(w * h * 3)
    prev = bytearray(stride)
    p = 0
    for y in range(h):
        f = raw[p]
        p += 1
        cur = bytearray(raw[p:p + stride])
        p += stride
        if f == 1:
            for i in range(nch, stride):
                cur[i] = (cur[i] + cur[i - nch]) & 0xFF
        elif f == 2:
            for i in range(stride):
                cur[i] = (cur[i] + prev[i]) & 0xFF
        elif f == 3:
            for i in range(stride):
                a = cur[i - nch] if i >= nch else 0
                cur[i] = (cur[i] + ((a + prev[i]) >> 1)) & 0xFF
        elif f == 4:
            for i in range(stride):
                a = cur[i - nch] if i >= nch else 0
                b = prev[i]
                c = prev[i - nch] if i >= nch else 0
                pp = a + b - c
                pa, pb, pc = abs(pp - a), abs(pp - b), abs(pp - c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                cur[i] = (cur[i] + pr) & 0xFF
        prev = cur
        o = y * w * 3
        for x in range(w):
            s = x * nch
            out[o + x * 3] = cur[s]
            out[o + x * 3 + 1] = cur[s + 1]
            out[o + x * 3 + 2] = cur[s + 2]
    return w, h, out


def write_png(path, w, h, pix):
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        raw += pix[y * w * 3:(y + 1) * w * 3]

    def chunk(typ, body):
        c = struct.pack('>I', len(body)) + typ + body
        return c + struct.pack('>I', zlib.crc32(typ + body) & 0xFFFFFFFF)

    png = b'\x89PNG\r\n\x1a\n'
    png += chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
    png += chunk(b'IDAT', zlib.compress(bytes(raw), 6))
    png += chunk(b'IEND', b'')
    open(path, 'wb').write(png)


def bg_count(w, h, pix, thr):
    """Number of non-background pixels (the background is the dark grey 0x20 family)."""
    n = 0
    for i in range(0, w * h * 3, 3):
        if pix[i] > 0x30 or pix[i + 1] > 0x30 or pix[i + 2] > 0x30:
            n += 1
    return n


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    out = None
    thr = 12
    for a in sys.argv[1:]:
        if a.startswith('--out='):
            out = a.split('=', 1)[1]
        elif a.startswith('--thr='):
            thr = int(a.split('=', 1)[1])
    wa, ha, pa = read_png(args[0])
    wb, hb, pb = read_png(args[1])
    if (wa, ha) != (wb, hb):
        print('size mismatch: %dx%d vs %dx%d' % (wa, ha, wb, hb))
        return
    na, nb = bg_count(wa, ha, pa, thr), bg_count(wa, ha, pb, thr)
    diff = bytearray(wa * ha * 3)
    nd = 0
    x0, y0, x1, y1 = wa, ha, -1, -1
    for y in range(ha):
        for x in range(wa):
            i = (y * wa + x) * 3
            d = max(abs(pa[i] - pb[i]), abs(pa[i + 1] - pb[i + 1]), abs(pa[i + 2] - pb[i + 2]))
            if d > thr:
                nd += 1
                diff[i], diff[i + 1], diff[i + 2] = 255, 40, 40
                if x < x0:
                    x0 = x
                if x > x1:
                    x1 = x
                if y < y0:
                    y0 = y
                if y > y1:
                    y1 = y
            else:
                v = (pa[i] + pa[i + 1] + pa[i + 2]) // 3 // 3
                diff[i] = diff[i + 1] = diff[i + 2] = v
    print('A non-background pixels %d    B non-background pixels %d' % (na, nb))
    print('differing pixels %d (%.2f%% of the frame)   bounding box (%d,%d)-(%d,%d)'
          % (nd, 100.0 * nd / (wa * ha), x0, y0, x1, y1))
    if out:
        write_png(out, wa, ha, diff)
        print('difference image ->', out)


if __name__ == '__main__':
    main()
