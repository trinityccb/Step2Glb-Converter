# -*- coding: utf-8 -*-
"""Compare two GLBs by "triangle multiset" -- better suited than a byte-wise cmp.

Tessellation in this project runs in parallel shards, so the write order and the
floating-point accumulation order vary with scheduling; even the same exe run twice
in a row produces different bytes (measured: a 469MB file differs at byte 885).
Therefore "zero side effects" has to be judged on the geometry itself:

  1. For each triangle, sort its three vertices and quantize them into a key
     (vertex coordinates rounded to --digits places).
  2. Compare the key multisets of both sides: how many were added / removed.
  3. Then compare triangle count / surface area / bounding box.

Usage:
  python cmpmesh.py a.glb b.glb [--digits 4] [--maxshow 10]
"""
import json
import struct
import sys


def read_glb(path):
    d = open(path, "rb").read()
    magic, ver, total = struct.unpack_from("<III", d, 0)
    assert magic == 0x46546C67, "not a GLB"
    off, js, bin_ = 12, None, None
    while off < total:
        clen, ctype = struct.unpack_from("<II", d, off)
        chunk = d[off + 8: off + 8 + clen]
        if ctype == 0x4E4F534A:
            js = json.loads(chunk.decode("utf-8"))
        elif ctype == 0x004E4942:
            bin_ = chunk
        off += 8 + clen + ((4 - clen % 4) % 4 if clen % 4 else 0)
    return js, bin_, d


CT = {5121: ("B", 1), 5123: ("H", 2), 5125: ("I", 4), 5126: ("f", 4)}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}


def acc(js, bin_, i):
    a = js["accessors"][i]
    fmt, sz = CT[a["componentType"]]
    n = NC[a["type"]]
    bv = js["bufferViews"][a["bufferView"]]
    base = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    stride = bv.get("byteStride") or n * sz
    out = []
    for k in range(a["count"]):
        o = base + k * stride
        out.append(struct.unpack_from("<" + fmt * n, bin_, o))
    return out


def mesh(path, digits):
    js, bin_, raw = read_glb(path)
    verts, tris = [], []
    for m in js["meshes"]:
        for p in m["primitives"]:
            v = acc(js, bin_, p["attributes"]["POSITION"])
            base = len(verts)
            verts.extend(v)
            idx = acc(js, bin_, p["indices"])
            idx = [t[0] for t in idx]
            for k in range(0, len(idx), 3):
                tris.append((base + idx[k], base + idx[k + 1], base + idx[k + 2]))
    q = float(10 ** digits)
    keys = []
    for (a, b, c) in tris:
        pts = []
        for vi in (a, b, c):
            x, y, z = verts[vi]
            pts.append((round(x * q), round(y * q), round(z * q)))
        pts.sort()
        keys.append((pts[0], pts[1], pts[2]))
    return keys, verts, tris, len(raw)


def area(m):
    keys, verts, tris, nb = m
    s = 0.0
    for (a, b, c) in tris:
        ax, ay, az = verts[a]
        bx, by, bz = verts[b]
        cx, cy, cz = verts[c]
        ux, uy, uz = bx - ax, by - ay, bz - az
        vx, vy, vz = cx - ax, cy - ay, cz - az
        nx = uy * vz - uz * vy
        ny = uz * vx - ux * vz
        nz = ux * vy - uy * vx
        s += 0.5 * (nx * nx + ny * ny + nz * nz) ** 0.5
    return s


def bbox(m):
    _, verts, _, _ = m
    mn = [min(v[i] for v in verts) for i in range(3)]
    mx = [max(v[i] for v in verts) for i in range(3)]
    return mn, mx


def main():
    args = sys.argv[1:]
    digits = 4
    if "--digits" in args:
        i = args.index("--digits")
        digits = int(args[i + 1])
        del args[i:i + 2]
    maxshow = 10
    if "--maxshow" in args:
        i = args.index("--maxshow")
        maxshow = int(args[i + 1])
        del args[i:i + 2]
    a, b = args[0], args[1]
    ma, mb = mesh(a, digits), mesh(b, digits)
    print("%s  %d tris  %.2f MB" % (a, len(ma[2]), ma[3] / 1048576))
    print("%s  %d tris  %.2f MB" % (b, len(mb[2]), mb[3] / 1048576))
    print("")
    ba, bb = bbox(ma), bbox(mb)
    print("bbox A (%s) ~ (%s)" % (",".join("%.4f" % v for v in ba[0]), ",".join("%.4f" % v for v in ba[1])))
    print("bbox B (%s) ~ (%s)" % (",".join("%.4f" % v for v in bb[0]), ",".join("%.4f" % v for v in bb[1])))
    sa, sb = area(ma), area(mb)
    print("surface area A %.4f   B %.4f   diff %+.6f%%" % (sa, sb, (sb - sa) / sa * 100 if sa else 0))
    print("")

    from collections import Counter
    ca, cb = Counter(ma[0]), Counter(mb[0])
    onlyA = ca - cb
    onlyB = cb - ca
    na, nb = sum(onlyA.values()), sum(onlyB.values())
    print("triangle multiset difference (quantized to %d decimal places): only in A %d, only in B %d, net %+d"
          % (digits, na, nb, nb - na))
    if na or nb:
        print("  samples only in A (first %d):" % maxshow)
        for k, c in list(onlyA.items())[:maxshow]:
            print("    x%d  %s" % (c, k))
        print("  samples only in B (first %d):" % maxshow)
        for k, c in list(onlyB.items())[:maxshow]:
            print("    x%d  %s" % (c, k))
    else:
        print("  * triangle sets are identical")


main()
