@echo off
chcp 65001 >nul
setlocal
set "EXE=%~dp0stp2glb-lite.exe"

if not exist "%EXE%" (
  echo [error] Converter not found. This file must sit in the same folder as stp2glb-lite.exe
  echo.
  pause
  exit /b 1
)

if "%~1"=="" (
  echo.
  echo   Usage: drop .stp / .step files onto this file to convert them.
  echo   Several files at once are fine.
  echo.
  echo   Output goes to a glb_output folder next to each source file.
  echo.
  pause
  exit /b 0
)

set /a n=0
set /a bad=0

:loop
if "%~1"=="" goto done
set /a n+=1
echo.
echo ------------------------------------------------------------
echo   [%n%] %~nx1
echo ------------------------------------------------------------
"%EXE%" "%~f1" "%~dp1glb_output"
if errorlevel 1 set /a bad+=1
shift
goto loop

:done
echo.
echo ============================================================
echo   Finished: %n% file(s) processed, %bad% failed
echo   Output: a glb_output folder next to each source file
echo ============================================================
echo.
pause
